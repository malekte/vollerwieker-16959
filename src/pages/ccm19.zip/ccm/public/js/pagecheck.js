'use strict';

$(function () {

	function encodeUtf8(string) {
		var enc = encodeURIComponent(string);
		var result = [];
		for (var i = 0; i < enc.length;) {
			if (enc[i] === '%') {
				result.push(String.fromCharCode(parseInt(enc.substr(i+1, 2), 16)));
				i += 3
			} else {
				result.push(String.fromCharCode(enc.charCodeAt(i)));
				i += 1;
			}
		}
		return result.join('');
	}
	
	function urlsafeBase64(string) {
		var data = encodeUtf8(string);
		return btoa(data).replace(/\+/g, '-').replace(/\//g, '_');
	}

	$('.solve-button').on('click', function () {
		var button = this;
		var url = $(this).closest('[data-solve-url]').data('solveUrl').replace('B64NAME', urlsafeBase64(this.getAttribute('data-name'))).replace('NAME', encodeURIComponent(encodeURIComponent(this.getAttribute('data-name'))));
		var $row = $(this).closest('tr');

		// Button deaktivieren
		button.disabled = true;

		// Request starten
		$.ajax(url, {
			dataType: 'json',
			method: 'DELETE'
		}).done(function (data) {
			$row.fadeOut({
				complete: function () {
					$row.remove();
				}
			})
		}).fail(function (xhr) {
			alert(xhr.responseJSON.message);
		}).always(function () {
			button.disabled = false;
		});

	});

	$('#clear-all').on('click', function () {
		return confirm(this.getAttribute('data-confirm-msg'));
	});
	
	function fillPlaceholders($container, $source)
	{
		$container.find('[data-generated]').remove();
		$container.find('[data-placeholder]').removeClass('hidden').attr('aria-hidden', null);
		
		$container.find('[data-from]').each(function () {
			var $placeholder = $(this);
			var $src = $source.find(this.getAttribute('data-from'));
			if ($src.length == 0) {
				return;
			}
			if ($src[0].tagName.toUpperCase() == 'DATALIST') {
				var $children = $(this).children();
				$src.children('option').each(function () {
					var option = this;
					var $items = $children.clone(true);
					$items.attr('data-generated', '');
					$items.find('[data-from="option"]').each(function () {
						var text = option.value;
						var href = (option.hasAttribute('data-href') ? option.getAttribute('data-href') : text.trim());
						this.textContent = text;
						if (this.href !== undefined)  {
							this.href = href;
						}
						this.removeAttribute('data-from');
					});
					$items.appendTo($placeholder);
				});
				$children.attr('data-placeholder', '').addClass('hidden').attr('aria-hidden', 'true');
			}
			else {
				var text = ($src.prop('title')) ? $src.prop('title') : $src.text();
				var href = ($src.prop('href')) ? $src.prop('href') : text.trim();
				if (this.href !== undefined)  {
					this.href = href;
				}
				this.textContent = text;
			}
		});
	}
	
	$('.details-button').on('click', function () {
		var button = this;
		var $row = $(this).closest('tr');
		var $panel = $(this).closest('.panel');
		var $dialog = $($panel.attr('data-details-dialog'));

		fillPlaceholders($dialog, $row);
		
		$dialog.modal('show');

	});
	
});
