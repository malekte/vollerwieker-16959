'use strict';

/* TCFv2 API
 * https://github.com/InteractiveAdvertisingBureau/GDPR-Transparency-and-Consent-Framework/blob/master/TCFv2/IAB%20Tech%20Lab%20-%20CMP%20API%20v2.md
 */
/**
 * @typedef TCData
 * @type {object}
 * @property {string} tcString
 * @property {number} tcfPolicyVersion
 * @property {number} cmpId
 * @property {number} cmpVersion
 * @property {(boolean|undefined)} gdprApplies
 * @property {string} eventStatus
 * @property {string} cmpStatus
 * @property {(number|undefined)} listenerId
 * @property {boolean} isServiceSpecific
 * @property {boolean} useNonStandardStacks
 * @property {string} publisherCC
 * @property {boolean} purposeOneTreatment
 * @property {Object} outOfBand
 * @property {Object.<string,(boolean|undefined)>} outOfBand.allowedVendors
 * @property {Object.<string,(boolean|undefined)>} outOfBand.disclosedVendors
 * @property {Object} purpose
 * @property {Object.<string,(boolean|undefined)>} purpose.consents
 * @property {Object.<string,(boolean|undefined)>} purpose.legitimateInterests
 * @property {Object.<string,(boolean|undefined)>} vendor.consents
 * @property {Object.<string,(boolean|undefined)>} vendor.legitimateInterests
 * @property {Object.<string,(boolean|undefined)>} specialFeatureOptins
 * @property {Object} publisher
 * @property {Object.<string,(boolean|undefined)>} publisher.consents
 * @property {Object.<string,(boolean|undefined)>} publisher.legitimateInterests
 * @property {Object} publisher.customPurpose
 * @property {Object.<string,(boolean|undefined)>} publisher.customPurpose.consents
 * @property {Object.<string,(boolean|undefined)>} publisher.customPurpose.legitimateInterests
 * @property {Object.<string,Object.<String,number>>} publisher.restrictions
 */
/**
 * @typedef PingReturn
 * @type {object}
 * @property {(boolean|undefined)} gdprApplies
 * @property {boolean} cmpLoaded
 * @property {string} cmpStatus ('stub'/'loading'/'loaded'/'error')
 * @property {string} displayStatus ('visible'/'hidden'/'disabled')
 * @property {string} apiVersion
 * @property {(number|undefined)} cmpVersion
 * @property {(number|undefined)} cmpId
 * @property {(gvlVersion|undefined)} gvlVersion
 * @property {(tcfPolicyVersion|undefined)} tcfPolicyVersion
 */

/**
 * @param {string} command
 * @param {number} version
 * @param {function} callback
 * @param {*=} parameter
 */
/*
window.__tcfapi = function __tcfapi_ccm19 (command, version, callback, parameter) {
	console.error('[CCM19] TCFAPIv2 not yet implemented!');
	// TODO
}
 */
