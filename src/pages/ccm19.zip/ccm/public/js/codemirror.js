'use strict';

(function ($) {
	var $textareas = $('textarea[data-language]');
	var activeScripts = {};
	var basePath = $('script[src$="js/codemirror.js"]').prop('src').slice(0, -13);

	function requireScript(path, callback) {
		if (path in activeScripts) {
			activeScripts[path].addEventListener('load', callback);
			return;
		}
		var fullPath = basePath + path;
		var element = document.createElement('script');
		element.src = fullPath;
		document.body.appendChild(element);
		activeScripts[path] = element;
		if (callback) {
			element.addEventListener('load', callback);
		}
		return element;
	}

	if ($textareas.length) {
		requireScript('vendor/codemirror/lib/codemirror.custom.js', function () {
			$textareas.each(function () {
				var textarea = this;
				var style = getComputedStyle(textarea);
				var lang = this.getAttribute('data-language').replace(/[^a-zA-Z0-9.-]/g, '');
				var codeMirror = CodeMirror.fromTextArea(textarea, {
					mode: textarea.getAttribute('data-language'),
					viewportMargin: Infinity,
				});
				var container = codeMirror.display.wrapper;
				container.style.width = style.width;
				container.style.height = style.height;
				$(container).on('blur', codeMirror.save.bind(codeMirror));
				$(textarea).on('click', codeMirror.focus.bind(codeMirror));
				var handle = null;
				var observer = new MutationObserver(function(mutations) {
					if (handle === null) {
						handle = setTimeout(function () {
							codeMirror.refresh();
							handle = null;
						}, 100);
					}
				});
				observer.observe(container, { attributes: true });
			});
		});

	}


})(jQuery);