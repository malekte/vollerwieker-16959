'use strict';

$(function () {
	var csrf_token = $('meta[name="X-CSRF-Token"]').prop('content');
	var $updateButton = $('#do-update-now');
	var $downgradeButton = $('#do-downgrade-now');

	function onAutoUpdateToggleStateChanged() {
		var self = this;

		$.post($(this).closest('form').attr('action'), {
			'csrf_token': csrf_token,
			'enableAutoUpdate': this.checked,
		}, function (response) {
			if (response.success) {
				self.checked = response.newState;
			}
		}).always(function () {
			self.disabled = false;
		});

		this.disabled = true;
	}

	var autoUpdateToggle = document.getElementById('enableAutoUpdate');
	if (autoUpdateToggle) {
		autoUpdateToggle.addEventListener('change', onAutoUpdateToggleStateChanged);
	}

	// Konami-Code
	var $developer_container = $('.developer-options');
	if ($developer_container.length) {
		var konami_state = 0;
		document.body.addEventListener('keyup', function (evt) {
			if (konami_state == 0 && (evt.key == 'ArrowUp' || evt.key == 'Up')) {
				konami_state = 1;
			}
			else if (konami_state == 1 && (evt.key == 'ArrowUp' || evt.key == 'Up')) {
				konami_state = 2;
			}
			else if (konami_state == 2 && (evt.key == 'ArrowDown' || evt.key == 'Down')) {
				konami_state = 3;
			}
			else if (konami_state == 3 && (evt.key == 'ArrowDown' || evt.key == 'Down')) {
				konami_state = 4;
			}
			else if (konami_state == 4 && (evt.key == 'ArrowLeft' || evt.key == 'Left')) {
				konami_state = 5;
			}
			else if (konami_state == 5 && (evt.key == 'ArrowRight' || evt.key == 'Right')) {
				konami_state = 6;
			}
			else if (konami_state == 6 && (evt.key == 'ArrowLeft' || evt.key == 'Left')) {
				konami_state = 7;
			}
			else if (konami_state == 7 && (evt.key == 'ArrowRight' || evt.key == 'Right')) {
				konami_state = 8;
			}
			else if (konami_state == 8 && (evt.key.toLowerCase() == 'b')) {
				konami_state = 9;
			}
			else if (konami_state == 9 && (evt.key.toLowerCase() == 'a')) {
				$developer_container.removeClass('hidden');
				$developer_container.hide();
				$developer_container.fadeIn(600);
				konami_state = 0;
			}
			else {
				konami_state = 0;
			}
		}, true)
	}

	// Check for updates
	var $check_container = $('.update-check[data-url]');
	if (!$check_container.length) {
		return;
	}

	var url = $check_container.data('url');
	$check_container.find('.indication--wait').removeClass('hidden');
	$.ajax(url, {
		method: 'HEAD'
	}).done(function (data, error, xhr) {
		var result = 'error';
		if (xhr.status == 204) {
			if (xhr.getResponseHeader('X-Next-Gen-Available')) {
				result = 'next-gen-available';
			} else {
				result = 'is-latest';
			}

		} else if (xhr.status == 200) {
			result = 'available';
			var size = xhr.getResponseHeader('Content-Length');
			if (!size) {
				size = xhr.getResponseHeader('X-File-Size');
			}
			if (size <= 104858) {
				size = 104858;
			}
			$('#update-size').text((parseInt(size)/1024/1024).toLocaleString(undefined, {maximumFractionDigits:1}))
		}

		var $alert = $check_container.find('.indication--'+result);
		if (!$alert.length) {
			$alert = $check_container.find('.indication--error');
			console.log('unexpected response', data);
		}
		$alert.removeClass('hidden');
		$check_container.find('.indication--wait').addClass('hidden');

		if (result == 'is-latest' || result == 'next-gen-available') {
			$updateButton.prop('disabled', true);
		}

	}).fail(function (xhr, error, errorText) {
		$check_container.find('.indication--wait').addClass('hidden');
		$updateButton.prop('disabled', true);
		if (xhr.status == 403) {
			$check_container.find('.indication--no-license').removeClass('hidden');
			$downgradeButton.prop('disabled', true);
		}
		else {
			$check_container.find('.indication--error').removeClass('hidden');
			console.log('unexpected error:', error, errorText);
		}
	});

	// Start download
	var $progress = $('#update-progress');
	var downloadUrl = $updateButton.data('downloadUrl');
	var installUrl = $updateButton.data('installUrl');

	function resetProgress()
	{
		$progress.parent().removeClass('hidden');
		$progress.attr('aria-valuenow', '0');
		$progress.css('width', '0%');
		$progress.text('');
	}
	function setProgress(p, text)
	{
		$progress.parent().removeClass('hidden');
		$progress.attr('aria-valuenow', p);
		$progress.css('width', p+'%');
		$progress.text(text);
	}



	$updateButton.on('click', function () {
		performUpdate();
	});
	$downgradeButton.on('click', function () {
		$('#enableAutoUpdate').prop('checked', false);
		performUpdate($('#downgrade-version').prop('value'));
	});

	function performUpdate(versionId)
	{
		var downloadProgressHandle = null;
		var installProgressHandle = null;

		// Button deaktivieren
		$updateButton.prop('disabled', true);
		$downgradeButton.prop('disabled', true);

		// Progressbar zurücksetzen
		resetProgress();

		var postData = {'csrf_token': csrf_token};

		if (versionId) {
			postData.forceVersionId = versionId;
		}

		// Download starten
		$.ajax(downloadUrl, {
			dataType: 'json',
			method: 'POST',
			data: postData
		}).done(function (data) {
			var mb = (data.size/1000/1000).toLocaleString(undefined, {minimumFractionDigits:1, maximumSignificantDigits:3});
			var message = mb+' MB/'+mb+' MB';
			setProgress(50, message);

			// Installation starten
			setTimeout(doInstall, 1);
		}).fail(function (xhr) {
			alert(xhr.responseJSON.message);
			$updateButton.prop('disabled', false);
			$downgradeButton.prop('disabled', false);
		}).always(function () {
			if (downloadProgressHandle) {
				clearTimeout(downloadProgressHandle);
			}
			downloadProgressHandle = null;
		});

		/* Fortschrittsbalken aktalisieren */
		function checkDownloadProgress () {
			$.ajax('../update-progress-download.json', {
				dataType: 'json',
				cache: false
			}).done(function (data) {
				var mbCurrent = data.current/1000/1000;
				var mbTotal = data.total/1000/1000;
				var percent = (data.current/data.total * 100 / 2) | 0;
				var message = mbCurrent.toLocaleString(undefined, {minimumFractionDigits:1, maximumSignificantDigits:3}) +
					' MB/' + mbTotal.toLocaleString(undefined, {minimumFractionDigits:1, maximumSignificantDigits:3}) + ' MB';
				setProgress(percent, message);

			}).always(function () {
				if (downloadProgressHandle) {
					downloadProgressHandle = setTimeout(checkDownloadProgress, 500);
				}
			});
		}
		function checkInstallProgress () {
			$.ajax('../update-progress-extract.json', {
				dataType: 'json',
				cache: false
			}).done(function (data) {
				if (installProgressHandle) {
					var percent = 50 + ((data.current/data.total * 100 / 2) | 0);
					var message = data.current+'/'+data.total;
					setProgress(percent, message);
				}
			}).always(function () {
				if (installProgressHandle) {
					installProgressHandle = setTimeout(checkInstallProgress, 200);
				}
			});
		}
		downloadProgressHandle = setTimeout(checkDownloadProgress, 200);

		function updateInstallProgress(data)
		{
			var current = 0, total = data.total;
			if ('nextOffset' in data) {
				current = data.nextOffset;
			}
			else if ('done' in data && data.done) {
				current = total;
			}
			else {
				current = 0;
			}
			var percent = 50 + ((current/total * 49) | 0);
			var message = current+'/'+total;
			setProgress(percent, message);
		}

		function doInstall()
		{
			var token, total;
			// Nächste Dateien extrahieren
			function extractNext(offset)
			{
				var url = installUrl + token + '/' + offset;
				$.ajax(url, {
					dataType: 'json',
					method: 'POST',
					data: {'csrf_token': csrf_token}
				}).done(function (data) {
					updateInstallProgress(data);
					if (data.done) {
						finishInstallation();
					} else {
						extractNext(data.nextOffset);
					}
				}).fail(function (xhr) {
					alert(xhr.responseJSON.message);
					$updateButton.prop('disabled', false);
					$downgradeButton.prop('disabled', false);
				});
			}

			// Abschluss der Installation
			function finishInstallation()
			{
				var url;

				function reloadAfterFinish()
				{
					$.ajax(url, {
						method: 'GET'
					}).done(function () {
						setTimeout(location.reload.bind(location), 100);
						$updateButton.prop('disabled', false);
						$downgradeButton.prop('disabled', false);
					}).fail(function (xhr) {
						if (xhr.status == 500) {
							setTimeout(reloadAfterFinish, 300);
						} else {
							setTimeout(location.reload.bind(location), 100);
							$updateButton.prop('disabled', false);
							$downgradeButton.prop('disabled', false);
						}
					});
				}

				url = installUrl + token + '/finish';
				$.ajax(url, {
					dataType: 'json',
					method: 'POST',
					data: {'csrf_token': csrf_token}
				}).done(function(data){
					setTimeout(function () { setProgress(100, data.message); }, 500);
				}).always(function () {
					// Weitere Abfragen zum Regenerieren des geleerten Caches
					// und dann Page-Reload.
					setTimeout(reloadAfterFinish, 300);
				});
			}

			// Extrahieren beginnen
			$.ajax(installUrl, {
				dataType: 'json',
				method: 'POST',
				data: {'csrf_token': csrf_token}
			}).done(function (data) {
				token = data.token;
				total = data.total;
				updateInstallProgress(data);
				extractNext(0);
			}).fail(function (xhr) {
				alert(xhr.responseJSON.message);
				$updateButton.prop('disabled', false);
				$downgradeButton.prop('disabled', false);
			});

		}
	}
});

