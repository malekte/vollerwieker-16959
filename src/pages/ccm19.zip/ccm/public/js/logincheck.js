'use strict';

(function () {
	var defaultTimeout = 180000;
	var channel = null;
	var handle = null;
	var modalVisible = false;
	var wasHidden = false;

	// Inter-Tab-Kommunikationskanal aufbauen
	if ('BroadcastChannel' in window) {
		channel = new BroadcastChannel('ccm19.backend.auth.state');

		channel.addEventListener('message', function (event) {
			var message = (event.data || {});
			if (message.type == 'heartbeat') {
				onHeartbeat(message);
			}
			else if (message.type == 'logout') {
				planLoginCheck(1750);
			}
			else if (message.type == 'login') {
				planLoginCheck(2000);
			}
		});

		// Bei Klick auf Login-/Logout-Buttons andere Tabs informieren
		$('.logout-button').on('click', function () {
			channel.postMessage({'type':'logout'});
		});
		$('.login-button').on('click', function () {
			channel.postMessage({'type':'login'});
		});
	}

	// Check-URL und erwarteten Benutzernamen auslesen
	var url = document.querySelector('head link[rel="x-logincheck-url"]').href;
	var username = document.querySelector('head meta[name="X-Username"]').content;

	function doLoginCheck () {
		$.ajax(url, { dataType: 'json' }).done(function (data) {
			if (channel) {
				data.type = 'heartbeat';
				channel.postMessage(data);
			}
			onHeartbeat(data);
		}).fail(function (xhr, status, error) {
			planLoginCheck(defaultTimeout);
		});
	}

	function planLoginCheck(timeout) {
		var timeout = timeout + (Math.random()*(timeout/4)-(timeout/8));
		if (handle) {
			window.clearTimeout(handle);
			handle = null;
		}
		handle = window.setTimeout(doLoginCheck, timeout);
	}

	// Dialog anzeigen/verstecken
	function onHeartbeat(data)
	{
		if (modalVisible) {
			if (username === data.user) {
				$('#modal-session-expired').modal('hide');
				modalVisible = false;
			}
		}
		else {
			if (username !== data.user) {
				$('#modal-session-expired').modal('show');
				modalVisible = true;
			}
		}

		// nächsten Check planen
		planLoginCheck(defaultTimeout);
	}

	// Beim Tab-Wechsel/Fenster-Fokussieren direkt neu prüfen, ob die Sitzung noch aktiv ist
	window.addEventListener('blur', function (event) {
		wasHidden = true;
	});
	window.addEventListener('focus', function (event) {
		if (wasHidden) {
			planLoginCheck(500);
			wasHidden = false;
		}
	});

	// Ersten Check planen
	planLoginCheck(defaultTimeout);

})();
