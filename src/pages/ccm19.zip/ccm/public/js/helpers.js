"use strict";

$(function () {
	$('input[data-disable-confirm]').on('click', function () {
		var message = this.getAttribute('data-disable-confirm').replace(/\\n/g, '\n');
		if (!this.checked) {
			return confirm(message);
		}
	});

	// Trägt bei Tab-Navigation ARIA-Attribute nach
	$('a[data-toggle="tab"]').each(function () {
		var match = this.href.match(/#(.*)$/, '');
		if (match && !this.hasAttribute('aria-controls')) {
			this.setAttribute('aria-controls', match[1]);
			this.setAttribute('aria-expanded', this.classList.contains('active'));
		}
	});

	// Beliebiges Element mit Tab mitverstecken/anzeigen mit data-binds-to="#selector"
	$('[data-binds-to]').each(function () {
		var self = this;
		var selector = this.getAttribute('data-binds-to');
		var $bound_to = $(selector);
		var $controller = $('[data-toggle][href="'+selector+'"');

		$controller.on('hide.bs.tab', function () {
			self.classList.add('hidden');
		});
		$controller.on('show.bs.tab', function () {
			self.classList.remove('hidden');
		});

		if ($bound_to.hasClass('active')) {
			self.classList.remove('hidden');
		} else {
			self.classList.add('hidden');
		}

		if (this.id) {
			var controls = $controller.attr('aria-controls');
			controls = (controls) ? (controls + ' ' + this.id) : this.id;
			$controller.attr('aria-controls', controls);
		}

	});

	// Typeahead.js
	var datalistMatcher = function(datalist) {
		return function findMatches(q, cb) {
			var matches = {};

			var pattern = q.replace(/[.+*^${}()|[\]\\]/g, '\\$&').replace(/\?/g, '.').replace(/\\\\\.\*/g, '\?');
			var prefixRegex = new RegExp("(^|\b|[ ,.-])"+pattern, "i");
			var substrRegex = new RegExp(pattern, "i");
			var count = 0;

			$(datalist).children('option').each(function() {
				if (prefixRegex.test(this.value)) {
					matches[this.value] = this;
					count++;
				}
			});
			$(datalist).children('option').each(function() {
				if (substrRegex.test(this.value) && count < 20 && matches[this.value] === undefined) {
					matches[this.value] = this;
					count++;
				}
			});

			cb(Object.values(matches));
		};
    };
    // Init Typeahead Plugin
    $('.typeahead[list]').each(function () {
		var $this = $(this).typeahead(
			{
				hint: true,
				highlight: true,
				minLength: 1
			}, {
				name: this.getAttribute('list'),
				displayKey: 'value',
				source: datalistMatcher(document.getElementById(this.getAttribute('list')))
			}
		);
		var ta = $this.data("ttTypeahead");

		this.removeAttribute('list');
		$(this).on('keypress', function(evt) {
			if (evt.key == 'Enter' || evt.keyCode == 13) {
				if (ta.input.getHint()) {
					ta.input.setInputValue(ta.input.getHint());
					evt.preventDefault();
					$(this).trigger('change');
				}
				if (ta.dropdown.isOpen) {
					ta.close();
					evt.preventDefault();
				}
			}
		});

	});

	// Sammelauswahl-Checkboxen in Tabellenheadern
	$('thead input.select-all[type="checkbox"]').each(function () {
		var self = this;
		var n = $(this).closest('td,th').prevAll('td,th').length + 1;
		var $tbody = $(this).closest('table').children('tbody');
		var $checkboxes = $tbody.find('tr :nth-child('+n+') input[type="checkbox"]')

		function updateState() {
			var checked = $checkboxes.filter(':checked');
			var unchecked = $checkboxes.filter(':not(:checked)');
			self.indeterminate = (checked.length > 0 && unchecked.length > 0);
			self.checked = (checked.length > 0 && unchecked.length == 0);
		}

		updateState();
		$tbody.on('click', 'input[type="checkbox"]', updateState);
		$(self).on('click', function () {
			var checked = self.checked;
			$checkboxes.each(function () {
				this.checked = checked;
			});
		});

	});

});
