(function () {
	function onSelectorStateChanged() {
		if (this.selectedIndex == -1) {
			return;
		}

		window.location.href = this.options[this.selectedIndex].dataset.url;
	}

	function initDomainSelector() {
		Array.prototype.slice.call(document.getElementsByClassName('domain-selector')).forEach(function (container) {
			if (container.classList.contains('initialized')) {
				return;
			}

			var selector = container.querySelector('select');
			if (selector) {
				selector.addEventListener('change', onSelectorStateChanged);
			}

			container.classList.add('initialized');
		});
	}

	window.addEventListener('DOMContentLoaded', initDomainSelector);
})();
