<?php

namespace App\Component\Cron;

use DirectoryIterator;

class Cron
{
	/** @var Job[] $jobs */
	private static $jobs = [];
	/** @var Job[] $deferredJobs */
	private static $deferredJobs = [];

	private static function loadJobs(): void
	{
		global $kernel;
		$container = $kernel->getContainer();
		self::$jobs = [];

		foreach (new DirectoryIterator(__DIR__.'/Job') as $file) {
			if ($file->isFile() && $file->getExtension() == 'php') {
				require_once $file->getPathname();
			}
		}

		$jobClasses = array_filter(get_declared_classes(), function ($className) {
			return is_subclass_of($className, Job::class);
		});

		self::$jobs = array_map(function ($className) use ($container) {
			return $container->get($className);
		}, $jobClasses);

		// Indizes zurücksetzen; rein kosmetischer Natur
		self::$jobs = array_values(self::$jobs);
	}

	/**
	 * @return Job[]
	 */
	public static function jobs(): array
	{
		if (empty($jobs)) {
			self::loadJobs();
		}

		return self::$jobs;
	}

	/**
	 * @return Job[]
	 */
	public static function dueJobs(): array
	{
		return array_filter(self::jobs(), function ($job) {
			/** @var Job $job */
			return $job->isDue();
		});
	}

	/**
	 * Job-Objekt nach Namen suchen
	 *
	 * @param string $name
	 * @return Job|null
	 */
	public static function jobByName(string $name): ?Job
	{
		return array_reduce(self::jobs(), function ($previousJob, $currentJob) use ($name) {
			/**
			 * @var Job|null $previousJob
			 * @var Job $currentJob
			 */
			return $currentJob->getName() == $name ? $currentJob : $previousJob;
		}, null);
	}

	/**
	 * Plant die Ausführung eines Jobs im Anschluss an die aktuelle Verarbeitung ein.
	 * Diese Jobs werden (mehr oder weniger) asynchron über Curl durchgeführt.
	 *
	 * @param Job $job
	 */
	public static function addDeferredJob(Job $job): void
	{
		self::$deferredJobs[] = $job;
	}

	/**
	 * Gibt die Liste der zurückgestellten Jobs aus. Die Liste wird nach der Rückgabe geleert.
	 *
	 * @return Job[]
	 */
	public static function deferredJobs(): array
	{
		$result = self::$deferredJobs;
		self::$deferredJobs = [];
		return $result;
	}
}
