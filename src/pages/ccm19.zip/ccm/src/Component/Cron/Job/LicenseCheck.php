<?php

namespace App\Component\Cron\Job;

use App\Component\Ccm19LicensingApiClient;
use App\Component\Cron\Job;
use App\Config;
use App\Model\Domain;
use App\Model\SystemLog;
use App\Model\User;
use App\Utils;
use Psr\Container\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

class LicenseCheck extends Job
{
	const COMPONENT = 'LicenseCheck';

	public function __construct()
	{
		parent::__construct(60 * 60 * 24);
	}

	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		// Lizenzschlüssel validieren
		$this->checkLicense($request);

		// Wenn kein Lizenzschlüssel hinterlegt ist, Cronjob als erledigt betrachten
		if (Utils::hasLicenseKey() == false) {
			return;
		}

		if (Utils::isExtendedEdition()) {
			$this->reportLicensees($request);
		}
	}

	/**
	 * Diese Methode validiert den im System hinterlegten Lizenzschlüssel.
	 */
	private function checkLicense(Request $request): void
	{
		$licenseKey = Utils::getLicenseKey();

		// Wenn kein Lizenzschlüssel hinterlegt ist, Vorgang überspringen
		if (empty($licenseKey)) {
			return;
		}

		$api = new Ccm19LicensingApiClient();
		$api->registerLicense($licenseKey, $request->getHttpHost());

		$translator = Utils::getTranslator();
		$logger = SystemLog::current();

		// Erfolg indiziert die Validität der Lizenz
		if ($api->isSuccess()) {
			Config::getInstance()->set('whitelabel', $api->hasWhitelabel());
			Utils::setLocalEnvironment([
				'APP_EDITION' => $api->getEdition(),
			]);
		}
		elseif ($api->isConnectionError() || $api->isServerError()) {
			$logMessage = 'License could not be verified.'.rtrim(' '.$translator->trans($api->getErrorMessage()), ' ');
			$logger->logError(self::COMPONENT, $logMessage);
		}
		else {
			// Lizenzinformationen nur in der Basisedition zurücksetzen; Konfiguration
			// einer Agenturversion unverändert lassen, um den Betrieb eines möglichen
			// Produktivsystems zu erhalten.
			if (Utils::isBaseEdition()) {
				Config::getInstance()
					->set('licensekey', '')
					->set('whitelabel', false)
				;
				Utils::setLocalEnvironment([
					'APP_EDITION' => '',
				]);
			}

			$logMessage = "License has expired.\nKey: {$licenseKey}\nReason: {$translator->trans($api->getErrorMessage())}";
			$logger->logWarning(self::COMPONENT, $logMessage);
		}
	}

	/**
	 * Diese Methode erstattet Bericht, über die Anzahl aktiver Kunden, Domains etc., zwecks Fakturierung.
	 */
	private function reportLicensees(Request $request): void
	{
		$domainCount = 0;
		try {
			$domainCount = array_reduce(User::all(), function ($count, $user) {
				/** @var User $user */
				if ($user->getRole() == User::ROLE_CLIENT) {
					Domain::switchToUser($user);
					$count += Domain::count();
				}

				return $count;
			}, 0);
		}
		finally {
			$user = User::loggedInUser();
			if ($user) {
				Domain::switchToUser($user);
			}
		}

		$api = new Ccm19LicensingApiClient();
		$api->reportLicensees(Utils::getLicenseKey(), $request->getHttpHost(), $domainCount);
	}
}
