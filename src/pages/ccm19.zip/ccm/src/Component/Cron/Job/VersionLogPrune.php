<?php

namespace App\Component\Cron\Job;

use App\Model\VersionLog;
use App\Component\Cron\Job;
use Symfony\Component\HttpFoundation\Request;

class VersionLogPrune extends Job
{
	const MAX_COUNT = 10;

	public function __construct()
	{
		parent::__construct(60 * 60 * 48);
	}

	/**
	 * Regelmäßig (1x alle 2 Tage) alte Einträge aus dem Versionslog löschen.
	 */
	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		VersionLog::prune(self::MAX_COUNT);
	}
}
