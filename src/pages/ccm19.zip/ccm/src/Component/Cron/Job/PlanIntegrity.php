<?php

namespace App\Component\Cron\Job;

use App\Component\Cron\Job;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;

class PlanIntegrity extends Job
{
	public function __construct()
	{
		parent::__construct(60 * 20);
	}

	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		// Wenn kein Lizenzschlüssel hinterlegt ist oder nicht in Hostingversion, Cronjob als erledigt betrachten
		if (Utils::hasLicenseKey() == false || Utils::isExtendedEdition() == false) {
			return;
		}

		$this->checkIntegrity();
	}

	private function checkIntegrity(): void
	{
		$clients = User::byRole(User::ROLE_CLIENT);

		try {
			array_walk($clients, function ($user) {
				/** @var User $user */
				Domain::switchToUser($user, true);

				// Frontend-Widget nur für so viele Domains aktivieren, wie im Tarif vereinbart
				$widgetCount = Domain::frontendWidgetCountForAllDomains();
				$widgetMaxCount = $user->getMaxDomainCount();

				/** @var Domain[] $domains */
				$domains = array_filter(Domain::all(), function ($domain) {
					/** @var Domain $domain */
					return $domain->isFrontendWidgetEnabled();
				});

				while (count($domains) > 0 && $widgetCount > $widgetMaxCount && $widgetMaxCount > -1) {
					array_pop($domains)->setFrontendWidgetEnabled(false);
					$widgetCount--;
				}

				// Anzahl verwendeter Whitelabel-Lizenzen überprüfen; ggf. streichen
				$whitelabelCount = Domain::whitelabelCountForAllDomains();
				$whitelabelMaxCount = $user->getMaxWLCount();

				/** @var Domain[] $domains */
				$domains = array_filter(Domain::all(), function ($domain) {
					/** @var Domain $domain */
					return $domain->hasWhitelabel();
				});

				while (count($domains) > 0 && $whitelabelCount > $whitelabelMaxCount && $whitelabelMaxCount > -1) {
					array_pop($domains)->setWhitelabel(false);
					$whitelabelCount--;
				}
			});
		} finally {
			Domain::switchToUser(User::loggedInUser(), true);
		}
	}
}
