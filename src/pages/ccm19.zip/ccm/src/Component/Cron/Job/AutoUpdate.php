<?php

namespace App\Component\Cron\Job;

use App\Component\Cron\Job;
use App\Component\LoggerInterface;
use App\Component\Update;
use App\Config;
use App\Exception\LicenseInvalidException;
use App\MailMessage;
use App\Utils;
use Exception;
use LogicException;
use Psr\Container\ContainerInterface;
use Swift_Mailer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Contracts\Translation\TranslatorInterface;
use Throwable;

class AutoUpdate extends Job
{
	const STATE_READY = 0, STATE_DOWNLOADED = 1, STATE_EXTRACTING = 2, STATE_FINISHING = 3;

	/** @var Swift_Mailer */
	private $mailer;
	/** @var LoggerInterface */
	private $logger;
	/** @var TranslatorInterface */
	private $translator;

	public function __construct(LoggerInterface $logger, TranslatorInterface $translator, Swift_Mailer $mailer)
	{
		parent::__construct(60 * 60 * 24);
		$this->logger = $logger;
		$this->mailer = $mailer;
		$this->translator = $translator;

		// Wenn das Update mittendrin hängenbleibt: Intervall auf 5 Minuten
		if ($this->getState() !== self::STATE_READY) {
			$this->intervalSeconds = 5*60;
		}
	}

	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		// Wenn die Funktion Auto-Update inaktiv ist, Cronjob als erledigt markieren und raus.
		if (Utils::isAutoUpdateEnabled() == false) {
			return;
		}

		// Update einleiten
		$updater = new Update;
		$zipPath = Utils::getVarDir().'/autoupdate.zip';
		$config = Config::getInstance();

		$noWriteDirs = $updater->checkDirectoryAccess();
		if ($noWriteDirs) {
			$this->logger->logWarning('AutoUpdate', "Some directories are non-writable (e.g. ${noWriteDirs[0]}). Cannot update.");
			$message = (new MailMessage($this->translator->trans('CCM19 AutoUpdate issue')))
				->setTo($config->get('email'))
				->setBody($this->container->get('twig')->render(
						'emails/autoupdate/file_permissions.txt.twig',
						['directories'=>$noWriteDirs]
					), 'text/plain');
			try {
				$this->mailer->send($message);
			} catch (Exception $e) {
				$this->logger->logWarning('AutoUpdate', "Could not send warn email.");
			}
			return;
		}

		try {
			switch ($this->getState()) {
				// Schritt 1: Version prüfen und herunterladen
				case self::STATE_READY:
					$result = $updater->downloadUpdate($zipPath);
					if ($result) {
						// Wenn Update vorhanden und heruntergeladen, nächsten Schritt triggern
						$this->logger->logInfo('AutoUpdate', "Starting update...");
						$this->setState(self::STATE_DOWNLOADED);
						$this->scheduleDeferred();
					}
					break;

				case self::STATE_DOWNLOADED:
					$result = $updater->prepareUpdateExtraction($zipPath);
					$token = $result['token'];
					$this->setState(self::STATE_EXTRACTING);
					$this->setToken($token);
					$this->setOffset(0);
					$this->setLastVersionIdWithExpiredLicense(null);
					$this->scheduleDeferred();
					break;

				case self::STATE_EXTRACTING:
					$token = $this->getToken();
					$offset = $this->getOffset();
					$result = $updater->extractUpdate($zipPath, $token, $offset, 10);
					if ($result['done']) {
						$this->setState(self::STATE_FINISHING);
					} else {
						$this->setOffset($result['nextOffset']);
					}
					$this->scheduleDeferred();
					break;

				case self::STATE_FINISHING:
					$oldVersion = Utils::getVersionName();
					$token = $this->getToken();
					$this->setToken(null);
					$this->setOffset(0);
					$this->setState(self::STATE_READY);
					Config::getInstance()->flush();

					// Erfolgs-E-Mail vorbereiten
					$message = (new MailMessage($this->translator->trans('CCM19 was successfully updated')))
					->setTo($config->get('email'));

					// Body hier schon einmal rendern, damit der Autoloader alles geladen hat.
					$body = $this->container->get('twig')->render(
						'emails/autoupdate/success.txt.twig',
						[
							'newVersion' => '%VERSION%',
							'changelog' => MailMessage::html2text(Update::getChangeLog())
						]
					);

					// Ein letztes Mal schedulen, damit Cache initialisiert wird.
					$this->scheduleDeferred();

					@ob_end_clean();
					// Update abschließen und Cache leeren
					$updater->finishUpdate($zipPath, $token);

					$newVersion = Utils::getVersionName();
					$this->logger->logInfo('AutoUpdate', "Update from $oldVersion to $newVersion finished");

					// E-Mail versenden
					$message->setBody(str_replace('%VERSION%', $newVersion, $body), 'text/plain');
					try {
						$this->mailer->send($message);
					} catch (Exception $e) {
						$this->logger->logWarning('AutoUpdate', "Could not send success email.");
					}

					break;

				default:
					throw new LogicException('invalid auto update state');
			}
		}
		catch (LicenseInvalidException $e) {
			// Lizenz nicht (mehr) für Updates gültig, Update abbrechen
			$token = $this->getToken();
			$this->setState(self::STATE_READY);
			$this->setToken(null);
			$this->setOffset(0);

			// Nur 1x pro Version Warnmail verschicken
			$versionId = $e->getUpdateVersionId();
			if ($versionId === null or $versionId !== $this->getLastVersionIdWithExpiredLicense()) {
				$this->setLastVersionIdWithExpiredLicense($versionId);

				// Log-Eintrag erstellen
				$message = $e->getMessage();
				$reason = $e->getReason();


				if ($reason == 'update_license_expired') {
					$reasonText = 'update license expired';
				}
				else {
					$reasonText = 'license invalid or expired';
				}

				$this->logger->logError('AutoUpdate', 'Aborted update: '.$reasonText);

				// E-Mail senden
				$exceptionMessage = array_reverse(explode('\\', get_class($e)))[0];
				if ($e->getCode()) {
					$exceptionMessage .= '['.$e->getCode().']';
				}
				$exceptionMessage .= ': '. $e->getMessage();
				$mailmsg = (new MailMessage($this->translator->trans('CCM19 AutoUpdate failed')))
					->setTo($config->get('email'))
					->setBody($this->container->get('twig')->render(
							'emails/autoupdate/expired.txt.twig',
							['error'=>$exceptionMessage, 'reason'=>$reason]
						), 'text/plain');
				try {
					$this->mailer->send($mailmsg);
				} catch (Exception $e) {
					$this->logger->logWarning('AutoUpdate', "Could not send error email.");
				}
			}

			// ZIP löschen
			if (file_exists($zipPath)) {
				unlink($zipPath);
			}

			// Temporären Ordner löschen
			if ($token !== '') {
				$updater->clearTemporaryFiles($token);
			}
		}
		catch (Throwable $e) {
			// Bei Exceptions Update abbrechen
			$token = $this->getToken();
			$this->setState(self::STATE_READY);
			$this->setToken(null);
			$this->setOffset(0);

			// Log-Eintrag erstellen
			$message = $e->getMessage();
			$this->logger->logException('AutoUpdate', $e, 'Aborted update:');

			// E-Mail senden
			$exceptionMessage = array_reverse(explode('\\', get_class($e)))[0];
			if ($e->getCode()) {
				$exceptionMessage .= '['.$e->getCode().']';
			}
			$exceptionMessage .= ': '. $e->getMessage();
			$mailmsg = (new MailMessage($this->translator->trans('CCM19 AutoUpdate failed')))
				->setTo($config->get('email'))
				->setBody($this->container->get('twig')->render(
						'emails/autoupdate/error.txt.twig',
						['error'=>$exceptionMessage]
					), 'text/plain');
			try {
				$this->mailer->send($mailmsg);
			} catch (Exception $e) {
				$this->logger->logWarning('AutoUpdate', "Could not send error email.");
			}

			// ZIP löschen
			if (file_exists($zipPath)) {
				unlink($zipPath);
			}

			// Temporären Ordner löschen
			if ($token !== '') {
				$updater->clearTemporaryFiles($token);
			}
		}
	}

	private function getState(): int
	{
		return (int)($this->readConfig('state') ?? self::STATE_READY);
	}

	private function setState(int $state): void
	{
		$this->writeConfig('state', $state);
	}

	private function getToken(): string
	{
		return (string)($this->readConfig('token') ?? '');
	}

	private function setToken(?string $token): void
	{
		$this->writeConfig('token', $token);
	}

	private function getOffset(): int
	{
		return (int)($this->readConfig('offset') ?? 0);
	}

	private function setOffset(int $offset): void
	{
		$this->writeConfig('offset', $offset);
	}

	private function getLastVersionIdWithExpiredLicense(): ?string
	{
		return $this->readConfig('lastExpiredVersionId') ?? null;
	}

	private function setLastVersionIdWithExpiredLicense(?string $versionId): void
	{
		$this->writeConfig('lastExpiredVersionId', $versionId);
	}

}
