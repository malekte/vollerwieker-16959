<?php

namespace App\Component\Cron\Job;

use App\Component\Cron\Job;
use App\Component\Update;
use App\Config;
use App\Model\User;
use App\MailMessage;
use App\Component\LoggerInterface;
use App\Utils;
use Psr\Container\ContainerInterface;
use Swift_Mailer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Contracts\Translation\TranslatorInterface;
use Throwable;
use LogicException;
use Exception;

class ClientUpdateNotification extends Job
{
	const BATCH_SIZE = 10;

	/** @var Config $config */
	private $config;
	/** @var Swift_Mailer $mailer */
	private $mailer;
	/** @var LoggerInterface $logger */
	private $logger;

	public function __construct(LoggerInterface $logger, Swift_Mailer $mailer)
	{
		parent::__construct(1);
		$this->config = Config::getInstance();
		$this->logger = $logger;
		$this->mailer = $mailer;
	}

	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		$versionId = Utils::getVersionId();
		$notificationCount = 0;

		$clients = User::byRole(User::ROLE_CLIENT);
		$client = null;
		foreach ($clients as $client) {
			$lastNotifiedVersion = $client->getLastNotifiedVersion();

			// Aktuelle Version für neue Nutzer festhalten
			if ($lastNotifiedVersion === null) {
				$client->setLastNotifiedVersion($versionId);
			}
			// Noch nicht informierte Kunden informieren
			elseif ($lastNotifiedVersion !== $versionId) {
				$client->setLastNotifiedVersion($versionId);
				try {
					$this->notifyClient($client);
					$notificationCount++;
				} catch (Throwable $e) {
					// Vorerst ignorieren
				}
			}

			if ($notificationCount >= self::BATCH_SIZE) {
				break;
			}
		}
		// Wir sind fertig, wenn wir beim letzten Kunden angekommen waren
		$done = (array_pop($clients) === $client);

		// Änderungen speichern
		User::flush();

		// Wenn noch nicht fertig mit allen Kunden, dann gleich fortsetzen
		if (!$done) {
			$this->scheduleDeferred();
		}
	}

	public function notifyClient(User $client): void
	{
		if ($this->config->get('sendUpdateNotifications', false) == false) {
			return; // Nichts senden, wenn deaktiviert
		}

		$to = $client->getEmailAddress();
		$toName = trim($client->getFirstName().' '.$client->getLastName());
		if ($client->getCompany()) {
			$toName .= ' ('.$client->getCompany().')';
		}
		$subject = (string)$this->config->get("sub_update_email_betreff");
		$body = (string)$this->config->get("sub_update_email_content");

		$message = (new MailMessage($subject))
			->setTo($to, '"'.$toName.'"')
			->setBody($body, 'text/plain');
		try {
			$this->mailer->send($message);
		} catch (Exception $e) {
			$this->logger->logWarning('ClientUpdateNotification', "Could not send info email to <$to>.");
		}
	}
}
