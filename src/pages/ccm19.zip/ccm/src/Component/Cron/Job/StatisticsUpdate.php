<?php

namespace App\Component\Cron\Job;

use App\Component\Cron\Job;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use App\Event\StatisticsCronJobEvent;
use Symfony\Component\HttpFoundation\Request;

class StatisticsUpdate extends Job
{
	public function __construct()
	{
		parent::__construct(60*60);
	}

	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		Utils::dispatchEvent(StatisticsCronJobEvent::NAME, new StatisticsCronJobEvent(true));
	}

}
