<?php

namespace App\Component\Cron\Job;

use App\Component\ThumbnailExtractor\ThumbnailExtractorService;
use App\Component\Cron\Job;
use Symfony\Component\HttpFoundation\Request;

class ThumbnailCachePrune extends Job
{
	const COMPONENT = 'ThumbnailCachePrune';

	private $thumbnails;

	public function __construct(ThumbnailExtractorService $thumbnails)
	{
		parent::__construct(60 * 60 * 24);
		$this->thumbnails = $thumbnails;
	}

	/**
	 * Regelmäßig (1x täglich) alle Thumbnails bereinigen.
	 */
	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		$this->thumbnails->pruneCache();
	}
}
