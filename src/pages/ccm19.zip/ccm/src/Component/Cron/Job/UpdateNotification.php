<?php

namespace App\Component\Cron\Job;

use App\Component\Cron\Job;
use App\Component\Update;
use App\Config;
use App\MailMessage;
use App\Component\LoggerInterface;
use App\Exception\LicenseInvalidException;
use App\Utils;
use Psr\Container\ContainerInterface;
use Swift_Mailer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Contracts\Translation\TranslatorInterface;
use Throwable;
use LogicException;
use Exception;

class UpdateNotification extends Job
{
	/** @var Swift_Mailer */
	private $mailer;
	/** @var LoggerInterface */
	private $logger;
	/** @var TranslatorInterface */
	private $translator;

	public function __construct(LoggerInterface $logger, TranslatorInterface $translator, Swift_Mailer $mailer)
	{
		parent::__construct(60 * 60 * 24);
		$this->logger = $logger;
		$this->mailer = $mailer;
		$this->translator = $translator;
	}

	public function run(Request $request): void
	{
		$this->touchLastExecutionTimestamp();

		// Wenn die Funktion Auto-Update aktiv ist, Cronjob als erledigt markieren und raus.
		if (Utils::isAutoUpdateEnabled() == true) {
			return;
		}

		// Auf Update prüfen
		$updater = new Update();
		$config = Config::getInstance();
		try {
			$updateInfo = $updater->checkForUpdate();
		}
		catch (LicenseInvalidException $e) {
			$reason = $e->getReason();
			$versionId = $e->getUpdateVersionId();

			if ($versionId !== null and $versionId !== $this->getLastVersionId()) {
				$this->setLastVersionId((string)$versionId);
				$this->logger->logWarning('UpdateNotification', "A new update is available (ID $versionId) but your update license is expired");

				// E-Mail senden
				$message = (new MailMessage($this->translator->trans('CCM19 Update available')))
					->setTo($config->get('email'))
					->setBody($this->container->get('twig')->render(
							'emails/update_notification_expired.txt.twig',
							['versionId'=>$versionId, 'reason'=>$reason]
						), 'text/plain');
				try {
					$this->mailer->send($message);
				} catch (Exception $e) {
					$this->logger->logWarning('UpdateNotification', "Could not send info email.");
				}
			}
			return;
		}
		catch (Throwable $e) {
			return; // Sonstige Fehler vorerst ignorieren
		}

		// Wenn ein Update verfügbar und noch nicht darüber informiert, informieren.
		if ($updateInfo and $updateInfo['versionId'] !== $this->getLastVersionId()) {
			$this->setLastVersionId((string)$updateInfo['versionId']);

			$fileSize = $updateInfo['fileSizeMB'] = number_format($updateInfo['fileSize']/1024/1024, 1);
			$versionId = $updateInfo['versionId'];
			$updateInfo['changelog'] = trim(MailMessage::html2text(Update::getChangeLog()));

			$this->logger->logInfo('UpdateNotification', "A new update is available ($fileSize MB, ID $versionId)");
			$message = (new MailMessage($this->translator->trans('CCM19 Update available')))
				->setTo($config->get('email'))
				->setBody($this->container->get('twig')->render(
						'emails/update_notification.txt.twig',
						$updateInfo
					), 'text/plain');
			try {
				$this->mailer->send($message);
			} catch (Exception $e) {
				$this->logger->logWarning('UpdateNotification', "Could not send info email.");
			}
		}
	}

	private function getLastVersionId(): string
	{
		return (string)$this->readConfig('lastVersionId');
	}

	private function setLastVersionId(string $versionId): void
	{
		$this->writeConfig('lastVersionId', $versionId);
	}
}
