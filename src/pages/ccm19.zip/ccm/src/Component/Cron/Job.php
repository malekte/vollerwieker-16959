<?php

namespace App\Component\Cron;

use App\Config;
use Psr\Container\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

abstract class Job
{
	/** @var string $namespace */
	private $namespace;

	/** @var int $intervalSeconds */
	protected $intervalSeconds;

	/** @var ?ContainerInterface $container */
	protected $container;

	public function __construct(int $intervalSeconds)
	{
		$this->container = null;
		$this->namespace = 'cron.jobs.'.lcfirst($this->getName());
		$this->intervalSeconds = $intervalSeconds;
	}

	/**
	 * @required
	 * @param ContainerInterface $container
	 */
	public function setContainer(ContainerInterface $container)
	{
		$this->container = $container;
	}

	/**
	 * @param string $identifier
	 * @return mixed
	 */
	protected final function readConfig(string $identifier)
	{
		return Config::getInstance()->get($this->namespace.'.'.$identifier);
	}

	/**
	 * @param string $identifier
	 * @param mixed $data
	 */
	protected final function writeConfig(string $identifier, $data): void
	{
		Config::getInstance()->set($this->namespace.'.'.$identifier, $data);
	}

	/**
	 * @return string
	 */
	public final function getName(): string
	{
		return array_reverse(explode('\\', static::class))[0];
	}

	/**
	 * @return int
	 */
	public final function getIntervalSeconds(): int
	{
		return $this->intervalSeconds;
	}

	/**
	 * Diese Methode aktualisiert den Zeitstempel der letzten Ausführung des Jobs.
	 */
	protected final function touchLastExecutionTimestamp(): void
	{
		$this->writeConfig('lastExecutionTimestamp', time());
		Config::getInstance()->flush();
	}

	/**
	 * @return int
	 */
	public final function lastExecutionTimestamp(): int
	{
		return (int)$this->readConfig('lastExecutionTimestamp');
	}

	/**
	 * @return bool
	 */
	public final function isDue(): bool
	{
		return time() > $this->lastExecutionTimestamp() + $this->intervalSeconds;
	}

	/**
	 * Führt diesen Job später über einen Curl-Aufruf aus.
	 */
	public final function scheduleDeferred(): void
	{
		Cron::addDeferredJob($this);
	}

	abstract public function run(Request $request): void;
}
