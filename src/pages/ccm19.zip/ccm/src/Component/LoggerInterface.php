<?php

namespace App\Component;

use Throwable;

interface LoggerInterface
{
	/**
	 * @param string $component Betroffene Komponente
	 * @param Throwable $exception
	 * @param string $message Nachricht
	 */
	public function logException(string $component, Throwable $exception, string $message=""): void;

	/**
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 */
	public function logError(string $component, string $message): void;

	/**
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 */
	public function logWarning(string $component, string $message): void;

	/**
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 */
	public function logInfo(string $component, string $message): void;
}
