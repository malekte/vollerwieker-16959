<?php

namespace App\Component;

use App\Component\Curl;
use ErrorException;
use Exception;
use RuntimeException;

class Ccm19LicensingApiClient
{
	const API_URL = 'https://licence.ccm19.de/index.php';

	/** @var bool $success */
	private $success;
	/** @var string $error */
	private $error;

	/** @var bool $connectionError */
	private $connectionError;
	/** @var bool $serverError */
	private $serverError;

	/** @var string $edition */
	private $edition;
	/** @var int $whitelabelMaxCount */
	private $whitelabelMaxCount;
	/** @var int $whitelabelCount */
	private $whitelabelCount;
	/** @var bool $whitelabel */
	private $whitelabel;

	public function __construct()
	{
		$this->reset();
	}

	private function reset(): void
	{
		$this->success = true;
		$this->error = '';

		$this->connectionError = false;
		$this->serverError = false;

		$this->edition = '';
		$this->whitelabelMaxCount = 0;
		$this->whitelabelCount = 0;
		$this->whitelabel = false;
	}

	/**
	 * @param string $endpoint
	 * @param array $params
	 * @param array $headers
	 * @return array|null
	 * @throws ErrorException Wird geschmissen, wenn cURL nicht zur Verfügung steht.
	 * @throws RuntimeException Wenn ein Problem in der Kommunikation mit dem API-Server auftritt.
	 */
	private function get(string $endpoint, array $params = [], array $headers = []): ?array
	{
		$params = ['action' => $endpoint] + $params;

		$curl = new Curl();

		foreach ($headers as $name => $value) {
			$curl->setHeader($name, $value);
		}

		$curl->get(self::API_URL, $params);

		if ($curl->curl_error) {
			$this->connectionError = true;
			throw new RuntimeException("An error has occurred in cURL module. (Code: {$curl->getErrorCode()}) ".$curl->getErrorMessage());
		}
		elseif ($curl->getResponseHeaders('Content-Type') != 'application/json') {
			$this->serverError = true;
			throw new RuntimeException('Unexpected response from license server.');
		}
		elseif ($curl->isServerError()) {
			$this->serverError = true;
		}

		$response = json_decode($curl->getResponse(), true);
		return is_array($response) ? $response : null;
	}

	/**
	 * @param string $licenseKey
	 * @param string $domain
	 * @return bool
	 */
	public function registerLicense(string $licenseKey, string $domain): bool
	{
		$this->reset();

		$response = null;
		try {
			$response = $this->get('registerLicense', [
				'licence_id' => $licenseKey,
				'dom' => $domain,
			]);

			$this->success = $response && ($response['ok'] ?? false);
		}
		catch (Exception $exception) {
			$this->setErrorMessage($exception->getMessage());
			$this->success = false;
			return false;
		}

		if ($this->isSuccess()) {
			$this
				->setEdition((string)($response['edition'] ?? ''))
				->setWhitelabel((bool)($response['whitelabel'] ?? false))
			;
		}
		else {
			$this->setErrorMessage($response ? (string)($response['error'] ?? '') : 'License server unreachable');
		}

		return $this->isSuccess();
	}

	/**
	 * @param string $licenseKey
	 * @param string $domain
	 * @return bool
	 */
	public function unregisterLicense(string $licenseKey, string $domain): bool
	{
		$this->reset();

		$response = null;
		try {
			$response = $this->get('unregisterLicense', [
				'licenseKey' => $licenseKey,
				'domain' => $domain,
			]);

			$this->success = $response && ($response['success'] ?? false);
		}
		catch (Exception $exception) {
			$this->setErrorMessage($exception->getMessage());
			$this->success = false;
			return false;
		}

		if ($this->isSuccess()) {
			$this
				->setEdition((string)($response['edition'] ?? ''))
				->setWhitelabel((bool)($response['whitelabel'] ?? false))
			;
		}
		else {
			$this->setErrorMessage($response ? (string)($response['error'] ?? '') : 'Unknown error');
		}

		return $this->isSuccess();
	}

	/**
	 * @param string $licenseKey
	 * @param string $domain
	 * @return bool
	 */
	public function registerWhitelabel(string $licenseKey, string $domain): bool
	{
		$this->reset();

		$response = null;
		try {
			$response = $this->get('registerWhitelabel', [
				'licenseKey' => $licenseKey,
				'domain' => $domain,
			]);

			$this->success = $response && ($response['success'] ?? false);
		}
		catch (Exception $exception) {
			$this->setErrorMessage($exception->getMessage());
			$this->success = false;
			return false;
		}

		if ($this->isSuccess()) {
			$this
				->setEdition((string)($response['edition'] ?? ''))
				->setWhitelabelMaxCount((int)($response['whitelabelMaxCount'] ?? 0))
				->setWhitelabelCount((int)($response['whitelabelCount'] ?? 0))
				->setWhitelabel((bool)($response['whitelabel'] ?? false))
			;
		}
		else {
			$this->setErrorMessage($response ? (string)($response['error'] ?? '') : 'Unknown error');
		}

		return $this->isSuccess();
	}

	/**
	 * @param string $licenseKey
	 * @param string $domain
	 * @return bool
	 */
	public function unregisterWhitelabel(string $licenseKey, string $domain): bool
	{
		$this->reset();

		$response = null;
		try {
			$response = $this->get('unregisterWhitelabel', [
				'licenseKey' => $licenseKey,
				'domain' => $domain,
			]);

			$this->success = $response && ($response['success'] ?? false);
		}
		catch (Exception $exception) {
			$this->setErrorMessage($exception->getMessage());
			$this->success = false;
			return false;
		}

		if ($this->isSuccess()) {
			$this
				->setEdition((string)($response['edition'] ?? ''))
				->setWhitelabelMaxCount((int)($response['whitelabelMaxCount'] ?? 0))
				->setWhitelabelCount((int)($response['whitelabelCount'] ?? 0))
				->setWhitelabel((bool)($response['whitelabel'] ?? false))
			;
		}
		else {
			$this->setErrorMessage($response ? (string)($response['error'] ?? '') : 'Unknown error');
		}

		return $this->isSuccess();
	}

	/**
	 * @param string $licenseKey
	 * @param string $domain
	 * @param int $domainCount
	 * @return bool
	 */
	public function reportLicensees(string $licenseKey, string $domain, int $domainCount): bool
	{
		$this->reset();

		$response = null;
		try {
			$response = $this->get('reportLicensees', [
				'licenseKey' => $licenseKey,
				'domain' => $domain,
				'domainCount' => $domainCount,
			]);

			$this->success = $response && ($response['success'] ?? false);
		}
		catch (Exception $exception) {
			$this->setErrorMessage($exception->getMessage());
			$this->success = false;
			return false;
		}

		if ($this->isError()) {
			$this->setErrorMessage($response ? (string)($response['error'] ?? '') : 'Unknown error');
		}

		return $this->isSuccess();
	}

	/**
	 * @return bool
	 */
	public function isSuccess(): bool
	{
		return $this->success;
	}

	/**
	 * @return bool
	 */
	public function isError(): bool
	{
		return $this->isSuccess() == false;
	}

	/**
	 * @return bool
	 */
	public function isConnectionError(): bool
	{
		return $this->connectionError;
	}

	/**
	 * @return bool
	 */
	public function isServerError(): bool
	{
		return $this->serverError;
	}

	/**
	 * @param string $message
	 * @return $this
	 */
	private function setErrorMessage(string $message): self
	{
		$this->error = $message;
		return $this;
	}

	/**
	 * @return string
	 */
	public function getErrorMessage(): string
	{
		return $this->error;
	}

	/**
	 * @param string $edition
	 * @return $this
	 */
	private function setEdition(string $edition): self
	{
		$this->edition = $edition;
		return $this;
	}

	/**
	 * @return string
	 */
	public function getEdition(): string
	{
		return $this->edition;
	}

	/**
	 * @param int $count
	 * @return $this
	 */
	private function setWhitelabelMaxCount(int $count): self
	{
		$this->whitelabelMaxCount = $count;
		return $this;
	}

	/**
	 * @return int
	 */
	public function getWhitelabelMaxCount(): int
	{
		return $this->whitelabelMaxCount;
	}

	/**
	 * @param int $count
	 * @return $this
	 */
	private function setWhitelabelCount(int $count): self
	{
		$this->whitelabelCount = $count;
		return $this;
	}

	/**
	 * @return int
	 */
	public function getWhitelabelCount(): int
	{
		return $this->whitelabelCount;
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	private function setWhitelabel(bool $state): self
	{
		$this->whitelabel = $state;
		return $this;
	}

	/**
	 * @return bool
	 */
	public function hasWhitelabel(): bool
	{
		return $this->whitelabel;
	}
}
