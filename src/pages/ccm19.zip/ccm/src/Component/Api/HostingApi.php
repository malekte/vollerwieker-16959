<?php

namespace App\Component\Api;

use App\Config;
use App\Utils;
use Dflydev\Hawk\Credentials\Credentials as HawkCredentials;
use Dflydev\Hawk\Server\Response as HawkResponse;
use Dflydev\Hawk\Server\Server as HawkServer;
use Dflydev\Hawk\Server\ServerBuilder as HawkServerBuilder;
use Dflydev\Hawk\Server\UnauthorizedException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class HostingApi
{
	private const API_KEY_CHARSET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	public const API_KEY_LENGTH = 48;

	private const SHARED_SECRET_CHARSET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&+';
	public const SHARED_SECRET_LENGTH = 12;

	public const PBKDF2_ALGORITHM = 'sha256';
	public const PBKDF2_ITERATIONS = 500;
	public const PBKDF2_KEY_LENGTH = 16;
	public const PBKDF2_SALT = 'hawk';

	/** @var self|null $instance */
	private static $instance = null;

	/** @var string $apiKey */
	private $apiKey;

	/** @var string $sharedSecret */
	private $sharedSecret;

	/** @var bool $useHawk */
	private $useHawk;

	/** @var HawkServer $hawkServer */
	private $hawkServer;

	/** @var HawkResponse|null $hawkResponse */
	private $hawkResponse;

	private function __construct()
	{
		$config = Config::getInstance();

		$this->setApiKey((string)$config->get('hosting.apiKey') ?: self::generateApiKey());
		$this->setSharedSecret((string)$config->get('hosting.sharedSecret') ?: self::generateSharedSecret());
		$this->setUseHawk((bool)($config->get('hosting.useHawk') ?? false));

		$this->initHawk();
	}

	/**
	 * @return self
	 */
	public static function getInstance(): self
	{
		if (self::$instance == null) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * @return string
	 */
	private static function generateApiKey(): string
	{
		$apiKey = Utils::randomString(self::API_KEY_LENGTH, self::API_KEY_CHARSET);

		$dashFirst = (bool)random_int(0, 1);
		$apiKey = substr_replace($apiKey, $dashFirst ? '-' : '_', random_int(6, 15), 1);
		$apiKey = substr_replace($apiKey, $dashFirst ? '_' : '-', random_int(21, 41), 1);

		return $apiKey;
	}

	/**
	 * @return string
	 */
	private static function generateSharedSecret(): string
	{
		return Utils::randomString(self::SHARED_SECRET_LENGTH, self::SHARED_SECRET_CHARSET);
	}

	/**
	 * @return string
	 */
	public function getApiKey(): string
	{
		return $this->apiKey;
	}

	/**
	 * @param string $apiKey
	 * @return $this
	 */
	public function setApiKey(string $apiKey): self
	{
		$this->apiKey = $apiKey;
		Config::getInstance()->set('hosting.apiKey', $apiKey);

		return $this;
	}

	/**
	 * @return string
	 */
	public function getSharedSecret(): string
	{
		return $this->sharedSecret;
	}

	/**
	 * @param string $sharedSecret
	 * @return $this
	 */
	public function setSharedSecret(string $sharedSecret): self
	{
		$this->sharedSecret = $sharedSecret;
		Config::getInstance()->set('hosting.sharedSecret', $sharedSecret);

		return $this;
	}

	/**
	 * @return bool
	 */
	public function isUseHawk(): bool
	{
		return $this->useHawk;
	}

	/**
	 * @param bool $useHawk
	 * @return $this
	 */
	public function setUseHawk(bool $useHawk): self
	{
		$this->useHawk = $useHawk;
		Config::getInstance()->set('hosting.useHawk', $useHawk);

		return $this;
	}

	private function initHawk(): void
	{
		$credentialsProvider = function ($id) {
			$key = hash_pbkdf2(
				self::PBKDF2_ALGORITHM,
				$this->getSharedSecret(),
				self::PBKDF2_SALT,
				self::PBKDF2_ITERATIONS,
				self::PBKDF2_KEY_LENGTH,
				true
			);

			return new HawkCredentials($key, 'sha256', $this->getApiKey());
		};

		$this->hawkServer = HawkServerBuilder::create($credentialsProvider)->build();
	}

	/**
	 * @param Request $request
	 * @throws UnauthorizedException Bei ungültigem API-Schlüssel oder sonstigen Hawk-Fehlern
	 */
	public function authorizeRequest(Request $request): void
	{
		$requestApiKey = $request->query->get('apiKey');

		if ($requestApiKey != $this->getApiKey()) {
			throw new UnauthorizedException('Invalid API key.');
		}

		if ($this->isUseHawk()) {
			$this->hawkResponse = $this->hawkServer->authenticate(
				$request->getRealMethod(),
				$request->getHttpHost(),
				$request->getPort(),
				$request->getRequestUri(),
				$request->headers->get('Content-Type'),
				$request->getContent() ?: null,
				$request->headers->get('Authorization')
			);
		}
	}

	public function signResponse(Response $response): void
	{
		if ($this->isUseHawk() && $this->hawkResponse) {
			$options = array_filter([
				'content_type' => (string)$response->headers->get('Content-Type'),
				'payload' => (string)$response->getContent(),
			]);

			$header = $this->hawkServer->createHeader(
				$this->hawkResponse->credentials(),
				$this->hawkResponse->artifacts(),
				$options
			);

			// Setzt den 'Server-Authorization' HTTP-Header
			$response->headers->set($header->fieldName(), $header->fieldValue());
		}
	}
}
