<?php

namespace App\Component;

use App\Config;
use App\Utils;
use App\Downloader;
use App\Exception\DownloaderException;
use App\Exception\DownloaderHTTPException;
use App\Exception\TempFileNotWritableException;
use App\Exception\LicenseInvalidException;
use App\Exception\ZipArchiveCorruptedException;
use App\Exception\ZipArchiveMemoryLimitException;
use App\Exception\ZipArchiveNoFileException;
use App\Exception\ZipArchiveAccessException;
use App\Exception\ZipArchiveExtractException;
use App\Exception\ZipArchiveException;
use App\Component\Curl;
use App\Model\VersionLog;
use ErrorException;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\BufferedOutput;
use Symfony\Component\HttpFoundation\HeaderBag;
use Throwable;
use ZipArchive;

class Update
{
	const UPDATE_URL = 'https://update.ccm19.de/';
	const MOVE_MODE_AUTO = 0, MOVE_MODE_OVERWRITE = 1, MOVE_MODE_FULL_REPLACE = 2;

	private $updateChannel;
	private $licenseKey;
	private $currentVersionId;
	private $acceptableGenerations;

	/**
	 * @param ?string $updateChannel
	 * @param ?string $licenseKey
	 * @param ?string $currentVersionId
	 * @param int[]|null $acceptableGenerations
	 */
	public function __construct($updateChannel=null, $licenseKey=null, $currentVersionId=null, $acceptableGenerations=null)
	{
		if ($updateChannel === null) {
			$updateChannel = Utils::getUpdateChannel();
		}
		if ($licenseKey === null) {
			$licenseKey = Utils::getLicenseKey();
		}
		if ($currentVersionId === null) {
			$currentVersionId = Utils::getVersionId();
		}
		if ($acceptableGenerations === null) {
			$config = Config::getInstance();
			$currentGeneration = Utils::getVersionGeneration();
			$acceptableGenerations = range(Utils::getVersionGeneration(), max($config->getMaximumGeneration(), $currentGeneration));
		}
		$this->updateChannel = $updateChannel;
		$this->licenseKey = $licenseKey;
		$this->currentVersionId = $currentVersionId;
		$this->acceptableGenerations = implode(',', $acceptableGenerations);
	}

	/**
	 * Prüft auf ein Update ohne es herunterzuladen
	 *
	 * @return array|null Update-Information, wenn ein Update verfügbar ist
	 * @throws LicenseInvalidException Wenn die Lizenz nicht mehr für Updates gültig ist
	 * @throws DownloaderException Bei Download-Problemen
	 */
	public function checkForUpdate()
	{
		if (!Curl::installed()) {
			return null;
		}

		$curl = new Curl();
		try {
			$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 5);
			$curl->setOpt(CURLOPT_TIMEOUT, 10);
			$curl->head(self::UPDATE_URL, [
				'version'=>$this->currentVersionId,
				'license'=>$this->licenseKey,
				'channel'=>$this->updateChannel,
				'gens' => $this->acceptableGenerations,
			]);

			$code = $curl->getHttpStatus();
			$headerbag = $curl->getResponseHeaderBag();

			$curlerror = $curl->getErrorMessage();
			$curlerrno = (int)$curl->getErrorCode();
		}
		catch (Throwable $e) {
			throw new DownloaderException($e->getMessage(), $e->getCode(), $e);
		}
		finally {
			@$curl->close();
		}

		// 403 Forbidden -> Lizenz ungültig
		if ($code == 403) {
			$reason = $headerbag->get('X-Reason', null);
			$versionId = $headerbag->get('X-Version-ID', null);
			throw new LicenseInvalidException('License key invalid or expired', 403, $reason, $versionId);
		}
		// 204 No Content -> Kein Update verfügbar
		if ($code == 204) {
			$nextGen = $headerbag->get('X-Next-Gen-Available', '') ?: false;
			if ($nextGen) {
				return [
					'fileSize' => 0,
					'versionId' => Utils::getVersionId(),
					'lastModified' => $headerbag->getDate('Last-Modified', null),
					'nextGenAvailable' => $nextGen,
				];
			} else {
				return null;
			}
		}

		// Sonstige Probleme
		if ($code !== 200) {
			throw new DownloaderHTTPException('Update check failed', $code);
		}
		elseif ($curl->error) {
			throw new DownloaderException($curlerror, $curlerrno);
		}

		return [
			'fileSize' => (int)$headerbag->get('X-File-Size', '0'),
			'versionId' => $headerbag->get('X-Version-Id', ''),
			'lastModified' => $headerbag->getDate('Last-Modified', null),
			'nextGenAvailable' => $headerbag->get('X-Next-Gen-Available', '') ?: false,
		];
	}

	/**
	 * Lädt ein Update-Archiv herunter. (Schritt 1 beim Update)
	 *
	 * @param string $destination Ziel-Dateipfad für das ZIP
	 * @param ?string $progressPath Pfad zu einer JSON-Datei, in welche der Download-Fortschritt geschrieben werden soll
	 * @param ?string $forcedVersionId Versions-ID erzwingen (für Downgrades)
	 * @return bool True, wenn ein Update verfügbar war
	 * @throws LicenseInvalidException Wenn die Lizenz nicht mehr für Updates gültig ist
	 * @throws TempFileNotWritableException Wenn das Ziel nicht beschreibbar ist
	 * @throws DownloaderException Wenn ein sonstiger Fehler beim Download auftritt
	 */
	public function downloadUpdate($destination, $progressPath=null, $forcedVersionId=null)
	{
		$queryData = [
			'version'=>$this->currentVersionId,
			'license'=>$this->licenseKey,
			'channel'=>$this->updateChannel,
			'gens' => $this->acceptableGenerations,
		];
		if ($forcedVersionId) {
			$queryData['req'] = (string)$forcedVersionId;
		}
		$url = self::UPDATE_URL.'?'.http_build_query($queryData);

		try {
			$filename = $destination;
			$downloader = new Downloader($url, $progressPath);
			$downloader->downloadInto($filename, true);
		}
		catch (DownloaderHTTPException $e) {
			// 204 No Content -> Kein Update verfügbar
			if ($e->getCode() == 204) {
				return false;
			}
			// 403 Forbidden -> Lizenz ungültig
			elseif ($e->getCode() == 403) {
				$data = @json_decode($e->getMessage(), true);
				$reason = ($data and !empty($data['error'])) ? $data['error'] : null;
				$versionId = ($data and !empty($data['versionId'])) ? $data['versionId'] : null;
				throw new LicenseInvalidException('License key invalid or expired', 403, $reason, $versionId, $e);
			}
			// Sonstige Fehler durchreichen
			else {
				throw $e;
			}
		}
		catch (ErrorException $e) {
			$message = $e->getMessage();
			$i = strpos($message, 'failed to open stream: ');
			if ($i !== false) {
				throw new TempFileNotWritableException($filename, $e->getCode(), $e);
			} else {
				throw $e;
			}
		}
		return true;
	}

	/**
	 * Bereitet ein Temporäres Verzeichnis für das Update vor und überprüft den Download.
	 * (Schritt 2 beim Update)
	 *
	 * @param string $zipFilename Pfad zum Update-ZIP
	 * @return array ['token'=>string, 'fileCount'=>int]
	 * @throws TempFileNotWritableException
	 * @throws ZipArchiveCorruptedException
	 * @throws ZipArchiveMemoryLimitException
	 * @throws ZipArchiveNoFileException
	 * @throws ZipArchiveAccessException
	 * @throws ZipArchiveException
	 */
	public function prepareUpdateExtraction($zipFilename)
	{
		// Suffix für temporäres Verzeichnis generieren
		$rnd = bin2hex(random_bytes(3));
		$suffix = date('Ymd').'-'.$rnd;

		// ZIP-Datei öffnen
		$zip = new ZipArchive();
		$result = $zip->open($zipFilename, ZIPARCHIVE::CHECKCONS);

		// Fehlerbehandlung
		if ($result !== true) {
			switch ($result) {
			case ZipArchive::ER_INCONS:
			case ZipArchive::ER_NOZIP:
			case ZipArchive::ER_INVAL:
			case ZipArchive::ER_READ:
			case ZipArchive::ER_SEEK:
				throw new ZipArchiveCorruptedException('update archive corrupted', $result);
				break;
			case ZipArchive::ER_MEMORY:
				throw new ZipArchiveMemoryLimitException('memory limit exceeded', $result);
				break;
			case ZipArchive::ER_NOENT:
				throw new ZipArchiveNoFileException('no update file found', $result);
				break;
			case ZipArchive::ER_OPEN:
				throw new ZipArchiveAccessException('could not open update file', $result);
				break;
			default:
				throw new ZipArchiveException('error while opening update archive', $result);
			}
		}

		$fileCount = $zip->numFiles;
		$path = $this->getTemporaryDir($suffix);
		$result = @mkdir($path, 0700);
		$zip->close();

		if (file_exists($path) and is_dir($path)) {
			return ['token'=>$suffix, 'fileCount'=>$fileCount];
		}
		else {
			throw new TempFileNotWritableException($path);
		}
	}

	/**
	 * Entpackt Dateien aus dem ZIP in ein temporäres Verzeichnis (Schritt 3 beim Update)
	 * @param string $zipFilename Pfad zum Update-ZIP
	 * @param string $token Token von prepareUpdateExtraction()
	 * @param int $offset Offset ab dem extrahiert werden soll
	 * @param int $timeLimit Zeitlimit für den Extraktionsprozess
	 * @return array ['done'=>bool, 'nextOffset'=>int, 'total'=>int]
	 * @throws TempFileNotWritableException
	 * @throws ZipArchiveExtractException
	 * @throws ZipArchiveException
	 */
	public function extractUpdate($zipFilename, $token, $offset=0, $timeLimit=-1)
	{
		$umask = umask();

		// Pfad zum temporären Verzeichnis
		$path = $this->getTemporaryDir($token);

		// ZIP-Datei öffnen
		$zip = new ZipArchive();
		$result = $zip->open($zipFilename);

		if ($result !== true) {
			throw new ZipArchiveException('zip file open failed', $result);
		}

		// Dateien extrahieren
		$startTS = time();
		$countFiles = $zip->numFiles;
		for ($idx=$offset; $idx < $countFiles; $idx++) {

			$stat = $zip->statIndex($idx);
			$entry = $stat['name'];

			// Zur Sicherheit alles mit ../ und / am Anfang ignorieren
			if ($entry === '' or $entry[0] === '/' or strpos($entry, '../') !== false) {
				continue;
			}

			// Zielpfad bestimmen
			$dest = $path . DIRECTORY_SEPARATOR . $entry;

			// Verzeichnisse: Existenz sicherstellen
			if (substr($entry, -1) === '/') {
				@mkdir($dest, 0777 & ~$umask);
			}
			// Dateien: extrahieren
			else {
				@mkdir(dirname($dest), 0777 & ~$umask, true);
				// Bei kleinen Dateien (<= 512k) gesamten Inhalt auf einmal kopieren
				if ($stat['size'] <= 512*1024) {
					$data = @$zip->getFromIndex($idx);
					if ($data === false) {
						throw new ZipArchiveExtractException($entry);
					}
					if (@file_put_contents($dest, $data) === false) {
						throw new TempFileNotWritableException($dest);
					}
					$data = null;
				}
				// Ansonsten als Stream in Chunks kopieren
				else {
					$sourceFd = @$zip->getStream($entry);
					if (!$sourceFd) {
						throw new ZipArchiveExtractException($entry);
					}

					$destFd = @fopen($dest, 'wb');
					if (!$destFd) {
						throw new TempFileNotWritableException($dest);
					}

					try {
						// Daten kopieren
						while (!feof($sourceFd)) {
							fwrite($destFd, fread($sourceFd, 512*1024));
						}
					}
					finally {
						fclose($sourceFd);
						fclose($destFd);
					}
				}

				if (strpos($entry, '/bin/') !== false) {
					@chmod($dest, 0777 & ~$umask);
				} elseif (strpos($entry, '/index.php') !== false) {
					@chmod($dest, 0777 & ~$umask);
				} else {
					@chmod($dest, 0666 & ~$umask);
				}

				// Stoppen, wenn Zeitlimit erreicht
				if ($timeLimit >= 0 and time() - $startTS >= $timeLimit) {
					break;
				}
			}

		}

		$zip->close();

		if ($idx < $countFiles) {
			return [
				'done' => false,
				'nextOffset' => $idx+1,
				'total'=> $countFiles
			];
		} else {
			return [
				'done' => true,
				'nextOffset' => $idx+1,
				'total' => $countFiles,
			];
		}
	}

	/**
	 * Verschiebt die entpackten Dateien und leert alle Caches (Letzter Schritt beim Update)
	 *
	 * Nach dieser Funktion muss das Script sofort beendet werden. Ansonten kommen Fehlermeldungen
	 * wegen veränderter Dateien, sobald der Autoloader anspringt!
	 *
	 * @param string $zipFilename Pfad zum Update-ZIP
	 * @param string $token Token von prepareUpdateExtraction()
	 * @return void
	 */
	public function finishUpdate($zipFilename, $token)
	{
		global $kernel;
		$projectDir = $kernel->getProjectDir();

		// Einige Klassen laden, damit der Autoloader nicht anspringen muss.
		class_exists('\\App\\Component\\Curl', true);
		class_exists('\\Curl\\Curl', true);
		class_exists('\\Symfony\\Bundle\\SwiftmailerBundle\\EventListener\\EmailSenderListener', true);
		class_exists('\\Symfony\\Component\\HttpKernel\\EventListener\\ExceptionListener', true);
		class_exists('\\Symfony\\Component\\HttpKernel\\Log\\Logger', true);
		class_exists('\\App\\Model\\VersionLog', true);

		// Pfad zum temporären Verzeichnis
		$path = $this->getTemporaryDir($token);

		$isDiff = (file_exists($path . '/.delete'));

		// Ggf. veraltete Dateien löschen
		if ($isDiff) {
			$deleteList = json_decode(file_get_contents($path . '/.delete'));
			$deleteList = array_reverse($deleteList);
			foreach ($deleteList as $item) {
				$item = $projectDir.DIRECTORY_SEPARATOR.$item;
				if (file_exists($item)) {
					if (is_dir($item)) {
						@rmdir($item);
					} else {
						@unlink($item);
					}
				}
			}
		}

		// Entpackte Dateien verschieben
		$this->moveDirContents($path.'/ccm', $projectDir, ($isDiff ? self::MOVE_MODE_OVERWRITE : self::MOVE_MODE_AUTO));

		// Temporären Ordner löschen
		$this->clearTemporaryFiles($token);

		// Cache-Verzeichnis ganz am Ende leeren
		$this->deleteFullCacheOnExit();

		// Versions-Installation merken
		VersionLog::logCurrentVersion();

		// ZIP-Datei löschen
		@unlink($zipFilename);
	}

	/**
	 * Löscht temporäre Dateien eines Update-Vorgangs.
	 *
	 * Wird bei erfolgreichem Durchlauf automatisch von finishUpdate() ausgeführt.
	 *
	 * @param string $token
	 */
	public function clearTemporaryFiles($token): void
	{
		$path = $this->getTemporaryDir($token);
		if (file_exists($path)) {
			Utils::removeDirectory($path);
		}
	}

	/**
	 * Prüft, ob für ein Verzeichnis oder dessen Unterverzeichnisse keine
	 * Schreibrechte vorliegen und gibt die Liste der Ordner mit falschen
	 * Rechten zurück.
	 *
	 * @param string $directory Verzeichnis, Standard: Project Root
	 * @return string[]
	 */
	public static function checkDirectoryAccess(string $directory=''): array
	{
		global $kernel;
		$directory = $kernel->getProjectDir();
		$nonWritableDirectories = [];
		self::checkDirectoryAccessRecurse($nonWritableDirectories, $directory);
		return $nonWritableDirectories;
	}

	/**
	 * Hilfsfunktion zum rekursiven Prüfen der Schreibrechte
	 *
	 * @param array &$nonWritableDirectories
	 * @param string $directory
	 * @return void
	 */
	private static function checkDirectoryAccessRecurse(array &$nonWritableDirectories, string $directory): void
	{
		$iterator = new \DirectoryIterator($directory);
		foreach ($iterator as $entry) {
			if ($entry->isDot()) {
				continue;
			}

			if ($entry->isDir()) {
				$pathname = $entry->getPathname();
				if ($entry->isWritable() == false) {
					array_push($nonWritableDirectories, $pathname);
				}
				self::checkDirectoryAccessRecurse($nonWritableDirectories, $pathname);
			}
		}
	}

	/**
	 * Löscht den Cache vollständig, sobald das Script beendet wird.
	 *
	 * Wird bei erfolgreichem Durchlauf automatisch von finishUpdate() ausgeführt.
	 */
	public function deleteFullCacheOnExit(): void
	{
		$cachePath = $this->getCachePath();
		// Cache-Verzeichnis ganz am Ende leeren
		register_shutdown_function(function () use ($cachePath) {
			rename($cachePath, $cachePath.'.tmp');
			Utils::removeDirectory($cachePath.'.tmp');
		});
	}

	/**
	 * Diese Methode gibt den Dateipfad des Symphony-Caches zurück.
	 * @return string
	 */
	private static function getCachePath(): string
	{
		$env = preg_replace('/[^a-zA-Z0-9_-]/', '', $_ENV['APP_ENV']);
		return Utils::getVarDir().'/cache/'.$env;
	}

	/**
	 * Diese Methode gibt den Dateipfad für die Fortschrittsdatei beim Download zurück.
	 * @return string
	 */
	public static function getDownloadProgressFilename(): string
	{
		return Utils::getBaseDir().'/public/update-progress-download.json';
	}

	/**
	 * Gibt einen Pfad für ein temporäres Verzeichnis zum Extrahieren zurück.
	 *
	 * @param string $suffix Verzeichnis-Suffix
	 * @return string Vollständiger Pfad zum temporären Verzeichnis
	 */
	private static function getTemporaryDir(string $suffix): string
	{
		$suffix = preg_replace('%[\\/\0]%', '', $suffix);
		$result =  Utils::getVarDir().'/cache/update.'.$suffix;
		return $result;
	}

	/**
	 * Dateien und Unterverzeichnisse verschieben
	 *
	 * @param string $srcPath Quellpfad
	 * @param string $dstPath Zielpfad
	 * @param int $mode Modus (MOVE_MODE_AUTO/MOVE_MODE_OVERWRITE/MOVE_MODE_FULL_REPLACE)
	 */
	private function moveDirContents(string $srcPath, string $dstPath, int $mode = self::MOVE_MODE_AUTO)
	{
		foreach (scandir($srcPath, SCANDIR_SORT_NONE) as $file) {
			if ($file === '.' or $file === '..') {
				continue;
			}

			$src = $srcPath . DIRECTORY_SEPARATOR . $file;
			$dst = $dstPath . DIRECTORY_SEPARATOR . $file;

			// Quellpfad innerhalb von Zielpfad nicht rekursiv verschieben
			if (stripos($dst, $src) === 0) {
				continue;
			}

			if (file_exists($dst) and is_dir($dst)) {
				// Wenn Ziel ein Verzeichnis ist, je nach Modus Verzeichnis ersetzen oder Dateien überschreiben
				if (($mode == self::MOVE_MODE_AUTO and ($file === 'var' or $file === 'public')) or ($mode == self::MOVE_MODE_OVERWRITE)) {
					// Dateien überschreiben
					self::moveDirContents($src, $dst, self::MOVE_MODE_OVERWRITE);
				}
				else {
					// Verzeichnis komplett ersetzen
					// Altes Verzeichnis umbenennen
					$rnd = bin2hex(random_bytes(3));
					$tmp = $dst.'tmp-'.$rnd;
					rename($dst, $tmp);
					// Neues Verzeichnis reinschieben
					rename($src, $dst);
					// Altes Verzeichnis löschen
					Utils::removeDirectory($tmp);
				}
			}
			else {
				// Wenn Ziel nicht existiert oder kein Verzeichnis ist, einfach verschieben und überschreiben
				// Beim Verschieben eines Verzeichnisses aber vorher Ziel löschen
				if ((!is_link($src) and is_dir($src)) or is_link($dst)) {
					@unlink($dst);
				}
				rename($src, $dst);
			}
		}
	}

	/**
	 * @return string
	 */
	public static function getChangeLog()
	{
		$changelog = self::getChangeLogData();
		if ($changelog) {
			$cl = explode("<h1>Changelog CCM19</h1>",$changelog);
			$cl2 = explode('<!-- MODUL: weiter -->',$cl[2]);
			$cl_plain = strip_tags($cl2[0],"<h1>,<h2>,<p>,<br>,<ol>,<li>");
			return trim($cl_plain);
		} else {
			return '';
		}
	}

	/**
	 * @return string
	 */
	private static function getChangeLogData()
	{
		$url ="https://www.ccm19.de/changelog-ccm19.html";

		//Es steht kein curl zur Verfügung... dann nix machen
		if (!Curl::installed()) {
			return '';
		}

		$curl = new Curl();
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 3);
		$curl->setOpt(CURLOPT_TIMEOUT, 3);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$curl->close();

		if (!$resultData) {
			return '';
		}

		return ($resultData);
	}
}
