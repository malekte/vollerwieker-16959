<?php

namespace App\Component;

use LogicException;
use Symfony\Component\HttpFoundation\Request;

class Pagination
{
	/** @var array $collection */
	private $collection;
	/** @var int $limit */
	private $limit;
	/** @var int $padding */
	private $padding;

	/** @var bool $dirty */
	private $dirty;
	/** @var array $cachedPagination */
	private $cachedPagination;

	/**
	 * @param array $items
	 * @param int $limit
	 * @param int $padding
	 */
	public function __construct(array $items, int $limit = 10, int $padding = 3)
	{
		$this->collection = $items;
		$this
			->setLimit($limit)
			->setPadding($padding)
		;

		$this->dirty = true;
		$this->cachedPagination = [];
	}

	/**
	 * Diese Methode ermittelt die Anzahl auf der aktuellen Seite anzuzeigender Einträge.
	 * @return int
	 */
	public function getItemCount(): int
	{
		return count($this->getItems());
	}

	/**
	 * Diese Methode gibt alle für die aktuelle Seite relevanten Einträge zurück.
	 * @return array
	 */
	public function getItems(): array
	{
		$offset = $this->limit * ($this->getCurrentPage() - 1);

		return array_slice($this->collection, $offset, $this->limit);
	}

	/**
	 * @param int $limit
	 * @return $this
	 */
	public function setLimit(int $limit): self
	{
		if ($limit < 1) {
			throw new LogicException('Pagination row limit may not be lower than 1.');
		}

		$this->limit = $limit;
		$this->dirty = true;
		return $this;
	}

	/**
	 * @param int $padding
	 * @return $this
	 */
	public function setPadding(int $padding): self
	{
		if ($padding < 0) {
			throw new LogicException('Pagination pad value may not be lower than 0.');
		}

		$this->padding = $padding;
		$this->dirty = true;
		return $this;
	}

	/**
	 * @return int
	 */
	public function getCurrentPage(): int
	{
		/** @var Request $request */
		global $request;

		return max(1, (int)$request->query->get('page'));
	}

	/**
	 * @return array
	 */
	public function build(): array
	{
		if ($this->dirty == false) {
			return $this->cachedPagination;
		}

		$pad = $this->padding;
		$limit = $this->limit;
		$currentPage = $this->getCurrentPage();
		$objectCount = count($this->collection);

		$lastPage = (int)floor($objectCount / $limit) + ($objectCount == 0 || $objectCount % $limit > 0 ? 1 : 0);

		$pagination = [[
			'page' => 1,
			'dots' => $currentPage - $pad > 2,
		]];

		$lowerBounds = max(2, $currentPage - $pad - max(0, $pad - ($lastPage - $currentPage)));
		$upperBounds = min($currentPage + $pad + max(0, $pad - $currentPage + 1), $lastPage);

		for ($i = $lowerBounds; $i <= $upperBounds; $i++) {
			if ($i == $lastPage) {
				break;
			}

			$pagination[] = [
				'page' => $i,
				'dots' => $i == $upperBounds && $i + 1 < $lastPage,
			];
		}

		if ($lastPage > 1) {
			$pagination[] = [
				'page' => $lastPage,
				'dots' => false,
			];
		}

		$this->cachedPagination = $pagination;
		$this->dirty = false;
		return $pagination;
	}
}
