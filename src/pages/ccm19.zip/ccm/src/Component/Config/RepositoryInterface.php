<?php

namespace App\Component\Config;

use App\Exception\ConfigNotWritableException;
use App\Exception\ConfigNotReadableException;

interface RepositoryInterface
{
	/**
	 * @return array
	 */
	public function toArray(): array;

	/**
	 * Daten aus Repository holen. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $fallback
	 * @return mixed
	 */
	public function get(string $identifier, $fallback = null);

	/**
	 * Daten in Repository speichern. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $data
	 * @return $this
	 */
	public function set(string $identifier, $data);

	/**
	 * Diese Methode entfernt einen Datenstrang.
	 * @param string $identifier
	 * @return $this
	 * @see RepositoryInterface::flush()
	 */
	public function unset(string $identifier);

	/**
	 * Leeren des Repositorys.
	 * @see RepositoryInterface::flush()
	 */
	public function clear(): void;

	/**
	 * Committen aller Änderungen im Repository.
	 * @throws ConfigNotWritableException
	 */
	public function flush(): void;

	/**
	 * Erneutes Einlesen des Repository von der Festplatte. Sämtliche Änderungen gehen verloren.
	 * @throws ConfigNotReadableException
	 */
	public function reload(): void;

	/**
	 * Sperren des Repositories zum Schreiben.
	 *
	 * Danach soll bis zu flush() oder reload() kein parallel laufender
	 * Prozess zugreifen können.
	 */
	public function beginWrite(): void;

	/**
	 * Größe des Repositories auf der Festplatte in Bytes, ohne ungespeicherte Änderungen
	 *
	 * @return int Größe in Bytes (-1 wenn nicht vom Repository unterstützt)
	 */
	public function getPersistedSize(): int;

	/**
	 * Escaping von Schlüsseln.
	 *
	 * @param string $key
	 * @return string
	 */
	public static function escapeKey($key): string;

	/**
	 * Unescaping von Schlüsseln.
	 *
	 * @param string $key
	 * @return string
	 * @see RepositoryInterface::escapeKey()
	 */
	public static function unescapeKey(string $key): string;
}
