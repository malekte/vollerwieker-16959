<?php

namespace App\Component\Config;

interface ModelInterface
{
	/**
	 * @param string $id
	 * @return bool
	 */
	public static function exists(string $id): bool;

	/**
	 * @param string $id
	 * @return static|null
	 */
	public static function find(string $id);

	/**
	 * @return static[]
	 */
	public static function all(): array;

	/**
	 * Zählt die vorhandenen Instanzen dieses Models.
	 * @return int
	 */
	public static function count(): int;

	/**
	 * @return string
	 */
	public function getId(): string;

	/**
	 * Größe des Repositories auf der Festplatte in Bytes, ohne ungespeicherte Änderungen
	 *
	 * @return int Größe in Bytes (-1 wenn nicht vom Repository unterstützt)
	 */
	public static function persistedRepositorySize(): int;
}
