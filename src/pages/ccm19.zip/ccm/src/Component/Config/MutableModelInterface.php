<?php

namespace App\Component\Config;

use App\Exception\ConfigNotWritableException;

interface MutableModelInterface extends ModelInterface
{
	/**
	 * Löschen den durch das aktuelle Objekt referenzierten Datensatz.
	 * @param string $id
	 * @throws ConfigNotWritableException
	 */
	public static function delete(string $id): void;

	/**
	 * Speichern aller Änderungen.
	 *
	 * @return void
	 * @throws ConfigNotWritableException
	 */
	public function save(): void;

	/**
	 * Speichern aller Änderungen.
	 *
	 * @return void
	 * @throws ConfigNotWritableException
	 */
	public static function flush(): void;

	/**
	 * Sperren des Models zum Schreiben.
	 *
	 * Danach soll bis zu flush() oder reload() kein parallel laufender
	 * Prozess zugreifen können.
	 */
	public static function beginWrite(): void;

}
