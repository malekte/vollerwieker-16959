<?php

namespace App\Component\HttpFoundation;

use Symfony\Component\HttpFoundation\Response;

class JavascriptResponse extends Response
{
	public function __construct($content = '', int $status = 200, array $headers = [])
	{
		parent::__construct($content, $status, $headers);
		$this->headers->set('Content-Type', 'application/javascript');
	}
}
