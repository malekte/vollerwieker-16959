<?php

namespace App\Component\ThumbnailExtractor;

class SlideshareThumbnailExtractor extends AbstractThumbnailExtractor
{
	const URL_REGEX = '~^(?:https?:)?//(www\.)?slideshare\.net/slideshow/embed_code/key/(?<key>[\w-]{4,32})~i';

	public function supportsUrl(string $url): bool
	{
		if (preg_match(static::URL_REGEX, $url)) {
			
			return true;
		}
		else {
			return false;
		}
	}

	public function fetchEmbedMetadata(string $url): ?EmbedInformation
	{
		$match = [];
		preg_match(static::URL_REGEX, $url, $match);

		if (substr($url, 0, 2) === '//') {
			$url = 'https:'.$url;
		}

		$jsonUrl = 'https://www.slideshare.net/api/oembed/2?format=json&url='.urlencode($url);
		$metaInfo = $this->fetchJson($jsonUrl);

		if ($metaInfo) {
			$title = $metaInfo['title'];
		}
		else {
			$title = '';
		}

		$startSlide = 1;
		if (preg_match('/[&?]startSlide=(?<slide>[0-9]+)/', $url, $match2)) {
			$startSlide = (int)$match2['slide'];
		}

		// Daten und erstes Thumbnail zusammenfassen
		$result = new EmbedInformation();
		$result->type = 'rich';
		$result->id = $metaInfo['slideshow_id'] ?? $match['key'];
		$result->url = $url;
		$result->title = $title;
		$result->providerName = 'SlideShare';
		$result->thumbnails = [
			new ThumbnailInformation([
				'originalUrl' => $metaInfo['thumbnail_url'] ?? '',
				'width'=> $metaInfo['thumbnail_width'] ?? 0,
			])
		];

		// Größeres Thumbnail bestimmen
		if (isset($metaInfo['slide_image_baseurl'])) {
			$thumburl = $metaInfo['slide_image_baseurl'];
			if (substr($thumburl, 0, 2) === '//') {
				$thumburl = 'https:'.$thumburl;
			}
			$thumburl .= $startSlide . $metaInfo['slide_image_baseurl_suffix'];
			$result->thumbnails[] = new ThumbnailInformation([
				'originalUrl' => $thumburl,
				'width'=> 1024,
			]);
		}

		return $result;
	}
}
