<?php

namespace App\Component\ThumbnailExtractor;

use App\Utils;
use App\Model\User;
use App\Model\Domain;
use App\Component\Curl;

abstract class AbstractThumbnailExtractor
{
	public function supportsUrl(string $url): bool
	{
		return false;
	}

	abstract public function fetchEmbedMetadata(string $url): ?EmbedInformation;

	public function fetchThumbnail(EmbedInformation $embedInfo, ThumbnailInformation $thumb)
	{
		$etag = ($thumb->path and file_exists($thumb->path)) ? $thumb->etag : '';

		$curl = new Curl();
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 4);
		$curl->setOpt(CURLOPT_TIMEOUT, 4);
		$curl->setOpt(CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; CCM19; +http://ccm19.de)');

		$headers = [];
		if ($etag) {
			$headers[] = 'If-None-Match: '.$etag;
		}
		$curl->setOpt(CURLOPT_HTTPHEADER, $headers);

		$curl->get($thumb->originalUrl);

		if ($curl->http_status_code == 304) {
			// Unverändert geblieben
			return;
		}
		elseif ($curl->http_status_code >= 200 and $curl->http_status_code <= 203) {
			// Bild verarbeiten
			$imgdata = $curl->response;
			$sizes = \getimagesizefromstring($imgdata);
			$ratio = $sizes[0]/(float)$sizes[1];

			// 16:9-Vorschaubild umbauen
			if ($ratio > 8.7) {
				$img = \imagecreatefromstring($imgdata);
				$bg = \imagecolorallocatealpha($img, 0, 0, 0, 0);
				$cropped = \imagecropauto($img, IMG_CROP_THRESHOLD, 0.3, $bg);
				\imagecolordeallocate($img, $bg);
				if ($cropped !== false) {
					\imagedestroy($img);
					$img = $cropped;
				}
				$width = \imagesx($img);
				$oldheight = \imagesy($img);
				$newimg = \imagecreatetruecolor($width, (int)($width*0.75));
				$bg = \imagecolorallocatealpha($newimg, 0, 0, 0, 0);
				\imagefill($newimg, 0, 0, $bg);
				\imagecolordeallocate($newimg, $bg);
				\imagecopy($newimg, $img, 0, (int)((($width*0.75)-$oldheight)/2), 0, 0, $width, $oldheight);
				\imagedestroy($img);
				\ob_start();
				\imagejpeg($newimg, null, 90);
				$imgdata = ob_get_clean();
				\imagedestroy($newimg);
			}
			else {
				$width = $sizes[0];
			}

			$etag = '';
			$match = [];
			foreach ($curl->response_headers as $header) {
				if (preg_match('/^Etag:\s*((?:W\/)?"[^"]{1,64}")/i', $header, $match)) {
					$etag = $match[1];
					break;
				}
			}

			$thumb->width = $width;
			$thumb->etag = $etag;

			$this->saveThumbnail($embedInfo, $thumb, $imgdata);
		}
	}

	public function getEmbedInformation($url): ?EmbedInformation
	{
		$embedInfo = $this->fetchEmbedMetadata($url);
		if (!$embedInfo) {
			return null;
		}
		foreach ($embedInfo->thumbnails as $thumb) {
			$this->fetchThumbnail($embedInfo, $thumb);
		}
		return $embedInfo;
	}

	/**
	 * @return string|null
	 */
	protected function fetchText(string $url): ?string
	{
		$curl = new Curl;
		$curl->setOpt(CURLOPT_TIMEOUT, 4);
		$curl->setOpt(CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; CCM19; +http://ccm19.de)');
		$curl->get($url);

		try {
			if ($curl->http_status_code >= 200 and $curl->http_status_code <= 203) {
				return $curl->response;
			}
			else {
				return null;
			}
		}
		finally {
			$curl->close();
		}
	}

	/**
	 * @return mixed
	 */
	protected function fetchJson(string $url)
	{
		$data = $this->fetchText($url);

		if ($data !== null) {
			return @json_decode($data, true);
		}
		else {
			return null;
		}
	}

	protected function saveThumbnail(EmbedInformation $embedInfo, ThumbnailInformation $thumb, $data)
	{
		$hash = $embedInfo->getUrlHash();
		$path = $this->getThumbnailCachePath($hash, $thumb->width);

		@mkdir(dirname($path), 0775, true);

		file_put_contents($path.'.tmp', $data, LOCK_EX);
		rename($path.'.tmp', $path);

		$thumb->path = $path;
	}

	public static function getThumbnailCachePath(string $urlHash, int $width): string
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();

		# Hash bereinigen
		$urlHash = preg_replace('/[^a-zA-Z0-9]/', '', $urlHash);

		return sprintf('%s/thumbnails/%s/%s/%s/%s-%s.jpeg',
			Utils::getCacheDir(),
			($user ? $user->getId() : 'null'),
			($domain ? $domain->getId() : 'null'),
			substr($urlHash, 0, 2),
			$urlHash,
			$width
		);
	}
}
