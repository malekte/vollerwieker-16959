<?php

namespace App\Component\ThumbnailExtractor;

class VimeoThumbnailExtractor extends AbstractThumbnailExtractor
{
	const URL_REGEX = '~^(?:https?:)?//player\.vimeo\.com/video/(?<video_id>[0-9]{3,10})~i';

	public function supportsUrl(string $url): bool
	{
		if (preg_match(static::URL_REGEX, $url)) {
			
			return true;
		}
		else {
			return false;
		}
	}

	public function fetchEmbedMetadata(string $url): ?EmbedInformation
	{
		$match = [];
		preg_match(static::URL_REGEX, $url, $match);

		$videoId = $match['video_id'];

		$jsonUrl = 'https://vimeo.com/api/oembed.json?url=https%3A%2F%2Fvimeo.com%2F'.$videoId;
		$metaInfo = $this->fetchJson($jsonUrl);

		if ($metaInfo) {
			$title = $metaInfo['title'];
			$thumbnailUrl = $metaInfo['thumbnail_url'];
			$thumbnailWidth = $metaInfo['thumbnail_width'];
		}
		else {
			$title = '';
			$thumbnailUrl = '';
			$thumbnailWidth = 0;
		}

		// Daten und erstes Thumbnail zusammenfassen
		$result = new EmbedInformation();
		$result->type = 'video';
		$result->id = $videoId;
		$result->url = $url;
		$result->title = $title;
		$result->providerName = 'Vimeo';
		$result->thumbnails = [
			new ThumbnailInformation([
				'originalUrl' => $thumbnailUrl,
				'width'=> $thumbnailWidth,
			])
		];

		// Größeres Thumbnail bestimmen
		$urlbase = preg_replace('~_[0-9]{2,4}x[0-9]{2,4}\.jpg$~', '', $thumbnailUrl);
		if ($urlbase  !== $thumbnailUrl) {
			$result->thumbnails[] = new ThumbnailInformation([
				'originalUrl' => $urlbase . '.jpg?mw=800&mh=600',
				'width'=> 800,
			]);
		}

		return $result;
	}
}
