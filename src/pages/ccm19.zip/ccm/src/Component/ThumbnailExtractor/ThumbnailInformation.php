<?php

namespace App\Component\ThumbnailExtractor;

use App\Utils;

class ThumbnailInformation implements \JsonSerializable
{
	/** @var string $originalUrl */
	public $originalUrl = '';

	/** @var string $path */
	public $path = '';

	/** @var string $etag */
	public $etag = '';

	/** @var ?int */
	public $width = null;

	public function __construct($data=[])
	{
		$cache_path = Utils::getCacheDir() . '/';
		foreach ($data as $key => $value) {
			if ($key === 'path' and $value) {
				$value = $cache_path . $value;
			}
			$this->{$key} = $value;
		}
	}

	public function jsonSerialize() {
		$data = (array)$this;
		$data['path'] = substr($data['path'], strlen(Utils::getCacheDir() . '/'));
		return $data;
	}

}
