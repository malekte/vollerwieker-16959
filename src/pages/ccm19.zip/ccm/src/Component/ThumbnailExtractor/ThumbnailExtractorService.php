<?php

namespace App\Component\ThumbnailExtractor;

use App\Component\LoggerInterface;
use App\Model\User;
use App\Model\Domain;
use App\Utils;
use DateTime;
use DirectoryIterator;
use FilesystemIterator;

class ThumbnailExtractorService
{
	private $extractors = [];
	private $log;

	/**
	 * @param iterable $extractors
	 */
	public function __construct(iterable $extractors, LoggerInterface $log)
	{
		if (!is_array($extractors)) {
			$extractors = iterator_to_array($extractors);
		}
		$this->extractors = $extractors;
		$this->log = $log;
	}

	public function getEmbedInformation($url): ?EmbedInformation
	{
		$url = preg_replace('/#.*$/', '', $url);

		$embedInfo = $this->loadCachedEmbedInformation($url);
		// Cache über 12 Stunden unkonditional verwenden
		if ($embedInfo and $embedInfo->lastChecked >= new Datetime('now - 12 hour')) {
			return $embedInfo;
		}

		foreach ($this->extractors as $extractor) {
			try {
				if ($extractor->supportsUrl($url)) {
					$embedInfo = $extractor->getEmbedInformation($url, $embedInfo);
					if ($embedInfo) {
						$this->saveEmbedInformation($url, $embedInfo);
					}
					return $embedInfo;
				}
			} catch (\Exception $e) {
				$this->log->logException('ThumbnailExtractor', $e, sprintf('%s failed for URL %s',
					get_class($extractor),
					preg_replace('/\?.*/', '?…', $url)
				));
			}
		}
		return null;
	}

	private function getMetadataCachePath(string $url): string
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();

		# Hash berechnen
		$md5 = md5($url);

		return sprintf('%s/thumbnails/%s/%s/%s/%s.json',
			Utils::getCacheDir(),
			($user ? $user->getId() : 'null'),
			($domain ? $domain->getId() : 'null'),
			substr($md5, 0, 2),
			$md5
		);
	}

	private function saveEmbedInformation($url, EmbedInformation $embedInfo): void
	{
		$path = $this->getMetadataCachePath($url);

		$dir = dirname($path);
		@mkdir($dir, 0775, true);

		file_put_contents($path, json_encode($embedInfo), LOCK_EX);
	}

	private function loadCachedEmbedInformation($url): ?EmbedInformation
	{
		$path = $this->getMetadataCachePath($url);

		$f = @fopen($path, 'r');
		if ($f) {
			flock($f, LOCK_SH);
			try {
				$data = json_decode(stream_get_contents($f), true);
				$mtime = filemtime($path);
				$result = new EmbedInformation($data);
				$result->lastChecked = new Datetime();
				$result->lastChecked->setTimestamp($mtime);
				return $result;
			}
			finally {
				flock($f, LOCK_UN);
				fclose($f);
			}
		}
		return null;
	}

	public function clearCache(?User $user=null)
	{
		$cacheDir = Utils::getCacheDir() . DIRECTORY_SEPARATOR . 'thumbnails';
		$rnd = bin2hex(random_bytes(3));
		$suffix = '~'.date('Ymd').'-'.$rnd;

		if (!$user) {
			if (@rename($cacheDir, $cacheDir.$suffix)) {
				Utils::removeDirectory($cacheDir.$suffix);
			}
		}
		else {
			$userCacheDir = $cacheDir . DIRECTORY_SEPARATOR . $user->getId();
			if (@rename($userCacheDir, $userCacheDir.$suffix)) {
				Utils::removeDirectory($userCacheDir.$suffix);
			}
		}
	}

	public function pruneCache(?User $user=null, int $maxAge=3*86400)
	{
		$cacheDir = Utils::getCacheDir() . DIRECTORY_SEPARATOR . 'thumbnails';
		if ($user) {
			$cacheDir .= DIRECTORY_SEPARATOR . $user->getId();
		}

		$cutoffTimestamp = ((int)time()) - $maxAge;
		if (file_exists($cacheDir)) {
			$this->_pruneCacheRecurse(new FilesystemIterator($cacheDir), $maxAge);
		}
	}

	private function _pruneCacheRecurse(DirectoryIterator $it, int $cutoffTimestamp): void
	{
		$path = $it->getPath();
		$images = [];
		$jsons = [];
		foreach ($it as $fileinfo) {
			if ($fileinfo->isLink()) {
				continue;
			}
			elseif ($fileinfo->isDir()) {
				$this->_pruneCacheRecurse(new FilesystemIterator($fileinfo->getPathname()), $cutoffTimestamp);
			}
			elseif ($fileinfo->isFile()) {
				$ext = $fileinfo->getExtension();
				if ($ext == 'json') {
					// Veraltetes JSON löschen
					if ($fileinfo->getMTime() < $cutoffTimestamp) {
						@unlink($fileinfo->getPathname());
					} else {
						$jsons[$fileinfo->getBasename('.json')] = $fileinfo->getFilename();
					}
				}
				elseif ($ext == 'jpeg') {
					$stem = explode('-', $fileinfo->getBasename('.jpeg'), 2)[0];
					// Kandidaten zum Löschen sammeln
					if (!isset($jsons[$stem])) {
						if (!isset($images[$stem])) {
							$images[$stem] = [];
						}
						$images[$stem][] = $fileinfo->getPathname();
					}
				}
			}
		}

		// Bilder ohne passendes JSON löschen
		foreach ($images as $stem => $files) {
			if (!isset($jsons[$stem])) {
				foreach ($files as $file) {
					@unlink($file);
				}
			}
		}

		// Leeres Verzeichnis löschen
		if (count(scandir($path, SCANDIR_SORT_NONE)) <= 2) {
			@rmdir($path);
		}
	}
	
}
