<?php

namespace App\Component\ThumbnailExtractor;

class PeertubeThumbnailExtractor extends AbstractThumbnailExtractor
{
	const URL_REGEX = '~^(?<base>(?:https?:)?//[^/]*)/videos/embed/(?<video_id>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?:\?|$)~i';

	public function supportsUrl(string $url): bool
	{
		if (preg_match(static::URL_REGEX, $url)) {
			return true;
		}
		else {
			return false;
		}
	}

	public function fetchEmbedMetadata(string $url): ?EmbedInformation
	{
		$match = [];
		preg_match(static::URL_REGEX, $url, $match);

		$base = $match['base'];
		$videoId = $match['video_id'];

		if (substr($base, 0, 2) === '//') {
			$base = 'https:'.$base;
		}

		$jsonUrl = $base.'/services/oembed?url='.urlencode($base).'%2Fvideos%2Fwatch%2F'.$videoId;
		$metaInfo = $this->fetchJson($jsonUrl);

		if ($metaInfo) {
			$title = $metaInfo['title'];
			$providerName = $metaInfo['provider_name'] . ' (' . $metaInfo['provider_url'] . ')';
			$thumbnailUrl = $metaInfo['thumbnail_url'];
			$thumbnailWidth = $metaInfo['thumbnail_width'];
		}
		else {
			$title = '';
			$providerName = 'PeerTube (' . $base . ')';
			$thumbnailUrl = '';
			$thumbnailWidth = 0;
		}

		// Daten und erstes Thumbnail zusammenfassen
		$result = new EmbedInformation();
		$result->type = 'video';
		$result->id = $videoId;
		$result->url = $url;
		$result->title = $title;
		$result->providerName = $providerName;
		$result->thumbnails = [
			new ThumbnailInformation([
				'originalUrl' => $thumbnailUrl,
				'width'=> $thumbnailWidth,
			])
		];

		return $result;
	}
}
