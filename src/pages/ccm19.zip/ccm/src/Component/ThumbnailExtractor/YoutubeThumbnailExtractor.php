<?php

namespace App\Component\ThumbnailExtractor;

class YoutubeThumbnailExtractor extends AbstractThumbnailExtractor
{
	const URL_REGEX = '~^(?:https?:)?//(www\.)?youtube(?:-nocookie)?\..{2,3}/embed/(?<video_id>[\w-]{10,12})~i';

	public function supportsUrl(string $url): bool
	{
		if (preg_match(static::URL_REGEX, $url)) {
			
			return true;
		}
		else {
			return false;
		}
	}

	public function fetchEmbedMetadata(string $url): ?EmbedInformation
	{
		$match = [];
		preg_match(static::URL_REGEX, $url, $match);

		$videoId = $match['video_id'];

		$jsonUrl = 'https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v='.$videoId.'&format=json';
		$metaInfo = $this->fetchJson($jsonUrl);

		if ($metaInfo) {
			$title = $metaInfo['title'];
			$thumbnailUrl = $metaInfo['thumbnail_url'];
			$thumbnailWidth = $metaInfo['thumbnail_width'];
		}
		else {
			$title = '';
			$thumbnailUrl = '';
			$thumbnailWidth = 0;
		}

		// Daten und erstes Thumbnail zusammenfassen
		$result = new EmbedInformation();
		$result->type = 'video';
		$result->id = $videoId;
		$result->url = $url;
		$result->title = $title;
		$result->providerName = 'YouTube';
		$result->thumbnails = [
			new ThumbnailInformation([
				'originalUrl' => $thumbnailUrl,
				'width'=> $thumbnailWidth,
			])
		];

		// Weitere Thumbnail-Größen bestimmen
		$sizes = ['maxresdefault.jpg'=>1280, 'sddefault.jpg'=>640, 'hqdefault.jpg'=>480, 'mqdefault.jpg'=>320];
		$urlbase = preg_replace('~/[^/]*$~', '/', $thumbnailUrl);
		foreach ($sizes as $filename => $size) {
			if ($urlbase . $filename !== $thumbnailUrl) {
				$result->thumbnails[] = new ThumbnailInformation([
					'originalUrl' => $urlbase . $filename,
					'width'=> $size,
				]);
			}
		}

		return $result;
	}
}
