<?php

namespace App\Component\ThumbnailExtractor;

use DateTime;

class EmbedInformation implements \JsonSerializable
{
	/** @var string $type video/photo/link/rich (siehe OEmbed) */
	public $type = 'link';

	/** @var string $url Ursprüngliche URL des IFrames */
	public $url = '';

	/** @var string $id Video-ID der Plattform o.ä. (wird nur intern verwendet) */
	public $id = '';

	/** @var string $title Titel des eingebetteten Contents  */
	public $title = '';

	/** @var string $providerName Name des Providers (YouTube, Twitter usw.) */
	public $providerName = '';

	/** @var \DateTimeInterface $lastChecked */
	public $lastChecked;

	/** @var ThumbnailInformation[] $thumbnails */
	public $thumbnails = [];

	public function __construct($data=[])
	{
		$this->lastChecked = new DateTime();
		foreach ($data as $key => $value) {
			if ($key == 'thumbnails' and is_array($value)) {
				$this->{$key} = array_map(function ($item) {
					return new ThumbnailInformation($item);
				}, $value);
			}
			else {
				$this->{$key} = $value;
			}
		}
	}

	/**
	 * @override
	 * @return array
	 */
	public function jsonSerialize() {
		return array_filter((array)$this, function ($key) {
			if ($key === 'lastChecked') {
				return false;
			}
			return true;
		}, ARRAY_FILTER_USE_KEY);
	}

	/**
	 * Liste aller Thumbnails, die heruntergeladen werden konnten.
	 *
	 * @return ThumbnailInformation[]
	 */
	public function getUsableThumbnails(): array
	{
		return array_filter($this->thumbnails, function ($thumb) {
			if ($thumb->path and file_exists($thumb->path)) {
				return true;
			}
			else {
				return false;
			}
		});
	}

	public function getUrlHash(): string
	{
		return md5($this->url);
	}

}
