<?php

namespace App\Component\ThumbnailExtractor;

class FacebookVideoThumbnailExtractor extends AbstractThumbnailExtractor
{
	const URL_REGEX = '~^(?:https?:)?//(?:www\.)?facebook\.com/plugins/video\.php\?href=.{1,128}%2Fvideos%2F(?<video_id>[0-9]{1,20})%2F~i';
	const IMG_REGEX = '~<img\s+class="[^"]*\bimg"\s+src="(?<src>[^"]+)" ~i';
	const TITLE_REGEX = '~<a\s+href="(?:https?:)?//(?:www\.)?facebook\.com/watch/[^"]*"[^>]*>(?<title>[^<>]{0,255})</a>~i';

	public function supportsUrl(string $url): bool
	{
		if (preg_match(static::URL_REGEX, $url)) {
			
			return true;
		}
		else {
			return false;
		}
	}

	public function fetchEmbedMetadata(string $url): ?EmbedInformation
	{
		$match = [];
		preg_match(static::URL_REGEX, $url, $match);

		$videoId = $match['video_id'];

		// Iframe holen
		$html = $this->fetchText($url);

		if (preg_match(static::TITLE_REGEX, (string)$html, $match)) {
			$title = $match['title'];
		}
		else {
			$title = '';
		}

		// Daten zusammenfassen
		$result = new EmbedInformation();
		$result->type = 'video';
		$result->id = $videoId;
		$result->url = $url;
		$result->title = $title;
		$result->providerName = 'Facebook';
		$result->thumbnails = [];

		// Thumbnail suchen
		if (preg_match(static::IMG_REGEX, (string)$html, $match)) {
			$src = html_entity_decode($match['src']);
			$result->thumbnails[] = new ThumbnailInformation([
				'originalUrl' => $src,
				'width'=> 560,
			]);
		}

		return $result;
	}
}
