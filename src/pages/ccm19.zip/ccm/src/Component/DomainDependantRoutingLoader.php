<?php

namespace App\Component;

use App\Controller\DomainDependantController;
use App\EventSubscriber\DomainSelectionHandler;
use Symfony\Component\Config\Loader\Loader;
use Symfony\Bundle\FrameworkBundle\Routing\AnnotatedRouteControllerLoader;
use Symfony\Component\Routing\Route;
use Symfony\Component\Routing\RouteCollection;
use ReflectionClass;

class DomainDependantRoutingLoader extends AnnotatedRouteControllerLoader
{
	/**
	 * Lädt Routen aus Annotationen in PHP-Klassen.
	 *
	 * Für Domains aus DomainDependantController-Subklassen wird eine zweite
	 * Route ohne den /domain/…/-Präfix erzeugt (Redirect).
	 *
	 * @override
	 * @param string $class
	 * @param string|null $type
	 * @return RouteCollection
	 * @throws \InvalidArgumentException When route can't be parsed
	 */
	public function load($class, $type = null)
	{
		$collection = parent::load($class, $type);
		
		foreach ($collection as $name => $route) {
			$controllerClass = explode('::', $route->getDefault('_controller'), 2)[0];
			if ($controllerClass and is_subclass_of($controllerClass, DomainDependantController::class)) {
				$newRoute = clone $route;

				$path = substr($route->getPath(), strlen('/domains/{_domainId}'));
				$newRoute->setPath($path);

				$newRoute->setDefault('_controller', DomainSelectionHandler::class.'::redirectToDomain');
				$collection->add($name.'.nodomain', $newRoute);
			}
		}
		return $collection;
	}

}
