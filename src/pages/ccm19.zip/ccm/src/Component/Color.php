<?php

namespace App\Component;

use OutOfRangeException;
use LogicException;

class Color
{
	/** @var float $h */
	private $h = 0.0;
	/** @var float $s */
	private $s = 0.0;
	/** @var float $l */
	private $l = 0.0;
	/** @var int $rgb */
	private $rgb = 0;

	/**
	 * @see Color::fromHSL()
	 * @see Color::fromRGB()
	 *
	 * @param float[] $hsl ['h' => 0.f..360, 's' => 0..1, 'l' => 0..1]
	 * @param int $rgb 3-Byte RGB-Farbwert
	 * @throws OutOfRangeException bei aktivierten Assertions: wenn HSL-Werte out-of-range sind
	 */
	private function __construct(array $hsl, int $rgb)
	{
		$this->h = (float)$hsl['h'];
		$this->s = (float)$hsl['s'];
		$this->l = (float)$hsl['l'];
		$this->rgb = $rgb;
	}

	/**
	 * Color-Objekt aus HSL-Farbwert erzeugen
	 *
	 * @param float[] $hsl ['h' => 0.f..360, 's' => 0..1, 'l' => 0..1]
	 * @return Color
	 */
	public static function fromHSL(array $hsl): self
	{
		$rgb = Color::hsl2Rgb($hsl);
		return new self($hsl, $rgb);
	}

	/**
	 * Color-Objekt aus RGB-Farbwert erzeugen
	 *
	 * @param int $rgb 3-Byte RGB-Farbwert
	 * @return Color
	 */
	public static function fromRGB(int $rgb): self
	{
		$hsl = Color::rgb2Hsl($rgb);
		return new self($hsl, $rgb);
	}

	/**
	 * String-Darstellung der Farbe
	 *
	 * @note Eine eindeutige String-Darstellung ist wichtig,
	 *       damit array_unique() wie erwartet funktioniert.
	 * @return string HTML-Farbcode (#000000 - #FFFFFF)
	 */
	public function __toString(): string
	{
		return sprintf('#%06x', $this->rgb);
	}

	/**
	 * @return int RGB-Farbe als Integer
	 */
	public function getRgb(): int
	{
		return $this->rgb;
	}

	/**
	 * @return float[] Alle Komponenten des HSL-Farbwerts: ['h' => 0..360, 's' => 0..1, 'l' => 0..1]
	 */
	public function getHsl(): array
	{
		return [
			'h' => $this->h,
			's' => $this->s,
			'l' => $this->l,
		];
	}

	/**
	 * @return float|int Farbton in ° (0..360)
	 */
	public function getHue(): float
	{
		return $this->h;
	}

	/**
	 * @return float Sättigung (0..1)
	 */
	public function getSaturation(): float
	{
		return $this->s;
	}

	/**
	 * @return float Helligkeit (0..1)
	 */
	public function getLightness(): float
	{
		return $this->l;
	}

	/**
	 * @param float $saturation (0..1)
	 * @return $this
	 */
	private function setSaturation(float $saturation): self
	{
		$saturation = (float)min(max(0, $saturation), 1);

		if ($saturation < 0 || $saturation > 1) {
			throw new OutOfRangeException('Saturation value must be in the range 0..1');
		}

		$this->s = $saturation;
		$this->rgb = self::hsl2Rgb($this->getHsl());

		return $this;
	}

	/**
	 * @param float $lightness (0..1)
	 * @return $this
	 */
	private function setLightness(float $lightness): self
	{
		$lightness = (float)min(max(0, $lightness), 1);

		if ($lightness < 0 || $lightness > 1) {
			throw new OutOfRangeException('Lightness value must be in the range 0..1');
		}

		$this->l = $lightness;
		$this->rgb = self::hsl2Rgb($this->getHsl());

		return $this;
	}

	/**
	 * @param float $amount (0..1) Ein Wert zwischen 0, keine Änderung, und 1, voll abgedunkelt.
	 * @return $this
	 */
	public function darken(float $amount): self
	{
		$amount = (float)min(max(0, $amount), 1);

		$lightnessDecrease = $amount * $this->getLightness();
		$saturation = $amount * ((1.0 - $this->getSaturation()) / 2);

		$this->setLightness($this->getLightness() - $lightnessDecrease);
		$this->setSaturation($this->getSaturation() + $saturation);

		return $this;
	}

	/**
	 * @param float $amount (0..1) Ein Wert zwischen 0, keine Änderung, und 1, voll erhellt.
	 * @return $this
	 */
	public function lighten(float $amount): self
	{
		$amount = (float)min(max(0, $amount), 1);

		$lightnessIncrease = $amount * (1.0 - $this->getLightness());
		$desaturation = $amount * ($this->getSaturation() / 2);

		$this->setLightness($this->getLightness() + $lightnessIncrease);
		$this->setSaturation($this->getSaturation() - $desaturation);

		return $this;
	}

	/**
	 * Diese Methode wandelt einen RGB-Farbwert in entsprechende HSL-Komponenten um.
	 *
	 * @param int $rgb 3-Byte RGB-Farbwert
	 * @return array Alle Komponenten des HSL-Farbwerts: ['h' => 0..360, 's' => 0..1, 'l' => 0..1]
	 */
	public static function rgb2Hsl(int $rgb)
	{
		$r = ($rgb >> 16 & 0xff) / 255;
		$g = ($rgb >> 8 & 0xff) / 255;
		$b = ($rgb & 0xff) / 255;

		$max = max($r, $g, $b);
		$min = min($r, $g, $b);

		if ($max == $min) {
			$h = 0;
		}
		else if ($max == $r) {
			$h = 60 * (0 + ($g - $b) / ($max - $min));
		}
		else if ($max == $g) {
			$h = 60 * (2 + ($b - $r) / ($max - $min));
		}
		else if ($max == $b) {
			$h = 60 * (4 + ($r - $g) / ($max - $min));
		}
		else {
			throw new LogicException('fatal error while converting color value');
		}

		if ($h < 0) {
			$h += 360;
		}

		$s = $max == 0 || $min == 1 ? 0 : ($max - $min) / (1 - abs($max + $min - 1));

		$l = ($max + $min) / 2;

		return [
			'h' => $h,
			's' => $s,
			'l' => $l,
		];
	}

	/**
	 * Diese Methode wandelt einen HSL-kodierten Farbwert in den entsprechenden RGB-Farbwert um.
	 *
	 * Implementiert nach: https://en.wikipedia.org/wiki/HSL_and_HSV#From_HSL
	 *
	 * @param array $hsl ['h' => 0.f..360, 's' => 0..1, 'l' => 0..1]
	 * @return int 3-Byte RGB-Farbwert
	 */
	private static function hsl2Rgb(array $hsl)
	{
		$h = max(0, min($hsl['h'], 360));
		$s = max(0, min($hsl['s'], 1));
		$l = max(0, min($hsl['l'], 1));

		$c = (1 - abs(2 * $l - 1)) * $s;

		$h_ = $h / 60;

		// Absolut wichtig: nicht den normalen Integer-Modulo verwenden => 5.123 % 2 = 1; fmod(5.123, 2) = 1.123
		$x = $c * (1 - abs(fmod($h_, 2) - 1));

		if ($h_ >= 0 && $h_ <= 1) {
			list($r1, $g1, $b1) = [$c, $x, 0];
		}
		else if ($h_ > 1 && $h_ <= 2) {
			list($r1, $g1, $b1) = [$x, $c, 0];
		}
		else if ($h_ > 2 && $h_ <= 3) {
			list($r1, $g1, $b1) = [0, $c, $x];
		}
		else if ($h_ > 3 && $h_ <= 4) {
			list($r1, $g1, $b1) = [0, $x, $c];
		}
		else if ($h_ > 4 && $h_ <= 5) {
			list($r1, $g1, $b1) = [$x, 0, $c];
		}
		else if ($h_ > 5 && $h_ <= 6) {
			list($r1, $g1, $b1) = [$c, 0, $x];
		}
		else {
			list($r1, $g1, $b1) = [0, 0, 0];
		}

		$m = $l - $c / 2;

		list($r, $g, $b) = [
			(int)round(($r1 + $m) * 255),
			(int)round(($g1 + $m) * 255),
			(int)round(($b1 + $m) * 255),
		];

		return ($r << 16 & 0xff0000) + ($g << 8 & 0xff00) + ($b & 0xff);
	}
}
