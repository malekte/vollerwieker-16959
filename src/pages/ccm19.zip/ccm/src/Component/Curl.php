<?php

namespace App\Component;

use App\Utils;
use Curl\Curl as BaseCurl;
use Symfony\Component\HttpFoundation\HeaderBag;

/**
 * {@inheritdoc}
 */
class Curl extends BaseCurl
{

	/**
	 * Make a HEAD request with optional data.
	 *
	 * The get request has no body data, the data will be correctly added to the $url with the http_build_query() method.
	 *
	 * @param string $url  The url to make the HEAD request for
	 * @param array  $data Optional arguments who are part of the url
	 * @return self
	 */
	public function head(string $url, $data = []): self
	{
		if (count($data) > 0) {
			$this->setOpt(CURLOPT_URL, $url.'?'.http_build_query($data));
		} else {
			$this->setOpt(CURLOPT_URL, $url);
		}
		$this->setOpt(CURLOPT_NOBODY, true);
		$this->exec();
		return $this;
	}

	/**
	 * Get response headers as header bag instance
	 */
	public function getResponseHeaderBag(): HeaderBag
	{
		$headers = $this->response_headers;
		$headerbag = new HeaderBag;
		array_shift($headers);
		foreach ($headers as $headerline) {
			if (strpos($headerline, ':') !== false) {
				$header = explode(':', $headerline, 2);
				$headerbag->set(trim($header[0]), trim($header[1]));
			}
		}
		return $headerbag;
	}

	/**
	 * {@inheritdoc}
	 */
	public function __construct()
	{
		parent::__construct();
		$this->appInit();
	}

	/**
	 * {@inheritdoc}
	 */
	public function reset()
	{
		$result = parent::reset();
		$this->appInit();
		return $this;
	}

	/**
	 * Set application specific defaults
	 */
	private function appInit(): void
	{
		// Set user agent
		$version = Utils::getVersionName();
		$user_agent = "CCM19/$version (+https://ccm19.de)";
		$this->setUserAgent($user_agent);

		// Follow redirects by default
		$this->setOpt(CURLOPT_FOLLOWLOCATION, true);

		// Use APP_PROXY environment variable
		if (isset($_ENV['APP_PROXY'])) {
			$this->setOpt(CURLOPT_PROXY, $_ENV['APP_PROXY']);
		}
	}

	static public function installed(): bool
	{
		return \function_exists("curl_init");
	}

	public function getInfoArray()
    {
        return curl_getinfo($this->curl);
    }
}
