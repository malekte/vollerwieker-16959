<?php

namespace App\Component;

use App\Model\Domain;
use App\Model\User;

class ConfigImporterContext
{
	/** @var User|null $user */
	private $user;

	/** @var Domain|null $domain */
	private $domain;

	/**
	 * @param User|null $user
	 * @param Domain|null $domain
	 */
	public function __construct(?User $user = null, ?Domain $domain = null)
	{
		$this->user = $user;
		$this->domain = $domain;
	}

	/**
	 * @return User|null
	 */
	public function getUser(): ?User
	{
		return $this->user;
	}

	/**
	 * @param User $user
	 * @return $this
	 */
	public function setUser(User $user): self
	{
		$this->user = $user;
		return $this;
	}

	/**
	 * @return bool
	 */
	public function hasUser(): bool
	{
		return (bool)$this->getUser();
	}

	/**
	 * @return Domain|null
	 */
	public function getDomain(): ?Domain
	{
		return $this->domain;
	}

	/**
	 * @param Domain $domain
	 * @return $this
	 */
	public function setDomain(Domain $domain): self
	{
		$this->domain = $domain;
		return $this;
	}

	/**
	 * @return bool
	 */
	public function hasDomain(): bool
	{
		return (bool)$this->getDomain();
	}
}
