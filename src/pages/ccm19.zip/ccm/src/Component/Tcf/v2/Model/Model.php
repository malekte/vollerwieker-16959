<?php

namespace App\Component\Tcf\v2\Model;

use App\Exception\ConfigNotReadableException;
use App\Component\Config\ModelInterface;
use App\Component\Tcf\v2\Repository;
use LogicException;

/**
 * Basisklasse für TCFv2 Models
 */
abstract class Model implements ModelInterface
{
	/** @var array $dataset */
	private $dataset;

	/** @var string|null $repositoryFilename */
	protected static $repositoryFilename = null;

	/** @var string|null $repositoryKey */
	protected static $repositoryKey = null;

	/**
	 * @param array $dataset
	 */
	protected function __construct(array $dataset)
	{
		$this->dataset = $dataset;
	}

	/**
	 * Diese Methode stellt die Konfiguration des aktuellen Models bereit.
	 * @return Repository
	 * @phan-suppress PhanUndeclaredStaticProperty
	 * @phan-suppress PhanUndeclaredStaticMethod
	 */
	protected static function getRepository(): Repository
	{
		if (static::$repository === null) {
			static::$repository = static::openRepository();
		}
		return static::$repository;
	}

	/**
	 * Diese Methode stellt die Konfiguration des aktuellen Models bereit und lädt dieses ggf. neu.
	 *
	 * @return Repository
	 */
	protected static function openRepository(): Repository
	{
		$repoFilename = static::$repositoryFilename;

		// Gewährleisten, dass dem Model ein Dateiname als Repository beiliegt
		if (empty($repoFilename)) {
			throw new LogicException('No repository defined for '.static::class);
		}
		if (empty(static::$repositoryKey)) {
			throw new LogicException('No repository key defined for '.static::class);
		}

		return Repository::load($repoFilename);
	}

	/**
	 * @param string $id
	 * @return bool
	 */
	public static function exists(string $id): bool
	{
		return is_array(self::getRepository()->get(static::$repositoryKey.'.'.$id));
	}

	/**
	 * @param string $id
	 * @return static|null
	 * @phan-suppress PhanTypeInstantiateAbstractStatic
	 */
	public static function find(string $id): ?self
	{
		return self::exists($id) ? new static(self::getRepository()->get(static::$repositoryKey.'.'.$id)) : null;
	}

	/**
	 * @return static[]
	 * @phan-suppress PhanTypeInstantiateAbstractStatic
	 */
	public static function all(): array
	{
		/** @var static[] $entities */
		$entities = [];

		foreach (self::getRepository()->get(static::$repositoryKey) as $id => $data) {
			$entities[$id] = new static($data);
		}

		return $entities;
	}

	/**
	 * Zählt die vorhandenen Instanzen dieses Models.
	 * @return int
	 */
	public static function count(): int
	{
		return count(self::getRepository()->get(static::$repositoryKey));
	}

	/**
	 * Größe des Repositories auf der Festplatte in Bytes, ohne ungespeicherte Änderungen
	 *
	 * @return int Größe in Bytes
	 */
	public static function persistedRepositorySize(): int
	{
		return static::getRepository()->getPersistedSize();
	}

	/**
	 * @param string $property
	 * @param mixed|null $fallback
	 * @return mixed
	 * @see JsonConfig::get()
	 */
	protected final function get(string $property, $fallback = null)
	{
		return isset($this->dataset[$property]) ? $this->dataset[$property] : $fallback;
	}

	/**
	 * Liest alle Einträge neu von der Festplatte oder ggf. dem Internet ein.
	 * @throws ConfigNotReadableException
	 */
	public static function reload(): void
	{
		self::getRepository()->reload();
	}

	/**
	 * @return string
	 */
	public final function getId(): string
	{
		return (string)$this->get('id');
	}
}
