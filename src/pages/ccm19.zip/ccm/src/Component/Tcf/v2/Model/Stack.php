<?php

namespace App\Component\Tcf\v2\Model;

use App\Component\Tcf\v2\Repository;

class Stack extends Model
{
	protected static $repositoryFilename = 'vendor-list.json';
	protected static $repositoryKey = 'stacks';

	/** @var Repository|null $repository */
	protected static $repository = null;

	public function getName(): string
	{
		return $this->get('name');
	}

	public function getDescription(): string
	{
		return $this->get('description');
	}

	/**
	 * @return Purpose[]
	 */
	public function getPurposes(): array
	{
		return array_map(function ($id) {
			return Purpose::find($id);
		}, $this->get('purposes'));
	}

	/**
	 * @return SpecialFeature[]
	 */
	public function getSpecialFeatures(): array
	{
		return array_map(function ($id) {
			return SpecialFeature::find($id);
		}, $this->get('specialFeatures'));
	}

	public function __toString(): string
	{
		return sprintf('[TCFv2 Stack %s: "%s"]', $this->getId(), $this->getName());
	}
}
