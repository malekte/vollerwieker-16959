<?php

namespace App\Component\Tcf\v2;

use App\Exception\ConfigNotWritableException;
use App\Exception\ConfigNotReadableException;
use App\Exception\DownloaderHTTPException;
use App\Component\Curl;
use App\Utils;
use InvalidArgumentException;

final class Repository
{
	/** @var self[] $instances*/
	static private $instances = [];

	/** @var string $filename */
	private $filename;

	/** @var array $data */
	private $data;

	/** @var bool $dirty */
	private $dirty;

	/** @var bool $dirty */
	private $writeLocked;

	/** @var resource */
	private $handle;

	/**
	 * Lädt eine TCFv2-Datendatei.
	 * @param string $filename
	 * @return self
	 */
	static public function load(string $filename): self
	{
		$filename = strtolower($filename);
		if (isset(self::$instances[$filename])) {
			return self::$instances[$filename];
		}

		$instance = new static($filename);

		self::$instances[$filename] = $instance;
		return $instance;
	}

	/**
	 * Lädt eine TCFv2-Datendatei.
	 * @param string $filename
	 */
	private function __construct(string $filename)
	{
		$this->filename = $filename;

		$data = [];
		// Wenn die Datei existiert, wird sie eingelesen, andernfalls wird versucht, sie herunterzuladen.
		$this->reload();
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @return string
	 */
	private function getPathname(): string
	{
		@mkdir(Utils::getVarDir() . DIRECTORY_SEPARATOR . 'tcfv2');
		return Utils::getVarDir() . DIRECTORY_SEPARATOR . 'tcfv2' . DIRECTORY_SEPARATOR . $this->filename;
	}

	/**
	 * @return array
	 */
	public function toArray(): array
	{
		return $this->data;
	}

	/**
	 * Größe des Repositories auf der Festplatte in Bytes, ohne ungespeicherte Änderungen
	 *
	 * @return int Größe in Bytes
	 */
	public function getPersistedSize(): int
	{
		return (int)@filesize($this->getPathname());
	}

	/**
	 * Diese Methode liest Daten aus der Konfiguration. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $fallback
	 * @return mixed
	 */
	public function get(string $identifier, $fallback = null)
	{
		$nodeNames = array_values(array_filter(explode('.', $identifier), function ($str) { return strlen($str) > 0; }));
		if (count($nodeNames) == 0) {
			return $fallback;
		}

		$value = $fallback;

		try {
			$value = array_reduce($nodeNames, function ($node, $key) use ($identifier) {
				if (is_array($node) && array_key_exists($key, $node)) {
					return $node[$key];
				}
				else {
					throw new InvalidArgumentException("TCF data `$identifier` not found.");
				}
			}, $this->data);
		} catch (InvalidArgumentException $exception) {}

		return $value;
	}

	/**
	 * Angepeilter Download-Intervall in Sekunden
	 *
	 * @param int $fallback
	 * @return int
	 */
	private function getDownloadInterval(int $fallback=86400): int
	{
		$path = $this->getPathname().'.maxage';
		return (int)(@file_get_contents($path) ?: $fallback);
	}

	/**
	 * Ob ein neuer Download durchgeführt werden sollte
	 *
	 * @return bool
	 */
	private function isStale(): bool
	{
		$path = $this->getPathname();
		return (!file_exists($path) or time() > (int)(@filemtime($path)) + $this->getDownloadInterval());
	}

	/**
	 * Lädt eine neue Version einer Datei von consenseu.org herunter.
	 *
	 * Wenn parallel schon ein anderer Prozess die Datei herunterlädt,
	 * wird, wenn es noch keine gecachte Datei gibt, der Prozess abgewartet,
	 * und ansonsten direkt FALSE zurück gegeben.
	 *
	 * @return bool FALSE, wenn ein paralleler Prozess schon ein Update durchführt,
	 *              das nicht abgewartet wurde.
	 * @throws DownloaderHTTPException
	 */
	private function download(): bool
	{
		$url = 'https://vendorlist.consensu.org/v2/'.$this->filename;
		$destfile = $this->getPathname();
		$maxagefile = $destfile.'.maxage';
		$tmpfile = $destfile.'.tmp';
		$mtime = @filemtime($destfile);
		$maxage = (int)(@file_get_contents($maxagefile) ?: 86400);

		$f = fopen($tmpfile, 'cb+');
		if (!$f) {
			throw new ConfigNotWritableException($tmpfile);
		}
		// Versuchen, die Datei exklusiv zu sperren
		if (flock($f, LOCK_EX | LOCK_NB)) {
			try {
				$curl = new Curl();

				// If-Not-Modified-Since setzen
				if ($mtime) {
					$curl->setOpt(CURLOPT_TIMEVALUE, $mtime);
					$curl->setOpt(CURLOPT_TIMECONDITION, CURL_TIMECOND_IFMODSINCE);
				}

				// Direkten Download in geöffnete Datei durchführen
				$curl->setOpt(CURLOPT_FILE, $f);
				$curl->get($url);

				// Status prüfen
				$status = $curl->getHttpStatus();
				if ($status == 304) {
					// Wenn "Not Modified": mtime anpassen, sodass es in spätestens 12 Stunden noch mal versucht wird
					touch($destfile, time()-max($maxage-43200, 0));
					@unlink($tmpfile);
					return true;
				}
				elseif ($status == 200) {
					// Wenn "Ok": Intervall merken und umbenennen

					// Max-Age-Intervall aus Headern extrahieren und speichern
					$cacheinfo = $curl->getResponseHeaders('Cache-Control') ?: '';
					$maxage_match = [];
					preg_match('/(?:^|\s|,)max-age=([0-9]+)/i', $cacheinfo, $maxage_match);
					if ($maxage_match) {
						file_put_contents($maxagefile, $maxage_match[1]);
					} else {
						// Default to 24 h
						file_put_contents($maxagefile, '86400');
					}

					// Mtime setzen
					$mtime = @strtotime($curl->getResponseHeaders('Last-Modified'));
					if ($mtime) {
						touch($tmpfile, $mtime);
					}

					// Umbenennen
					if (!rename($tmpfile, $destfile)) {
						throw new ConfigNotWritableException($destfile);
					}
				}
				else {
					// Exception bei anderen HTTP-Fehlern
					throw new DownloaderHTTPException($url, $curl->getHttpStatus());
				}
			}
			catch (\Throwable $e) {
				@unlink($tmpfile);
				throw $e;
			}
			finally {
				flock($f, LOCK_UN);
				fclose($f);
			}
			return true;
		}
		// Wenn noch keine Zieldatei vorhanden, aber ein anderer Update-Prozess läuft, diesen abwarten
		elseif (!file_exists($destfile)) {
			flock($f, LOCK_SH);
			flock($f, LOCK_UN);
			fclose($f);
			clearstatcache(false, $destfile);
			return true;
		}
		// Ansonsten einfach abbrechen
		else {
			return false;
		}
	}

	/**
	 * Diese Methode liest die Datendatei erneut von der Festplatte oder aus dem Internet ein.
	 *
	 * @param bool $mayUpdate Ob ein Update aus dem Internet durchgeführt werden darf
	 *
	 * @throws ConfigNotReadableException
	 * @throws DownloaderHTTPException
	 */
	public function reload(bool $mayUpdate=true): void
	{
		$path = $this->getPathname();

		if ($mayUpdate && $this->isStale()) {
			$this->download();
		}

		// Datei öffnen
		try {
			$content = file_get_contents($path);
		}
		catch (\ErrorException $e) {
			throw new ConfigNotReadableException($path, '', 0, $e);
		}
		$this->data = json_decode($content, true) ?: [];
	}

}
