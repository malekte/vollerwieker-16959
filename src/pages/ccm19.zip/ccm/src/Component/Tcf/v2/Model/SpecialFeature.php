<?php

namespace App\Component\Tcf\v2\Model;

use App\Component\Tcf\v2\Repository;

class SpecialFeature extends Model
{
	protected static $repositoryFilename = 'vendor-list.json';
	protected static $repositoryKey = 'specialFeatures';

	/** @var Repository|null $repository */
	protected static $repository = null;

	public function getName(): string
	{
		return $this->get('name');
	}

	public function getDescription(): string
	{
		return $this->get('description');
	}

	public function getLegalDescription(): string
	{
		return $this->get('descriptionLegal');
	}

	public function __toString(): string
	{
		return sprintf('[TCFv2 Special Feature %1: "%2"]', $this->getId(), $this->getName());
	}
}
