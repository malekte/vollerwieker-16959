<?php

namespace App\Component\Tcf\v2\Model;

use App\Component\Tcf\v2\Repository;
use \DateTimeInterface;
use \DateTime;

class Vendor extends Model
{
	protected static $repositoryFilename = 'vendor-list.json';
	protected static $repositoryKey = 'vendors';

	/** @var Repository|null $repository */
	protected static $repository = null;

	public function getName(): string
	{
		return $this->get('name');
	}

	public function getPolicyUrl(): string
	{
		return $this->get('policyUrl');
	}

	/**
	 * @return Purpose[]
	 */
	public function getPurposes(): array
	{
		return array_map(function ($id) {
			return Purpose::find($id);
		}, $this->get('purposes'));
	}

	/**
	 * @return Purpose[]
	 */
	public function getFlexiblePurposes(): array
	{
		return array_map(function ($id) {
			return Purpose::find($id);
		}, $this->get('flexiblePurposes'));
	}

	/**
	 * @return int[]
	 */
	public function getFlexiblePurposeIds(): array
	{
		return (array)$this->get('flexiblePurposes');
	}

	/**
	 * @return Purpose[]
	 */
	public function getLegitimateInterestPurposes(): array
	{
		return array_map(function ($id) {
			return Purpose::find($id);
		}, $this->get('legIntPurposes'));
	}

	/**
	 * @return SpecialPurpose[]
	 */
	public function getSpecialPurposes(): array
	{
		return array_map(function ($id) {
			return SpecialPurpose::find($id);
		}, $this->get('specialPurposes'));
	}

	/**
	 * @return Feature[]
	 */
	public function getFeatures(): array
	{
		return array_map(function ($id) {
			return Feature::find($id);
		}, $this->get('features'));
	}

	/**
	 * @return SpecialFeature[]
	 */
	public function getSpecialFeatures(): array
	{
		return array_map(function ($id) {
			return SpecialFeature::find($id);
		}, $this->get('specialFeatures'));
	}

	/**
	 * @return DateTimeInterface|null
	 */
	public function getDeletedDate(): ?DateTimeInterface
	{
		$data = $this->get('deletedDate');
		return ($data ? new DateTime($data) : null);
	}

	public function isDeleted(): bool
	{
		$date = $this->getDeletedDate();
		if ($date) {
			return $date <= (new DateTime('now'));
		} else {
			return false;
		}
	}

	public function getHttpGetLimit(): ?int
	{
		$data = $this->get('overflow');
		return $data['httpGetLimit'] ?? null;
	}

	public function __toString(): string
	{
		return sprintf('[TCFv2 Vendor %s: "%s"]', $this->getId(), $this->getName());
	}
}
