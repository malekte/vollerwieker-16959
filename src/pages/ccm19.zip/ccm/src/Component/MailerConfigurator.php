<?php

namespace App\Component;

use App\Utils;
use App\Component\Curl;

class MailerConfigurator
{
	private $config;

	public function __construct()
	{
	}

	/**
	 * Setzt die Mailserver-Einstellungen.
	 *
	 * Bei sendmail wird der Pfad aus der PHP-INI berücksichtigt.
	 *
	 * @see https://symfony.com/doc/current/reference/configuration/swiftmailer.html
	 * @param string $scheme
	 * @param string|null $host
	 * @param int|string|null $port
	 * @param string $encryption
	 * @param string $auth_mode
	 * @param string $user
	 * @param string $pass
	 * @return void
	 */
	public function setMailer(string $scheme, ?string $host=null, $port=null, string $encryption='', string $auth_mode='', string $user='', string $pass=''): void
	{
		if ($scheme == 'null') {
			$url = 'null://localhost';
		}
		elseif ($scheme == 'sendmail') {
			$url = 'sendmail://localhost';
			$sendmail_path = ini_get('sendmail_path');
			if ($sendmail_path) {
				if (strpos($sendmail_path, '-t') === false and strpos($sendmail_path, '-bs') === false) {
					$sendmail_path .= ' -t';
				}
				$url .= '?'.http_build_query(['command'=>$sendmail_path], '', '&');
			}
		}
		else {
			$url = rawurlencode($scheme) . '://' . rawurlencode($host);
			if ($port) {
				$url .= ':'.$port;
			}
			$options = [];
			if ($user !== '') {
				$options['username'] = $user;
			}
			if ($pass !== '') {
				$options['password'] = $pass;
			}
			if ($encryption !== '') {
				$options['encryption'] = $encryption;
			}
			if ($auth_mode !== '') {
				$options['auth_mode'] = $auth_mode;
			}
			if ($options) {
				$url .= '?'.http_build_query($options, '', '&');
			}
		}

		Utils::setLocalEnvironment(['MAILER_URL'=>$url]);
	}


	/**
	 * Liest eine E-Mail-Autokonfigurations-Datei
	 *
	 * @see https://developer.mozilla.org/en-US/docs/Mozilla/Thunderbird/Autoconfiguration
	 * @param string $url
	 * @return array
	 */
	public function readConfigXml($url): array
	{
		$curl = new Curl;
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 3);
		$curl->setOpt(CURLOPT_TIMEOUT, 7);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$curl->close();

		if (!$resultData) {
			return [];
		}

		$root = @simplexml_load_string($resultData);
		if ($root === false) {
			return [];
		}

		$result = [];
		foreach ($root->emailProvider as $provider)
		{
			$domain = (string)($provider->domain);
			$servers = [];
			foreach ($provider->outgoingServer as $server) {
				$auths = [];
				foreach ($server->authentication as $auth) {
					$auth = (string)$auth;
					$auths[strtolower($auth)] = $auth;
				}
				$servers[] = [
					'type' => (string)($server['type'] ?? 'smtp'),
					'hostname' => (string)$server->hostname,
					'port' => (string)$server->port,
					'socketType' => (string)$server->socketType,
					'authentication' => $auths,
					'username' => (string)$server->username,
				];
			}
			$result[$domain] = $servers;
		}
		return $result;
	}

	/**
	 * @param resource $s
	 * @return array ['starttls'=>bool, 'auth'=>string[]]
	 */
	private function parseEhlo($s): array
	{
		$starttls = false;
		$auth = [];
		do {
			$line = fgets($s, 1024);
			if (substr($line, 0, 12) === '250-STARTTLS') {
				$starttls = true;
			}
			if (substr($line, 0, 8) === '250-AUTH') {
				foreach (explode(' ', substr(trim($line), 9)) as $method) {
					$method = trim($method);
					if ($method) {
						$auth[strtoupper($method)] = strtolower($method);
					}
				}
			}
		}
		while (substr($line, 0, 4) === '250-');
		return ['starttls'=>$starttls, 'auth'=>$auth];
	}

	/**
	 * Testet die Verbindung zu einem E-Mail-Server.
	 *
	 * @param string $host
	 * @param int|string $port
	 * @return array ['starttls'=>bool, 'auth'=>string[]]
	 */
	public function testEmailServer($host, $port, bool $ssl): array
	{
		$context = stream_context_create();
		stream_context_set_option($context, 'ssl', 'verify_peer_name', false);

		if (!is_int($port) and !is_numeric($port)) {
			$port = getservbyname($port, 'tcp');
		}
		$myhostname = gethostname();
		$url = sprintf('%s://%s:%d', ($ssl ? 'ssl' : 'tcp'), rawurlencode($host), $port);
		$errno = $error = null;
		$s = @stream_socket_client($url, $errno, $error, 3, STREAM_CLIENT_CONNECT, $context);

		if (!$s) {
			return [];
		}

		// Receive initial greeting
		$helo = fgets($s, 1024);
		if (substr($helo, 0, 4) !== '220 ') {
			@stream_socket_shutdown($s, STREAM_SHUT_RDWR);
			@fclose($s);
			return [];
		}

		// Greet back
		fwrite($s, "EHLO $myhostname\r\n");

		// Read capabilities
		$ehloData = $this->parseEhlo($s);
		$starttls = $ehloData['starttls'];
		$auth = $ehloData['auth'];

		// Try STARTTLS and read auth information
		if ($starttls and !$ssl) {
			fwrite($s, "STARTTLS\r\n");
			$resp = fgets($s, 1024);
			if (substr($resp, 0, 4) === '220 ') {
				stream_socket_enable_crypto($s, true, STREAM_CRYPTO_METHOD_ANY_CLIENT);
				fwrite($s, "EHLO $myhostname\r\n");
				$ehloData = $this->parseEhlo($s);
				$auth = array_merge($auth, $ehloData['auth']);
			}
		}

		@fwrite($s, "QUIT\r\n");
		@fgets($s, 1024);
		@stream_socket_shutdown($s, STREAM_SHUT_RDWR);
		@fclose($s);
		return ['starttls'=>$starttls, 'auth'=>$auth];
	}

	/**
	 * Ersetzt adressenbezogene Variablen
	 *
	 * @param string $string Inhalt mit möglichen Platzhaltern
	 * @param string $email E-Mail-Adresse
	 * @return string Inhalt mit durchgeführten Ersetzungen
	 */
	public function autoconfigReplaceVars(string $string, string $email): string
	{
		$domain = substr($email, strrpos($email, '@')+1);
		$localpart = substr($email, 0, strrpos($email, '@'));
		$string = str_replace('%EMAILADDRESS%', $email, $string);
		$string = str_replace('%EMAILLOCALPART%', $localpart, $string);
		$string = str_replace('%EMAILDOMAIN%', $domain, $string);
		$string = preg_replace('/%[^%]+%/', '', $string);
		return $string;
	}


}
