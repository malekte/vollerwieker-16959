<?php
namespace App\Event;
use Symfony\Contracts\EventDispatcher\Event;

final class StatisticsDisplayEvent extends Event
{
	const NAME = 'ccm19.statistics.display';
}
