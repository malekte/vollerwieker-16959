<?php
namespace App\Event;
use Symfony\Contracts\EventDispatcher\Event;

final class StatisticsCronJobEvent extends Event
{
	const NAME = 'ccm19.statistics.cronjob';
	private $fullUpdate;

	public function __construct(bool $fullUpdate = true)
	{
		$this->fullUpdate = $fullUpdate;
	}

	public function isFullUpdateRequested(): bool
	{
		return $this->fullUpdate;
	}

}
