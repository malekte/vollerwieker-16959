<?php
namespace App\Event;
use Symfony\Contracts\EventDispatcher\Event;

final class ProtocolRotateEvent extends Event
{
	const NAME = 'ccm19.protocol.rotate';
}
