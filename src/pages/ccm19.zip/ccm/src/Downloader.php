<?php

namespace App;
use Throwable;
use RuntimeException;
use DateTime;
use App\Component\Curl;
use App\Exception\DownloaderException;
use App\Exception\DownloaderHTTPException;
use App\Utils;

/**
 * Klasse zum Herunterladen großer Dateien
 */
class Downloader
{
	private static $options = [
		'http' => [
			'method' => CURLOPT_CUSTOMREQUEST,
			'content' => CURLOPT_POSTFIELDS,
		],
		'ssl' => [
			'cafile' => CURLOPT_CAINFO,
			'capath' => CURLOPT_CAPATH,
		],
	];

	/* @var string */
	private $url;
	/** @var Curl $curl */
	private $curl;
	/** @var ?resource $progressFile */
	private $progressFile;
	/** @var ?string $progressPath */
	private $progressPath;
	
	/**
	 * @param string $url URL
	 * @param ?string $progressFile Datei in die Fortschrittsdaten geschrieben werden
	 */
	public function __construct($url, $progressFile=null)
	{
		$this->url = $url;
		$this->curl = new Curl();
		$this->progressPath = $progressFile;
	}

	/**
	 * Download der URL in eine Datei
	 *
	 * @param string $destination Zieldateipfad
	 * @param bool $atomic Wenn TRUE wird erst in eine temporäre
	 *             Datei geschrieben und dann umbenannt/ersetzt.
	 * @param string[] $headers Extra-Header zum Übergeben an Curl
	 * @return array Curl-Info-Daten
	 * @throws DownloaderException
	 */
	public function downloadInto($destination, $atomic=false, $headers=[]): array
	{
		// Zielpfad bestimmen
		if ($atomic) {
			$rnd = random_bytes(3);
			$tmpDestination = $destination.'.'.bin2hex($rnd).'.tmp';
		} else {
			$tmpDestination = $destination;
		}

		// Fortschritts-Info-Datei öffnen
		$progressPath = $this->progressPath;
		if ($progressPath) {
			$this->progressFile = fopen($progressPath, 'w+');
			$time = new DateTime('now');
			fwrite($this->progressFile, json_encode(['total'=>0, 'current'=>0, 'ts'=>$time->format('Y-m-d H:i:s')]));
		} else {
			$this->progressFile = fopen('php://memory', 'w+');
		}

		// Zieldatei öffnen
		$f = fopen($tmpDestination, 'wb');
		flock($f, LOCK_EX);

		$result = false;
		try {
			// Curl configurieren
			if ($headers) {
				$this->curl->setOpt(CURLOPT_HTTPHEADER, $headers);
			}
			$this->curl->setOpt(CURLOPT_RETURNTRANSFER, false);
			$this->curl->setOpt(CURLOPT_FILE, $f);
			$this->curl->setOpt(CURLOPT_NOPROGRESS, false);
			$this->curl->setOpt(CURLOPT_PROGRESSFUNCTION, [$this, 'onProgress']);
			$this->curl->setOpt(CURLOPT_REFERER, Utils::getFullUrl());

			// Download starten
			$this->curl->get($this->url);

			if ($this->curl->error and $this->curl->getErrorCode()) {
				throw new DownloaderException($this->curl->getErrorMessage(), (int)$this->curl->getErrorCode());
			}

			// Alles nicht mit HTTP-Statuscode 200-203 als Download-Fehler behandeln
			$code = $this->curl->getHttpStatus();
			if ($code < 200 or $code > 203) {
				throw new DownloaderHTTPException(file_get_contents($tmpDestination), $code);
			}

			if ($destination !== $tmpDestination) {
				rename($tmpDestination, $destination);
			}

		}
		catch (Throwable $e) {
			if ($destination !== $tmpDestination) {
				@unlink($tmpDestination);
			}
			throw $e;
		}
		finally {
			fclose($this->progressFile);
			if ($progressPath) {
				unlink($progressPath);
			}
			$this->progressFile = null;
		}
		
		if (!$this->curl->error) {
			return $this->curl->getInfoArray();
		} else {
			throw new DownloaderException($this->curl->getErrorMessage(), (int)$this->curl->getErrorCode());
		}
	}

	/**
	 * Callback-Funktion für Curl: schreibt den Fortschritt des Downloads in die
	 * Fortschritts-JSON-Datei.
	 *
	 * @param resource $curl
	 * @param int $totalBytes
	 * @param int $currentBytes
	 * @param int $uploadTotalBytes
	 * @param int $uploadCurrentBytes
	 * @return void
	 */
	public function onProgress($curl, $totalBytes, $currentBytes, $uploadTotalBytes, $uploadCurrentBytes)
	{
		$f = $this->progressFile;
		flock($f, LOCK_EX);
		$time = new DateTime('now');
		fseek($f, 0);
		fwrite($f, json_encode(['total'=>$totalBytes, 'current'=>$currentBytes, 'ts'=>$time->format('Y-m-d H:i:s')]));
		ftruncate($f, ftell($f));
		flock($f, LOCK_UN);
	}
	
}
