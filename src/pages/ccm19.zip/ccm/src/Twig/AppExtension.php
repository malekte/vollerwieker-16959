<?php

namespace App\Twig;

use App\Component\Color;
use App\Model\Placeholder;
use Twig\Environment;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;
use Twig\TwigFilter;

class AppExtension extends AbstractExtension
{
	/**
	 * @return TwigFunction[]
	 */
	public function getFunctions(): array
	{
		return [
			new TwigFunction('in_route', [$this, 'inRoute'], ['needs_environment' => true]),
			new TwigFunction('darken', [$this, 'darkenColor']),
			new TwigFunction('lighten', [$this, 'lightenColor']),
			new TwigFunction('checked', [$this, 'checked'], ['is_safe' => ['html']]),
		];
	}

	/**
	 * @return TwigFilter[]
	 */
	public function getFilters(): array
	{
		return [
			new TwigFilter('hover', [$this, 'hoverColor']),
			new TwigFilter('trunc_url', [$this, 'truncUrl']),
			new TwigFilter('format_bytes', [$this, 'formatBytes']),
			new TwigFilter('replace_placeholders', [$this, 'replacePlaceholders'], ['pre_escape' => 'html', 'is_safe' => ['html']]),
			new TwigFilter('checked', [$this, 'checked'], ['is_safe' => ['html']]),
			new TwigFilter('selected', [$this, 'selected'], ['is_safe' => ['html']]),
		];
	}

	/**
	 * @param Environment $env
	 * @param string $name
	 * @return bool
	 * @phan-suppress PhanAccessMethodInternal
	 */
	public function inRoute(Environment $env, $name)
	{
		$vars = $env->getGlobals();
		$app = $vars['app'];
		$route = $app->getRequest()->attributes->get('_route');

		return fnmatch($name, $route);
	}

	/**
	 * @param int|string $bytes
	 * @return string
	 */
	public function formatBytes($bytes)
	{
		if ($bytes > 900 * 1024 * 1024) {
			return number_format($bytes / 1024 / 1024 / 1024, 1, ',', '&thinsp;') .' GiB';
		}
		if ($bytes > 900 * 1024) {
			return number_format($bytes / 1024 / 1024, 1, ',', '&thinsp;') .' MiB';
		}
		if ($bytes > 900) {
			return number_format($bytes / 1024, 1, ',', '&thinsp;') .' KiB';
		}
		return number_format($bytes, 0, ',', '&thinsp;') .' B';
	}

	/**
	 * @param string $string
	 * @param int $maxlen
	 * @param string $delim
	 * @param string $ellipsis
	 * @return string
	 */
	private function truncMiddle($string, $maxlen, $delim, $ellipsis='…')
	{
		$result = [];
		$parts = explode($delim, $string);
		$suffix = array_pop($parts);
		$len = strlen($suffix);
		$used_parts = 0;
		
		if ($parts and $parts[0] == '') {
			$result[] = array_shift($parts) . $delim;
			$len += strlen($delim);
		}

		$part = '';
		foreach ($parts as $part) {
			if ($len+strlen($part)+strlen($delim) < $maxlen-1) {
				$result[] = $part . $delim;
				$len += strlen($part)+strlen($delim);
				$used_parts ++;
			} else {
				break;
			}
		}
		
		if ($used_parts == count($parts)) {
			return $string;
		} else {
			$finalPrefix = implode('', $result);
			$finalSuffix = $delim . $suffix;
			if (strlen($finalPrefix)+strlen($finalSuffix) + strlen($ellipsis) >= $maxlen) {
				return $finalPrefix . $ellipsis . $finalSuffix;
			}
			else {
				$restlen = $maxlen - (strlen($finalPrefix)+strlen($finalSuffix) + strlen($ellipsis));
				return $finalPrefix . substr($part, 0, $restlen) . $ellipsis . $finalSuffix;
			}
		}
	}

	/**
	 * @param string $url
	 * @param int $maxlen
	 * @return string
	 */
	public function truncUrl($url='',$maxlen=60)
	{
		$urlparts = parse_url($url);
		if ($urlparts === false) {
			return '[invalid url]';
		}
		$url = '';
		if (isset($urlparts['scheme'])) {
			$url .= $urlparts['scheme'].':';
		}
		if (isset($urlparts['host'])) {
			$url .= '//'.$urlparts['host'];
			if (isset($urlparts['port'])) {
				$url .= ':'.$urlparts['port'];
			}
		}
		if (isset($urlparts['path'])) {
			$maxpathlen = $maxlen - strlen($url) - (isset($urlparts['query']) ? 3 : 0);
			$url .= $this->truncMiddle($urlparts['path'], $maxpathlen, '/');
		}
		if (isset($urlparts['query'])) {
			$url .= '?';
			if (strlen($urlparts['query']) + strlen($url) < $maxlen) {
				$url .= $urlparts['query'];
			} else {
				$maxquerylen = $maxlen - strlen($url) - 1;
				if ($maxquerylen > 1) {
					$url .= substr($urlparts['query'], 0, $maxlen - strlen($url) - 1).'…';
				} else {
					$url .= '…';
				}
			}
		}
		return $url;
	}

	/**
	 * @param string $hexCode Ein Farbcode, z.B. #000000 oder #FFFFFF.
	 * @param float $amount Ein Wert zwischen 0 und 100. Keine Änderung bei 0, komplett abgedunkelt bei 100.
	 * @return string
	 */
	public function darkenColor(string $hexCode, float $amount): string
	{
		if (preg_match('~^#[0-9a-f]{6}$~i', $hexCode, $match) == false) {
			return $hexCode;
		}

		$amount = min(max(0, $amount), 100);

		$color = Color::fromRGB(hexdec(substr($hexCode, 1)))
			->darken($amount / 100)
		;

		return (string)$color;
	}

	/**
	 * @param string $hexCode Ein Farbcode, z.B. #000000 oder #FFFFFF.
	 * @param float $amount Ein Wert zwischen 0 und 100. Keine Änderung bei 0, komplett aufgehellt bei 100.
	 * @return string
	 */
	public function lightenColor(string $hexCode, float $amount): string
	{
		if (preg_match('~^#[0-9a-f]{6}$~i', $hexCode, $match) == false) {
			return $hexCode;
		}

		$amount = min(max(0, $amount), 100);

		$color = Color::fromRGB(hexdec(substr($hexCode, 1)))
			->lighten($amount / 100)
		;

		return (string)$color;
	}

	/**
	 * Hellt den Farbwert auf, wenn die Helligkeit unter einen bestimmten Punkt
	 * fällt; andernfalls wird er abgedunkelt.
	 * @param string $hexCode Ein Farbcode, z.B. #000000 oder #FFFFFF.
	 * @param float $amount Ein Wert zwischen 0 und 100. Keine Änderung bei 0, komplett aufgehellt/abgedunkelt bei 100.
	 * @return string
	 */
	public function hoverColor(string $hexCode, float $amount = 15): string
	{
		if (preg_match('~^#[0-9a-f]{6}$~i', $hexCode, $match) == false) {
			return $hexCode;
		}

		$amount = min(max(0, $amount), 100);
		$color = Color::fromRGB(hexdec(substr($hexCode, 1)));

		return $color->getLightness() < 0.4
			? $this->lightenColor($hexCode, $amount)
			: $this->darkenColor($hexCode, $amount);
	}

	/**
	 * @param string $content HTML-Code in dem Placeholder ersetzt werden sollen
	 * @return string
	 */
	public function replacePlaceholders($content)
	{
		foreach (Placeholder::all() as $placeholder) {
			$content = str_ireplace($placeholder->getName(), htmlspecialchars($placeholder->getValue()), $content);
		}
		return $content;
	}

	/**
	 * @param bool $expression
	 * @return string
	 */
	public function checked($expression)
	{
		return $expression ? ' checked="checked"' : '';
	}

	/**
	 * @param bool $expression
	 * @return string
	 */
	public function selected($expression, $test)
	{
		return ($expression == $test) ? ' selected="selected"' : '';
	}
}
