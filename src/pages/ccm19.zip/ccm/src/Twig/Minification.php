<?php

namespace App\Twig;

use Twig\Environment;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;
use Twig\TwigFilter;
use Twig\Markup;
use MatthiasMullie\Minify;

class Minification extends AbstractExtension
{
	/**
	 * @return TwigFunction[]
	 */
	public function getFunctions(): array
	{
		return [
			
		];
	}

	/**
	 * @return TwigFilter[]
	 */
	public function getFilters(): array
	{
		return [
			new TwigFilter('minify', [$this, 'minify'], ['needs_environment' => true]),
		];
	}

	/**
	 * @param Environment $env
	 * @param string|Markup $content
	 * @param string $type
	 * @return string|Markup
	 * @phan-suppress PhanAccessMethodInternal
	 */
	public function minify(Environment $env, $content, $type='auto')
	{
		// Bei entsprechender globaler Einstellung, Minifizierung deaktivieren
		if ($env->getGlobals()['_forceDisableMinification'] ?? false) {
			return $content;
		}

		// Auto-Erkennung CSS/JS
		if ($type == 'auto') {
			if (stripos($_SERVER['REQUEST_URI'], '.css') !== false) {
				$type = 'css';
			}
			else {
				$type = 'js';
			}
		}
		
		/** @var Minify\Minify $minifier */
		$minifier = ($type == 'css') ? (new Minify\CSS()) : (new Minify\JS());
		$minifier->add((string)$content);

		$result = $minifier->execute(preg_replace('/[?#].*$/', '', $_SERVER['REQUEST_URI']));
		if ($content instanceof Markup) {
			return new Markup($result, 'utf-8');
		}
		else {
			return $result;
		}
	}

}
