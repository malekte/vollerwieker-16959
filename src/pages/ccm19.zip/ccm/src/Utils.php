<?php

namespace App;

use App\Model\Domain;
use App\Model\User;
use App\Model\Locale;
use App\Component\Curl;
use DirectoryIterator;
use Exception;
use RuntimeException;
use Symfony\Component\Dotenv\Dotenv;
use Symfony\Component\HttpFoundation\IpUtils;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\EventListener\SessionListener;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Contracts\Translation\TranslatorInterface;
use Symfony\Contracts\EventDispatcher\EventDispatcherInterface;
use Symfony\Contracts\EventDispatcher\Event;

class Utils
{
	const RANDOM_STRING_CHARSET = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

	/**
	 * Diese Methode generiert eine zugällige Zeichenkette bestimmter Länge und gegebenem Zeichensatz.
	 * @param int $length
	 * @param string $charset
	 * @return string
	 * @throws \Exception if it was not possible to gather sufficient entropy.
	 */
	public static function randomString(int $length = 16, string $charset = self::RANDOM_STRING_CHARSET): string
	{
		$charsetLength = mb_strlen($charset);

		$chars = [];
		for ($i = 0; $i < $length; $i++) {
			$chars[] = mb_substr($charset, random_int(0, $charsetLength - 1), 1);
		}

		return implode('', $chars);
	}

	/**
	 * Diese Methode prüft den Lizenzschlüssel
	 * @param string $key
	 * @param string $domain
	 * @return array Erweiterte Lizenzdaten
	 * @throws Exception
	 */
	public static function checkLicense($key, $domain): array
	{
		$curl = new Curl();
		$url = 'https://licence.ccm19.de/index.php?'.http_build_query(['licence_id'=>$key, 'dom'=>$domain]);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$result = json_decode($resultData, true);
		if (!$result) {
			throw new RuntimeException('License server unreachable');
		}
		if (!$result['ok']) {
			throw new RuntimeException($result['error']);
		}
		return $result;
	}

	/**
	 * @return string
	 */
	public static function getLicenseKey(): string
	{
		return (string)Config::getInstance()->get('licensekey');
	}

	/**
	 * @return bool
	 */
	public static function hasLicenseKey(): bool
	{
		return strlen(self::getLicenseKey()) > 0;
	}

	/**
	 * @return bool
	 */
	public static function isLicensed(): bool
	{
		return preg_match('~^[a-f0-9]{10,}$~', self::getLicenseKey()) == 1;
	}

	/**
	 * @return string
	 */
	public static function getUpdateChannel(): string
	{
		return (string)($_ENV['APP_UPDATE_CHANNEL'] ?? 'stable');
	}

	/**
	 * @return bool
	 */
	public static function hasWhitelabelLicense(): bool
	{
		/** @var User|null $user */
		$user = User::loggedInUser();
		/** @var Domain|null $domain */
		$domain = null;

		if ($user) {
			$domain = Domain::activeDomain();
		}

		return self::isExtendedEdition()
			? $user->getRole() == User::ROLE_ADMIN || ($domain && $domain->hasWhitelabel())
			: (bool)Config::getInstance()->get('whitelabel');
	}

	/**
	 * @return string
	 */
	public static function getPoweredByText(): string
	{
		$fallback = 'Powered by CCM19';
		return self::isExtendedEdition() ? (string)(Config::getInstance()->get('poweredByText') ?? $fallback) : $fallback;
	}

	/**
	 * @return string
	 */
	public static function getPoweredByTooltip(): string
	{
		$fallback = 'Cookie Consent Tool / Cookie Consent Manager';
		return self::isExtendedEdition() ? (string)(Config::getInstance()->get('poweredByTooltip') ?? $fallback) : $fallback;
	}

	/**
	 * @return string
	 * @phan-suppress PhanTypeInvalidDimOffset
	 */
	public static function getPoweredByUrl(): string
	{
		$url = Config::getInstance()->get('poweredByUrl');

		// Migration des Konfigurationsinhalts alter Versionen
		if (preg_match('~<a\s[^>]*(?<=\s)href="(?<url>[^"]+)~', $url, $match)) {
			$url = $match['url'];
			Config::getInstance()->set('poweredByUrl', $url);
		}

		$fallback = 'https://www.ccm19.de/';
		return self::isExtendedEdition() ? (string)($url ?? $fallback) : $fallback;
	}

	/**
	 * @return string
	 * Gibt das aktuelle Backend CSS aus das aus dem Whitelabel kommt
	 */
	public static function getThemeBack_customCss(): string
	{
		$customCss = Config::getInstance()->get('themeBack_customCss');

		$fallback = '.specialCss {} ';
		return self::isExtendedEdition() ? (string)($customCss ?? $fallback) : $fallback;
	}

	/**
	 * Diese Methode dekodiert eine Anfrage vom Typ `application/json`.
	 * @param Request $request
	 * @param mixed|JsonResponse $data Das Ergebnis der Methode wird in der Referenz $data hinterlegt. Bei Erfolg ist
	 *                                 das dekodierte Ergebnis enthalten, andernfalls ein JsonResponse-Objekt, das die
	 *                                 Fehlermeldung bezeichnet.
	 * @param bool $assoc   Wird intern an json_decode übergeben.
	 * @param int  $depth   Wird intern an json_decode übergeben.
	 * @param int  $options Wird intern an json_decode übergeben.
	 * @return bool Gibt true zurück, wenn das JSON-Objekt des Requests erfolgreich dekodiert wurde, andernfalls false.
	 */
	public static function decodeJsonRequest(Request $request, &$data, bool $assoc = true, int $depth = 5, int $options = 0): bool
	{
		if ($request->getContentType() == 'json') {
			try {
				$json = $request->getContent();
				$data = @json_decode($json, $assoc, $depth, $options);
				if ($data === null && json_last_error() != JSON_ERROR_NONE) {
					throw new RuntimeException(json_last_error_msg(), json_last_error());
				}

				return true;
			}
			catch (RuntimeException $e) {
				$data = new JsonResponse(['success'=>false, 'message'=>$e->getMessage()], 400);
			}
			catch (Exception $e) {
				$data = new JsonResponse(['success'=>false, 'message'=>$e->getMessage()], 500);
			}
		}
		else {
			$data = new JsonResponse(['success'=>false, 'message'=>'Invalid payload. Make sure to send a JSON encoded object and set Content-Type header to application/json.'], 400);
		}

		return false;
	}

	/**
	 * @param string $routeName
	 * @return string
	 */
	public static function getDocUrl($routeName="")
	{
		//print_r($routeName);
		$arrayLinks = array(
			"app_domains_index"			=>"/verwaltung/domainverwaltung/",
			"app_user_theme_index" 		=> "/agency-version/themes/",
			"app_theme_edit" 			=> "/funktionen/themes/",
			"app_theme_new" 			=> "/funktionen/themes/",
			"app_account"				=>"/verwaltung/kontoeinstellungen/",
			"app_dashboard" 			=> "/erste_schritte/login-und-passwoerter/",
			"app_theme_list" 			=> "/funktionen/themes/",
			"app_embeddings_list" 		=> "/funktionen/cookies-und-andere/",
			"app_embeddings_edit" 		=> "/funktionen/cookies-und-andere/",
			"app_embeddings_new" 		=> "/funktionen/cookies-und-andere/",
			"app_embeddings_from_db"	=> "/funktionen/cookies-und-andere/",
			"app_scripts_list"	 		=> "/funktionen/skripte/",
			"app_setting_locale_list"	=> "/funktionen/uebersetzungen/",
			"app_setting_locale_edit"   => "/funktionen/uebersetzungen/",
			"app_impressum"				=> "/funktionen/impressum/",
			"app_datenschutz"			=> "/funktionen/datenschutz/",
			"app_barrierefreiheit"		=> "/",
			"app_placeholder_list"		=> "/funktionen/platzhalter/",
			"app_protokoll"				=> "/logs/consent-protokoll/",
			"app_settings_frontend"		=> "/system-und-co/frontend-einstellungen/",
			"app_settings_consentstorage"=> "/system-und-co/consent-speicherung/",
			"app_page_check"			=> "/funktionen/pagecheck/"
		);

		if (!empty($arrayLinks[$routeName]))
		{
			$link = $arrayLinks[$routeName];
		}
		else{
			$link ="/";
		}

		return  $link;
	}

	/**
	 * @return string
	 */
	public static function generateUniqueCookieId(): string
	{
		// alternativ bin2hex(random_bytes(n))
		return hash('sha256', uniqid(microtime()));
	}

	/**
	 * @param string $ucid
	 * @return bool
	 */
	public static function validateUniqueCookieId(string $ucid): bool
	{
		return (bool)preg_match('~^[0-9a-f]{64}$~', $ucid);
	}

	/**
	 * @param string $value
	 * @return bool
	 */
	public static function validateEmailAddress(string $value): bool
	{
		// Kleine Schreibweise der E-Mail-Adresse validieren
		$value = mb_strtolower($value);

		// General Email Regex (RFC 5322 Official Standard) - https://emailregex.com/
		$pattern = '/^(?:[a-z0-9!#$%&\'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&\'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/';

		return (bool)preg_match($pattern, $value);
	}

	/**
	 * @return bool
	 */
	public static function hostingInterface(): bool
	{
		return self::isExtendedEdition() && ($user = User::loggedInUser()) && $user->getRole() == User::ROLE_ADMIN;
	}

	/**
	 * Setz das Managment auf Modern mit Skripten statt Cookies...
	 * @return bool
	 */
	public static function getModernManagemet(): bool
	{
		return true;
	}

	/**
	 * @return string
	 */
	public static function getEdition(): string
	{
		return (string)($_ENV['APP_EDITION'] ?? '');
	}

	/**
	 * @return bool
	 */
	public static function isExtendedEdition(): bool
	{
		return self::getEdition() == 'extended';
	}

	/**
	 * @return bool
	 */
	public static function isBaseEdition(): bool
	{
		return self::isExtendedEdition() == false;
	}

	/**
	 * @return bool
	 */
	public static function isAutoUpdateEnabled(): bool
	{
		return (bool)Config::getInstance()->get('enableAutoUpdate');
	}

	/**
	 * @param string $path
	 * @throws RuntimeException Wenn das angegebene Verzeichnis nicht existiert und nicht angelegt werden konnte.
	 */
	public static function assertDirectoryWritable(string $path): void
	{
		if (is_dir($path) == false && @mkdir($path, 0777, true) == false || is_writable($path) == false) {
			throw new RuntimeException('Cannot access directory '.$path.', check permissions.');
		}
	}

	/**
	 * Gibt die aktuelle Session zurück.
	 * @return Session
	 */
	public static function getSession(): Session
	{
		/** @var Kernel $kernel */
		global $kernel;
		return $kernel->getContainer()->get('session');
	}

	/**
	 * Liefert das Übersetzungsmodul.
	 * @return TranslatorInterface
	 */
	public static function getTranslator(): TranslatorInterface
	{
		/** @var Kernel $kernel */
		global $kernel;
		return $kernel->getContainer()->get('translator');
	}

	/**
	 * Übernimmt die übergebenen Daten in die .env.local
	 */
	public static function setLocalEnvironment(array $data): void
	{
		global $kernel;
		$path = static::getBaseDir() . DIRECTORY_SEPARATOR . '.env.local';

		// Daten aus bestehender Datei holen
		if (file_exists($path)) {
			$dotenv = new Dotenv(false);
			$existing_items = $dotenv->parse(file_get_contents($path), '.env.local');
			$data = array_merge($existing_items, $data);
		}

		// Zeilen für neue Datei erstellen
		$items = array_map(function ($key, $value) {
			$key = preg_replace('/[^a-zA-Z0-9_]/', 'X', $key);
			if (! preg_match('/^[a-zA-Z0-9,._-]+$/', $value)) {
				$value = escapeshellarg($value);
			}
			return "$key=$value";
		}, array_keys($data), array_values($data));

		// Datei atomar schreiben
		$result = file_put_contents($path.'.tmp', implode("\n", $items)."\n", LOCK_EX);
		if ($result !== false) {
			rename($path.'.tmp', $path);
		}
	}

	/**
	 * @return string
	 */
	public static function getBaseDir(): string
	{
		/** @var Kernel $kernel */
		global $kernel;
		return $kernel->getProjectDir();
	}

	/**
	 * @return string
	 */
	public static function getVarDir(): string
	{
		return static::getBaseDir() . DIRECTORY_SEPARATOR . 'var';
	}

	/**
	 * @return string
	 */
	public static function getCacheDir(): string
	{
		/** @var Kernel $kernel */
		global $kernel;
		return $kernel->getCacheDir();
	}

	/**
	 * Diese Methode löscht ein komplettes Verzeichnis. Dabei werden sämtliche Dateien und Ordner rekursiv entfernt.
	 *
	 * Es wird nicht rekursiv durch symbolische Links auf Verzeichnisse entfernt.
	 * With great power comes great responsibility.
	 * @param string $path
	 */
	public static function removeDirectory(string $path): void
	{
		/** @var DirectoryIterator $it */
		$it = null;
		try {
			$it = new DirectoryIterator($path);
		}
		catch (RuntimeException $exception) {
			return;
		}

		foreach (new DirectoryIterator($path) as $it) {
			if ($it->isDot()) {
				continue;
			}
			elseif (!$it->isLink() and $it->isDir()) {
				self::removeDirectory($it->getPathname());
				@rmdir($it->getPathname());
			}
			else {
				@unlink($it->getPathname());
			}
		}

		// Nur für öußersten Rekursionslevel relevant
		@rmdir($path);
	}

	/**
	 * Diese Methode kopiert ein komplettes Verzeichnis...
	 * Ref: https://www.php.net/manual/de/function.copy.php#91010
	 * @param string $src
	 * @param string $dst
	 */
	public static function copyDirectory(string $src, string $dst):void
	{
		$dir = opendir($src);
		@mkdir($dst);
		while(false !== ( $file = readdir($dir)) ) {
			if (( $file != '.' ) && ( $file != '..' )) {
				if ( is_dir($src . '/' . $file) ) {
					self::copyDirectory($src . '/' . $file,$dst . '/' . $file);
				}
				else {
					copy($src . '/' . $file,$dst . '/' . $file);
				}
			}
		}
		closedir($dir);
	}

	/**
	 * Diese Methode gibt die aktuelle Versions-ID zurück.
	 * @return string
	 */
	public static function getVersionId(): string
	{
		$filename = self::getBaseDir().'/config/version-id.txt';
		return trim(@file_get_contents($filename));
	}

	/**
	 * Diese Methode gibt die aktuelle menschenlesbare Versionsnummer zurück.
	 * @return string
	 */
	public static function getVersionName(): string
	{
		$filename = self::getBaseDir().'/config/version-name.txt';
		return trim(@file_get_contents($filename));
	}

	/**
	 * Diese Methode gibt die Generation der aktuellen Version zurück.
	 * @return int
	 */
	public static function getVersionGeneration(): int
	{
		$filename = self::getBaseDir().'/config/version-generation.txt';
		return (int)(trim(@file_get_contents($filename) ?: '1' ));
	}

	/**
	 * Setzt bestehende Cache-Control-Header zurück und verhindert, dass
	 * der SessionListener die Cache-Control überschreibt.
	 * @param ?Response $response
	 * @return void
	 */
	public static function resetCacheControl(?Response $response): void
	{
		if (headers_sent() == false) {
			// Setzen des Headers in AbstractSessionHandler::open() annullieren
			header_remove('Cache-Control');
		}
		if ($response) {
			// Ggf. schon gesetztes Cache-Control aus $response entfernen
			$response->headers->remove('Cache-Control');
			// Setzen des Headers in AbstractSessionListener::onKernelResponse() annullieren
			$response->headers->set(SessionListener::NO_AUTO_CACHE_CONTROL_HEADER, '1');
		}
	}

	/**
	 * Prüft, ob der Request höchstwahrscheinlich von einem Bot stammt.
	 * @param Request $request
	 * @return bool
	 */
	public static function isBotRequest(Request $request): bool
	{
		$useragent = $request->headers->get('User-Agent', '');
		if (preg_match('/(bot\b|BOT\b|Bot\b|BingPreview| \(\+http)/', $useragent)) {
			return true;
		}
		return false;
	}

	/**
	 * Gibt eine Liste aller IPv4/IPv6-Adressen zu einem Hostnamen zurück
	 * @param string $host
	 * @return string[]
	 */
	public static function getIPAddresses(string $host): array
	{
		$addresses = [];

		// Wenn Socket-Extension vorhanden, verwenden.
		if (function_exists('socket_addrinfo_lookup')) {
			foreach (socket_addrinfo_lookup($host, 'https') ?: [] as $addr) {
				$addrinfo = (socket_addrinfo_explain($addr));
				if (!empty($addrinfo['ai_addr']['sin_addr'])) {
					$addresses[] = $addrinfo['ai_addr']['sin_addr'];
				}
				elseif (!empty($addrinfo['ai_addr']['sin6_addr'])) {
					$addresses[] = $addrinfo['ai_addr']['sin6_addr'];
				}
			}
		}
		// Ansonsten mit gethostbynamel und dns_get_record behelfen
		else {
			$addresses = array_merge(
				gethostbynamel($host) ?: [],
				array_map(function ($record)  {
					return $record['ipv6'];
				},
				dns_get_record($host, DNS_AAAA) ?: [])
			);
		}

		$addresses = array_unique($addresses);

		return $addresses;
	}

	/**
	 * Prüft ob der Hostname eine öffentliche IP-Adresse zugeordnet hat
	 * @param string $host
	 * @return bool
	 */
	public static function isPublicHost(string $host): bool
	{
		$subnets = ['127.0.0.0/8', '10.0.0.0/8', '100.64.0.0/10', '172.16.0.0/12', '192.168.0.0/16', '::1/128', 'fc00::/7', 'fd00::/8'];

		$ip = filter_var($host, FILTER_VALIDATE_IP);
		if ($ip) {
			$addresses = [$ip];
		} else {
			$addresses = self::getIPAddresses($host);
		}

		foreach ($addresses as $addr) {
			foreach ($subnets as $subnet) {
				if (IpUtils::checkIp($addr, $subnet)) {
					return false;
				}
			}
		}

		return (bool)$addresses;
	}

	/**
	 * Gibt die volle URL für eine Route aus (Standard: Root/Startseite)
	 *
	 * @throws \Symfony\Component\Routing\Exception\RouteNotFoundException
	 * @throws \Symfony\Component\Routing\Exception\MissingMandatoryParametersException
	 */
	public static function getFullUrl(string $route='app_root', array $parameters=[]): string
	{
		global $kernel;
		return $kernel->getContainer()->get('router')->generate($route, $parameters, UrlGeneratorInterface::ABSOLUTE_URL);
	}

	/**
	 * @param string $name
	 * @param Event|null $event
	 */
	public static function dispatchEvent(string $name, ?Event $event = null): void
	{
		global $kernel;
		/** @var EventDispatcherInterface */
		$dispatcher = $kernel->getContainer()->get('event_dispatcher');
		if (!$event) {
			$event = new Event();
		}
		$dispatcher->dispatch($event, $name);
	}

	/**
	 * Eine Lebenszeit-Angabe ("1 Tag" usw.) parsen und aufgerundet in Stunden zurückgeben.
	 *
	 * $sessionFallback wird zurückgegeben, wenn "Sitzung"/"Session" statt einer Zeitangabe
	 * verwendet wird und wenn die Zeit nicht eindeutig bestimmbar ist, $fallback.
	 *
	 * @param string $lifetimeString
	 * @param mixed $sessionFallback
	 * @param mixed $fallback
	 * @return int|mixed
	 */
	public static function parseLifetimeToHours(string $lifetimeString, $sessionFallback=null, $fallback=null)
	{
		$lifetime = null;
		$match = [];

		preg_match('/^\s*(?<number>\.[0-9]+|[0-9]+(?:\.[0-9*]*)?)\s*(?<unit>[^\s\d.]*)/ui', $lifetimeString, $match);

		if ($match and $match['number'] != '') {
			$number = (float)$match['number'];
			switch (strtolower($match['unit'])) {
				case 's':
				case 'sek':
				case 'sec':
				case 'second':
				case 'seconds':
				case 'sekunde':
				case 'sekunden':
					$lifetime = $number / 3600;
					break;
				case 'm':
				case 'min':
				case 'minute':
				case 'minutes':
				case 'minuten':
					$lifetime = $number / 60;
					break;
				case 'h':
				case 'hour':
				case 'hours':
				case 'std':
				case 'st':
				case 'stdn':
				case 'stunde':
				case 'stunden':
					$lifetime = $number;
					break;
				case 'd':
				case 'day':
				case 'days':
				case 't':
				case 'tag':
				case 'tage':
					$lifetime = $number*24;
					break;
				case 'w':
				case 'week':
				case 'weeks':
				case 'woche':
				case 'wochen':
					$lifetime = $number*24*7;
					break;
				case 'mon':
				case 'month':
				case 'months':
				case 'monat':
				case 'monate':
					$lifetime = $number*24*30.5;
					break;
				case 'y':
				case 'year':
				case 'years':
				case 'jahr':
				case 'jahre':
					$lifetime = $number*24*365;
					break;
				case 'dec':
				case 'decade':
				case 'decades':
				case 'jahrzehnt':
				case 'jahrzehnte':
					$lifetime = $number*24*365*10;
					break;
			}
		}

		if ($lifetime === null) {
			if (preg_match('/(sitzung|session)/i', $lifetimeString)) {
				return $sessionFallback;
			} else {
				return $fallback;
			}
		} else {
			return (int)ceil($lifetime);
		}
	}

	/**
	 * Sucht das passendste Locale anhand der vom Browser angegebenen
	 * Sprachen.
	 *
	 * Existiert kein passendes Locale, wird ein leerer String zurückgegeben.
	 *
	 * @param Request $request
	 * @return string
	 */
	public static function guessLocaleFromBrowser(Request $request)
	{
		$locales = Locale::enabledLocales();
		foreach ($request->getLanguages() as $lang)
		{
			// Optionale Angabe des Schriftsystems rauslöschen (siehe BCP 47)
			// Sonst würde de-Latn-DE → de_LATN_DE nicht de_DE matchen.
			$lang = preg_replace('/_[A-Z]{4}(_|$)/', '\1', $lang);

			// Passendes Locale suchen
			foreach ($locales as $locale) {
				if ($locale->getName() === $lang) {
					return $lang;
				}
				elseif (strpos($locale->getName(), $lang.'_') === 0) {
					return $locale->getName();
				}
			}
		}
		return '';
	}
}
