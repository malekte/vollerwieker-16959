<?php

namespace App;

use Symfony\Bundle\FrameworkBundle\Kernel\MicroKernelTrait;
use Symfony\Component\Config\Loader\LoaderInterface;
use Symfony\Component\Config\Resource\FileResource;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\HttpKernel\Kernel as BaseKernel;
use Symfony\Component\Routing\RouteCollectionBuilder;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;

class Kernel extends BaseKernel implements CompilerPassInterface
{
	use MicroKernelTrait;

	private const CONFIG_EXTS = '.{php,xml,yaml,yml}';

	public function registerBundles(): iterable
	{
		$contents = require $this->getProjectDir().'/config/bundles.php';
		foreach ($contents as $class => $envs) {
			if ($envs[$this->environment] ?? $envs['all'] ?? false) {
				yield new $class();
			}
		}
	}

	public function getProjectDir(): string
	{
		return \dirname(__DIR__);
	}

	protected function configureContainer(ContainerBuilder $container, LoaderInterface $loader): void
	{
		$container->addResource(new FileResource($this->getProjectDir().'/config/bundles.php'));
		$container->setParameter('container.dumper.inline_class_loader', true);
		$confDir = $this->getProjectDir().'/config';

		$loader->load($confDir.'/{packages}/*'.self::CONFIG_EXTS, 'glob');
		$loader->load($confDir.'/{packages}/'.$this->environment.'/**/*'.self::CONFIG_EXTS, 'glob');
		$loader->load($confDir.'/{services}'.self::CONFIG_EXTS, 'glob');
		$loader->load($confDir.'/{services}_'.$this->environment.self::CONFIG_EXTS, 'glob');
	}

	protected function configureRoutes(RouteCollectionBuilder $routes): void
	{
		$confDir = $this->getProjectDir().'/config';

		$routes->import($confDir.'/{routes}/'.$this->environment.'/**/*'.self::CONFIG_EXTS, '/', 'glob');
		$routes->import($confDir.'/{routes}/*'.self::CONFIG_EXTS, '/', 'glob');
		$routes->import($confDir.'/{routes}'.self::CONFIG_EXTS, '/', 'glob');
	}

	/**
	 * Whitelabeling: Übersetzungen injecten
	 */
	public function process(ContainerBuilder $container): void
	{
		if (Utils::isExtendedEdition()) {
			@mkdir(Utils::getVarDir() . '/translations');
			$translator = $container->findDefinition('translator');
			$projectDir = rtrim($container->getParameter('kernel.project_dir'), '/\\');
			$whitelabelDir = $projectDir . '/var/translations';
			$whitelabelTemplate = $projectDir . '/var/translations/messages.%LANG%.yaml';

			$options = $translator->getArgument(4);
			foreach ($options['resource_files'] as $lang => &$files) {
				$whitelabelFile = str_replace('%LANG%', $lang, $whitelabelTemplate);
				if (!file_exists($whitelabelFile)) {
					touch($whitelabelFile);
				}
				$files[] = $whitelabelFile;
			}
			$options['scanned_directories'][] = $whitelabelDir;
			$options['cache_vary']['scanned_directories'][] = 'var/translations';

			$translator->replaceArgument(4, $options);
		}
	}
}
