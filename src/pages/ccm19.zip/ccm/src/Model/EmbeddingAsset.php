<?php

namespace App\Model;

use App\JsonConfig;
use App\Exception\ConfigNotWritableException;
use App\Utils;

class EmbeddingAsset extends Model
{
	const STORAGE_TYPE_COOKIE = 'cookie';
	const STORAGE_TYPE_LOCAL_STORAGE = 'localStorage';
	const STORAGE_TYPE_SESSION_STORAGE = 'sessionStorage';
	const STORAGE_TYPE_INDEXED_DB = 'indexedDb';
	const STORAGE_TYPE_WEB_SQL = 'webSql';
	const STORAGE_TYPE_OTHER = 'other';

	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-embedding-assets.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setName(string $text): self
	{
		$this->set('name', $text);
		return $this;
	}

	/**
	 * Überprüfen, ob ein Cookie/...-Name zu diesem Asset passt
	 */
	public function matchName(string $name): bool
	{
		if (!$this->isDynamic()) {
			return trim($this->getName()) == trim($name);
		}
		else {
			$pattern = $this->getName();
			if (strpos($pattern, '[') !== false) {
				$pattern = preg_replace('/(?<!\\\\)([][])/', '\\\\$1', $pattern);
			}
			return fnmatch($pattern, $name);
		}
	}

	/**
	 * @return bool
	 */
	public function isDynamic(): bool
	{
		return (bool)$this->get('dynamic');
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setDynamic(bool $value): self
	{
		$this->set('dynamic', $value);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getStorageType(): string
	{
		return (string)$this->get('storageType');
	}

	/**
	 * @param string $code
	 * @return $this
	 */
	public function setStorageType(string $code): self
	{
		$this->set('storageType', $code);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getLifetime(): string
	{
		return (string)$this->get('lifetime');
	}

	/**
	 * @param string $lifetime
	 * @return $this
	 */
	public function setLifetime(string $lifetime): self
	{
		$this->set('lifetime', $lifetime);
		return $this;
	}

	/**
	 * Maximale Lebenszeit des Cookies in Stunden, oder
	 * $fallback wenn die Zeit nicht eindeutig bestimmbar ist.
	 *
	 * @param mixed $sessionFallback
	 * @param mixed $fallback
	 * @return int|mixed
	 */
	public function getLifetimeHours($sessionFallback=null, $fallback=null)
	{
		return Utils::parseLifetimeToHours($this->getLifetime(), $sessionFallback, $fallback);
	}

	/**
	 * @return string
	 */
	public function getDescription(): string
	{
		return (string)$this->get('description');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setDescription(string $text): self
	{
		$this->set('description', $text);
		return $this;
	}


	/**
	 * @param Locale $locale
	 * @return string
	 */
	public function getTranslatedDescription(Locale $locale): string
	{
		return $this->get('translated_description.'.$locale->getName())
			?? $this->get('translated_description.'.$locale->getId())
			?? $this->getDescription()
		;
	}

	/**
	 * @param Locale $locale
	 * @param string $description
	 * @return $this
	 */
	public function setTranslatedDescription(Locale $locale, string $description): self
	{
		$this->set('translated_description.'.$locale->getName(), $description);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @return string
	 */
	public function getTranslatedLifetime(Locale $locale): string
	{
		return $this->get('translated_lifetime.'.$locale->getName())
			?? $this->get('translated_lifetime.'.$locale->getId())
			?? $this->getLifetime()
		;
	}

	/**
	 * @param Locale $locale
	 * @param string $description
	 * @return $this
	 */
	public function setTranslatedLifetime(Locale $locale, string $lifetime): self
	{
		$this->set('translated_lifetime.'.$locale->getName(), $lifetime);
		return $this;
	}
}
