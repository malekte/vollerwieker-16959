<?php

namespace App\Model;

use App\JsonConfig;
use LogicException;

class Language extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-languages.json';

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @param string $code
	 * @return static
	 * @throws LogicException
	 */
	public static function create($code=null): Model
	{
		if ($code === null) {
			throw new \LogicException('cannot use create() with Language model');
		}
		self::beginWrite();
		return new static(JsonConfig::escapeKey($code));
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @return string
	 */
	public function getEnglishName(): string
	{
		return (string)$this->get('name_en');
	}

	/**
	 * @return string
	 */
	public function getGermanName(): string
	{
		return (string)$this->get('name_de');
	}

	/**
	 * @return string
	 */
	public function getDisplayName(string $user_language): string
	{
		if (strpos($user_language, 'de') === 0) {
			$loc_name = $this->getGermanName();
		} else {
			$loc_name = $this->getEnglishName();
		}

		$name = $this->getName();
		if ($name !== $loc_name and strpos($loc_name, '(') === false) {
			return $loc_name . ' ('.$name.')';
		} else {
			return $loc_name;
		}
	}

	/**
	 * @return string
	 */
	public function getCode(): string
	{
		return (string)$this->getId();
	}

	/**
	 * @return string
	 */
	public function getIsoCode(): string
	{
		return str_replace('_', '-', $this->getId());
	}
}
