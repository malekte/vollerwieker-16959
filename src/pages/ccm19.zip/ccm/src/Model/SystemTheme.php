<?php

namespace App\Model;

use App\JsonConfig;

class SystemTheme extends ThemeBase
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}
}
