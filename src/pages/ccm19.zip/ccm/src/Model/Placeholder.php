<?php

namespace App\Model;

use App\JsonConfig;
use App\Exception\ConfigNotWritableException;

class Placeholder extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-placeholders.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * Diese Methode erstellt ein Objekt dieser Klasse
	 * @param string $id Platzhalter-Name
	 * @return static
	 * @throws \LogicException
	 */
	public static function create($id=null): Model
	{
		if ($id === null) {
			throw new \LogicException('cannot use create() with Placeholder model');
		}
		self::beginWrite();
		$id = trim($id, '{}');
		return new static(JsonConfig::escapeKey($id));
	}

	/**
	 * Diese Methode löscht den durch das aktuelle Objekt referenzierten Datensatz aus der Konfiguration.
	 * @param string $id
	 * @param bool $autocommit
	 * @throws ConfigNotWritableException
	 */
	public static function delete(string $id, bool $autocommit=true): void
	{
		$id = trim($id, '{}');
		parent::delete(JsonConfig::escapeKey($id), $autocommit);
	}

	/**
	 * @param string $id
	 * @return bool
	 */
	public static function exists(string $id): bool
	{
		$id = trim($id, '{}');
		return parent::exists(JsonConfig::escapeKey($id));
	}

	/**
	 * @param string $id
	 * @return static|null
	 */
	public static function find(string $id): ?Model
	{
		$id = trim($id, '{}');
		return self::exists($id) ? new static(JsonConfig::escapeKey($id)) : null;
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return '{'.JsonConfig::unescapeKey($this->getId()).'}';
	}

	/**
	 * @return string
	 */
	public function getValue(): string
	{
		return (string)$this->get('value');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setValue(string $text): self
	{
		$this->set('value', $text);
		return $this;
	}
}
