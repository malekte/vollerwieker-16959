<?php

namespace App\Model;

use App\Component\ConfigImporterContext;
use App\Exception\ConfigNotReadableException;
use App\Exception\ConfigNotWritableException;
use App\Component\Config\MutableModelInterface;
use App\Component\Config\RepositoryInterface;
use App\JsonConfig;
use App\Config;
use App\Utils;
use LogicException;
use RuntimeException;

/**
 * Basisklasse für JSON-Models
 *
 */
abstract class Model implements MutableModelInterface
{
	/** @var string $id */
	private $id;

	/** @var string|null $repositoryFilename */
	protected static $repositoryFilename = null;

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = false;

	/** @var bool $userSpecificRepository */
	protected static $userSpecificRepository = false;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		$this->id = $id;
	}

	/**
	 * Diese Methode stellt die Konfiguration des aktuellen Models in Form eines JsonConfig-Objekts bereit.
	 * @return RepositoryInterface
	 * @phan-suppress PhanUndeclaredStaticProperty
	 * @phan-suppress PhanUndeclaredStaticMethod
	 */
	protected static function getRepository(): RepositoryInterface
	{
		if (static::$repository === null) {
			static::$repository = static::openRepository();

			if (method_exists(static::class, 'onRepositoryLoaded')) {
				static::onRepositoryLoaded();
			}
		}

		return static::$repository;
	}

	/**
	 * Öffnet das Repository vollständig neu
	 *
	 * Dabei werden Wechsel des aktiven Benutzers und der aktiven Domain berücksichtigt
	 * und alle ungespeicherten Änderungen gehen verloren.
	 *
	 * @phan-suppress PhanUndeclaredStaticProperty
	 */
	public static function reloadRepository(): void
	{
		if (static::$repository !== null) {
			if (static::$repository->isInWrite()) {
				static::$repository->reload();
			}
		}

		static::$repository = static::openRepository();
	}

	/**
	 * Diese Methode stellt die Konfiguration des aktuellen Models in Form eines neuen JsonConfig-Objekts bereit.
	 *
	 * @param User|null $user
	 * @param Domain|null $domain
	 * @return RepositoryInterface
	 */
	protected static function openRepository(?User $user=null, ?Domain $domain=null): RepositoryInterface
	{
		$repoFilename = static::$repositoryFilename;
		$domainSpecificRepository = (bool)(static::$domainSpecificRepository ?? false);
		$userSpecificRepository = (bool)(static::$userSpecificRepository ?? false);

		// Gewährleisten, dass dem Model ein Dateiname als Repository beiliegt
		if (empty($repoFilename)) {
			throw new LogicException('No repository defined for '.static::class);
		}

		if ($domainSpecificRepository) {
			if (static::class == Domain::class) {
				throw new LogicException('Domain model repository may not be domain specific');
			}

			if ($domain === null) {
				$domain = Domain::activeDomain();
			}

			if ($domain) {
				$domainConfigDir = $domain->configDir();
				if (is_dir($domainConfigDir) == false && @mkdir($domainConfigDir, 0777, true) == false || is_writable($domainConfigDir) == false) {
					throw new RuntimeException('Could not access domain config folder '.$domainConfigDir.', check permissions.');
				}
			}
			else {
				throw new LogicException('Cannot access domain repository '.static::class.' if no domain is selected.');
			}

			$repoFilename = $domain->configDir(true).'/'.static::$repositoryFilename;
		}
		else if ($userSpecificRepository) {
			if (static::class == User::class) {
				throw new LogicException('User model repository may not be user specific');
			}

			if ($user === null) {
				$user = User::loggedInUser();
			}

			if ($user) {
				$userConfigDir = $user->configDir();
				if (is_dir($userConfigDir) == false && @mkdir($userConfigDir) == false || is_writable($userConfigDir) == false) {
					throw new RuntimeException('Could not access user config folder '.$userConfigDir.', check permissions.');
				}
			}
			else {
				throw new LogicException('Cannot access user repository '.static::class.' if no user is logged in.');
			}

			$repoFilename = $user->configDir(true).'/'.static::$repositoryFilename;
		}

		return new JsonConfig($repoFilename);
	}

	/**
	 * Diese Methode lädt eine Konfigurationsdatei in ein benutzerspezifisches Verzeichnis und löscht optional die
	 * originale Datei.
	 * @param ConfigImporterContext $context
	 * @param string $filename
	 * @param bool $keepOriginal
	 */
	private static function importConfigFile(ConfigImporterContext $context, string $filename, bool $keepOriginal = true): void
	{
		$sourceFile = Utils::getVarDir() . DIRECTORY_SEPARATOR . $filename;
		$repoFilename = '';

		if ((bool)(static::$domainSpecificRepository ?? false)) {
			if ($context->hasDomain() == false) {
				return;
			}

			$repoFilename = $context->getDomain()->configDir().'/'.static::$repositoryFilename;
		}
		else if ((bool)(static::$userSpecificRepository ?? false)) {
			if ($context->hasUser() == false) {
				return;
			}

			$repoFilename = $context->getUser()->configDir().'/'.static::$repositoryFilename;
		}
		else {
			return;
		}

		$repoDir = dirname($repoFilename);
		if (is_dir($repoDir) == false && @mkdir($repoDir, 0777, true) == false || is_writable($repoDir) == false) {
			throw new RuntimeException('Cannot access config folder '.$repoDir.', check permissions.');
		}

		// Wenn globale Konfiguration nicht oder lokale bereits existiert, Vorgang abbrechen
		if (is_file($sourceFile) == false || is_file($repoFilename)) {
			return;
		}
		// Konfigurationsdatei migrieren, alte Datei u. U. löschen
		else if (@copy($sourceFile, $repoFilename)) {
			@chmod($repoFilename, 0666);

			if ($keepOriginal == false) {
				@unlink($sourceFile);
			}
		}
	}

	/**
	 * Diese Methode lädt die für das aufgerufene Model vorgesehene Konfigurationsdatei aus dem Vorlagenverzeichnis und
	 * speichert diese für den übergebenen Benutzer in seinem Konfigurationsverzeichnis.
	 * @param ConfigImporterContext $context
	 */
	public static function importSkeleton(ConfigImporterContext $context): void
	{
		self::importConfigFile($context, 'user_data/skeleton/'.static::$repositoryFilename);
	}

	/**
	 * Diese Methode lädt die Konfigurationsdatei des aufgerufenen Models in den nutzerspezifischen Konfigurationsraum.
	 * Hierbei handelt es sich um eine Migrationsroutine alter Versionen, die als Single-User-Version liefen und alle
	 * Konfigurationsdateien direkt im Verzeichnis var/ speicherten.
	 * @param ConfigImporterContext $context
	 */
	public static function migratePreMultiUserConfig(ConfigImporterContext $context): void
	{
		self::importConfigFile($context, static::$repositoryFilename, false);
	}

	/**
	 * Diese Methode lädt die Konfigurationsdatei des aufgerufenen Models in den domainspezifischen Konfigurationsraum.
	 * Hierbei handelt es sich um eine Migrationsroutine alter Versionen, die als Single-Domain-Version liefen und
	 * Konfigurationsdateien ggf. im Verzeichnis var/user_data/... speicherten.
	 * @param ConfigImporterContext $context
	 * @throws LogicException
	 */
	public static function migratePreMultiDomainConfig(ConfigImporterContext $context): void
	{
		if ($context->hasUser() == false) {
			throw new LogicException('Import context is missing a user');
		}

		self::importConfigFile($context, $context->getUser()->configDir(true).'/'.static::$repositoryFilename, false);
	}

	/**
	 * @param string $id
	 * @return bool
	 */
	public static function exists(string $id): bool
	{
		return is_array(self::getRepository()->get($id));
	}

	/**
	 * @param string $id
	 * @return static|null
	 * @phan-suppress PhanTypeInstantiateAbstractStatic
	 */
	public static function find(string $id): ?self
	{
		return self::exists($id) ? new static($id) : null;
	}

	/**
	 * @return static[]
	 * @phan-suppress PhanTypeInstantiateAbstractStatic
	 */
	public static function all(): array
	{
		/** @var static[] $entities */
		$entities = [];

		foreach (self::getRepository()->toArray() as $id => $data) {
			$entities[$id] = new static($id);
		}

		return $entities;
	}

	/**
	 * Diese Methode erstellt ein Objekt dieser Klasse mit generierter ID. Daten müssen mit Setter-Methoden eingepflegt werden.
	 * @return static
	 * @phan-suppress PhanTypeInstantiateAbstractStatic
	 */
	public static function create(): self
	{
		self::beginWrite();
		$id = null;

		do {
			$id = substr(hash('sha256', uniqid()), 0, 7);
		} while (self::exists($id));

		return new static($id);
	}


	/**
	 * Zählt die vorhandenen Instanzen dieses Models.
	 * @return int
	 */
	public static function count(): int
	{
		return count(self::getRepository()->toArray());
	}

	/**
	 * Diese Methode löscht den durch das aktuelle Objekt referenzierten Datensatz aus der Konfiguration.
	 * @param string $id
	 * @param bool $autocommit
	 * @throws ConfigNotWritableException
	 */
	public static function delete(string $id, bool $autocommit=true): void
	{
		$repository = self::getRepository();
		$repository->unset($id);
		if ($autocommit) {
			static::flush();
		}
	}

	/**
	 * Größe des Repositories auf der Festplatte in Bytes, ohne ungespeicherte Änderungen
	 *
	 * @return int Größe in Bytes
	 */
	public static function persistedRepositorySize(): int
	{
		return static::getRepository()->getPersistedSize();
	}

	/**
	 * Diese Methode löscht alle Datensätze aus einer Konfiguration
	 */
	public static function clear(): void
	{
		$repository = self::getRepository();
		$repository->clear();
		static::flush();
	}

	/**
	 * Wrapper für den Zugriff auf `JsonConfig::get(string $identifier, $fallback = null)`.
	 * @param string $property
	 * @param mixed|null $fallback
	 * @return mixed
	 * @see JsonConfig::get()
	 */
	protected final function get(string $property, $fallback = null)
	{
		$data =  self::getRepository()->get($this->getId().'.'.$property, $fallback);
		return $data;
	}

	/**
	 * Wrapper für den Zugriff auf `JsonConfig::set(string $identifier, $data)`.
	 * @param string $property
	 * @param mixed $data
	 * @see JsonConfig::set()
	 */
	protected final function set(string $property, $data): void
	{
		self::getRepository()->set($this->getId().'.'.$property, $data);
	}

	/**
	 * Diese Methode schreibt alle durch Setter-Methoden vorgenommenen
	 * Änderungen in die Konfiguration auf der Platte.
	 *
	 * Alternativ kann auch stattdessen Model::flush() nach dem Verändern
	 * mehrerer Objekte des gleichen Models verwendet werden.
	 *
	 * @return void
	 * @throws ConfigNotWritableException
	 */
	public final function save(): void
	{
		static::flush();
	}

	/**
	 * Diese Methode schreibt alle durch Setter-Methoden vorgenommenen
	 * Änderungen im Model in die Konfiguration auf der Platte.
	 *
	 * @return void
	 * @throws ConfigNotWritableException
	 */
	public static function flush(): void
	{
		self::getRepository()->flush();
	}

	/**
	 * Liest alle Einträge neu von der Festplatte ein.
	 * Sämtliche Änderungen gehen verloren.
	 * @throws ConfigNotReadableException
	 */
	public static function reload(): void
	{
		self::getRepository()->reload();
	}

	/**
	 * Sperrt diese Model um Schreiben.
	 *
	 * Danach kann bis zu flush(), reload() oder save() kein parallel
	 * laufender Prozess auf das Model zugreifen.
	 */
	public static function beginWrite(): void
	{
		self::getRepository()->beginWrite();
	}

	/**
	 * @return string
	 */
	public final function getId(): string
	{
		return $this->id;
	}

	/**
	 * IDs sind nicht modifizierbar.
	 */
	private final function setId(): void {}
}
