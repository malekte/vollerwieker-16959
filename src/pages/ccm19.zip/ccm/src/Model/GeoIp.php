<?php

namespace App\Model;

use MaxMind\Db\Reader;
use App\Component\Config\ModelInterface;
use Exception;

class GeoIp implements ModelInterface
{
	/** @var object|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = '/config/GeoLite2-Country.mmdb';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/** @var string $id */
	private $id;

	/** @var array $data */
	private $data;

	/**
	 * @param string $ipAddress
	 * @param array $data
	 */
	protected function __construct($ipAddress, $data)
	{
		$this->id = $ipAddress;
		$this->data = $data;
	}

	public static function getRepository()
	{
		global $kernel;
		if (static::$repository) {
			return static::$repository;
		}

		$databaseFile = $kernel->getProjectDir() . static::$repositoryFilename;
		static::$repository = $repo = new Reader($databaseFile);
		return $repo;
	}

	public static function all(): array
	{
		throw new Exception('not implemented');
	}

	public static function count(): int
	{
		return static::getRepository()->metadata()->nodeCount;
	}

	/**
	 * IP-Datenbank schließen und Speicher freigeben.
	 */
	public static function flush(): void
	{
		static::$repository->close();
		static::$repository = null;
	}

	public function getId(): string {
		return $this->id;
	}

	/**
	 * @param string $ipAddress
	 * @return bool
	 */
	public static function exists(string $ipAddress): bool
	{
		$repo = static::getRepository();
		return (bool)$repo->get($ipAddress);
	}

	/**
	 * @param string $ipAddress
	 * @return static|null
	 */
	public static function find(string $ipAddress): ?GeoIp
	{
		$repo = static::getRepository();
		list($data, $prefixlen) = $repo->getWithPrefixLen($ipAddress);
		if ($data) {
			$data['prefixlen'] = $prefixlen;
			return new static($ipAddress, $data);
		} else {
			return null;
		}
	}

	/**
	 * Größe des Repositories auf der Festplatte in Bytes
	 *
	 * @return int Größe in Bytes
	 */
	public static function persistedRepositorySize(): int
	{
		global $kernel;
		$databaseFile = $kernel->getProjectDir() . static::$repositoryFilename;
		return (int)@filesize($databaseFile);
	}

	/**
	 * @return string
	 */
	public function getCountryCode(): string
	{
		return $this->data['country']['iso_code'] ?? '';
	}

	/**
	 * @return string
	 */
	public function getContinentCode(): string
	{
		return $this->data['continent']['code'] ?? '';
	}

	/**
	 * @return bool
	 */
	public function isInEu(): bool
	{
		return (($this->data['country']['is_in_european_union'] ?? false) or ($this->data['registered_country']['is_in_european_union'] ?? false));
	}

	/**
	 * @return int
	 */
	public function getPrefixLen(): int
	{
		return $this->data['prefixlen'] ?? -1;
	}
}
