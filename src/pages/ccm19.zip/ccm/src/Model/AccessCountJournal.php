<?php

namespace App\Model;

use DateTimeInterface;
use DateTimeImmutable;
use Generator;
use App\Exception\LogNotCreatableException;
use App\Exception\LogNotDeletableException;
use App\Exception\LogNotWritableException;

/**
 * Dient der effizienten Erfassung des Call- und View-Counts pro Tag.
 *
 * Die Daten werden regelmäßig in die Statistik übertragen.
 */
final class AccessCountJournal
{
	/** @var DateTimeImmutable */
	private static $NOW;

	/** @var string */
	private static $directory = 'cm-journal';

	/** @var string */
	private $pathname;

	private function getFilePath(DateTimeInterface $date)
	{
		return $this->pathname.'/'.$date->format('Y-m-d').'.log';
	}

	/**
	 * @param Domain $domain
	 * @param string $kind
	 * @throws LogNotCreatableException Wenn Logdatei nicht geschrieben werden kann.
	 */
	private function __construct(Domain $domain, string $kind)
	{
		if (self::$NOW === null) {
			self::$NOW = new DateTimeImmutable('now');
		}
		$this->pathname = self::staticPathname($domain, $kind);
		self::createDirectoryIfNotExists();
	}

	/**
	 * @param Domain $domain
	 * @param string $kind Zählername ('call','view',…)
	 * @return self
	 * @throws LogNotCreatableException Wenn nicht auf die Logdateien zugegriffen werden kann.
	 */
	public static function byDomainAndKind(Domain $domain, string $kind): self
	{
		return new self($domain, $kind);
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @param Domain $domain
	 * @return string
	 */
	public static function staticPathname(Domain $domain, string $kind): string
	{
		return $domain->configDir().'/'.self::$directory.'/'.$kind;
	}

	/**
	 * @param int $count
	 * @return void
	 * @throws LogNotWritableException Wenn nicht in Logdatei geschrieben werden kann.
	 * @phan-suppress PhanParamSuspiciousOrder
	 */
	public function increment(int $count=1): void
	{
		$path = $this->getFilePath(self::$NOW);
		if (file_put_contents($path, str_pad('', $count, "\0"), FILE_APPEND) === false) {
			throw new LogNotWritableException($path);
		}
	}

	/**
	 * Liefert die gezählten Werte pro Tag
	 *
	 * @param bool $reset Ob die Zähler beim Auslesen zurückgesetzt werden sollen
	 * @return Generator|int[] ["Y-m-d" => Zählerwert]
	 * @phan-return generator<string,int>
	 * @throws LogNotDeletableException
	 */
	public function iterateEntries(bool $reset=true): Generator
	{
		$today = self::$NOW->format('Y-m-d');
		$directory = strtr($this->pathname, ['\\'=>'\\\\', '*'=>'\*', '?'=>'\?', '['=>'\[', ']'=>'\]']);
		$pattern = $directory . '/*.log';
		foreach (glob($pattern) as $file) {
			$date = basename($file, '.log');
			// Journale der Vergangenheit können vereinfacht ausgelesen werden
			if ($date < $today) {
				yield $date => filesize($file);
				if ($reset) {
					@unlink($file);
					// Wenn das Löschen nicht funktioniert hat:
					if (file_exists($file)) {
						// Versuchen Datei zu leeren
						$f = fopen($file, 'wb');
						if ($f) {
							fclose($f);
						}
						// und Fehlermeldung produzieren
						throw new LogNotDeletableException($file);
					}
				}
			}
			// Heutiges Journal vorsichtig behandeln
			else {
				$f = fopen($file, 'rb+');
				if ($f) {

					flock($f, ($reset)?LOCK_EX:LOCK_SH);
					try {
						// Ans Ende springen und Position auslesen -> Zählerwert
						fseek($f, 0, SEEK_END);
						$count = ftell($f);
						yield $date => $count;
						if ($reset) {
							// Datei abschneiden um Zähler zurückzusetzen:
							// Hier können durch eine kleine Race-Condition Zählerwerte
							// verloren gehen, aber jede bessere Lösung benötigt Locking.
							fseek($f, -$count, SEEK_END);
							ftruncate($f, ftell($f));
						}
					}
					finally {
						flock($f, LOCK_UN);
					}
				}
		}	}
	}

	/**
	 * @throws LogNotCreatableException
	 */
	private function createDirectoryIfNotExists(): void
	{
		$dirname = $this->pathname;
		if (is_dir($dirname) == false && mkdir($dirname, 0755, true) === false) {
			throw new LogNotCreatableException($dirname);
		}
	}

	/**
	 * @return array<string,int>
	 * @throws LogNotDeletableException
	 * @see self::iterateEntries()
	 */
	public function all(bool $reset=true): array
	{
		return iterator_to_array($this->iterateEntries($reset));
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @return string
	 */
	public function getPathname(): string
	{
		return $this->pathname;
	}

}
