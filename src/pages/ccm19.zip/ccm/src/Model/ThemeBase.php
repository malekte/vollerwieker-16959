<?php

namespace App\Model;

use LogicException;

abstract class ThemeBase extends Model
{
	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-themes.json';

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return static|null
	 */
	public static function activeTheme(): ?self
	{
		return array_reduce(self::all(), function ($theme, $currentTheme) {
			/** @var self $currentTheme */
			return $theme ?? ($currentTheme->isDefaultTheme() ? $currentTheme : $theme);
		}, null);
	}

	/**
	 * @param bool $default
	 */
	private function setDefaultTheme(bool $default): void
	{
		$this->set('isDefault', $default);
	}

	/**
	 * @return bool
	 */
	public function isDefaultTheme(): bool
	{
		return (bool)$this->get('isDefault');
	}

	public function makeDefault(): void
	{
		/** @var self[] $themes */
		$themes = self::all();

		foreach ($themes as $theme) {
			$theme->setDefaultTheme(false);
		}
		$this->setDefaultTheme(true);

		self::flush();
	}

	/**
	 * @return int
	 */
	public function getLastModifiedTimestamp(): int
	{
		return (int)$this->get('lastModifiedTimestamp');
	}

	/**
	 * @param int $time
	 * @return $this
	 */
	public function setLastModifiedTimestamp(int $time): self
	{
		$this->set('lastModifiedTimestamp', $time);
		return $this;
	}

	/**
	 * @return $this
	 */
	public function touchLastModifiedTimestamp(): self
	{
		// Am elegantesten wäre die Implementierung in einer überschriebenen set-Methode; die ist aber final...
		return $this->setLastModifiedTimestamp(time());
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	public function setName(string $name): self
	{
		$this->set('name', $name);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPosition(): string
	{
		return (string)$this->get('position');
	}

	/**
	 * @param string $position
	 * @return $this
	 */
	public function setPosition(string $position): self
	{
		$allowedValues = [
			'bottom',
			'center',
			'top',
		];

		if (in_array($position, $allowedValues) == false) {
			throw new LogicException('Invalid value for position, allowed values: '.implode(', ', $allowedValues));
		}

		$this->set('position', $position);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isShowPurposesInMainWindow(): bool
	{
		return (bool)$this->get('showPurposesInMainWindow');
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setShowPurposesInMainWindow(bool $state): self
	{
		$this->set('showPurposesInMainWindow', $state);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isBlocking(): bool
	{
		return (bool)$this->get('blocking');
	}

	/**
	 * @param bool $blocking
	 * @return $this
	 */
	public function setBlocking(bool $blocking): self
	{
		$this->set('blocking', $blocking);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isSettingsIconEnabled(): bool
	{
		return (bool)$this->get('settingsIconEnabled');
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setSettingsIconEnabled(bool $state): self
	{
		$this->set('settingsIconEnabled', $state);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getSettingsIconTarget(): string
	{
		return (string)$this->get('settingsIconTarget', 'purpose');
	}

	/**
	 * @param string $target
	 * @return $this
	 */
	public function setSettingsIconTarget(string $target): self
	{
		$allowedValues = [
			'main',
			'purpose',
		];

		if (in_array($target, $allowedValues) == false) {
			throw new LogicException('Invalid value for settings icon target, allowed values: '.implode(', ', $allowedValues));
		}

		$this->set('settingsIconTarget', $target);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isShowDeclineButton(): bool
	{
		return (bool)$this->get('showDeclineButton');
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setShowDeclineButton(bool $state): self
	{
		$this->set('showDeclineButton', $state);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getSelectType(): string
	{
		return (string)$this->get('selectType', 'checkbox');
	}

	/**
	 * @param string $type
	 * @return $this
	 */
	public function setSelectType(string $type): self
	{
		$allowedValues = [
			'checkbox',
			'switch',
		];

		if (in_array($type, $allowedValues) == false) {
			throw new LogicException('Invalid value for select type, allowed values: '.implode(', ', $allowedValues));
		}

		$this->set('selectType', $type);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isComplyingDoNotTrack(): bool
	{
		return (bool)$this->get('complyingDoNotTrack');
	}

	/**
	 * @param bool $complyingDoNotTrack
	 * @return $this
	 */
	public function setComplyingDoNotTrack(bool $complyingDoNotTrack): self
	{
		$this->set('complyingDoNotTrack', $complyingDoNotTrack);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isShowAcceptAllButtonInControlPanel(): bool
	{
		return (bool)$this->get('showAcceptAllButtonInControlPanel');
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setShowAcceptAllButtonInControlPanel(bool $state): self
	{
		$this->set('showAcceptAllButtonInControlPanel', $state);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getOkButtonBackgroundColor(): string
	{
		return (string)$this->get('okButtonBackgroundColor');
	}

	/**
	 * @param string $okButtonBackgroundColor
	 * @return $this
	 */
	public function setOkButtonBackgroundColor(string $okButtonBackgroundColor): self
	{
		$this->set('okButtonBackgroundColor', $okButtonBackgroundColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getMoreInfoButtonBackgroundColor(): string
	{
		return (string)$this->get('moreInfoButtonBackgroundColor');
	}

	/**
	 * @param string $moreInfoButtonBackgroundColor
	 * @return $this
	 */
	public function setMoreInfoButtonBackgroundColor(string $moreInfoButtonBackgroundColor): self
	{
		$this->set('moreInfoButtonBackgroundColor', $moreInfoButtonBackgroundColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWindowBackgroundColor(): string
	{
		return (string)$this->get('windowBackgroundColor');
	}

	/**
	 * @param string $windowBackgroundColor
	 * @return $this
	 */
	public function setWindowBackgroundColor(string $windowBackgroundColor): self
	{
		$this->set('windowBackgroundColor', $windowBackgroundColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWindowBorderColor(): string
	{
		return (string)$this->get('windowBorderColor');
	}

	/**
	 * @param string $windowBorderColor
	 * @return $this
	 */
	public function setWindowBorderColor(string $windowBorderColor): self
	{
		$this->set('windowBorderColor', $windowBorderColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getLinkInInfotextColor(): string
	{
		return (string)$this->get('linkInInfotextColor');
	}

	/**
	 * @param string $linkInInfotextColor
	 * @return $this
	 */
	public function setLinkInInfotextColor(string $linkInInfotextColor): self
	{
		$this->set('linkInInfotextColor', $linkInInfotextColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getOkButtonColor(): string
	{
		return (string)$this->get('okButtonColor');
	}

	/**
	 * @param string $okButtonColor
	 * @return $this
	 */
	public function setOkButtonColor(string $okButtonColor): self
	{
		$this->set('okButtonColor', $okButtonColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getMoreInfoButtonColor(): string
	{
		return (string)$this->get('moreInfoButtonColor');
	}

	/**
	 * @param string $moreInfoButtonColor
	 * @return $this
	 */
	public function setMoreInfoButtonColor(string $moreInfoButtonColor): self
	{
		$this->set('moreInfoButtonColor', $moreInfoButtonColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getOkButtonBorderColor(): string
	{
		return (string)$this->get('okButtonBorderColor');
	}

	/**
	 * @param string $okButtonBorderColor
	 * @return $this
	 */
	public function setOkButtonBorderColor(string $okButtonBorderColor): self
	{
		$this->set('okButtonBorderColor', $okButtonBorderColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getMoreInfoButtonBorderColor(): string
	{
		return (string)$this->get('moreInfoButtonBorderColor');
	}

	/**
	 * @param string $moreInfoButtonBorderColor
	 * @return $this
	 */
	public function setMoreInfoButtonBorderColor(string $moreInfoButtonBorderColor): self
	{
		$this->set('moreInfoButtonBorderColor', $moreInfoButtonBorderColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getDeclineButtonBackgroundColor(): string
	{
		return (string)$this->get('declineButtonBackgroundColor', $this->getMoreInfoButtonBackgroundColor());
	}

	/**
	 * @param string $color
	 * @return $this
	 */
	public function setDeclineButtonBackgroundColor(string $color): self
	{
		$this->set('declineButtonBackgroundColor', $color);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getDeclineButtonTextColor(): string
	{
		return (string)$this->get('declineButtonTextColor', $this->getMoreInfoButtonColor());
	}

	/**
	 * @param string $color
	 * @return $this
	 */
	public function setDeclineButtonTextColor(string $color): self
	{
		$this->set('declineButtonTextColor', $color);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getDeclineButtonBorderColor(): string
	{
		return (string)$this->get('declineButtonBorderColor', $this->getMoreInfoButtonBorderColor());
	}

	/**
	 * @param string $color
	 * @return $this
	 */
	public function setDeclineButtonBorderColor(string $color): self
	{
		$this->set('declineButtonBorderColor', $color);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getInfotextColor(): string
	{
		return (string)$this->get('infotextColor');
	}

	/**
	 * @param string $infotextColor
	 * @return $this
	 */
	public function setInfotextColor(string $infotextColor): self
	{
		$this->set('infotextColor', $infotextColor);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getInfotextFontFamily(): string
	{
		return (string)$this->get('infotextFontFamily');
	}

	/**
	 * @param string $infotextFontFamily
	 * @return $this
	 */
	public function setInfotextFontFamily(string $infotextFontFamily): self
	{
		$this->set('infotextFontFamily', $infotextFontFamily);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getInfotextFontSize(): string
	{
		return (string)$this->get('infotextFontSize');
	}

	/**
	 * @param string $infotextFontSize
	 * @return $this
	 */
	public function setInfotextFontSize(string $infotextFontSize): self
	{
		$this->set('infotextFontSize', $infotextFontSize);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getIframeBlockerBackgroundColor(): string
	{
		return (string)$this->get('iframeBlockerBackgroundColor', '#111111');
	}

	/**
	 * @param string $hexCode
	 * @return $this
	 */
	public function setIframeBlockerBackgroundColor(string $hexCode): self
	{
		$this->set('iframeBlockerBackgroundColor', $hexCode);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getIframeBlockerForegroundColor(): string
	{
		return (string)$this->get('iframeBlockerForegroundColor', '#f8f8f8');
	}

	/**
	 * @param string $hexCode
	 * @return $this
	 */
	public function setIframeBlockerForegroundColor(string $hexCode): self
	{
		$this->set('iframeBlockerForegroundColor', $hexCode);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getIframeBlockerButtonBackgroundColor(): string
	{
		return (string)$this->get('iframeBlockerButtonBackgroundColor', $this->getOkButtonBackgroundColor());
	}

	/**
	 * @param string $hexCode
	 * @return $this
	 */
	public function setIframeBlockerButtonBackgroundColor(string $hexCode): self
	{
		$this->set('iframeBlockerButtonBackgroundColor', $hexCode);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getIframeBlockerButtonForegroundColor(): string
	{
		return (string)$this->get('iframeBlockerButtonForegroundColor', '#ffffff');
	}

	/**
	 * @param string $hexCode
	 * @return $this
	 */
	public function setIframeBlockerButtonForegroundColor(string $hexCode): self
	{
		$this->set('iframeBlockerButtonForegroundColor', $hexCode);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCustomCss(): string
	{
		return (string)$this->get('customCss');
	}

	/**
	 * @param string $customCss
	 * @return $this
	 */
	public function setCustomCss(string $customCss): self
	{
		$this->set('customCss', $customCss);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCustomCssForIframeBlocker(): string
	{
		return (string)$this->get('customCssForIframeBlocker');
	}

	/**
	 * @param string $customCss
	 * @return $this
	 */
	public function setCustomCssForIframeBlocker(string $customCss): self
	{
		$this->set('customCssForIframeBlocker', $customCss);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getOnlyInEu(): bool
	{
		return (bool)$this->get('onlyInEu');
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setOnlyInEu(bool $value): self
	{
		$this->set('onlyInEu', $value);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getManipulationPrevention(): bool
	{
		return (bool)$this->get('manipulationPrevention', true);
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setManipulationPrevention(bool $value): self
	{
		$this->set('manipulationPrevention', $value);
		return $this;
	}
}
