<?php

namespace App\Model;

use App\Exception\CsrfTokenException;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;

class CsrfToken
{
	/** @var string $token */
	private $token;

	private function __construct($token)
	{
		$this->token = $token;
	}

	/**
	 * @return string
	 */
	public function __toString()
	{
		return $this->token;
	}

	/**
	 * Diese Methode gibt das aktuelle Token zurück
	 * oder erzeugt ein neues.
	 * @return self|null
	 */
	public static function get(): ?self
	{
		$session = Utils::getSession();
		
		$token = $session->get('csrf_token', null);
		if ($token === '' or $token === null) {
			$token = bin2hex(random_bytes(12));
			$session->set('csrf_token', $token);
		}

		return new CsrfToken($token);
	}

	/**
	 * Diese Methode löscht das aktuelle CSRF-Token
	 */
	public static function reset(): void
	{
		$session = Utils::getSession();

		$session->set('csrf_token', null);
	}

	/**
	 * @param string $token
	 * @return void
	 * @throws CsrfTokenException
	 */
	public function check($token): void
	{
		if ($this->token !== (string)$token) {
			throw new CsrfTokenException('invalid or missing token', 0);
		}
	}

	/**
	 * Akzeptiert, wenn das richtige Token in
	 * der POST-Variable csrf_token oder im
	 * Header X-CSRF-Token steht. Ansonsten
	 * wird eine CsrfTokenException geworfen.
	 *
	 * @param Request $request
	 * @return void
	 * @throws CsrfTokenException
	 */
	public function checkRequest(Request $request): void
	{
		if ($request->request->has('csrf_token')) {
			$this->check($request->request->get('csrf_token'));
			return;
		}
		if ($request->headers->has('X-CSRF-Token')) {
			$this->check($request->headers->get('X-CSRF-Token'));
			return;
		}
		throw new CsrfTokenException('missing token', 0);
	}
}
