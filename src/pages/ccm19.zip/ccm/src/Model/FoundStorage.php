<?php

namespace App\Model;

use App\Exception\ConfigNotWritableException;
use App\JsonConfig;
use DateTime;

class FoundStorage extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-found-storage.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return JsonConfig::unescapeKey($this->getId());
	}

	/**
	 * @return DateTime
	 */
	public function getLastSeenOn(): DateTime
	{
		return new DateTime($this->get('last_seen_on'));
	}

	/**
	 * @param DateTime $timestamp
	 * @return $this
	 */
	public function setLastSeenOn(DateTime $timestamp): self
	{
		$this->set('last_seen_on', $timestamp->format('Y-m-d H:i:s'));
		return $this;
	}

	/**
	 * @return string[]
	 */
	public function getFoundOnPages(): array
	{
		return $this->get('found_on_pages') ?? [];
	}

	/**
	 * @param string[] $pages
	 * @return $this
	 */
	public function setFoundOnPages(array $pages): self
	{
		$this->set('found_on_pages', $pages);
		return $this;
	}

	/**
	 * @param string $page
	 * @return $this
	 */
	public function addFoundOnPage(string $page): self
	{
		$array = $this->get('found_on_pages');
		if (!$array) {
			$array = [];
		}
		if (!in_array($page, $array)) {
			$array[] = $page;
		}
		$this->set('found_on_pages', $array);
		return $this;
	}

	public function getIsSessionStorage(): bool
	{
		return (bool)$this->get('is_session_storage');
	}

	public function setIsSessionStorage(bool $is_session): self
	{
		$this->set('is_session_storage', $is_session);
		return $this;
	}

	/**
	 * Diese Methode erstellt ein Objekt dieser Klasse
	 * @param string $id Storage-Key
	 * @return static
	 * @throws \LogicException
	 */
	public static function create($id=null): Model
	{
		if ($id === null) {
			throw new \LogicException('cannot use create() with FoundStorage model');
		}
		self::beginWrite();
		return new static(JsonConfig::escapeKey($id));
	}


	/**
	 * Diese Methode löscht den durch das aktuelle Objekt referenzierten Datensatz aus der Konfiguration.
	 * @param string $id
	 * @param bool $autocommit
	 * @throws ConfigNotWritableException
	 */
	public static function delete(string $id, bool $autocommit=true): void
	{
		parent::delete(JsonConfig::escapeKey($id), $autocommit);
	}
		/**
	 * @param string $id
	 * @return bool
	 */
	public static function exists(string $id): bool
	{
		return parent::exists(JsonConfig::escapeKey($id));
	}

	/**
	 * @param string $id
	 * @return static|null
	 */
	public static function find(string $id): ?Model
	{
		return self::exists($id) ? new static(JsonConfig::escapeKey($id)) : null;
	}
}
