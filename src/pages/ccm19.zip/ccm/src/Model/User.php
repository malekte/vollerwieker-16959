<?php

namespace App\Model;

use App\Config;
use App\Exception\ConfigNotReadableException;
use App\Exception\ConfigNotWritableException;
use App\Exception\UserAlreadyExistsException;
use App\Exception\UserIsBlockedException;
use App\Exception\UserIsDeactivatedException;
use App\JsonConfig;
use App\Utils;
use DateTime;
use DateTimeInterface;
use DateTimeZone;
use LogicException;
use Symfony\Component\HttpFoundation\Session\Session;

class User extends Model
{
	const LOGIN_BLOCKED_DURATION = 900;
	const LOGIN_MAX_RETRIES = 2;

	const ROLE_ADMIN = 'admin';
	const ROLE_CLIENT = 'client';

	private const PASSWORD_ALGORITHM = PASSWORD_BCRYPT;
	private const PASSWORD_COST = 10;

	/** @var self|null $apiUser */
	private static $apiUser = null;

	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-users.json';

	/** @var array $nameLookupCache */
	private static $nameLookupCache = [];

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * Diese Methode wird ausgeführt, sobald das Repository durch die Basisklasse Model geladen wurde.
	 */
	protected static final function onRepositoryLoaded(): void
	{
		self::migrateFromConfig();

		if (self::count() == 1) {
			/** @var self $user */
			$user = array_values(self::all())[0];

			// Updateroutine: Benutzerrolle Administrator in alten Versionen nachtragen
			if (empty($user->getRole())) {
				$user->setRole(self::ROLE_ADMIN)->save();
			}
		}

		// Updateroutine: API-Schlüssel für Benutzer generieren
		foreach (self::all() as $user) {
			/** @var self $user */
			if (empty($user->getApiKey())) {
				$user->generateApiKey();
			}
		}

		self::flush();
	}

	/**
	 * Diese Methode migriert den Datenbestand an Benutzern aus der Systemkonfiguration in das eigene Modul.
	 * @throws ConfigNotWritableException
	 */
	private static function migrateFromConfig(): void
	{
		$config = Config::getInstance();

		if ((bool)$config->get('usersMigratedIntoOwnModule')) {
			return;
		}

		$users = $config->get('users');
		if (is_array($users) == false) {
			return;
		}

		foreach ($users as $userData) {
			$username = trim($userData['username'] ?? '');
			$passwordHash = trim($userData['password_hash'] ?? '');

			if (empty($username) || empty($passwordHash)) {
				continue;
			}

			try {
				$user = self::create($username)->setPasswordHash($passwordHash);
			}
			catch (UserAlreadyExistsException $exception) {
				continue;
			}
		}

		// Migrierte Benutzer auf die Platte schreiben und Migration als durchgeführt festhalten
		self::flush();
		$config->unset('users');
		$config->set('usersMigratedIntoOwnModule', true);
	}

	/**
	 * @param string $id
	 * @return static|null
	 */
	public static function byId(string $id): ?self
	{
		return parent::find($id);
	}

	/**
	 * @param string $key
	 * @return self|null
	 */
	public static function byApiKey(string $key): ?self
	{
		return array_reduce(self::all(), function ($user, $currentUser) use ($key) {
			/** @var self $currentUser */
			return $user ?? ($currentUser->getApiKey() == $key ? $currentUser : $user);
		}, null);
	}

	/**
	 * @param string $role
	 * @return self[]
	 */
	public static function byRole(string $role): array
	{
		return array_filter(self::all(), function ($user) use ($role) {
			/** @var User $user */
			return $user->getRole() == $role;
		});
	}

	/**
	 * Diese Methode liefert den aktuell eingeloggten Benutzer oder null, falls keiner existiert.
	 * Bei externen Aufrufen wird ggf. der API-Schlüssel berücksichtigt und der entsprechende Benutzer verwendet.
	 * @return self|null
	 * @phan-return static|null
	 */
	public static function loggedInUser(): ?self
	{
		if (self::$apiUser) {
			return self::$apiUser;
		}

		$session = Utils::getSession();
		$name = $session->get('user', '');
		return ($name !== '') ? self::find($name) : null;
	}

	/**
	 * Diese Methode liefert den ursprünglich eingeloggten Benutzer, wenn aus
	 * dem Admin-Konto in einen Kunden gewechselt wurde und ansonsten null.
	 * @return self|null
	 * @phan-return static|null
	 */
	public static function originalLoggedInUser(): ?self
	{
		$session = Utils::getSession();
		$name = $session->get('originalUser', '');
		return ($name !== '') ? self::find($name) : null;
	}

	/**
	 * @param string $key
	 * @return bool
	 */
	public static function setApiUser(string $key): bool
	{
		return (bool)(self::$apiUser = self::byApiKey($key));
	}

	/**
	 * Diese Methode ermittelt, ob bereits ein Benutzer mit demselben Namen existiert.
	 * @param string $username
	 * @return bool
	 */
	public static function exists(string $username): bool
	{
		if (isset(self::$nameLookupCache[$username])) {
			return true;
		}

		return array_reduce(self::all(), function ($userExists, $user) use ($username) {
			/** @var self $user */
			return $userExists || mb_strtolower($user->getUsername()) === mb_strtolower($username);
		}, false);
	}

	/**
	 * Diese Methode gibt den zu $username passenden Benutzer zurück.
	 * @param string $username
	 * @return static|null
	 * @override
	 * @phan-return static|null
	 */
	public static function find(string $username): ?Model
	{
		/** @var User|null $result */
		$result = self::$nameLookupCache[$username] ?? null;

		// Wenn nicht im Cache: suchen
		if ($result === null) {
			$result = array_reduce(self::all(), function ($foundUser, $user) use ($username) {
				/** @var self $user */
				/** @var self|null $foundUser */
				if ($foundUser) {
					return $foundUser;
				}

				return mb_strtolower($user->getUsername()) === mb_strtolower($username)
					? $user
					: null;
			}, null);

			// Ergebnis im Cache speichern
			if ($result) {
				self::$nameLookupCache[$username] = $result;
			}
		}

		return $result;
	}

	/**
	 * Diese Methode sucht nach Usern und gibt ein Ergebnis-Array zurük.
	 * @param string $search Suchbegriff
	 * @return User[]
	 */
	public static function search(string $search): array
	{
		return array_filter(self::all(), function ($user) use ($search) {
			/** @var User $user */
			if (	stristr($user->getUsername()		,$search)
				|| 	stristr($user->getEmailAddress()	,$search)
				|| 	stristr($user->getFirstName()		,$search)
				|| 	stristr($user->getLastName()		,$search)
				|| 	stristr($user->getCompany()			,$search)
			)
			{
				if($user->getRole()=="client")
				{
					return $user->getId();
				}

			}

		});
	}

	/**
	 * Diese Methode fügt der Konfiguration einen neuen Benutzer hinzu, allerdings wird die Anpassung nicht permanent
	 * geschrieben. Zu einem späteren Zeitpunkt kann dies mit User::flush nachgeholt werden.
	 * @param ?string $username
	 * @return self
	 * @throws LogicException
	 * @throws UserAlreadyExistsException
	 * @override
	 * @phan-return static
	 * @phan-assert string $username
	 * @phan-assert-true-condition $username
	 */
	public static function create(?string $username = null): Model
	{
		if (empty($username)) {
			throw new LogicException('Username may not be empty.');
		}

		self::beginWrite();
		if (self::exists($username)) {
			throw new UserAlreadyExistsException($username);
		}

		/** @var self $user */
		$user = parent::create();
		assert($user instanceof User);
		$user
			->setUsername($username)
			->setCreateTimeStamp()
			->generateApiKey()
		;

		return $user;
	}

	/**
	 * Diese Methode loggt einen Benutzer ins System ein.
	 * @param string $username
	 * @param string $password
	 * @return self|null
	 * @throws ConfigNotWritableException
	 * @throws UserIsBlockedException
	 */
	public static function login(string $username, string $password): ?self
	{
		$user = self::find($username);

		if ($user) {
			if ($user->isBlocked()) {
				throw new UserIsBlockedException($user->getUsername());
			}
			elseif ($user->isActive() == false && $user->getRole() == User::ROLE_CLIENT) {
				throw new UserIsDeactivatedException($user->getUsername());
			}
			elseif ($user->checkPassword($password)) {
				$user->switchTo();

				// Passwort-Hash ggf. aktualisieren
				if (password_needs_rehash($user->getPasswordHash(), self::PASSWORD_ALGORITHM, [
					'cost' => self::PASSWORD_COST,
				])) {
					$user->setPassword($password);
				}

				$user
					->resetFailedLoginAttempts()
					->setLastLogin()
					->save()
				;
				return $user;
			}
			else {
				$user
					->incrementFailedLoginAttempts()
					->touchFailedLoginTimestamp()
					->save()
				;
			}
		}
		return null;
	}

	/**
	 * Diese Methode loggt einen Benutzer ins System ein, ohne Passwortabfrage.
	 * @param bool $keepPreviousUserInfo Ob gespeichert werden soll, wer ursprünglich eingeloggt war, um zurückwechseln zu können.
	 * @return self
	 * @throws ConfigNotWritableException
	 * @throws UserIsBlockedException
	 */
	public function switchTo(bool $keepPreviousUserInfo=false): self
	{
		$prevUser = User::loggedInUser();
		$session = Utils::getSession();
		$session->clear();
		$session->set('user', $this->getUsername());
		if ($keepPreviousUserInfo && $prevUser->getUsername() !== $this->getUsername()) {
			$session->set('originalUser', $prevUser->getUsername());
		}
		return $this;
	}

	/**
	 * Liest alle Einträge neu von der Festplatte ein.
	 * Sämtliche Änderungen gehen verloren.
	 * @throws ConfigNotReadableException
	 * @override
	 */
	public static function reload(): void
	{
		parent::reload();
		self::$nameLookupCache = [];
	}

	/**
	 * Diese Methode schreibt alle durch Setter-Methoden vorgenommenen
	 * Änderungen im Model in die Konfiguration auf der Platte.
	 * @return void
	 * @throws ConfigNotWritableException
	 * @override
	 */
	public static function flush(): void
	{
		self::getRepository()->flush();
		self::$nameLookupCache = [];
	}

	/**
	 * Diese Methode loggt den aktiven Benutzer aus dem System aus.
	 */
	public static function logout(): void
	{
		$session = Utils::getSession();
		$session->set('user', null);
		$session->set('csrf_token', null);
		$session->clear();
	}

	/**
	 * Diese Methode nennt das benutzerspezifische Konfigurationsverzeichnis.
	 * @param bool $rel Wenn true, wird der Pfad relativ zum Verzeichnis var/ zurückgegeben, ansonsten als abosluter Pfad.
	 * @return string
	 */
	public function configDir(bool $rel = false): string
	{
		$relPath = 'user_data/'.$this->getId();
		if ($rel) {
			return $relPath;
		}

		return Utils::getVarDir() . DIRECTORY_SEPARATOR . $relPath;
	}

	/**
	 * @return string
	 */
	public function getUsername(): string
	{
		return (string)$this->get('username');
	}

	/**
	 * @param string $username
	 * @return $this
	 */
	private function setUsername(string $username): self
	{
		$this->set('username', $username);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getCreateTimeStamp(): int
	{
		return (int)$this->get('createtimestamp');
	}

	/**
	 * @return $this
	 */
	private function setCreateTimeStamp(): self
	{
		$this->set('createtimestamp', time());
		return $this;
	}

	//setLastLogin
	/**
	 * @return int
	 */
	public function getLastLogin(): int
	{
		return (int)$this->get('lastlogin');
	}

	/**
	 * @return $this
	 */
	private function setLastLogin(): self
	{
		$this->set('lastlogin', time());
		return $this;
	}


	/**
	 * @return string
	 */
	public function getRole(): string
	{
		return (string)$this->get('role');
	}

	/**
	 * @param string $role
	 * @return $this
	 */
	public function setRole(string $role): self
	{
		$this->set('role', $role);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getApiKey(): string
	{
		return (string)$this->get('apiKey');
	}

	/**
	 * Diese Methode generiert einen unter allen Benutzern eindeutigen API-Schlüssel.
	 * @return $this
	 */
	private function generateApiKey(): self
	{
		$users = self::all();

		$apiKey = null;
		do {
			$apiKey = bin2hex(random_bytes(24));
		} while (array_reduce($users, function ($exists, $user) use ($apiKey) {
			/** @var self $user */
			return $exists || $user->getApiKey() == $apiKey;
		}, false));

		$this->set('apiKey', $apiKey);
		return $this;
	}

	/**
	 * @param string $password
	 * @return $this
	 */
	public function setPassword(string $password): self
	{
		$passwordHash = password_hash($password, self::PASSWORD_ALGORITHM, [
			'cost' => self::PASSWORD_COST,
		]);

		return $this->setPasswordHash($passwordHash);
	}

	/**
	 * @param string $password
	 * @return bool
	 */
	public function checkPassword(string $password): bool
	{
		return password_verify($password, $this->getPasswordHash());
	}

	/**
	 * @return string
	 */
	public function getPasswordHash(): string
	{
		return (string)$this->get('passwordHash');
	}

	/**
	 * Diese Methode überschreibt den Passwort-Hash des Benutzers. Aufgrund bestimmter Anforderungen
	 * an die Hosting-API ist die Methode `public`. Nach Möglichkeit sollte vorzugsweise ein Passwort
	 * in Klartext über die Methode `setPassword` eingepflegt werden.
	 *
	 * @see setPassword
	 *
	 * @param string $hash
	 * @return $this
	 */
	public function setPasswordHash(string $hash): self
	{
		$this->set('passwordHash', $hash);
		return $this;
	}

	public function getFailedLoginAttempts(): int
	{
		return (int)$this->get('failedLoginAttempts');
	}

	public function incrementFailedLoginAttempts(): self
	{
		self::beginWrite();
		$this->set('failedLoginAttempts', $this->getFailedLoginAttempts() + 1);
		return $this;
	}

	public function resetFailedLoginAttempts(): self
	{
		$this->set('failedLoginAttempts', 0);
		return $this;
	}

	public function getFailedLoginTimestamp(): int
	{
		return (int)$this->get('failedLoginTimestamp');
	}

	public function touchFailedLoginTimestamp(): self
	{
		$this->set('failedLoginTimestamp', time());
		return $this;
	}

	public function isBlocked(): bool
	{
		$attempts = $this->getFailedLoginAttempts();
		$time = $this->getFailedLoginTimestamp();

		// Wenn alle Versuche aufgebraucht und Zeitsperre abgelaufen, Benutzer wieder freigeben
		if ($attempts > self::LOGIN_MAX_RETRIES && time() - $time > self::LOGIN_BLOCKED_DURATION) {
			$this->resetFailedLoginAttempts()->save();
		}

		return $this->getFailedLoginAttempts() > self::LOGIN_MAX_RETRIES;
	}

	/**
	 * @return string
	 */
	public function getFirstName(): string
	{
		return (string)$this->get('firstName');
	}

	/**
	 * @param string $value
	 * @return $this
	 */
	public function setFirstName(string $value): self
	{
		$this->set('firstName', $value);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getLastName(): string
	{
		return (string)$this->get('lastName');
	}

	/**
	 * @param string $value
	 * @return $this
	 */
	public function setLastName(string $value): self
	{
		$this->set('lastName', $value);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getEmailAddress(): string
	{
		return (string)$this->get('emailAddress');
	}

	/**
	 * @param string $value
	 * @return $this
	 */
	public function setEmailAddress(string $value): self
	{
		$this->set('emailAddress', $value);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCompany(): string
	{
		return (string)$this->get('company');
	}

	/**
	 * @param string $value
	 * @return $this
	 */
	public function setCompany(string $value): self
	{
		$this->set('company', $value);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isOnBoarding(): bool
	{
		return (bool)$this->get('OnBoarding') ?? FALSE;
	}

	/**
	 * @param bool $OnBoarding
	 * @return $this
	 */
	public function setOnBoarding(bool $OnBoarding): self
	{
		$this->set('OnBoarding', $OnBoarding);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isActive(): bool
	{
		return (bool)$this->get('active');
	}

	/**
	 * @param bool $active
	 * @return $this
	 */
	public function setActive(bool $active): self
	{
		$this->set('active', $active);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getMaxWLCount(): int
	{
		return (int)$this->get('maxWLCount');
	}

	/**
	 * @param int $value
	 * @return $this
	 */
	public function setMaxWLCount($value): self
	{
		$this->set('maxWLCount', (int)$value);
		return $this;
	}

	/**
	 * @return array
	 */
	public function getDomList(): array
	{
		return (array)$this->get('domlist');
	}

	/**
	 * @param array $value
	 * @return $this
	 */
	public function setDomList($value): self
	{
		$this->set('domlist', (array)$value);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getActualWLCount(): int
	{
		return (int)$this->get('actualWLCount');
	}

	/**
	 * @param int $value
	 * @return $this
	 */
	public function setActualWLCount($value): self
	{
		$this->set('actualWLCount', (int)$value);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPasswordRecoveryKey(): string
	{
		return (string)$this->get('passwordRecoveryKey');
	}

	/**
	 * @return DateTimeInterface
	 */
	public function getPasswordRecoveryTime(): DateTimeInterface
	{
		$value = $this->get('passwordRecoveryTime');
		if (!$value) {
			$value = '1970-01-01 00:00:00';
		}
		return new DateTime((string)$value);
	}

	/**
	 * @param string|null $value
	 * @return $this
	 */
	public function setPasswordRecoveryKey(?string $value): self
	{
		if ($value === null) {
			$this->set('passwordRecoveryKey', null);
			$this->set('passwordRecoveryTime', null);
		}
		else {
			$this->set('passwordRecoveryKey', $value);
			$this->set('passwordRecoveryTime', (new DateTime('now'))->format('Y-m-d H:i:s'));
		}
		return $this;
	}

	/**
	 * @return Locale|null
	 */
	public function getDefaultLocale(): ?Locale
	{
		return Locale::find((string)$this->get('defaultLocale'));
	}

	/**
	 * @param Locale $locale
	 * @return $this
	 */
	public function setDefaultLocale(Locale $locale): self
	{
		$this->set('defaultLocale', $locale->getName());
		return $this;
	}

	/**
	 * @return int
	 */
	public function getMaxDomainCount(): int
	{
		return (int)$this->get('maxDomainCount');
	}

	/**
	 * @param int $value
	 * @return $this
	 */
	public function setMaxDomainCount(int $value): self
	{
		if ($value < -1) {
			throw new \OutOfRangeException("$value is no valid maximum domain count");
		}
		$this->set('maxDomainCount', $value);
		return $this;
	}
	//MaxCallCount
	/**
	 * @return int
	 */
	public function getMaxCallCount(): int
	{
		return (int)$this->get('MaxCallCount');
	}

	/**
	 * @param int $value
	 * @return $this
	 */
	public function setActualDomainCount(int $value): self
	{
		$this->set('actualdomaincount', $value);
		return $this;
	}
	/**
	 * @return int
	 */
	public function getActualDomainCount(): int
	{
		return (int)$this->get('actualdomaincount');
	}
	//MaxCallCount
	/**
	 * @return int
	 */
	public function getActualCallCount(): int
	{
		return (int)$this->get('actualCallCount');
	}

	/**
	 * @param int $count
	 * @return $this
	 */
	public function setCallCount(int $count): self
	{
		$this->set('actualCallCount', $count);
		return $this;
	}

	/**
	 * @return $this
	 */
	public function incrementCallCount(int $diff=1): self
	{
		self::beginWrite();
		return $this->setCallCount($this->getActualCallCount() + $diff);
	}

	/**
	 * @return bool
	 */
	public function callCountReached(): bool
	{
		$callCount = $this->getActualCallCount();
		$callMaxCount = $this->getMaxCallCount();

		return ($callMaxCount > -1) && ($callCount >= $callMaxCount);
	}

	/**
	 * Diese Methode setzt den Aufrufszähler zurück auf 0, wenn ein neuer Monat begonnen hat.
	 * @return $this
	 */
	public function resetCallCountForNextMonth(): self
	{
		$previousMonth = (new DateTime('@'.max(0, (int)$this->get('callCountMonthTimestamp'))))->setTimezone(new DateTimeZone('Europe/Berlin'));
		$currentMonth = new DateTime(date('Y-m-01 00:00:00'), new DateTimeZone('Europe/Berlin'));

		if ($currentMonth != $previousMonth) {
			$this->set('callCountMonthTimestamp', $currentMonth->getTimestamp());
			$this
				->setCallCount(0)
				->setLastCallReportQuota(0)
			;
		}

		return $this;
	}

	/**
	 * @return int
	 */
	public function getLastCallReportQuota(): int
	{
		return (int)$this->get('lastCallReportQuota');
	}

	/**
	 * @param int $quota
	 * @return $this
	 */
	public function setLastCallReportQuota(int $quota): self
	{
		$this->set('lastCallReportQuota', (int)min(max(0, $quota), 100));
		return $this;
	}

	/**
	 * @param int $value
	 * @return $this
	 */
	public function setMaxCallCount(int $value): self
	{
		if ($value < -1) {
			throw new \OutOfRangeException("$value is no valid maximum domain count");
		}
		$this->set('MaxCallCount', $value);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isAutoAddDomains(): bool
	{
		return (bool)$this->get('autoAddDomains') ?? false;
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setAutoAddDomains(bool $value): self
	{
		$this->set('autoAddDomains', $value);
		return $this;
	}

	/**
	 * Letztes Versionsupdate, über das der Nutzer informiert wurde
	 */
	public function getLastNotifiedVersion(): ?string
	{
		return $this->get('lastNotifiedVersion') ?? null;
	}

	/**
	 * @param string|null $value
	 * @return $this
	 */
	public function setLastNotifiedVersion(?string $value): self
	{
		$this->set('lastNotifiedVersion', $value);
		return $this;
	}
}
