<?php

namespace App\Model;

use App\JsonConfig;
use App\Model\Locale;
use App\Exception\ConfigNotWritableException;

class Script extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-scripts.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	const CURRENT_HASH_VERSION = 2;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return static[]
	 * @phan-suppress PhanTypeMismatchArgument
	 */
	public static function all($ignoreHashVersion=false): array
	{
		if ($ignoreHashVersion) {
			return parent::all();
		}
		else {
			return array_filter(parent::all(), function (Script $obj) {
				return $obj->getHashVersion() == self::CURRENT_HASH_VERSION;
			});
		}
	}

	/**
	 * Zählt die vorhandenen Instanzen dieses Models.
	 * @return int
	 */
	public static function count($ignoreHashVersion=false): int
	{
		if ($ignoreHashVersion) {
			return parent::count();
		}
		return count(array_filter(self::getRepository()->toArray(), function ($item) {
			return (int)($item['hashVersion'] ?? 1) == self::CURRENT_HASH_VERSION;
		}));
	}

	/**
	 * @return static[]
	 */
	public static function byEnabled(bool $enabled=true): array
	{
		return array_filter(static::all(), function (Script $obj) use ($enabled) {
			return $obj->getEnableScript() == $enabled;
		});
	}

	/**
	 * @return string
	 */
	public function getContent(): string
	{
		return (string)$this->get('content');
	}

	/**
	 * @param string $url
	 * @return $this
	 */
	public function setContent(string $url): self
	{
		$this->set('content', $url);
		return $this;
	}

	/**
	 * @return string[]
	 */
	public function getFoundOnPages(): array
	{
		return $this->get('found_on_pages') ?? [];
	}

	/**
	 * @param string[] $pages
	 * @return $this
	 */
	public function setFoundOnPages(array $pages): self
	{
		$this->set('found_on_pages', $pages);
		return $this;
	}

	/**
	 * @param string $page
	 * @return $this
	 */
	public function addFoundOnPage(string $page): self
	{
		$array = $this->get('found_on_pages');
		if (!$array) {
			$array = [];
		}
		if (!in_array($page, $array)) {
			$array[] = $page;
		}
		$this->set('found_on_pages', $array);
		return $this;
	}

	/**
	 * @return string[]
	 */
	public function getCookies(): array
	{
		return $this->get('cookies') ?? [];
	}

	/**
	 * @param string[] $cookies
	 * @return $this
	 */
	public function setCookies(array $cookies): self
	{
		$this->set('cookies', $cookies);
		return $this;
	}

	/**
	 * @param string[] $cookies
	 * @return $this
	 */
	public function addCookies(array $cookies): self
	{
		$array = $this->get('cookies');
		if (!$array) {
			$array = [];
		}
		$array = array_unique(array_merge(
			$array,
			$cookies
		));

		$this->set('cookies', $array);
		return $this;
	}

	/**
	 * Diese Methode erstellt ein Objekt dieser Klasse
	 * @param string $id
	 * @return static
	 * @throws \LogicException
	 */
	public static function create($id=null): Model
	{
		if ($id === null) {
			throw new \LogicException('cannot use create() with Script model');
		}
		self::beginWrite();
		$obj = new static(JsonConfig::escapeKey($id));
		$obj->setHashVersion();
		return $obj;
	}

	/**
	 * Diese Methode löscht den referenzierten Datensatz aus der Konfiguration.
	 * @param string $id
	 * @param bool $autocommit
	 * @throws ConfigNotWritableException
	 */
	public static function delete(string $id, bool $autocommit=true): void
	{
		parent::delete(JsonConfig::escapeKey($id), $autocommit);
	}
		/**
	 * @param string $id
	 * @return bool
	 */
	public static function exists(string $id): bool
	{
		return parent::exists(JsonConfig::escapeKey($id));
	}

	/**
	 * @param string $id
	 * @return static|null
	 */
	public static function find(string $id): ?Model
	{
		return self::exists($id) ? new static(JsonConfig::escapeKey($id)) : null;
	}

	/**
	 * @return bool
	 */
	public function getEnableScript(): bool
	{
		return (bool)$this->get('enableScript');
	}

	/**
	 * @param bool $enableScript
	 * @return $this
	 */
	public function setEnableScript(bool $enableScript): self
	{
		$this->set('enableScript', $enableScript);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getHashVersion(): int
	{
		return (int)($this->get('hashVersion') ?? 1);
	}

	/**
	 * @param int $version
	 * @return $this
	 */
	public function setHashVersion(int $version=2): self
	{
		$this->set('hashVersion', $version);
		return $this;
	}

}
