<?php

namespace App\Model;

use App\Component\ConfigImporterContext;
use App\JsonConfig;
use App\Utils;
use DateTime;
use DateTimeInterface;
use LogicException;

class Domain extends Model
{
	const MANAGEMENT_STRUCTURE_COOKIE = 'cookie';
	const MANAGEMENT_STRUCTURE_EMBEDDING = 'embedding';

	/** @var self|null $requestDomain */
	private static $requestDomain = null;

	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-domains.json';

	/** @var bool $userSpecificRepository */
	protected static $userSpecificRepository = true;

	/** @var User|null $user */
	private $user;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
		$this->getUser();
	}

	/**
	 * Zählt die Domains unter Einbezug der Domainnamen für das
	 * Consent-Sharing.
	 *
	 * Eine Domain mit drei Namen zählt hier z.B. als drei Domains.
	 */
	public static function countIncludingShareNames(): int
	{
		return array_reduce(self::all(), function ($carry, $domain) {
			return $carry + $domain->getDomainNamesCount();
		}, 0);
	}

	/**
	 * @param string $name
	 * @return self|null
	 */
	public static function byName(string $name): ?self
	{
		$name = strtolower($name);
		return array_reduce(self::all(), function ($carry, $domain) use ($name) {
			return $carry ?? (strtolower($domain->getName()) == $name ? $domain : $carry);
		}, null);
	}

	/**
	 * Findet die Domain, die am besten zum Domainnamen passt
	 * @param string $name
	 * @return self|null
	 */
	public static function byMatchedDomain(string $name): ?self
	{
		$name = strtolower($name);
		$result = array_reduce(self::all(), function ($carry, $domain) use ($name) {
			list($carryDomain, $carryPrio) = $carry;
			$prio = $domain->matchesDomainName($name);
			if ($prio > $carryPrio) {
				return [$domain, $prio];
			} else {
				return $carry;
			}
		}, [null, 0]);
		return $result[0];
	}

	/**
	 * Wechselt zum Domain-Repository eines anderen Users
	 *
	 * @param User $user
	 * @param bool $flush Ob Änderungen im vorherigen Repository gespeichert werden sollen
	 * @return void
	 */
	public static function switchToUser(User $user, bool $flush=false)
	{
		if ($flush && static::$repository) {
			static::flush();
		}
		static::$repository = static::openRepository($user);
	}

	/**
	 * @return static
	 * @throws LogicException Ist für Model Domain nicht verfügbar.
	 * @see self::createForUser
	 * @override @internal
	 */
	public static function create(): Model
	{
		throw new LogicException('Use Domain::createForUser to add a new domain');
	}

	/**
	 * @param User $user Use User::loggedInUser()
	 * @param bool $useSkeleton
	 * @return static
	 */
	public static function createForUser(User $user, $useSkeleton = true): self
	{
		/** @var self $domain */
		$domain = parent::create();
		assert($domain instanceof Domain);
		$domain
			->setUser($user)
		;

		if ($useSkeleton) {
			$context = new ConfigImporterContext(null, $domain);

			Cookie::importSkeleton($context);
			LegalText::importSkeleton($context);
			Locale::importSkeleton($context);
			Theme::importSkeleton($context);
			Placeholder::importSkeleton($context);
		}

		// System- und User-Themes für Benutzer der Hostingversion in neue Domain integrieren
		if (Utils::isExtendedEdition()) {
		// In Theme-Kontext der neuen Domain wechseln
		Theme::switchRepository($user, $domain);

		// System-Themes importieren
		foreach (SystemTheme::all() as $systemTheme) {
			$theme = Theme::create()
				->setSystemTheme($systemTheme)
			;

			if ($systemTheme->isDefaultTheme()) {
				$theme->makeDefault();
			}
		}

		// User-Themes importieren
		foreach (UserTheme::all() as $userTheme) {
			$theme = Theme::create()
				->setUserTheme($userTheme)
			;

			if ($userTheme->isDefaultTheme()) {
				$theme->makeDefault();
			}
		}

		// Themes schreiben
		Theme::flush();
		}

		return $domain;
	}

	/**
	 * Diese Methode wählt die aktuelle Domain zur Bearbeitung im Backend aus; ähnlich wie User::login, nur für Domains.
	 * @param string $id
	 * @return bool
	 */
	public static function select(string $id): bool
	{
		$domain = self::find($id);

		$session = Utils::getSession();
		$session->set('domain', $domain ? $domain->getId() : '');

		return (bool)$domain;
	}

	/**
	 * Diese Methode liefert die aktuell verwendete Domain oder null, falls keine aktiv ist.
	 * Für externe Aufrufe wird, bei gültigem API-Schlüssel, die übergebene Domain-ID verwendet.
	 * @return self|null
	 */
	public static function activeDomain(): ?self
	{
		if (self::$requestDomain) {
			return self::$requestDomain;
		}

		$session = Utils::getSession();

		if (Utils::isBaseEdition() && empty($session->get('domain'))) {
			/** @var self $domain */
			$domain = null;

			if (self::count() == 0) {
				$user = User::loggedInUser();
				assert($user instanceof User);
				$domain = self::createForUser($user);
				self::flush();
			}
			else {
				$domain = array_values(self::all())[0];
			}

			self::select($domain->getId());
		}

		return self::find((string)$session->get('domain', ''));
	}

	/**
	 * @param string $id
	 * @return bool
	 */
	public static function setDomainForRequest(string $id): bool
	{
		return (bool)(self::$requestDomain = self::find($id));
	}

	/**
	 * Diese Methode nennt das domainspezifische Konfigurationsverzeichnis.
	 * @param bool $rel Wenn true, wird der Pfad relativ zum Verzeichnis var/ zurückgegeben, ansonsten als abosluter Pfad.
	 * @return string
	 * @throws LogicException
	 */
	public function configDir(bool $rel = false): string
	{
		$user = $this->getUser();

		if ($user == null) {
			throw new LogicException('User referenced by domain does not exist.');
		}

		return $user->configDir($rel).'/domains/'.$this->getId();
	}

	/**
	 * @param string $id
	 * @param bool $autocommit
	 */
	public static function delete(string $id, bool $autocommit = true): void
	{
		/** @var Domain|null $domain */
		$domain = Domain::find($id);

		if ($domain == null) {
			return;
		}

		Utils::removeDirectory($domain->configDir());
		parent::delete($id, true);

		// Für den Fall, dass die derzeit aktive Domain gelöscht wurde, Auswahl nach Löschvorgang aufheben
		self::select('');
	}

	/**
	 * Diese Methode nennt das domainspezifische Konfigurationsverzeichnis.
	 * @param bool $rel Wenn true, wird der Pfad relativ zum Verzeichnis var/ zurückgegeben, ansonsten als abosluter Pfad.
	 * @return string
	 * @throws LogicException
	 */
	public function logoDir(bool $rel = false): string
	{
		return $this->configDir($rel).'/logos';
	}

	/**
	 * @return string
	 */
	private function getUserId(): string
	{
		return (string)$this->get('userId');
	}

	/**
	 * @param string $id
	 * @return $this
	 */
	private function setUserId(string $id): self
	{
		$this->set('userId', $id);
		return $this;
	}

	/**
	 * Diese Methode gibt den Benutzer zurück, dem diese Domain zugewiesen ist.
	 * @return User|null
	 */
	public function getUser(): ?User
	{
		if ($this->user == null) {
			$this->user = User::byId($this->getUserId());
		}

		return $this->user;
	}

	/**
	 * @param User $user
	 * @return $this
	 */
	private function setUser(User $user): self
	{
		$this->setUserId($user->getId());
		return $this;
	}

    /**
     * @return bool
     */
    public function isOnBoarding(): bool
    {
        return (bool)$this->get('OnBoarding') ?? FALSE;
    }

    /**
     * @param bool $OnBoarding
     * @return $this
     */
    public function setOnBoarding(bool $OnBoarding): self
    {
        $this->set('OnBoarding', $OnBoarding);
        return $this;
    }

	/**
	 * @return bool
	 */
	public function hasWhitelabel(): bool
	{
		return (bool)$this->get('whitelabel');
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setWhitelabel(bool $value): self
	{
		$this->set('whitelabel', $value);
		return $this;
	}

	/**
	 * Zählt die vorhandenen Instanzen dieses Models.
	 * @return int
	 */
	public static function whitelabelCountForAllDomains(): int
	{
		return array_reduce(self::all(), function ($count, $domain) {
			/** @var self $domain */
			return $domain->hasWhitelabel() ? $count + 1 : $count;
		}, 0);
	}

	/**
	 * Zählt die Domains, in denen die Ausgabe des Frontend-Widgets aktiviert ist.
	 * @return int
	 */
	public static function frontendWidgetCountForAllDomains(): int
	{
		return array_reduce(self::all(), function ($count, $domain) {
			/** @var Domain $domain */
			return $domain->isFrontendWidgetEnabled() ? $count + 1 : $count;
		}, 0);
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	public function setName(string $name): self
	{
		$this->set('name', $name);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isIframesBlocked(): bool
	{
		return (bool)$this->get('blockIframes');
	}

	/**
	 * @param bool $block
	 * @return $this
	 */
	public function setIframesBlocked(bool $block): self
	{
		$this->set('blockIframes', $block);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isRememberIframeConsentPerDomain(): bool
	{
		return (bool)$this->get('rememberIframeConsentPerDomain');
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setRememberIframeConsentPerDomain(bool $state): self
	{
		$this->set('rememberIframeConsentPerDomain', $state);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isNewScriptsBlocked(): bool
	{
		return (bool)$this->get('blockScripts');
	}

	/**
	 * @param bool $block
	 * @return $this
	 */
	public function setNewScriptsBlocked(bool $block): self
	{
		$this->set('blockScripts', $block);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isSameDomainScriptsBlocked(): bool
	{
		return (bool)($this->get('blockSameDomainScripts') ?? true);
	}

	/**
	 * @param bool $block
	 * @return $this
	 */
	public function setSameDomainScriptsBlocked(bool $block): self
	{
		$this->set('blockSameDomainScripts', $block);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isInlineScriptsBlocked(): bool
	{
		return (bool)($this->get('blockInlineScripts') ?? true);
	}

	/**
	 * @param bool $block
	 * @return $this
	 */
	public function setInlineScriptsBlocked(bool $block): self
	{
		$this->set('blockInlineScripts', $block);
		return $this;
	}

	/**
	 * @return string[]
	 */
	public function getAllowedScriptMarkers(): array
	{
		return (array)$this->get('allowedScriptMarkers');
	}

	/**
	 * @param string[] $list
	 * @return $this
	 */
	public function setAllowedScriptMarkers(array $list): self
	{
		$this->set('allowedScriptMarkers', $list);
		return $this;
	}

	/**
	 * @return string[]
	 */
	public function getIframeMarkers(): array
	{
		return (array)$this->get('iframeMarkers', $this->get('allowedIframeMarkers'));
	}

	/**
	 * @param string[] $list
	 * @return $this
	 */
	public function setIframeMarkers(array $list): self
	{
		$this->set('iframeMarkers', $list);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getIframeBlockMode(): string
	{
		return $this->get('iframeBlockMode', 'whitelist');
	}

	/**
	 * @param string $mode
	 * @return $this
	 */
	public function setIframeBlockMode(string $mode): self
	{
		$this->set('iframeBlockMode', $mode);
		return $this;
	}


	/**
	 * @return bool
	 */
	public function isfrontendLegalEnabled(): bool
	{
		return (bool)$this->get('frontendLegalEnabled', false);
	}

	/**
	 * @param bool $enabled
	 * @return $this
	 */
	public function setfrontendLegalEnabled(bool $enabled): self
	{
		$this->set('frontendLegalEnabled', $enabled);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isFrontendWidgetEnabled(): bool
	{
		return (bool)$this->get('frontendWidgetEnabled', true);
	}

	/**
	 * @param bool $enabled
	 * @return $this
	 */
	public function setFrontendWidgetEnabled(bool $enabled): self
	{
		$this->set('frontendWidgetEnabled', $enabled);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isManagementStructurePreLegalConsent(): bool
	{
		return (bool)$this->get('managementStructurePreLegalConsent');
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setManagementStructurePreLegalConsent(bool $state): self
	{
		$this->set('managementStructurePreLegalConsent', $state);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getManagementStructure(): string
	{
		return (string)$this->get('managementStructure', self::MANAGEMENT_STRUCTURE_COOKIE);
	}

	/**
	 * @param string $type
	 * @return $this
	 */
	public function setManagementStructure(string $type): self
	{
		$allowedValues = [
			self::MANAGEMENT_STRUCTURE_COOKIE,
			self::MANAGEMENT_STRUCTURE_EMBEDDING,
		];

		if (in_array($type, $allowedValues) == false) {
			throw new LogicException('Invalid value for storage type, allowed values: '.implode(', ', $allowedValues));
		}

		$this->set('managementStructure', $type);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getDeleteUnknownCookies(): bool
	{
		return (bool)$this->get('deleteUnknownCookies');
	}

	/**
	 * @param bool $delete
	 * @return $this
	 */
	public function setDeleteUnknownCookies(bool $delete): self
	{
		$this->set('deleteUnknownCookies', $delete);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getDeleteUnknownCookiesForceReload(): bool
	{
		// Funktion auf unbestimmte Zeit deaktiviert
		return false;
		return (bool)$this->get('deleteUnknownCookiesForceReload');
	}

	/**
	 * @param bool $force
	 * @return $this
	 */
	public function setDeleteUnknownCookiesForceReload(bool $force): self
	{
		$this->set('deleteUnknownCookiesForceReload', $force);
		return $this;
	}

	/**
	 * @deprecated
	 * @return bool
	 */
	public function hasRecordedViewCounts(): bool
	{
		return $this->get('viewCount') !== null;
	}

	/**
	 * @deprecated
	 * @return int
	 */
	public function getViewCount(): int
	{
		return (int)$this->get('viewCount');
	}

	/**
	 * @deprecated
	 * @param int $value
	 * @return $this
	 */
	public function setViewCount(int $value): self
	{
		$this->set('viewCount', $value);
		return $this;
	}

	/**
	 * @deprecated
	 * @param int $diff
	 * @return $this
	 */
	public function incrementViewCount(int $diff = 1): self
	{
		self::beginWrite();
		$this->set('viewCount', $this->get('viewCount') + $diff);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getConsentStorage(): string
	{
		return (string)$this->get('consentStorage', 'localStorage');
	}

	/**
	 * @param string $storageType
	 * @return $this
	 */
	public function setConsentStorage(string $storageType): self
	{
		$this->set('consentStorage', $storageType);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getConsentCookieLifetime(): int
	{
		return (int)$this->get('consentCookieLifetime', 365);
	}

	/**
	 * @param int $cookieLifetime
	 * @return $this
	 */
	public function setConsentCookieLifetime(int $cookieLifetime): self
	{
		$this->set('consentCookieLifetime', max(0, $cookieLifetime));
		return $this;
	}

	/**
	 * @return string[]
	 */
	public function getShareDomainNames(): array
	{
		return (array)$this->get('shareDomainNames', []);
	}

	/**
	 * @return int Anzahl dieser Domain zugeordneter Domainnamen, ausgenommen IP-Adressen (Minimum 1).
	 */
	public function getDomainNamesCount(): int
	{
		return array_reduce($this->getShareDomainNames(), function ($carry, $domainName) {
			return $carry + (int)(
				filter_var($domainName, FILTER_VALIDATE_IP) === false
				and (
					$domainName[0] !== '['
					or
					filter_var(substr($domainName, 1, -1), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) === false
				)
			);
		}, 0) ?: 1;
	}

	/**
	 * @param string[] $domainNames
	 * @return $this
	 */
	public function setShareDomainNames(array $domainNames): self
	{
		$this->set('shareDomainNames', $domainNames);
		return $this;
	}

	/**
	 * @param string $domainName
	 * @return int je höher, desto besser passt die Domain. 0 wenn kein Match.
	 */
	public function matchesDomainName(string $domainName): int
	{
		$domainName = strtolower(rtrim($domainName, '.'));
		$mainHost = strtolower(rtrim($this->getName(), '.'));
		if ($mainHost === $domainName) {
			return strlen($domainName);
		}
		foreach ($this->getShareDomainNames() as $domain)
		{
			if ($domainName === strtolower($domain) or stripos($domainName, '.'.$domain, -strlen($domain)-1) !== false) {
				return strlen($domain);
			}
		}
		return 0;
	}

	/**
	 * @return bool
	 */
	public function hasCrossDomainSharing(): bool
	{
		return (bool)$this->get('crossDomainSharing', false);
	}

	/**
	 * @param bool $activate
	 * @return $this
	 */
	public function setCrossDomainSharing(bool $activate): self
	{
		$this->set('crossDomainSharing', $activate);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function hasSecureConsentCookie(): bool
	{
		return (bool)$this->get('secureConsentCookie', true);
	}

	/**
	 * @param bool $activate
	 * @return $this
	 */
	public function setSecureConsentCookie(bool $activate): self
	{
		$this->set('secureConsentCookie', $activate);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function hasCodeMinification(): bool
	{
		return (bool)$this->get('minify', true);
	}

	/**
	 * @param bool $activate
	 * @return $this
	 */
	public function setCodeMinification(bool $activate): self
	{
		$this->set('minify', $activate);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getConsentTablePrependIntroText(): bool
	{
		return (bool)$this->get('consentTablePrependIntroText', true);
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setConsentTablePrependIntroText(bool $value): self
	{
		$this->set('consentTablePrependIntroText', $value);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getConsentTablePrependConsentChangeLink(): bool
	{
		return (bool)$this->get('consentTablePrependConsentChangeLink', true);
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setConsentTablePrependConsentChangeLink(bool $value): self
	{
		$this->set('consentTablePrependConsentChangeLink', $value);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getConsentTableHeadingStartLevel(): int
	{
		return (int)$this->get('consentTableHeadingStartLevel', 3);
	}

	/**
	 * @param int $level
	 * @return $this
	 */
	public function setConsentTableHeadingStartLevel(int $level): self
	{
		$this->set('consentTableHeadingStartLevel', $level);
		return $this;
	}

	/**
	 * Ob die Domain bereits eingerichtet wurde
	 *
	 * Das ist True, wenn noch kein Impressum und keine
	 * Datenschutzerklärung hinterlegt ist.
	 *
	 * @return bool
	 */
	public function isUnconfigured(): bool
	{
		$activeDomain = Domain::activeDomain();
		Domain::select($this->getId());
		LegalText::reloadRepository();

		$unconfigured = true;

		foreach (LegalText::all() as $legal) {
			if ($legal->getImprintScheme() === 'link' or strlen($legal->getImprint()) >= 28) {
				$unconfigured = false;
			}
			if ($legal->getPrivacyScheme() === 'link' or strlen($legal->getPrivacyPolicy()) >= 40) {
				$unconfigured = false;
			}
		}

		if ($activeDomain) {
			Domain::select($activeDomain->getId());
			LegalText::reloadRepository();
		}
		return $unconfigured;
	}

}
