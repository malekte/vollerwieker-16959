<?php

namespace App\Model;

use App\JsonConfig;
use App\Utils;
use App\Component\Curl;
use Symfony\Component\HttpFoundation\Request;
use RuntimeException;

class OnBoarding extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	static $repositoryFilename = 'cm-cookies.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	const API_URL = 'https://www.ccm19.de/crawler/cookie_crawler/crawl.php';
	//http://localhost/ccm19/cookie_crawler/crawl.php
	//const API_URL = 'http://localhost/ccm19/cookie_crawler/crawl.php';

	static $connectionError = "";

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return string
	 */
	public function gettest(): string
	{
		return "test";
	}

	/**
	 * @param Request $request
	 * @param string $domain
	 * @return array
	 */
	public static function getDataFromRemote(Request $request, $domain): array
	{
		//korrigieren falls falsch eingetragen...
		if (!stristr($domain, "http:") && !stristr($domain, "https:")) {
			$domain = "http://" . $domain;
		}

		//parse url
		$domain_data = parse_url($domain);
		$host = $domain_data['host'];
		$domain = $domain_data['scheme'].'://'.$host . '/';

		//auf lokale urls checken
		if (!$host or !(Utils::isPublicHost($host))) {
			return [];
		}

		//curl ini
		$curl = new Curl();

		//https://www.ccm19.de/crawler/cookie_crawler/crawl.php?apikey=1234&url=https://www.papoo.de
		$params = [ "apikey" => "1234", "url" => $domain ];

		//Daten holen
		$curl->get(self::API_URL, $params);

		if ($curl->curl_error) {
			throw new RuntimeException("An error has occurred in cURL module. (Code: {$curl->getErrorCode()}) " . $curl->getErrorMessage());
		} elseif ($curl->getResponseHeaders('Content-Type') != 'application/json') {
			throw new RuntimeException('Unexpected response from crawling server.');
		} elseif ($curl->isServerError()) {
		}

		$response = json_decode($curl->getResponse(), true);

		return $response;
	}


	/**
	 * Gibt die Daten zurück mit den Daten des Cookies aus der DB
	 *
	 * @param array $cookies Cookie-Namen
	 * @return array
	 */
	public static function getDataFromCCM19Database(array $cookies): array
	{
		if (!($cookies)) {
			return [];
		}
		$name = "";
		foreach ($cookies['cookies'] as $k => $v) {
			$name .= $v['name'] . ",";
		}
		#print_r($name);
		#exit();
		$url = "https://www.ccm19.de/plugins/flexapi/api.php?" . http_build_query([
				'key' => 'jkn487gbf67igvfg6f2fhfbzg96ibjgbvzug',
				'cookiename' => $name
			]);

		//Es steht kein curl zur Verfügung... dann nix machen
		if (!Curl::installed()) {
			return [];
		}

		$curl = new Curl();
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 3);
		$curl->setOpt(CURLOPT_TIMEOUT, 3);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$curl->close();

		if (!$resultData) {
			return [];
		}

		$result = json_decode($resultData, true);
		return (is_array($result)) ? $result : [];
	}

	/**
	 * @param $data
	 * @param $kat_data
	 * @return array
	 */
	public static function sortDataForCategories($data, $kat_data): array
	{
		#print_r($data['cookies']);
		#print_r($kat_data['cookie_daten']['de']);
		//umtragen
		if (empty($data['cookies'])) {
			return [];
		}

		//alle Cookies der Seite durchgehen
		$page_cookies = [];
		foreach ($data['cookies'] as $k => $v) {
			if (!empty($kat_data['cookie_daten']['de'][$k])) {
				$merge = array_merge($v, $kat_data['cookie_daten']['de'][$k]['0']);
			} else {
				$merge = array_merge($v, $kat_data['cookie_daten']['de'][$k]);
			}

			$page_cookies[$v['name']] = $merge;
		}
		#print_r($page_cookies);
		#exit();
		//Die Kategorien iDS
		$kategorien_ids = [1, 2, 3, 4, 5, 6];
		// das rückgabe Array
		$neu = [];
		$count = [];

		foreach ($kategorien_ids as $kategorien_id) {
			foreach ($page_cookies as $k => $v) {
				//print_r($v);
				if (!empty($v['Zweck_2'])) {
					if ($v['Zweck_2'] == $kategorien_id) {
						//print_r($v);
						$v['LebensdauerdesCookies_8'] = self::getDiffMonth($v['expires'] - time());
						$v['active'] = true;
						$v['CookieName_1'] = $v['NamedesCookiesimBrowser_7'] = $v['name'];
						$neu[$kategorien_id][] = $v;
						unset($page_cookies[$k]);
					}
				}
			}
			if (!empty($neu[$kategorien_id])) {
				$count[$kategorien_id] = count($neu[$kategorien_id]);
			} else {
				$count[$kategorien_id] = 0;
				$neu[$kategorien_id] = [];
			}
		}

		// den Rest nochmal durchgehen und mit VOrlagen unter sonstiges eintragen
		foreach ($page_cookies as $k => $v) {
			$page_cookies[$k]['Zweck_2'] = 6;
			$page_cookies[$k]['CookieName_1'] = $v['name'];
			$page_cookies[$k]['AnbieterdesCookies_4'] = "N.A.";
			$page_cookies[$k]['BeschreibungdesCookies_5'] = "N.A.";
			$page_cookies[$k]['DatenschutzLinkfrdasCookie_6'] = "N.A.";
			$page_cookies[$k]['NamedesCookiesimBrowser_7'] = $v['name'];
			$page_cookies[$k]['LebensdauerdesCookies_8'] = self::getDiffMonth($v['expires'] - time());
			$page_cookies[$k]['WelcheDatenwerdengesammelt_9'] = "N.A.";
			$page_cookies[$k]['ZuwelchemZweckwerdendieDatengesammelt_10'] = "N.A.";
			$page_cookies[$k]['RechtlicheGrundlage_11'] = "Einwilligung, Art. 6 Abs. 1 lit. a DSGVO";
			$page_cookies[$k]['OrtderVerarbeitung_12'] = "N.A.";
			$page_cookies[$k]['Hinweis_15'] = "N.A.";
			$page_cookies[$k]['codeBlock_30'] = "";
			$page_cookies[$k]['active'] = true;

		}

		foreach ($kategorien_ids as $kategorien_id) {
			foreach ($page_cookies as $k => $v) {
			    if (empty($v['CookieName_1']))
                {
                    $page_cookies[$k]['CookieName_1'] = "N.A.";
                }
				//print_r($v);
				if (!empty($v['Zweck_2'])) {
					//print_r($v);
					$v['active'] = 1;
					if ($v['Zweck_2'] == $kategorien_id) {
						$neu[$kategorien_id][] = $v;
						unset($page_cookies[$k]);
					}
				}

			}
			if (!empty($neu[$kategorien_id])) {
				$count[$kategorien_id] = count($neu[$kategorien_id]);
			} else {
				$count[$kategorien_id] = 0;
			}
		}

		//CCM Consent Cookie
		$neu[1][] = self::ccm_consent_cookie();

		$return = [
			'sortdata' => $neu,
			'count' => $count
		];
		return $return;
	}

	/**
	 * @return mixed
	 */
	private static function ccm_consent_cookie()
	{
		$ccm_consent_cookie = [];

		//Ausgabe auf ccm19 Hosted Server
		if (Utils::isExtendedEdition() && stristr($_SERVER['HTTP_HOST'], "5f3c395")) {
			$ccm_consent_cookie['Zweck_2'] = 1;
			$ccm_consent_cookie['CookieName_1'] = "ccm_consent";
			$ccm_consent_cookie['name'] = "ccm_consent";
			$ccm_consent_cookie['AnbieterdesCookies_4'] = "Papoo Software & Media Gmbh - CCM19 Cookie Consent Manager";
			$ccm_consent_cookie['BeschreibungdesCookies_5'] = "Dient zur Speicherung der Cookie Consent Vereinbarung - welche Cookies gesetzt werden dürfen.";
			$ccm_consent_cookie['DatenschutzLinkfrdasCookie_6'] = "https://www.ccm19.de/datenschutzerklaerung.html";
			$ccm_consent_cookie['NamedesCookiesimBrowser_7'] = "ccm_consent";
			$ccm_consent_cookie['LebensdauerdesCookies_8'] = "12 Monate";
			$ccm_consent_cookie['WelcheDatenwerdengesammelt_9'] = "Zustand der Einstellung welche Cookies gesetzt werden dürfen für Sie. Daten werden nach Kategorien sortiert gespeichert.";
			$ccm_consent_cookie['ZuwelchemZweckwerdendieDatengesammelt_10'] = "Um Ihre Präferenz für die Nutzung von Cookies auf dieser Seite zu speichern.";
			$ccm_consent_cookie['RechtlicheGrundlage_11'] = "DSGVO Art.7 Absatz 1";
			$ccm_consent_cookie['OrtderVerarbeitung_12'] = "Bonn und Frankfurt";
			$ccm_consent_cookie['Hinweis_15'] = "";
			$ccm_consent_cookie['codeBlock_30'] = "";
			$ccm_consent_cookie['active'] = true;
		} else {
			$ccm_consent_cookie['Zweck_2'] = 1;
			$ccm_consent_cookie['name'] = "ccm_consent";
			$ccm_consent_cookie['CookieName_1'] = "ccm_consent";
			$ccm_consent_cookie['AnbieterdesCookies_4'] = "{FIRMA}";
			$ccm_consent_cookie['BeschreibungdesCookies_5'] = "Dient zur Speicherung der Cookie Consent Vereinbarung - welche Cookies gesetzt werden dürfen.";
			$ccm_consent_cookie['DatenschutzLinkfrdasCookie_6'] = "{Firma_Datenschutz}";
			$ccm_consent_cookie['NamedesCookiesimBrowser_7'] = "ccm_consent";
			$ccm_consent_cookie['LebensdauerdesCookies_8'] = "12 Monate";
			$ccm_consent_cookie['WelcheDatenwerdengesammelt_9'] = "Zustand der Einstellung welche Cookies gesetzt werden dürfen für Sie. Daten werden nach Kategorien sortiert gespeichert.";
			$ccm_consent_cookie['ZuwelchemZweckwerdendieDatengesammelt_10'] = "Um Ihre Präferenz für die Nutzung von Cookies auf dieser Seite zu speichern.";
			$ccm_consent_cookie['RechtlicheGrundlage_11'] = "DSGVO Art.7 Absatz 1";
			$ccm_consent_cookie['OrtderVerarbeitung_12'] = "{Firma_Ort}";
			$ccm_consent_cookie['Hinweis_15'] = "";
			$ccm_consent_cookie['codeBlock_30'] = "";
			$ccm_consent_cookie['active'] = true;
		}


		return $ccm_consent_cookie;
	}

	/**
	 * @param $date int
	 * @return float
	 */
	private static function getDiffMonth($date): float
	{
		$month = round($date / 2635200, 0);
		if ($month < 0) {
			$month = 0;
		}
		return $month;
	}


}
