<?php

namespace App\Model;

use App\Component\ConfigImporterContext;
use App\Kernel;
use App\Utils;
use DateTimeInterface;
use Generator;
use LogicException;
use RuntimeException;
use App\Event\ProtocolRotateEvent;
use App\Exception\LogNotReadableException;
use App\Exception\LogNotWritableException;
use App\Exception\LogNotCreatableException;

class Protocol
{
	const MAX_FILESIZE_IN_MEGABYTES = 5;

	private static $filename = 'cm-consent-protocol.log';

	/** @var string $pathname */
	private $pathname;

	/** @var resource|null $fileHandle */
	private $fileHandle;

	/**
	 * @param Domain $domain
	 * @throws RuntimeException Wenn Logdatei nicht geschrieben werden kann.
	 */
	private function __construct(Domain $domain)
	{
		$this->fileHandle = null;
		$this->pathname = self::staticPathname($domain);
		self::createFileIfNotExists();
	}

	public function __destruct()
	{
		$this->close();
	}

	/**
	 * @param Domain $domain
	 * @return self
	 * @throws LogNotWritableException Wenn nicht auf Logdatei zugegriffen werden kann.
	 */
	public static function byDomain(Domain $domain): self
	{
		return new self($domain);
	}

	/**
	 * @param string $text
	 * @return array[]
	 * @throws RuntimeException Wenn nicht auf Logdatei zugegriffen werden kann.
	 */
	public function search($text): array
	{
		return array_filter(self::all(), function ($row) use ($text) {
			return stripos($row['ucid'], $text) !== false;
		});
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @param Domain $domain
	 * @return string
	 */
	public static function staticPathname(Domain $domain): string
	{
		return $domain->configDir().'/'.self::$filename;
	}

	/**
	 * @param ConfigImporterContext $context
	 * @phan-suppress PhanTypeMismatchArgumentNullable
	 */
	public static function migratePreMultiUserConfig(ConfigImporterContext $context): void
	{
		if ($context->hasDomain() == false) {
			return;
		}

		/** @var Kernel $kernel */
		global $kernel;

		$sourceFile = Utils::getVarDir() . DIRECTORY_SEPARATOR . self::$filename;
		$destFile = self::staticPathname($context->getDomain());

		if (is_file($sourceFile) == false || is_file($destFile)) {
			return;
		}
		else if (@copy($sourceFile, $destFile)) {
			@chmod($destFile, 0666);
			@unlink($sourceFile);
		}
	}

	/**
	 * @param ConfigImporterContext $context
	 * @throws LogicException
	 * @phan-suppress PhanTypeMismatchArgumentNullable
	 */
	public static function migratePreMultiDomainConfig(ConfigImporterContext $context): void
	{
		if ($context->hasUser() == false || $context->hasDomain() == false) {
			return;
		}

		/** @var Kernel $kernel */
		global $kernel;

		$sourceFile = $context->getUser()->configDir().'/'.self::$filename;
		$destFile = self::staticPathname($context->getDomain());

		if (is_file($sourceFile) == false || is_file($destFile)) {
			return;
		}
		else if (@copy($sourceFile, $destFile)) {
			@chmod($destFile, 0666);
			@unlink($sourceFile);
		}
	}

	/**
	 * @throws LogNotCreatableException
	 */
	private function createFileIfNotExists(): void
	{
		$filename = $this->pathname;
		$firstLine = "# This file was generated automatically, please do not edit.\n";
		if (is_file($filename) == false && @file_put_contents($filename, $firstLine) === false) {
			throw new LogNotCreatableException($filename);
		}
	}

	/**
	 * @return array
	 * @throws LogNotReadableException
	 */
	public function all(): array
	{
		return iterator_to_array($this->iterateEntries());
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @return string
	 */
	public function getPathname(): string
	{
		return $this->pathname;
	}

	/**
	 * @param string $mode
	 * @param int $lock
	 * @throws LogNotReadableException
	 * @throws LogNotWritableException
	 */
	private function open(string $mode, int $lock): void
	{
		if (is_resource($this->fileHandle)) {
			return;
		}

		$filename = $this->getPathname();

		$this->fileHandle = @fopen($filename, $mode);

		if (is_resource($this->fileHandle) == false) {
			if ($mode == 'r') {
				throw new LogNotReadableException($filename);
			} else {
				throw new LogNotWritableException($filename);
			}
		}

		flock($this->fileHandle, $lock);
	}

	/**
	 * @throws RuntimeException
	 */
	private function openForReading(): void
	{
		$this->open('r', LOCK_SH);
	}

	/**
	 * @param bool $truncate
	 * @throws RuntimeException
	 */
	private function openForReadingAndWriting(bool $truncate = false): void
	{
		$this->open($truncate ? 'w+' : 'r+', LOCK_EX);
	}

	/**
	 * @param bool $truncate
	 * @throws RuntimeException
	 */
	private function openForWriting(bool $truncate = false): void
	{
		$this->open($truncate ? 'w' : 'a', LOCK_EX);
	}

	private function rewind(): void
	{
		if (is_resource($this->fileHandle) == false) {
			return;
		}

		rewind($this->fileHandle);
	}

	/**
	 * @see fseek()
	 * @throws RuntimeException
	 */
	private function seek($offset, $whence=SEEK_SET): void
	{
		if (fseek($this->fileHandle, $offset, $whence) == -1) {
			throw new RuntimeException('Could not seek in logfile');
		}
	}

	/**
	 * Protokoll rotieren/archivieren
	 *
	 * Vor dem eigentlichen Prozess wird ein ProtocolRotateEvent ausgelöst.
	 */
	public function rotateProtocol(): void
	{
		if (!is_resource($this->fileHandle)) {
			$this->openForWriting();
		}
		flock($this->fileHandle, LOCK_SH);
		Utils::dispatchEvent(ProtocolRotateEvent::NAME, new ProtocolRotateEvent());
		flock($this->fileHandle, LOCK_EX);

		$pathinfo = pathinfo($this->pathname);
		$i = 0;
		do {
			$destPathname = $pathinfo['dirname'].'/'.$pathinfo['filename'].date('~Ymd-His').(($i == 0) ? '' : '-'.$i).'.'.($pathinfo['extension'] ?? '');
			$i++;
		} while (file_exists($destPathname));

		$compressed = false;

		if (is_resource($logHandle = fopen($this->pathname, 'rb'))) {
			if (is_resource($gzHandle = gzopen($destPathname.'.gz', 'wb9'))) {
				// Compress file in chunks of 64 KB in size
				while (feof($logHandle) == false && ($buffer = fread($logHandle, pow(2, 16))) !== false) {
					gzwrite($gzHandle, $buffer);
				}

				$compressed = true;
				gzclose($gzHandle);
			}

			fclose($logHandle);
		}
		elseif ($compressed == false) {
			// Datei kopieren statt umzubenennen, da ein Handle geöffnet ist
			copy($this->pathname, $destPathname);
		}

		ftruncate($this->fileHandle, 0);
	}

	/**
	 * @param string $data
	 */
	private function write(string $data): void
	{
		// Sobald die Datei zu groß wird, komprimieren und leeren
		if (fstat($this->fileHandle)['size'] + strlen($data) > self::MAX_FILESIZE_IN_MEGABYTES * pow(1024, 2)) {
			$this->rotateProtocol();
		}

		fwrite($this->fileHandle, $data);
	}

	public function close(): void
	{
		if (is_resource($this->fileHandle) == false) {
			return;
		}

		fflush($this->fileHandle);
		flock($this->fileHandle, LOCK_UN);
		fclose($this->fileHandle);

		$this->fileHandle = null;
	}

	public function count(): int
	{
		$this->openForReading();

		$counter = 0;
		while (($line = fgets($this->fileHandle)) !== false) {
			if (empty($line) || substr($line, 0, 1) == '#') {
				continue;
			}

			$counter++;
		}

		$this->close();
		return $counter;
	}

	/**
	 * @param array $data
	 * @param bool $keepOpen Wenn true, wird das Dateihandle offen gehalten, sodass der Entwickler u. U. mit close() selbst ran muss.
	 */
	public function append(array $data, bool $keepOpen = false): void
	{
		$this->openForWriting();
		$this->write(json_encode($data)."\n");

		if ($keepOpen == false) {
			$this->close();
		}
	}
	
	/**
	 * Iteriert über alle Einträge im Log
	 *
	 * @return Generator|array[]
	 * @phan-return generator<array>
	 */
	public function iterateEntries(): Generator
	{
		$this->openForReading();

		while (($line = fgets($this->fileHandle)) !== false) {
			if (empty($line) || substr($line, 0, 1) == '#') {
				continue;
			}

			yield json_decode($line, true);
		}

		$this->close();
	}

	/**
	 * Löscht alle Einträge, die vor $date angelegt wurden
	 *
	 * @param DateTimeInterface $date
	 * @return int Anzahl gelöschter Einträge
	 */
	public function trimBefore(DateTimeInterface $date): int
	{
		$timestamp = $date->getTimestamp();

		$this->openForReadingAndWriting(false);

		$position = 0;
		$skipHead = 0;
		$count = 0;
		try {
			// Datei-Position bestimmen, vor der gelöscht werden soll
			while (($line = fgets($this->fileHandle)) !== false) {
				if (empty($line) || substr($line, 0, 1) == '#') {
					if ($position == 0) {
						$skipHead = ftell($this->fileHandle);
					}
					continue;
				}

				$row = json_decode($line, true);
				if ($row and $row['timestamp'] >= $timestamp) {
					break;
				}
				$position = ftell($this->fileHandle);
				$count++;
			}

			// Wenn alles aktuell, dann ist nichts zu tun
			if ($position-$skipHead <= 0) {
				return 0;
			}

			// Daten in Blöcken verschieben
			$blocksize = min($position-$skipHead, 524288);
			$readOffset = $position;
			$writeOffset = $skipHead;
			$retries = 5;
			while (!feof($this->fileHandle)) {
				// Block einlesen
				$this->seek($readOffset);
				$block = fread($this->fileHandle, $blocksize);
				if ($block === '') {
					// Ende der Datei erreicht
					break;
				}
				// Block schreiben
				$this->seek($writeOffset);
				$writtenCount = fwrite($this->fileHandle, $block);
				// Bei zu häufigen Schreibfehlern aufgeben
				if ($writtenCount == 0) {
					if ($retries == 0) {
						throw new RuntimeException('trimming logfile failed. Log might be in an inconsistent state!');
					}
					$retries--;
				}
				// Schreibgröße verkleinern, wenn nicht so viel auf einmal geschrieben werden kann
				if ($writtenCount > 0 and $writtenCount < $blocksize) {
					$blocksize = $writtenCount;
				}
				$readOffset += $writtenCount;
				$writeOffset += $writtenCount;
			}
			// Dateigröße anpassen (verkleinern)
			$this->rewind();
			ftruncate($this->fileHandle, $writeOffset);
		}
		finally {
			$this->close();
		}
		return $count;
	}

}
