<?php

namespace App\Model;

use App\JsonConfig;
use App\Model\Locale;

class Purpose extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-purposes.json';

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @param string $name
	 * @return static|null
	 */
	public static function findByName(string $name): ?self
	{
		$filtered = array_values(array_filter(static::all(), function ($item) use ($name) {
			return $name == $item->getName();
		}));

		if ($filtered) {
			return $filtered[0];
		}
		else {
			return null;
		}
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	public function setName(string $name): self
	{
		$this->set('name', $name);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedName(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_name.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_name.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->get('name');
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $name
	 * @return $this
	 */
	public function setTranslatedName(Locale $locale, string $name): self
	{
		$this->set('translated_name.'.$locale->getName(), $name);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getDescription(): string
	{
		return (string)$this->get('description');
	}

	/**
	 * @param string $description
	 * @return $this
	 */
	public function setDescription(string $description): self
	{
		$this->set('description', $description);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedDescription(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_description.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_description.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->get('description');
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $description
	 * @return $this
	 */
	public function setTranslatedDescription(Locale $locale, string $description): self
	{
		$this->set('translated_description.'.$locale->getName(), $description);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isMandatory(): bool
	{
		return (bool)$this->get('mandatory');
	}

	/**
	 * @param bool $mandatory
	 * @return $this
	 */
	public function setMandatory(bool $mandatory): self
	{
		$this->set('mandatory', $mandatory);
		return $this;
	}

	/**
	 * Setzt alle übersetzten Texte, die in $locale noch nie vorher gesetzt
	 * wurden, auf den nicht-übersetzten Wert.
	 *
	 * @param Locale $locale Zu füllendes Locale
	 * @return $this
	 */
	public function fillTranslationsFromDefault(Locale $locale): self
	{
		$this->setTranslatedName($locale, $this->getTranslatedName($locale));
		$this->setTranslatedDescription($locale, $this->getTranslatedDescription($locale));
		return $this;
	}
}
