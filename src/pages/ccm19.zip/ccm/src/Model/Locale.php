<?php

namespace App\Model;

use App\Exception\LocaleAlreadyExistsException;
use App\JsonConfig;
use LogicException;

class Locale extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-locales.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @param string $id
	 * @return self|null
	 */
	public static function byId(string $id): ?self
	{
		return parent::find($id);
	}

	/**
	 * @return self[]
	 */
	public static function enabledLocales(): array
	{
		return array_filter(self::all(), function ($locale) {
			/** @var self $locale */
			return $locale->isEnabled();
		});
	}

	/**
	 * @return self|null
	 * @phan-return static|null
	 */
	public static function getDefault(): ?self
	{
		$user = User::loggedInUser();
		return $user->getDefaultLocale();
	}

	/**
	 * @return Language|null
	 */
	public function getLanguage(): ?Language
	{
		return Language::find($this->get('name'));
	}

	/**
	 * @param string $localeName
	 * @return bool
	 */
	public static function exists(string $localeName): bool
	{
		return array_reduce(self::all(), function ($exists, $locale) use ($localeName) {
			/** @var Locale $locale */
			return $exists || $localeName == $locale->getName();
		}, false);
	}

	/**
	 * @param string $localeName
	 * @return static|null
	 * @phan-return static|null
	 */
	public static function find(string $localeName): ?Model
	{
		return array_reduce(self::all(), function ($match, $locale) use ($localeName) {
			/** @var Locale $locale */
			return $match ?? ($localeName == $locale->getName() ? $locale : $match);
		}, null);
	}

	/**
	 * @param ?string $localeName
	 * @return static
	 * @throws LocaleAlreadyExistsException
	 * @throws LogicException
	 * @phan-assert string $localeName
	 */
	public static function create(?string $localeName = null): Model
	{
		if ($localeName === null) {
			throw new LogicException('Locale name may not be null.');
		}

		self::beginWrite();

		if (self::exists($localeName)) {
			throw new LocaleAlreadyExistsException($localeName);
		}

		/** @var self $locale */
		$locale = parent::create();
		assert($locale instanceof Locale);
		$locale->setName($localeName);

		LegalText::create()->setLocale($locale)->save();

		return $locale;
	}

	/**
	 * @param string[] $localeNames Nach Priorität sortierte Locale-Namen
	 * @return static Die zuerst ermittelte Locale; entweder passend zu $localeNames, ansonsten die erstbeste.
	 */
	public static function yieldAny(array $localeNames): self
	{
		$locales = self::all();

		$match = array_reduce($localeNames, function ($match, $localeName) use ($locales) {
			return $match ?? array_reduce($locales, function ($match, $locale) use ($localeName) {
				/** @var self $locale */
				return $match ?? (strtolower($localeName) == strtolower($locale->getName()) ? $locale : $match);
			});
		});

		return $match ?? reset($locales);
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	private function setName(string $name): self
	{
		$this->set('name', $name);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isEnabled(): bool
	{
		// Fallback ist true, um alte Versionen zu unterstützen
		return (bool)$this->get('enabled', true);
	}

	/**
	 * @param bool $enabled
	 * @return $this
	 */
	public function setEnabled(bool $enabled): self
	{
		$this->set('enabled', $enabled);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWidgetTitle(): string
	{
		return (string)$this->get('widget_title');
	}

	/**
	 * @param string $title
	 * @return $this
	 */
	public function setWidgetTitle(string $title): self
	{
		$this->set('widget_title', $title);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWidgetIntroduction(): string
	{
		return (string)$this->get('widget_introduction');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setWidgetIntroduction(string $text): self
	{
		$this->set('widget_introduction', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWidgetConsentButtonText(): string
	{
		return (string)$this->get('widget_consent_button_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setWidgetConsentButtonText(string $text): self
	{
		$this->set('widget_consent_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWidgetDeclineButtonText(): string
	{
		return (string)$this->get('widget_decline_button_text', 'Ablehnen');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setWidgetDeclineButtonText(string $text): self
	{
		$this->set('widget_decline_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getWidgetSettingsButtonText(): string
	{
		return (string)$this->get('widget_settings_button_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setWidgetSettingsButtonText(string $text): self
	{
		$this->set('widget_settings_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCategoriesAcceptAllButtonText(): string
	{
		$language = $this->getLanguage();
		$fallback = $language && $language->getCode() == 'de_DE' ? 'Alle akzeptieren' : 'Accept all';
		return (string)$this->get('categories_accept_all_button_text', $fallback);
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCategoriesAcceptAllButtonText(string $text): self
	{
		$this->set('categories_accept_all_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getControlPanelTitle(): string
	{
		return (string)$this->get('control_panel_title');
	}

	/**
	 * @param string $title
	 * @return $this
	 */
	public function setControlPanelTitle(string $title): self
	{
		$this->set('control_panel_title', $title);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getControlPanelCancelButtonText(): string
	{
		return (string)$this->get('control_panel_cancel_button_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setControlPanelCancelButtonText(string $text): self
	{
		$this->set('control_panel_cancel_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getControlPanelSaveButtonText(): string
	{
		return (string)$this->get('control_panel_save_button_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setControlPanelSaveButtonText(string $text): self
	{
		$this->set('control_panel_save_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getDetailsTitle(): string
	{
		return (string)$this->get('details_title');
	}

	/**
	 * @param string $title
	 * @return $this
	 */
	public function setDetailsTitle(string $title): self
	{
		$this->set('details_title', $title);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getDetailsCloseButtonText(): string
	{
		return (string)$this->get('details_close_button_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setDetailsCloseButtonText(string $text): self
	{
		$this->set('details_close_button_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getImprintText(): string
	{
		return (string)$this->get('imprint_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setImprintText(string $text): self
	{
		$this->set('imprint_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPrivacyPolicyText(): string
	{
		return (string)$this->get('privacy_policy_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setAccessibilityText(string $text): self
	{
		$this->set('accessibility_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getAccessibilityText(): string
	{
		return (string)$this->get('accessibility_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setPrivacyPolicyText(string $text): self
	{
		$this->set('privacy_policy_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookieVendorText(): string
	{
		return (string)$this->get('cookie_vendor_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookieVendorText(string $text): self
	{
		$this->set('cookie_vendor_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookieDescriptionText(): string
	{
		return (string)$this->get('cookie_description_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookieDescriptionText(string $text): self
	{
		$this->set('cookie_description_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookiePrivacyPolicyUrlText(): string
	{
		return (string)$this->get('cookie_privacy_policy_url_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookiePrivacyPolicyUrlText(string $text): self
	{
		$this->set('cookie_privacy_policy_url_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookieLifetimeText(): string
	{
		return (string)$this->get('cookie_lifetime_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookieLifetimeText(string $text): self
	{
		$this->set('cookie_lifetime_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookieCollectedDataInfoText(): string
	{
		return (string)$this->get('cookie_collected_data_info_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookieCollectedDataInfoText(string $text): self
	{
		$this->set('cookie_collected_data_info_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookiePurposeOfDataCollectionText(): string
	{
		return (string)$this->get('cookie_purpose_of_data_collection_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookiePurposeOfDataCollectionText(string $text): self
	{
		$this->set('cookie_purpose_of_data_collection_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookieLegalBasisText(): string
	{
		return (string)$this->get('cookie_legal_basis_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookieLegalBasisText(string $text): self
	{
		$this->set('cookie_legal_basis_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCookiePlaceOfProcessingText(): string
	{
		return (string)$this->get('cookie_place_of_processing_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setCookiePlaceOfProcessingText(string $text): self
	{
		$this->set('cookie_place_of_processing_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getBlockedContentTitle(): string
	{
		return (string)$this->get('blocked_content_title');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setBlockedContentTitle(string $text): self
	{
		$this->set('blocked_content_title', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getBlockedContentText(): string
	{
		return (string)$this->get('blocked_content_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setBlockedContentText(string $text): self
	{
		$this->set('blocked_content_text', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getBlockedContentButtonText(): string
	{
		return (string)$this->get('blocked_content_button_text');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setBlockedContentButtonText(string $text): self
	{
		$this->set('blocked_content_button_text', $text);
		return $this;
	}

	/**
	 * @param Purpose $purpose
	 * @return string
	 */
	public function getPurposeName(Purpose $purpose): string
	{
		$result = (string)$this->get('purpose_name.'.$purpose->getId());
		if ($result === '') {
			$result = (string)$purpose->getTranslatedName($this);
		}

		return $result;
	}

	/**
	 * @param Purpose $purpose
	 * @param string $text
	 * @return $this
	 */
	public function setPurposeName(Purpose $purpose, string $text): self
	{
		$this->set('purpose_name.'.$purpose->getId(), $text);
		return $this;
	}

	/**
	 * @param Purpose $purpose
	 * @return string
	 */
	public function getPurposeDescription(Purpose $purpose): string
	{
		return (string)$this->get('purpose_description.'.$purpose->getId()) ?: $purpose->getTranslatedDescription($this);
	}

	/**
	 * @param Purpose $purpose
	 * @param string $text
	 * @return $this
	 */
	public function setPurposeDescription(Purpose $purpose, string $text): self
	{
		$this->set('purpose_description.'.$purpose->getId(), $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getChangeConsentLabel(): string
	{
		return (string)$this->get('change_consent_label');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setChangeConsentLabel(string $text): self
	{
		$this->set('change_consent_label', $text);
		return $this;
	}
}
