<?php

namespace App\Model;

use App\JsonConfig;

class UserTheme extends ThemeBase
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var bool $userSpecificRepository */
	protected static $userSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}
}
