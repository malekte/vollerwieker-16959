<?php

namespace App\Model;

use App\Utils;
use App\Component\LoggerInterface;
use DateTime;
use Generator;
use RuntimeException;
use Throwable;
use App\Exception\LogNotReadableException;
use App\Exception\LogNotWritableException;
use App\Exception\LogNotCreatableException;

class SystemLog implements LoggerInterface
{
	private static $filenameTemplate = 'log/cm-system-%s.log';

	/** @var string $pathname */
	private $pathname;

	/** @var resource|null $fileHandle */
	private $fileHandle;

	/**
	 * @param DateTime|null $date
	 */
	public function __construct(?DateTime $date)
	{
		if ($date === null) {
			$date = new DateTime('now');
		}
		$this->fileHandle = null;
		$this->pathname = self::staticPathname($date);
	}

	public function __destruct()
	{
		$this->close();
	}

	/**
	 * @param DateTime $date
	 * @return self
	 */
	public static function byDate(DateTime $date): self
	{
		return new self($date);
	}

	public static function listDateRanges(): array
	{
		$result = [];
		foreach (glob(Utils::getVarDir().'/log/cm-system-????-??.log') as $file)
		{
			$date = substr(basename($file), 10, -4). ' 12:00:00';
			$result[] = new Datetime($date);
		}
		return array_reverse($result);
	}

	/**
	 * @return self
	 */
	public static function current(): self
	{
		return new self(null);
	}

	/**
	 * Diese Methode gibt den Dateipfad der Logdatei zurück.
	 * @param DateTime $date
	 * @return string
	 */
	public static function staticPathname(DateTime $date): string
	{
		return Utils::getVarDir().'/'.sprintf(self::$filenameTemplate, $date->format('Y-m'));
	}

	/**
	 * @throws LogNotCreatableException
	 */
	private function createFileIfNotExists(): void
	{
		$filename = $this->pathname;
		$firstLine = "# This file was generated automatically, please do not edit.\n";
		if (is_file($filename) == false && @file_put_contents($filename, $firstLine) === false) {
			throw new LogNotCreatableException($filename);
		}
	}

	/**
	 * @return array
	 */
	public function all(): array
	{
		return iterator_to_array($this->iterateEntries());
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @return string
	 */
	public function getPathname(): string
	{
		return $this->pathname;
	}

	/**
	 * @param string $mode
	 * @param int $lock
	 * @throws LogNotReadableException
	 * @throws LogNotWritableException
	 */
	private function open(string $mode, int $lock): void
	{
		if (is_resource($this->fileHandle)) {
			return;
		}

		$filename = $this->getPathname();

		$this->fileHandle = @fopen($filename, $mode);

		if (is_resource($this->fileHandle) == false) {
			if ($mode == 'r') {
				throw new LogNotReadableException($filename);
			} else {
				throw new LogNotWritableException($filename);
			}
		}

		flock($this->fileHandle, $lock);
	}

	/**
	 * @throws LogNotReadableException
	 */
	private function openForReading(): void
	{
		$this->open('r', LOCK_SH);
	}

	/**
	 * @param bool $truncate
	 * @throws LogNotWritableException
	 */
	private function openForReadingAndWriting(bool $truncate = false): void
	{
		$this->createFileIfNotExists();
		$this->open($truncate ? 'w+' : 'r+', LOCK_EX);
	}

	/**
	 * @param bool $truncate
	 * @throws LogNotWritableException
	 */
	private function openForWriting(bool $truncate = false): void
	{
		$this->createFileIfNotExists();
		$this->open($truncate ? 'w' : 'a', LOCK_EX);
	}

	private function rewind(): void
	{
		if (is_resource($this->fileHandle) == false) {
			return;
		}

		rewind($this->fileHandle);
	}

	/**
	 * @param string $data
	 */
	private function write(string $data): void
	{
		fwrite($this->fileHandle, $data);
	}

	public function close(): void
	{
		if (is_resource($this->fileHandle) == false) {
			return;
		}

		fflush($this->fileHandle);
		flock($this->fileHandle, LOCK_UN);
		fclose($this->fileHandle);

		$this->fileHandle = null;
	}

	public function count(): int
	{
		try {
			$this->openForReading();
		}
		catch (RuntimeException $e) {
			return 0;
		}

		$counter = 0;
		while (($line = fgets($this->fileHandle)) !== false) {
			if (empty($line) || substr($line, 0, 1) == '#') {
				continue;
			}

			$counter++;
		}

		$this->close();
		return $counter;
	}

	/**
	 * @param string $severity Schweregrad (Warnung/Fehler/etc.)
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 * @param bool $keepOpen Wenn true, wird das Dateihandle offen gehalten, sodass der Entwickler u. U. mit close() selbst ran muss.
	 */
	private function append(string $severity, string $component, string $message, bool $keepOpen = false): void
	{
		$timestamp = new DateTime('now');
		$this->openForWriting();
		$this->write(json_encode([
			'ts'=>$timestamp->format(DateTime::ISO8601),
			'cm'=>$component,
			'sev'=>$severity,
			'msg'=> $message,
		])."\n");

		if ($keepOpen == false) {
			$this->close();
		}
	}

	/**
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 * @param bool $keepOpen Wenn true, wird das Dateihandle offen gehalten, sodass der Entwickler u. U. mit close() selbst ran muss.
	 */
	public function logError(string $component, string $message, bool $keepOpen = false): void
	{
		$this->append('ERROR', $component, $message);
	}

	/**
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 * @param bool $keepOpen Wenn true, wird das Dateihandle offen gehalten, sodass der Entwickler u. U. mit close() selbst ran muss.
	 */
	public function logWarning(string $component, string $message, bool $keepOpen = false): void
	{
		$this->append('WARNING', $component, $message);
	}

	/**
	 * @param string $component Betroffene Komponente
	 * @param string $message Nachricht
	 * @param bool $keepOpen Wenn true, wird das Dateihandle offen gehalten, sodass der Entwickler u. U. mit close() selbst ran muss.
	 */
	public function logInfo(string $component, string $message, bool $keepOpen = false): void
	{
		$this->append('INFO', $component, $message);
	}

	public function logException(string $component, Throwable $exception, string $message=""): void
	{
		$exceptionMessage = array_reverse(explode('\\', get_class($exception)))[0];
		if ($exception->getCode()) {
			$exceptionMessage .= '['.$exception->getCode().']';
		}
		$exceptionMessage .= ': '. $exception->getMessage();

		$fullMessage = ($message == '') ? $exceptionMessage : $message . ' ' . $exceptionMessage;

		$this->append('ERROR', $component, $fullMessage);
	}

	/**
	 * Iteriert über alle Einträge im Log
	 *
	 * @return Generator|array[]
	 * @phan-return generator<array>
	 */
	public function iterateEntries(): Generator
	{
		try {
			$this->openForReading();
		} catch (RuntimeException $e) {
			return;
		}

		while (($line = fgets($this->fileHandle)) !== false) {
			if (empty($line) || substr($line, 0, 1) == '#') {
				continue;
			}

			yield json_decode($line, true);
		}

		$this->close();
	}
}
