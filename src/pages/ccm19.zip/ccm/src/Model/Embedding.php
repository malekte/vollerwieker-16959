<?php

namespace App\Model;

use App\JsonConfig;
use App\Model\Locale;
use App\Component\Curl;
use App\Component\Tcf\v2\Model\Vendor as TcfVendor;
use App\Component\Tcf\v2\Model\Purpose as TcfPurpose;
use App\Utils;

class Embedding extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-embeddings.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/** @var EmbeddingAsset[] $assets */
	private $assets;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
		$this->assets = [];
	}

	/**
	 * Diese Methode ergänzt die abzuleitende Methode um Sortierung der Embeddings nach Vertreiber und Name.
	 * @return static[]
	 */
	public static function all(): array
	{
		/** @var static[] $embeddings */
		$embeddings = parent::all();

		// ORDER BY vendor, name
		uasort($embeddings, function ($a, $b) {
			/**
			 * @var self $a
			 * @var self $b
			 */
			return ($vendorCmp = strnatcasecmp($a->getEmbeddingVendor(), $b->getEmbeddingVendor())) == 0
				? strnatcasecmp($a->getName(), $b->getName())
				: $vendorCmp;
		});

		return $embeddings;
	}

	/**
	 * @param Purpose $purpose
	 * @return static[]
	 */
	public static function byPurpose(Purpose $purpose): array
	{
		return array_filter(static::all(), function (Embedding $obj) use ($purpose) {
			return $obj->getPurpose()->getId() == $purpose->getId();
		});
	}

	/**
	 * @return string
	 */
	public function getName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param mixed $data
	 * @return string
	 */
	public static function getNameFromGet($data): string
	{
		return (string) $data;
	}

	/**
	 * Gibt die Daten zurück mit den Daten des Embeddings aus der DB
	 *
	 * @param string $name Embedding-Name
	 * @return array
	 */
	public static function getCookeDBInformation(string $name): array
	{
		$url ="https://www.ccm19.de/plugins/flexapi/api2.php?".http_build_query([
				'key'=>'jkn487gbf67igvfg6f2fhfbzg96ibjgbvzug',
				'cookiename'=>$name
			]);

		//Es steht kein curl zur Verfügung... dann nix machen
		if (!Curl::installed()) {
			return [];
		}

		$curl = new Curl();
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 3);
		$curl->setOpt(CURLOPT_TIMEOUT, 3);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$curl->close();

		if (!$resultData) {
			return [];
		}

		$result = json_decode($resultData,true);
		return (is_array($result)) ? $result : [];
	}

	/**
	 * Gibt die Daten zurück mit den Daten der Embeddings die es gibt aus der DB
	 *
	 * @return array
	 */
	public static function getEmbeddingsDBCompleteInformation(): array
	{
		$url ="https://www.ccm19.de/plugins/flexapi/api_embeddings.php?".http_build_query([
				'key'=>'jkn487gbf67igvfg6f2fhfbzg96ibjgbvzug'
			]);

		//Es steht kein curl zur Verfügung... dann nix machen
		if (!Curl::installed()) {
			return [];
		}

		$curl = new Curl();
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 3);
		$curl->setOpt(CURLOPT_TIMEOUT, 3);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$curl->close();

		if (!$resultData) {
			return [];
		}

		$result = json_decode($resultData,true);

		if (is_array($result)) {

			foreach ($result['embeddings'] as $k=>$v)
			{
				foreach ($v as $k1=>$v1) {
					//print_r($v1['Zweck_35']);
					if ($v1['Zweck_35'] == 1) {
						$result['embeddings'][$k][$k1]['Zweck_35'] = "41ba25c";
					}
					if ($v1['Zweck_35'] == 2) {
						$result['embeddings'][$k][$k1]['Zweck_35'] = "cdcbd7c";
					}
					if ($v1['Zweck_35'] == 3) {
						$result['embeddings'][$k][$k1]['Zweck_35'] = "a717ff5";
					}
					if ($v1['Zweck_35'] == 4) {
						$result['embeddings'][$k][$k1]['Zweck_35'] = "7c19e32";
					}
					if ($v1['Zweck_35'] == 5) {
						$result['embeddings'][$k][$k1]['Zweck_35'] = "6cd2721";
					}
					if ($v1['Zweck_35'] == 6) {
						$result['embeddings'][$k][$k1]['Zweck_35'] = "15c61c3";
					}
				}
			}

			return $result;

		}
		else {
			return [];
		}
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	public function setName(string $name): self
	{
		$this->set('name', $name);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCodeSnippet(): string
	{
		return (string)$this->get('code');
	}

	/**
	 * @param string $code
	 * @return $this
	 */
	public function setCodeSnippet(string $code): self
	{
		$this->set('code', $code);
		return $this;
	}

	/**
	* @return string[]
	*/
	public function getCodeBlock(): array
	{
		$value = $this->get('code_block');
		if (is_string($value)) {
			$value = array_filter(explode("\n", trim($value)), function ($line) { return trim($line) !== ''; });
		}
		return (array)$value;
	}

	/**
	* @param string[] $code
	* @return $this
	*/
	public function setCodeBlock(array $code): self
	{
		$this->set('code_block', $code);
		return $this;
	}

	/**
	 * @return EmbeddingAsset[]
	 */
	public function getAssets(): array
	{
		if (empty($this->assets)) {
			$this->assets = array_values(array_filter(array_map(function ($id) {
				return EmbeddingAsset::find($id);
			}, $this->get('assets', []))));
		}

		return $this->assets;
	}

	/**
	 * Liste aller Assets, die den angegebenen Storage-Type haben
	 *
	 * @return EmbeddingAsset[]
	 */
	public function getAssetsWithType(string $storageType): array
	{
		return array_filter($this->getAssets(), function (EmbeddingAsset $asset) use ($storageType) {
			return $asset->getStorageType() == $storageType;
		});
	}

	/**
	 * @param EmbeddingAsset[] $assets
	 * @return $this
	 */
	public function setAssets(array $assets): self
	{
		$this->assets = $assets;

		$this->set('assets', array_map(function ($item) {
			return $item->getId();
		}, $assets));
		return $this;
	}

	/**
	 * @param string $id
	 * @return EmbeddingAsset|null
	 */
	public function getAsset(string $id): ?EmbeddingAsset
	{
		return array_reduce($this->getAssets(), function ($carry, EmbeddingAsset $asset) use ($id) {
			return $carry ?? ($asset->getId() == $id ? $asset : $carry);
		}, null);
	}

	/**
	 * @param EmbeddingAsset $target
	 * @return bool
	 */
	public function hasAsset(EmbeddingAsset $target): bool
	{
		return array_reduce($this->getAssets(), function ($hasAsset, EmbeddingAsset $asset) use ($target) {
			return $hasAsset || $asset->getId() == $target->getId();
		}, false);
	}

	/**
	 * @param EmbeddingAsset $asset
	 * @return $this
	 */
	public function addAsset(EmbeddingAsset $asset): self
	{
		if ($this->hasAsset($asset) == false) {
			$this->setAssets(array_merge($this->assets, [$asset]));
		}

		return $this;
	}

	/**
	 * @param string $assetId
	 * @return $this
	 */
	public function removeAsset(string $assetId): self
	{
		$assets = array_filter($this->assets, function (EmbeddingAsset $asset) use ($assetId) {
			return $asset->getId() != $assetId;
		});

		$this->setAssets($assets);
		EmbeddingAsset::delete($assetId, false);

		return $this;
	}

	/**
	 * @return string
	 */
	public function getDescription(): string
	{
		return (string)$this->get('description');
	}

	/**
	 * @param string $description
	 * @return $this
	 */
	public function setDescription(string $description): self
	{
		$this->set('description', $description);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedDescription(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_description.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_description.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getDescription();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $description
	 * @return $this
	 */
	public function setTranslatedDescription(Locale $locale, string $description): self
	{
		$this->set('translated_description.'.$locale->getName(), $description);
		return $this;
	}

	/**
	 * @return Purpose|null
	 */
	public function getPurpose(): ?Purpose
	{
		return Purpose::find((string)$this->get('purpose'));
	}

	/**
	 * @param Purpose $purpose
	 * @return $this
	 */
	public function setPurpose(Purpose $purpose): self
	{
		$this->set('purpose', $purpose->getId());
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPrivacyPolicyUrl(): string
	{
		return (string)$this->get('privacy_policy_url');
	}

	/**
	 * @param string $url
	 * @return $this
	 */
	public function setPrivacyPolicyUrl(string $url): self
	{
		$this->set('privacy_policy_url', $url);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedPrivacyPolicyUrl(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_privacy_policy_url.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_privacy_policy_url.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getPrivacyPolicyUrl();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $url
	 * @return $this
	 */
	public function setTranslatedPrivacyPolicyUrl(Locale $locale, string $url): self
	{
		$this->set('translated_privacy_policy_url.'.$locale->getName(), $url);
		return $this;
	}


	/**
	 * @return string
	 */
	public function getEmbeddingVendor(): string
	{
		return (string)$this->get('embedding_vendor');
	}

	/**
	 * @param string $vendor
	 * @return $this
	 */
	public function setEmbeddingVendor(string $vendor): self
	{
		$this->set('embedding_vendor', $vendor);
		return $this;
	}

	/**
	 * @return TcfVendor|null
	 */
	public function getTcfVendor(): ?TcfVendor
	{
		return TcfVendor::find((string)$this->get('tcf_vendor'));
	}

	/**
	 * @param TcfVendor|null $vendor
	 * @return $this
	 */
	public function setTcfVendor(?TcfVendor $vendor): self
	{
		$this->set('tcf_vendor', $vendor ? $vendor->getId() : null);
		return $this;
	}

	/**
	 * @return TcfPurpose[]
	 */
	public function getTcfPurposes(): array
	{
		return array_map(function ($id) {
			return TcfPurpose::find($id);
		}, $this->get('tcf_purposes', []));
	}

	/**
	 * @param TcfPurpose[] $data
	 * @return $this
	 */
	public function setTcfPurposes(array $data): self
	{
		$this->set('tcf_purposes', array_map(function (TcfPurpose $purpose) {
			return $purpose->getId();
		}));
		return $this;
	}

	/**
	 * Maximale Lebenszeit des Embeddings in Stunden, oder
	 * $fallback wenn die Zeit nicht eindeutig bestimmbar ist.
	 *
	 * @param mixed $sessionFallback
	 * @param mixed $fallback
	 * @return int|mixed
	 */
	public function getLifetimeHours($sessionFallback=null, $fallback=null)
	{
		return Utils::parseLifetimeToHours($this->getLifetime(), $sessionFallback, $fallback);
	}

	/**
	 * @return string
	 */
	public function getLifetime(): string
	{
		return (string)$this->get('lifetime');
	}

	/**
	 * @param string $lifetime
	 * @return $this
	 */
	public function setLifetime(string $lifetime): self
	{
		$this->set('lifetime', $lifetime);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedLifetime(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_lifetime.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_lifetime.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getLifetime();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $lifetime
	 * @return $this
	 */
	public function setTranslatedLifetime(Locale $locale, string $lifetime): self
	{
		$this->set('translated_lifetime.'.$locale->getName(), $lifetime);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getHttpEmbeddingName(): string
	{
		return (string)$this->get('http_embedding_name');
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	public function setHttpEmbeddingName(string $name): self
	{
		$this->set('http_embedding_name', $name);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isActive(): bool
	{
		return (bool)$this->get('active');
	}

	/**
	 * @param bool $status
	 * @return $this
	 */
	public function setActive(bool $status): self
	{
		$this->set('active', $status);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getCollectedDataInfo(): string
	{
		return (string)$this->get('collected_data_info');
	}

	/**
	 * @param string $info
	 * @return $this
	 */
	public function setCollectedDataInfo(string $info): self
	{
		$this->set('collected_data_info', $info);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedCollectedDataInfo(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_collected_data_info.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_collected_data_info.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getCollectedDataInfo();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $info
	 * @return $this
	 */
	public function setTranslatedCollectedDataInfo(Locale $locale, string $info): self
	{
		$this->set('translated_collected_data_info.'.$locale->getName(), $info);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPurposeOfDataCollection(): string
	{
		return (string)$this->get('purpose_of_data_collection');
	}

	/**
	 * @param string $purpose
	 * @return $this
	 */
	public function setPurposeOfDataCollection(string $purpose): self
	{
		$this->set('purpose_of_data_collection', $purpose);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedPurposeOfDataCollection(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_purpose_of_data_collection.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_purpose_of_data_collection.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getPurposeOfDataCollection();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $purpose
	 * @return $this
	 */
	public function setTranslatedPurposeOfDataCollection(Locale $locale, string $purpose): self
	{
		$this->set('translated_purpose_of_data_collection.'.$locale->getName(), $purpose);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getLegalBasis(): string
	{
		return (string)$this->get('legal_basis');
	}

	/**
	 * @param string $basis
	 * @return $this
	 */
	public function setLegalBasis(string $basis): self
	{
		$this->set('legal_basis', $basis);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedLegalBasis(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_legal_basis.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_legal_basis.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getLegalBasis();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $basis
	 * @return $this
	 */
	public function setTranslatedLegalBasis(Locale $locale, string $basis): self
	{
		$this->set('translated_legal_basis.'.$locale->getName(), $basis);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPlaceOfProcessing(): string
	{
		return (string)$this->get('place_of_processing');
	}

	/**
	 * @param string $place
	 * @return $this
	 */
	public function setPlaceOfProcessing(string $place): self
	{
		$this->set('place_of_processing', $place);
		return $this;
	}

	/**
	 * @param Locale $locale
	 * @param bool $useFallback
	 * @return string
	 */
	public function getTranslatedPlaceOfProcessing(Locale $locale, $useFallback=true): string
	{
		$result = $this->get('translated_place_of_processing.'.$locale->getName());
		if ($result === null) {
			$result = $this->get('translated_place_of_processing.'.$locale->getId());
		}
		if ($useFallback and $result === null) {
			return $this->getPlaceOfProcessing();
		}
		return (string)$result;
	}

	/**
	 * @param Locale $locale
	 * @param string $place
	 * @return $this
	 */
	public function setTranslatedPlaceOfProcessing(Locale $locale, string $place): self
	{
		$this->set('translated_place_of_processing.'.$locale->getName(), $place);
		return $this;
	}

	/**
	 * Setzt alle übersetzten Texte, die in $locale noch nie vorher gesetzt
	 * wurden, auf den nicht-übersetzten Wert.
	 *
	 * @param Locale $locale Zu füllendes Locale
	 * @return $this
	 */
	public function fillTranslationsFromDefault(Locale $locale): self
	{
		$this->setTranslatedCollectedDataInfo($locale, $this->getTranslatedCollectedDataInfo($locale));
		$this->setTranslatedDescription($locale, $this->getTranslatedDescription($locale));
		$this->setTranslatedLegalBasis($locale, $this->getTranslatedLegalBasis($locale));
		$this->setTranslatedLifetime($locale, $this->getTranslatedLifetime($locale));
		$this->setTranslatedPlaceOfProcessing($locale, $this->getTranslatedPlaceOfProcessing($locale));
		$this->setTranslatedPrivacyPolicyUrl($locale, $this->getTranslatedPrivacyPolicyUrl($locale));
		$this->setTranslatedPurposeOfDataCollection($locale, $this->getTranslatedPurposeOfDataCollection($locale));
		return $this;
	}

}
