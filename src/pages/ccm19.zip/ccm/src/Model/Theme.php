<?php

namespace App\Model;

use App\JsonConfig;
use App\Utils;

class Theme extends ThemeBase
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * Diese Methode wird ausgeführt, sobald das Repository durch die Basisklasse Model geladen wurde.
	 */
	protected static function onRepositoryLoaded(): void
	{
		$domain = Domain::activeDomain();

		if (User::count() == 1) {
			// Updateroutine: Themelogos aus Single-User-Env in domainspezifische Konfigurationsstruktur migrieren
			foreach (self::all() as $theme) {
				/** @var self $theme */
				$basename = $theme->getLogoFilename(true);
				if (empty($basename)) {
					continue;
				}

				$sourceFile = Utils::getBaseDir() . '/public/img/logos/'.$basename;
				if (is_file($sourceFile) == false) {
					continue;
				}

				$destination = $domain->logoDir().'/'.$basename;
				if (is_file($destination)) {
					continue;
				}

				Utils::assertDirectoryWritable(dirname($destination));
				rename($sourceFile, $destination);
			}
		}
	}

	/**
	 * Schließt das aktive Theme-Repository.
	 * @param bool $flush
	 */
	public static function closeRepository(bool $flush = false): void
	{
		if ($flush && static::$repository) {
			static::flush();
		}
		static::$repository = null;
	}

	/**
	 * Wechselt zum Theme-Repository einer bestimmten Benutzer-Domain-Kombination.
	 *
	 * @param User $user
	 * @param Domain $domain
	 * @param bool $flush Ob Änderungen im vorherigen Repository gespeichert werden sollen
	 */
	public static function switchRepository(User $user, Domain $domain, bool $flush = false): void
	{
		self::closeRepository($flush);
		static::$repository = static::openRepository($user, $domain);
	}

	/**
	 * @param ThemeBase $theme
	 * @return $this
	 */
	public function importTheme(ThemeBase $theme): self
	{
		return $this
			->touchLastModifiedTimestamp()
			->setName($theme->getName())
			->setPosition($theme->getPosition())
			->setSelectType($theme->getSelectType())
			->setShowPurposesInMainWindow($theme->isShowPurposesInMainWindow())
			->setBlocking($theme->isBlocking())
			->setShowAcceptAllButtonInControlPanel($theme->isShowAcceptAllButtonInControlPanel())
			->setSettingsIconEnabled($theme->isSettingsIconEnabled())
			->setSettingsIconTarget($theme->getSettingsIconTarget())
			->setShowDeclineButton($theme->isShowDeclineButton())
			->setComplyingDoNotTrack($theme->isComplyingDoNotTrack())
			->setOnlyInEu($theme->getOnlyInEu())
			->setOkButtonBackgroundColor($theme->getOkButtonBackgroundColor())
			->setOkButtonColor($theme->getOkButtonColor())
			->setOkButtonBorderColor($theme->getOkButtonBorderColor())
			->setDeclineButtonBackgroundColor($theme->getDeclineButtonBackgroundColor())
			->setDeclineButtonTextColor($theme->getDeclineButtonTextColor())
			->setDeclineButtonBorderColor($theme->getDeclineButtonBorderColor())
			->setMoreInfoButtonBackgroundColor($theme->getMoreInfoButtonBackgroundColor())
			->setMoreInfoButtonColor($theme->getMoreInfoButtonColor())
			->setMoreInfoButtonBorderColor($theme->getMoreInfoButtonBorderColor())
			->setWindowBackgroundColor($theme->getWindowBackgroundColor())
			->setInfotextColor($theme->getInfotextColor())
			->setWindowBorderColor($theme->getWindowBorderColor())
			->setLinkInInfotextColor($theme->getLinkInInfotextColor())
			->setIframeBlockerBackgroundColor($theme->getIframeBlockerBackgroundColor())
			->setIframeBlockerForegroundColor($theme->getIframeBlockerForegroundColor())
			->setIframeBlockerButtonBackgroundColor($theme->getIframeBlockerButtonBackgroundColor())
			->setIframeBlockerButtonForegroundColor($theme->getIframeBlockerButtonForegroundColor())
			->setCustomCss($theme->getCustomCss())
			->setCustomCssForIframeBlocker($theme->getCustomCssForIframeBlocker())
		;
	}

	/**
	 * @return static[]
	 */
	public static function systemThemes(): array
	{
		return array_filter(self::all(), function ($theme) {
			/** @var self $theme */
			return $theme->getSystemTheme() !== null;
		}, 0);
	}

	/**
	 * @param SystemTheme $systemTheme
	 * @return static|null
	 */
	public static function bySystemTheme(SystemTheme $systemTheme): ?self
	{
		return array_reduce(self::systemThemes(), function ($theme, $currentTheme) use ($systemTheme) {
			/**
			 * @var self|null $theme
			 * @var self $currentTheme
			 * @var SystemTheme|null $currentSystemTheme
			 */
			$currentSystemTheme = $currentTheme->getSystemTheme();

			/** @var self $currentTheme */
			return $theme ?? ($currentSystemTheme && $currentSystemTheme->getId() == $systemTheme->getId() ? $currentTheme : $theme);
		}, null);
	}

	/**
	 * @return SystemTheme|null
	 */
	public function getSystemTheme(): ?SystemTheme
	{
		return SystemTheme::find((string)$this->get('systemThemeId'));
	}

	/**
	 * Diese Methode übernimmt sämtliche Eigenschaften des gegebenen System-Themes.
	 * @param SystemTheme|null $theme
	 * @return $this
	 */
	public function setSystemTheme(?SystemTheme $theme): self
	{
		if ($theme) {
			$this->setUserTheme(null);
			$this->importTheme($theme);
		}

		$this->set('systemThemeId', $theme ? $theme->getId() : null);
		return $this;
	}

	/**
	 * @return static[]
	 */
	public static function userThemes(): array
	{
		return array_filter(self::all(), function ($theme) {
			/** @var self $theme */
			return $theme->getUserTheme() !== null;
		}, 0);
	}

	/**
	 * @param UserTheme $userTheme
	 * @return static|null
	 */
	public static function byUserTheme(UserTheme $userTheme): ?self
	{
		return array_reduce(self::userThemes(), function ($theme, $currentTheme) use ($userTheme) {
			/**
			 * @var self|null $theme
			 * @var self $currentTheme
			 * @var UserTheme|null $currentUserTheme
			 */
			$currentUserTheme = $currentTheme->getUserTheme();

			/** @var self $currentTheme */
			return $theme ?? ($currentUserTheme && $currentUserTheme->getId() == $userTheme->getId() ? $currentTheme : $theme);
		}, null);
	}

	/**
	 * @return UserTheme|null
	 */
	public function getUserTheme(): ?UserTheme
	{
		return UserTheme::find((string)$this->get('userThemeId'));
	}

	/**
	 * Diese Methode übernimmt sämtliche Eigenschaften des gegebenen User-Themes.
	 * @param UserTheme|null $theme
	 * @return $this
	 */
	public function setUserTheme(?UserTheme $theme): self
	{
		if ($theme) {
			$this->setSystemTheme(null);
			$this->importTheme($theme);
		}

		$this->set('userThemeId', $theme ? $theme->getId() : null);
		return $this;
	}

	/**
	 * @param bool $preserveDeleted
	 * @return string
	 */
	public function getLogoFilename(bool $preserveDeleted = false): string
	{
		$logoFilename = (string)$this->get('logoFilename');

		// Wenn die Datei nicht mehr existiert, Eintrag aus Theme-Konfiguration entfernen
		if (strlen($logoFilename) > 0 && $preserveDeleted == false) {
			$logoPathName = Domain::activeDomain()->logoDir().'/'.$logoFilename;
			if (is_file($logoPathName) == false) {
				$this->setLogoFilename('');
				$logoFilename = '';
			}
		}

		return $logoFilename;
	}

	/**
	 * @param string $logoFilename
	 * @return $this
	 */
	public function setLogoFilename(string $logoFilename): self
	{
		$this->set('logoFilename', $logoFilename);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function isLogoDisplayed(): bool
	{
		return (bool)$this->get('logoDisplayed');
	}

	/**
	 * @param bool $logoDisplayed
	 * @return $this
	 */
	public function setLogoDisplayed(bool $logoDisplayed): self
	{
		$this->set('logoDisplayed', $logoDisplayed);
		return $this;
	}

	/**
	 * @return bool
	 */
	public function getWhitelabel(): bool
	{
		return (bool)$this->get('whitelabel');
	}

	/**
	 * @param bool $value
	 * @return $this
	 */
	public function setWhitelabel(bool $value): self
	{
		$this->set('whitelabel', $value);
		return $this;
	}
}
