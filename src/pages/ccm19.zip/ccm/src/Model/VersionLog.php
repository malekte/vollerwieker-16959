<?php

namespace App\Model;

use App\JsonConfig;
use App\Utils;
use DateTime;
use DateTimeInterface;
use LogicException;
use OutOfRangeException;


class VersionLog extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-versionlog.json';

	/**
	 * @param string $id
	 */
	public function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @param string $id
	 * @return static|null
	 */
	public static function byId(string $id): ?self
	{
		return parent::find($id);
	}

	/**
	 * Diese Methode löscht veraltete Einträge, bis nur noch die $maxCount neusten übrig bleiben.
	 *
	 * @throws OutOfRangeException
	 */
	public static function prune(int $maxCount, bool $autocommit=true): void
	{
		if ($maxCount <= 0) {
			throw new OutOfRangeException('maxCount must be positive');
		}

		self::beginWrite();

		$ids = array_keys(self::all());
		foreach (array_slice($ids, 0, -$maxCount) as $id) {
			self::delete($id, false);
		}

		if ($autocommit) {
			self::flush();
		}
	}

	/**
	 * Diese Methode speichert die Installation der aktuellen Version im Log.
	 *
	 * @param bool $autocommit
	 * @return self
	 * @throws LogicException
	 */
	public static function logCurrentVersion(bool $autocommit=true): Model
	{
		$versionId = Utils::getVersionId();
		$versionName = Utils::getVersionName();

		self::beginWrite();

		$instance = new self($versionId);
		$instance->setVersionName($versionName);
		$instance->addInstallDate();

		if ($autocommit) {
			self::flush();
		}
		return $instance;
	}

	public function wasInstalled(): bool
	{
		return (bool)$this->get('timestamps');
	}

	public function getVersionName(): string
	{
		return (string)$this->get('name');
	}

	/**
	 * @param string $name
	 * @return $this
	 */
	public function setVersionName(string $name): self
	{
		$this->set('name', $name);
		return $this;
	}

	public function getFirstInstallDate(): ?DateTimeInterface
	{
		$value = $this->get('timestamps')[0] ?? null;
		return ($value) ? new DateTime($value) : null;
	}

	public function getLastInstallDate(): ?DateTimeInterface
	{
		$values = $this->get('timestamps', []);
		$value = array_pop($values);
		return ($value) ? new DateTime($value) : null;
	}

	/**
	 * @return $this
	 */
	public function addInstallDate(?DateTimeInterface $date = null): self
	{
		if (!$date) {
			$date = new DateTime('now');
		}
		self::beginWrite();

		$timestamps = (array)$this->get('timestamps', []);
		$timestamps[] = $date->format('c');
		$this->set('timestamps', $timestamps);
		return $this;
	}

	/**
	 * @return DateTimeInterface[]
	 */
	public function getInstallDates(): array
	{
		$values = (array)$this->get('timestamps', []);
		return array_map(function ($v) {
			return new DateTime($v);
		}, $values);
	}

	/**
	 * @return $this
	 */
	protected function setInstallDates(array $dates): self
	{
		$values = array_map(function ($d) {
			return $d->format('c');
		}, $dates);
		$this->set('timestamps', $dates);
		return $this;
	}

}
