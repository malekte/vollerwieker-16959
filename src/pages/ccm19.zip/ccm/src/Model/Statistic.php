<?php

namespace App\Model;

use App\Exception\ConfigNotWritableException;
use App\JsonConfig;
use DateTime;
use DateTimeInterface;
use DateTimeImmutable;

class Statistic extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-statistic.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return DateTimeInterface
	 */
	public function getDate(): DateTimeInterface
	{
		return new DateTimeImmutable($this->getId());
	}

	/**
	 * @return string|null
	 */
	public function getLastConsentId(): ?string
	{
		return $this->get('lastucid');
	}

	/**
	 * @param string|null $ucid
	 * @return $this
	 */
	public function setLastConsentId(?string $ucid): self
	{
		$this->set('lastucid', $ucid);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getCallCountOffset(): int
	{
		return $this->get('co') ?? 0;
	}

	/**
	 * @param int $count
	 * @return $this
	 */
	public function setCallCountOffset(int $count): self
	{
		$this->set('co', $count);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getCallCount(): int
	{
		return $this->get('c') ?? 0;
	}

	/**
	 * @param int $count
	 * @return $this
	 */
	public function setCallCount(int $count): self
	{
		$this->set('c', $count);
		return $this;
	}

	/**
	 * @param int $inc Zähler um diese Anzahl erhöhen
	 * @return $this
	 */
	public function incrementCallCount(int $inc): self
	{
		self::beginWrite();
		$this->set('c', $this->getCallCount() + $inc);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getViewCount(): int
	{
		return $this->get('v') ?? 0;
	}

	/**
	 * @param int $count
	 * @return $this
	 */
	public function setViewCount(int $count): self
	{
		$this->set('v', $count);
		return $this;
	}

	/**
	 * @param int $inc Zähler um diese Anzahl erhöhen
	 * @return $this
	 */
	public function incrementViewCount(int $inc): self
	{
		self::beginWrite();
		$this->set('v', $this->getViewCount() + $inc);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getPurposeAcceptCount(string $purposeId, bool $includeArchived=true): int
	{
		$result = $this->get('p.'.$purposeId, 0);
		if ($includeArchived) {
			$result += $this->get('ap.'.$purposeId, 0);
		}
		return $result;
	}

	/**
	 * @param string $purposeId
	 * @param int $count
	 * @return $this
	 */
	public function setPurposeAcceptCount(string $purposeId, int $count): self
	{
		$this->set('p.'.$purposeId, $count);
		return $this;
	}

	/**
	 * @param string $purposeId
	 * @param int $diff Zähler um diese Anzahl erhöhen
	 * @return $this
	 */
	public function incrementPurposeAcceptCount(string $purposeId, int $diff=1): self
	{
		self::beginWrite();
		$this->set('p.'.$purposeId, $this->getPurposeAcceptCount($purposeId) + $diff);
		return $this;
	}

	/**
	 * @return int
	 */
	public function getEmbeddingAcceptCount(string $embeddingId, bool $includeArchived=true): int
	{
		$result = $this->get('e.'.$embeddingId, 0);
		if ($includeArchived) {
			$result += $this->get('ae.'.$embeddingId, 0);
		}
		return $result;
	}

	/**
	 * @param string $embeddingId
	 * @param int $count
	 * @return $this
	 */
	public function setEmbeddingAcceptCount(string $embeddingId, int $count): self
	{
		$this->set('e.'.$embeddingId, $count);
		return $this;
	}

	/**
	 * @param string $embeddingId
	 * @param int $diff Zähler um diese Anzahl erhöhen
	 * @return $this
	 */
	public function incrementEmbeddingAcceptCount(string $embeddingId, int $diff=1): self
	{
		self::beginWrite();
		$this->set('e.'.$embeddingId, $this->getEmbeddingAcceptCount($embeddingId) + $diff);
		return $this;
	}

	/**
	 * Archivieren von Purpose+Embedding-Zählern bei Protokoll-Rollover
	 *
	 * @return $this
	 */
	public function archivePurposeEmbeddingCounts(): self
	{
		self::beginWrite();
		$embeddings = $this->get('e', []);
		foreach ($embeddings as $embeddingId => $count) {
			$this->set('ae.'.$embeddingId, $this->get('ae.'.$embeddingId, 0)+$count);
			$this->set('e.'.$embeddingId, 0);
		}
		$purposes = $this->get('p', []);
		foreach ($purposes as $purposeId => $count) {
			$this->set('ap.'.$purposeId, $this->get('ap.'.$purposeId, 0)+$count);
			$this->set('p.'.$purposeId, 0);
		}
		return $this;
	}

	/**
	 * Diese Methode erstellt ein Objekt dieser Klasse
	 * @param string|null $date Y-m-d (default: heute)
	 * @return static
	 * @throws \LogicException
	 */
	public static function create($date=null): Model
	{
		if ($date === null) {
			$date = (new DateTimeImmutable('now'))->format('Y-m-d');
		}
		self::beginWrite();
		return new static($date);
	}

	/**
	 * Diese Methode löscht den durch das aktuelle Objekt referenzierten Datensatz aus der Konfiguration.
	 * @param string $date Y-m-d
	 * @param bool $autocommit
	 * @throws ConfigNotWritableException
	 */
	public static function delete(string $date, bool $autocommit=true): void
	{
		parent::delete($date, $autocommit);
	}
		/**
	 * @param string $date Y-m-d
	 * @return bool
	 */
	public static function exists(string $date): bool
	{
		return parent::exists($date);
	}

	/**
	 * @param string $date Y-m-d
	 * @return static|null
	 */
	public static function find(string $date): ?Model
	{
		return self::exists($date) ? new static($date) : null;
	}

	/**
	 * @param string $date Y-m-d
	 * @return static
	 */
	public static function findOrCreate(string $date): self
	{
		return self::find($date) ?? self::create($date);
	}
}
