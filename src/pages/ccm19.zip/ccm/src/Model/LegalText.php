<?php

namespace App\Model;

use App\JsonConfig;

class LegalText extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	protected static $repositoryFilename = 'cm-legal-texts.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	public static function byLocale(Locale $locale): ?self
	{
		return array_reduce(self::all(), function ($carry, $legalText) use ($locale) {
			/**
			 * @var LegalText $legalText
			 * @var Locale|null $currentLocale
			 */
			$currentLocale = $legalText->getLocale();

			if ($currentLocale === null) {
				return $carry;
			}

			return $carry ?? ($currentLocale->getId() == $locale->getId() ? $legalText : $carry);
		}, null);
	}

	/**
	 * @return Locale|null
	 */
	public function getLocale(): ?Locale
	{
		return Locale::byId((string)$this->get('localeId'));
	}

	/**
	 * @param Locale $locale
	 * @return $this
	 */
	public function setLocale(Locale $locale): self
	{
		$this->set('localeId', $locale->getId());
		return $this;
	}

	/**
	 * @return string
	 */
	public function getImprint(): string
	{
		return (string)$this->get('imprint');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setImprint(string $text): self
	{
		$this->set('imprint', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getImprintScheme(): string
	{
		return (string)$this->get('imprintScheme');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setImprintScheme(string $text): self
	{
		$this->set('imprintScheme', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPrivacyScheme(): string
	{
		return (string)$this->get('privacyScheme');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setPrivacyScheme(string $text): self
	{
		$this->set('privacyScheme', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getImprintUrl(): string
	{
		return (string)$this->get('imprintUrl');
	}


	/**
	 * @param string $text
	 * @return $this
	 */
	public function setImprintUrl(string $text): self
	{
		$this->set('imprintUrl', $text);
		return $this;
	}


	/**
	 * @param string $text
	 * @return $this
	 */
	public function setPrivacyUrl(string $text): self
	{
		$this->set('privacyUrl', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getPrivacyUrl(): string
	{
		return (string)$this->get('privacyUrl');
	}





	/**
	 * @return string
	 */
	public function getPrivacyPolicy(): string
	{
		return (string)$this->get('privacyPolicy');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setPrivacyPolicy(string $text): self
	{
		$this->set('privacyPolicy', $text);
		return $this;
	}



	/**
	 * @return string
	 */
	public function getAccessibilityScheme(): string
	{
		return (string)$this->get('accessibilityScheme');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setAccessibilityScheme(string $text): self
	{
		$this->set('accessibilityScheme', $text);
		return $this;
	}


	/**
	 * @param string $text
	 * @return $this
	 */
	public function setAccessibilityUrl(string $text): self
	{
		$this->set('accessibilityUrl', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getAccessibilityUrl(): string
	{
		return (string)$this->get('accessibilityUrl');
	}





	public function setEnableFrontendWidgetAccessibility(string $text): self
	{
		$this->set('setEnableFrontendWidgetAccessibility', $text);
		return $this;
	}

	/**
	 * @return string
	 */
	public function getEnableFrontendWidgetAccessibility(): string
	{
		return (string)$this->get('setEnableFrontendWidgetAccessibility');
	}






	/**
	 * @return string
	 */
	public function getAccessibility(): string
	{
		return (string)$this->get('accessibility');
	}

	/**
	 * @param string $text
	 * @return $this
	 */
	public function setAccessibility(string $text): self
	{
		$this->set('accessibility', $text);
		return $this;
	}
}
