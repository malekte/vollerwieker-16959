<?php

namespace App\Model;

use App\JsonConfig;
use App\Model\Cookie as CookieModel;
use App\Model\Locale as Locale;
use App\Utils;
use App\Component\Curl;
use Symfony\Component\HttpFoundation\Request;
use RuntimeException;

class OnBoardingEmbeddings extends Model
{
	/** @var JsonConfig|null $repository */
	protected static $repository = null;

	/** @var string $repositoryFilename */
	static $repositoryFilename = 'cm-cookies.json';

	/** @var bool $domainSpecificRepository */
	protected static $domainSpecificRepository = true;

	const API_URL = 'https://www.ccm19.de/crawler/cookie_crawler/crawlp.php';
	//http://localhost/ccm19/cookie_crawler/crawl.php
	//const API_URL = 'http://localhost/ccm19/cookie_crawler/crawl.php';

	static $connectionError = "";

	/**
	 * @param string $id
	 */
	protected function __construct(string $id)
	{
		parent::__construct($id);
	}

	/**
	 * @return string
	 */
	public function gettest(): string
	{
		return "test";
	}

	/**
	 * @param Request $request
	 * @param string $domain
	 * @return array
	 */
	public static function getDataFromRemote(Request $request, $domain): array
	{
		//korrigieren falls falsch eingetragen...
		if (!stristr($domain, "http:") && !stristr($domain, "https:")) {
			$domain = "http://" . $domain;
		}

		//parse url
		$domain_data = parse_url($domain);
		$host = $domain_data['host'];
		$domain = $domain_data['scheme'] . '://' . $host . '/';

		//auf lokale urls checken
		if (!$host or !(Utils::isPublicHost($host))) {
			return [];
		}

		//curl ini
		$curl = new Curl();

		//https://www.ccm19.de/crawler/cookie_crawler/crawl.php?apikey=1234&url=https://www.papoo.de
		$params = ["apikey" => "1234", "url" => $domain];

		//Daten holen
		$curl->get(self::API_URL, $params);

		if ($curl->curl_error) {
			throw new RuntimeException("An error has occurred in cURL module. (Code: {$curl->getErrorCode()}) " . $curl->getErrorMessage());
		} elseif ($curl->getResponseHeaders('Content-Type') != 'application/json') {
			throw new RuntimeException('Unexpected response from crawling server.');
		} elseif ($curl->isServerError()) {
		}

		$response = json_decode($curl->getResponse(), true);

		return $response;
	}


	/**
	 * Gibt die Daten zurück mit den Daten des Cookies aus der DB
	 *
	 * @param array $cookies Cookie-Namen
	 * @return array
	 */
	public static function getDataFromCCM19Database(array $cookies): array
	{
		if (!($cookies)) {
			return [];
		}
		$name = "";

		//Cookies durchlaufen und anhängen
		foreach ($cookies['cookies'] as $k => $v) {
			$name .= $v['name'] . ",";
			#print_r($v['name']."\n");
		}

		//local storage Elemente anhängen.
		foreach ($cookies['localStorage'] as $k => $v) {
			$name .= $v['name'] . ",";
			#print_r($v['name']."\n");
		}
		//print_r($cookies);
		//print_r($name);
		#exit();
		$url = "https://www.ccm19.de/plugins/flexapi/api2.php?" . http_build_query([
				'key' => 'jkn487gbf67igvfg6f2fhfbzg96ibjgbvzug',
				'cookiename' => $name
			]);
		##print_r($url);
		##exit();
		//Es steht kein curl zur Verfügung... dann nix machen
		if (!Curl::installed()) {
			return [];
		}

		$curl = new Curl();
		$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 3);
		$curl->setOpt(CURLOPT_TIMEOUT, 3);
		$curl->get($url);
		$resultData = $curl->getResponse();
		$curl->close();

		if (!$resultData) {
			return [];
		}

		$result = json_decode($resultData, true);
		//print_r($resultData);
		//exit();
		return (is_array($result)) ? $result : [];
	}

	/**
	 * @param $data
	 * @param $kat_data
	 * @return array
	 */
	public static function sortDataForCategories($data, $kat_data): array
	{
		$allDataCookieStorage = array_merge($data['cookies'],$data['localStorage'],$data['sessionStorage']);
		//print_r($data['cookies']);
		//exit();
		//umtragen
		if (empty($data['cookies'])) {
			return [];
		}

		//alle Cookies der Seite durchgehen
		$page_cookies = [];
		$dataNew = array();
		if (is_array($allDataCookieStorage)) {
			foreach ($allDataCookieStorage as $k => $v) {
				foreach ($kat_data['cookie_daten']['de'] as $kk => $kv) {
					#print_r($kv);
					#print_r($v['name']);
					if ($kk == $v['name']) {
						$dataNew['cookies'][$kk] = $kv;
					}

				}
				if (empty($dataNew['cookies'][$v['name']])) {
					$dataNew['cookies'][$v['name']] = $v;
				}
			}
		}
		//print_r($dataNew['cookies']);

		//exit();
		//Die Kategorien iDS
		$kategorien_ids = [1, 2, 3, 4, 5, 6];

		// das rückgabe Array
		$neu = [];
		$count = [];

		//Arrays sind leider sehr tief...
		foreach ($kategorien_ids as $kategorien_id) {
			foreach ($dataNew as $ok => $ov) {
				foreach ($ov as $ak => $av) {
					foreach ($av as $k => $v) {
						//print_r($v);
						if (!empty($v['Zweck_35'])) {
							if ($v['Zweck_35'] == $kategorien_id) {
								//print_r($v);
								//$v['LebensdauerdesCookies_8'] = self::getDiffMonth($v['expires'] - time());
								$v['active'] = true;
								$cookiesFromEmbedding = $v['nutztelement_50'];
								unset($v['nutztelement_50']);
								$v['nutztelement_50']['assets'] = $cookiesFromEmbedding;
								//$v['CookieName_1'] = $v['NamedesCookiesimBrowser_7'] = $v['name'];
								$neu[$kategorien_id][$v['mv_content_id']] = $v;
								unset($dataNew[$ok][$ak]);
							}
						}
					}
					if (!empty($neu[$kategorien_id])) {
						$count[$kategorien_id] = count($neu[$kategorien_id]);
					} else {
						$count[$kategorien_id] = 0;
						$neu[$kategorien_id] = [];
					}
				}
			}
		}

		//print_r($dataNew['cookies']);
		//print_r($neu);

		$i = 0;
		$dataNewSet = array();

		$ppIds=array("41ba25c"=>1,"cdcbd7c"=>2,"a717ff5"=>3,"7c19e32"=>4,"6cd2721"=>5,"15c61c3"=>6);

		// den Rest nochmal durchgehen und mit VOrlagen unter sonstiges eintragen
		foreach ($dataNew['cookies'] as $k => $v) {
			if (empty($v)) {
				unset($dataNew['cookies'][$k]);
				continue;
			}

			//es ist ein Cookie aus der alten Cookie DB - dann die Daten auch übernehmen...
			if (!empty($v['localeId']))
			{
				$defaultLocale = Locale::getDefault();
				$cookie = CookieModel::find($v['localeId']);
				$v['storageType'] = "cookie";
				$v['lifetime'] = $v['expires'];

				if (!empty($cookie))
				{
					$purpose = $ppIds[$cookie->getPurpose()->getId()];
					$dataNewSet['Zweck_35'] = $purpose;
					$dataNewSet['BezeichnungderEinbindung_34'] = "Vendor of: ".$v['name'];
					$dataNewSet['HerstellerAnbieter_36'] = $cookie->getCookieVendor();
					$dataNewSet['QuellcodederEinbindung_37'] = $cookie->getCodeSnippet();
					$dataNewSet['SkripteBlockierendiefolgendenTextenthalten_38'] = implode("\n",$cookie->getCodeBlock());
					$dataNewSet['BeschreibungderEinbindung_39'] = $cookie->getTranslatedDescription($defaultLocale);
					$dataNewSet['DatenschutzURL_40'] = $cookie->getPrivacyPolicyUrl();
					$dataNewSet['RechtlicheGrundlage_43'] = $cookie->getLegalBasis();
					$dataNewSet['ZweckderSammlung_42'] = $cookie->getTranslatedPurposeOfDataCollection($defaultLocale);
					$dataNewSet['WelcheDatenwerdengesammelt_41'] = $cookie->getTranslatedCollectedDataInfo($defaultLocale);
					$dataNewSet['OrtderVerarbeitung_44'] = $cookie->getTranslatedPlaceOfProcessing($defaultLocale);
					$dataNewSet['nutztelement_50']['assets']['0'] = $v;
					$dataNewSet['active'] = $cookie->isActive();
					$neu[$purpose][] = $dataNewSet;
					$count[$purpose]++;
				}
			}
			//Überhaupt nix bekannt -also neu - > dann leer setzen
			else{
				$i++;
				$v['id']=$i;
				$v['dynamic'] = 0;
				$v['storageType'] = "cookie";
				$v['description'] = "";
				if (!empty($v['expires']))
				{
					$v['lifetime'] = self::getDiffMonth($v['expires'] - time());
				}
				else{
					$v['lifetime'] = self::getDiffMonth(0);
				}


				foreach($data['localStorage'] as $sesk=>$sesv)
				{
					if ($v['name'] == $sesv['name'])
					{
						$v['storageType'] = "localStorage";
					}
				}

				foreach($data['sessionStorage'] as $sesk=>$sesv)
				{
					if ($v['name'] == $sesv['name'])
					{
						$v['storageType'] = "sessionStorage";
					}
				}

				//print_r($v);
				$dataNewSet['Zweck_35'] = 6;
				$dataNewSet['BezeichnungderEinbindung_34'] = "Anbieter von Cookie: ".$v['name'];
				$dataNewSet['HerstellerAnbieter_36'] = "N.A.";
				$dataNewSet['QuellcodederEinbindung_37'] = "N.A.";
				$dataNewSet['SkripteBlockierendiefolgendenTextenthalten_38'] = "";
				$dataNewSet['BeschreibungderEinbindung_39'] = "N.A.";
				$dataNewSet['DatenschutzURL_40'] = "N.A.";
				$dataNewSet['RechtlicheGrundlage_43'] = "Einwilligung, Art. 6 Abs. 1 lit. a DSGVO";
				$dataNewSet['ZweckderSammlung_42'] = "N.A.";
				$dataNewSet['WelcheDatenwerdengesammelt_41'] = "N.A.";
				$dataNewSet['OrtderVerarbeitung_44'] = "N.A.";
				$dataNewSet['nutztelement_50']['assets']['0'] = $v;
				$dataNewSet['active'] = true;
				$neu['6'][] = $dataNewSet;
				$count['6']++;
			}
		}
		//CCM Consent Cookie
		$neu[1][] = self::ccm_consent_cookie();
		$count['1']++;

		$return = [
			'sortdata' => $neu,
			'count' => $count
		];
		//print_r($return);
		//exit();
		return $return;
	}

	/**
	 * @return mixed
	 */
	private static function ccm_consent_cookie()
	{
		$ccm_consent_cookie = [];
		$cookie = array(
			"Cookiename_45" => "ccm_consent",
			"lifetime" => "365 Tage",
			"name" => "ccm_consent",
			"id" => 9999,
			"dynamic" => "0",
			"storageType" => 1,
			"description" => "Speichert den Consent Zustand"
		);
		$cookieAsset['assets']['0'] = $cookie;
		#print_r($cookieAsset);
		#exit();

		if (Utils::isExtendedEdition() && stristr($_SERVER['HTTP_HOST'], "5f3c395")) {
			$ccm_consent_cookie['Zweck_35'] = 1;
			$ccm_consent_cookie['BezeichnungderEinbindung_34'] = "CCM19 Cookie Consent Manager";
			$ccm_consent_cookie['HerstellerAnbieter_36'] = "Papoo Software & Media Gmbh - CCM19 Cookie Consent Manager";
			$ccm_consent_cookie['BeschreibungderEinbindung_39'] = "Dient zur Speicherung der Cookie Consent Vereinbarung - welche Cookies und Skripte gesetzt werden dürfen.";
			$ccm_consent_cookie['DatenschutzURL_40'] = "https://www.ccm19.de/datenschutzerklaerung.html";
			$ccm_consent_cookie['RechtlicheGrundlage_43'] = "DSGVO Art.7 Absatz 1";
			$ccm_consent_cookie['ZweckderSammlung_42'] = "Um Ihre Präferenz für die Nutzung von Cookies auf dieser Seite zu speichern.";
			$ccm_consent_cookie['WelcheDatenwerdengesammelt_41'] = "Zustand der Einstellung welche Cookies gesetzt werden dürfen für Sie. Daten werden nach Kategorien sortiert gespeichert.";
			$ccm_consent_cookie['OrtderVerarbeitung_44'] = "Limburg bei Frankfurt, Deutschland";

			$ccm_consent_cookie['SkripteBlockierendiefolgendenTextenthalten_38'] = "";
			$ccm_consent_cookie['nutztelement_50'] = $cookieAsset;
			$ccm_consent_cookie['active'] = true;
		} else {
			$ccm_consent_cookie['Zweck_35'] = 1;
			$ccm_consent_cookie['BezeichnungderEinbindung_34'] = "CCM19 Cookie Consent Manager";
			$ccm_consent_cookie['HerstellerAnbieter_36'] = "{Firma}";
			$ccm_consent_cookie['BeschreibungderEinbindung_39'] = "Dient zur Speicherung der Cookie Consent Vereinbarung - welche Cookies und Skripte gesetzt werden dürfen.";
			$ccm_consent_cookie['DatenschutzURL_40'] = "{Firma_Datenschutz}";
			$ccm_consent_cookie['RechtlicheGrundlage_43'] = "DSGVO Art.7 Absatz 1";
			$ccm_consent_cookie['ZweckderSammlung_42'] = "Um Ihre Präferenz für die Nutzung von Cookies auf dieser Seite zu speichern.";
			$ccm_consent_cookie['WelcheDatenwerdengesammelt_41'] = "Zustand der Einstellung welche Cookies gesetzt werden dürfen für Sie. Daten werden nach Kategorien sortiert gespeichert.";
			$ccm_consent_cookie['OrtderVerarbeitung_44'] = "{Firma_Ort}";

			$ccm_consent_cookie['SkripteBlockierendiefolgendenTextenthalten_38'] = "";
			$ccm_consent_cookie['nutztelement_50'] = $cookieAsset;
			$ccm_consent_cookie['active'] = true;
		}
		return $ccm_consent_cookie;
	}

	/**
	 * @param $date int
	 * @return float
	 */
	private static function getDiffMonth($date): float
	{
		$month = round($date / 2635200, 0);
		if ($month < 0) {
			$month = 0;
		}
		return $month;
	}


}
