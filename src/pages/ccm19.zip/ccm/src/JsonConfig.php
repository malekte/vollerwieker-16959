<?php

namespace App;

use App\Component\Config\RepositoryInterface;
use App\Exception\ConfigNotWritableException;
use App\Exception\ConfigNotReadableException;
use App\Utils;
use InvalidArgumentException;

class JsonConfig implements RepositoryInterface
{
	/** @var string $filename */
	private $filename;

	/** @var array $data */
	private $data;

	/** @var array $cache */
	private $cache;

	/** @var bool $dirty */
	private $dirty;

	/** @var bool $dirty */
	private $writeLocked;

	/** @var resource */
	private $handle;

	/**
	 * Lädt bzw. erstellt eine Konfigurationsdatei relativ zum Projektverzeichnis <i>`var/`</i>.
	 * @param string $filename
	 */
	public function __construct(string $filename)
	{
		$this->filename = $filename;
		$this->dirty = false;
		$this->writeLocked = false;

		$this->data = [];
		$this->cache = [];

		// Wenn die Konfigurationsdatei existiert, wird sie eingelesen, andernfalls wird versucht, sie zu erstellen.
		$this->reload();
	}

	/**
	 * Stellt sicher, dass die Datei entsperrt wird
	 *
	 * @phan-suppress PhanTypeMismatchProperty
	 */
	public function __destruct()
	{
		if (@$this->handle) {
			@flock($this->handle, LOCK_UN);
			@fclose($this->handle);
			$this->handle = null;
		}
	}

	/**
	 * Diese Methode gibt den Dateipfad der Konfigurationsdatei zurück.
	 * @return string
	 */
	private function getPathname(): string
	{
		return Utils::getVarDir() . DIRECTORY_SEPARATOR . $this->filename;
	}

	/**
	 * @return array
	 */
	public function toArray(): array
	{
		return $this->data;
	}

	/**
	 * Größe des Repositories auf der Festplatte in Bytes, ohne ungespeicherte Änderungen
	 *
	 * @return int Größe in Bytes
	 */
	public function getPersistedSize(): int
	{
		return (int)@filesize($this->getPathname());
	}

	/**
	 * Diese Methode liest Daten aus der Konfiguration. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $fallback
	 * @return mixed
	 * @phan-side-effect-free
	 */
	public function get(string $identifier, $fallback = null)
	{
		if (isset($this->cache[$identifier])) {
			return $this->cache[$identifier];
		}

		$nodeNames = array_values(array_filter(explode('.', $identifier), function ($str) { return strlen($str) > 0; }));
		if (count($nodeNames) == 0) {
			return $fallback;
		}

		$value = $fallback;

		try {
			$value = array_reduce($nodeNames, function ($node, $key) use ($identifier) {
				if (is_array($node) && array_key_exists($key, $node)) {
					return $node[$key];
				}
				else {
					throw new InvalidArgumentException("Config `$identifier` not found.");
				}
			}, $this->data);
		} catch (InvalidArgumentException $exception) {}

		$this->cache[$identifier] = $value;

		return $value;
	}

	/**
	 * Diese Methode schreibt Daten in die Konfiguration. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $data
	 * @return $this
	 */
	public function set(string $identifier, $data): self
	{
		$this->beginWrite();
		$nodeNames = array_values(array_filter(explode('.', $identifier), function ($str) { return strlen($str) > 0; }));
		if (count($nodeNames) == 0) {
			return $this;
		}

		$node = &$this->data;

		foreach ($nodeNames as $key => $childNode) {
			$isLast = $key == count($nodeNames) - 1;

			if (array_key_exists($childNode, $node) == false || ($isLast == false && is_array($node[$childNode]) == false)) {
				$node[$childNode] = [];
			}

			$tmpRef = &$node[$childNode];
			unset($node);

			$node = &$tmpRef;
			unset($tmpRef);
		}

		$hasChanged = is_array($node) || is_object($node) || $node === null || $node !== $data;

		if ($hasChanged) {
			$node = $data;
			$this->cache[$identifier] = $data;
			$this->dirty = true;
		}

		return $this;
	}

	/**
	 * Diese Methode entfernt einen Konfigurationsstrang. Die Änderung muss mit JsonConfig::flush() verewigt werden.
	 * @param string $identifier
	 * @return $this
	 * @see JsonConfig::flush()
	 */
	public function unset(string $identifier): self
	{
		$this->beginWrite();
		$nodeNames = array_values(array_filter(explode('.', $identifier), function ($str) { return strlen($str) > 0; }));
		if (count($nodeNames) == 0) {
			return $this;
		}

		$node = &$this->data;
		foreach ($nodeNames as $key => $nodeName) {
			// Datenzweig entfernen
			if ($key + 1 == count($nodeNames)) {
				unset($node[$nodeName]);
				unset($this->cache[$identifier]);
				$this->dirty = true;
				break;
			}
			// Wenn die definierte Datenstruktur nicht existiert, muss nichts gemacht werden
			else if (array_key_exists($nodeName, $node) == false || is_array($node[$nodeName]) == false) {
				break;
			}

			$tmpRef = &$node[$nodeName];
			unset($node);

			$node = &$tmpRef;
			unset($tmpRef);
		}

		return $this;
	}

	/**
	 * Diese Methode leert die gesamte Konfiguration, muss jedoch noch mit JsonConfig::flush() geschrieben werden.
	 * @see JsonConfig::flush()
	 */
	public function clear(): void
	{
		$this->beginWrite();
		$this->data = [];
		$this->cache = [];
		$this->dirty = true;
	}

	/**
	 * Diese Methode schreibt alle an der Konfiguration vorgenommenen Änderungen auf die Platte.
	 * @throws ConfigNotWritableException
	 */
	public function flush(): void
	{
		$f = $this->handle;

		if (!$f) {
			return;
		}

		if ($this->dirty == false) {
			flock($f, LOCK_UN);
			return;
		}

		// Sicher gehen, dass wir einen exklusiven Lock haben
		if (!$this->writeLocked) {
			flock($f, LOCK_EX);
		}

		$filename = $this->getPathname();
		$data     = json_encode($this->data);

		fseek($f, 0);
		if (@fwrite($f, $data) < strlen($data)) {
			throw new ConfigNotWritableException($filename);
		}
		ftruncate($f, ftell($f));

		// Datei wieder entsperren
		flock($f, LOCK_UN);
		$this->dirty = false;
		$this->writeLocked = false;
	}

	/**
	 * Diese Methode liest die Konfiguration erneut von der Festplatte ein. Sämtliche Änderungen gehen verloren.
	 *
	 * @param bool $forWrite Ob die Datei zum Schreiben gesperrt werden soll
	 *
	 * @throws ConfigNotReadableException
	 */
	public function reload(bool $forWrite=false): void
	{
		// Dateihandle entsperren und schließen wenn offen
		$f = $this->handle;
		if ($f) {
			flock($f, LOCK_UN);
			fclose($f);
		}
		$this->writeLocked = false;

		// Datei öffnen
		$f = $this->handle = @fopen($this->getPathname(), ($forWrite ? 'rb+' : 'rb'));
		if ($f) {
			flock($f, ($forWrite ? LOCK_EX : LOCK_SH));
			$data = json_decode(@stream_get_contents($f), true);
			$this->dirty = false;
			$this->writeLocked = $forWrite;
			if (!$forWrite) {
				flock($f, LOCK_UN);
			}
		}
		else {
			$error = error_get_last()['message'];
			if (is_file($this->getPathname())) {
				if ($forWrite) {
					throw new ConfigNotWritableException($this->getPathname());
				}
				else {
					throw new ConfigNotReadableException($this->getPathname());
				}
			}
			// Datei erstellen, falls sie fehlt
			else {
				$f = $this->handle = @fopen($this->getPathname(), 'cb+');
				flock($f, LOCK_EX);
				$data = json_decode(@stream_get_contents($f), true);
				$this->dirty = true;
				$this->writeLocked = true;
				if ($forWrite == false) {
					$this->flush();
				}
			}
		}
		$this->data = is_array($data) ? $data : [];
		$this->cache = [];
	}

	public function isInWrite(): bool {
		return $this->writeLocked;
	}

	/**
	 * Sperrt die Konfiguration zum Schreiben.
	 *
	 * Danach kann bis zu flush() oder reload() kein parallel laufender
	 * Prozess auf die Datei zugreifen.
	 */
	public function beginWrite(): void
	{
		if ($this->writeLocked == false) {
			$this->reload(true);
		}
	}

	/**
	 * Escaping von Schlüsseln.
	 *
	 * Verhindert das . als Trenner für Unterelemente interpretiert wird.
	 *
	 * @param string $key
	 * @return string
	 */
	public static function escapeKey($key): string
	{
		$key = str_replace('%', '%25', (string)$key);
		$key = str_replace("\0", '%00', $key);
		$key = str_replace('.', '%2E', $key);
		return $key;
	}

	/**
	 * Unescaping von Schlüsseln.
	 *
	 * @param string $key
	 * @return string
	 * @see JsonConfig::escapeKey()
	 */
	public static function unescapeKey(string $key): string
	{
		$key = str_replace('%2E', '.', $key);
		$key = str_replace('%00', "\0", $key);
		$key = str_replace('%25', '%', $key);
		return $key;
	}
}
