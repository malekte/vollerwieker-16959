<?php

namespace App\EventSubscriber;

use App\Controller\AdminController;
use App\Controller\DomainDependantController;
use App\Controller\ExternalController;
use App\Kernel;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\ControllerEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Twig\Environment;

class TwigGlobalsHandler extends AbstractController implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::CONTROLLER => ['onKernelController', 1000],
		];
	}

	/**
	 * Diese Methode setzt ein paar häufig verwendete Templatevariablen an zentraler Stelle.
	 *
	 * Wichtig: Sollte nach dem AuthenticationHandler laufen, um den aktiven Benutzer korrekt zu bestimmen.
	 *
	 * @param ControllerEvent $event
	 * @phan-suppress PhanTypeArraySuspicious
	 */
	public function onKernelController(ControllerEvent $event): void
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		/** @var AbstractController $controller */
		$controller = $event->getController()[0];

		/** @var Kernel $kernel */
		global $kernel;

		/** @var Request $request */
		$request = $event->getRequest();

		/** @var Environment $twig */
		$twig = $kernel->getContainer()->get('twig');

		/** @var User|null $user */
		$user = User::loggedInUser();
		/** @var Domain|null $domain */
		$domain = $user ? Domain::activeDomain() : null;
		/** @var Domain[] $domains */
		$domains = $user ? Domain::all() : [];

		// Sortiere Domains dem Namen nach
		usort($domains, function (Domain $a, Domain $b) {
			return strnatcasecmp($a->getName(), $b->getName());
		});

		if(isset($_SESSION['update_notifier']) and $_SESSION['update_notifier'] === true)
		{
			$twig->addGlobal('update_notifier', true);
		}
		else {
			$twig->addGlobal('update_notifier', false);
		}

		$twig->addGlobal('user', $user);
		$twig->addGlobal('_isAdmin', $user ? $user->getRole() == User::ROLE_ADMIN : false);
		$twig->addGlobal('_isClient', $user ? $user->getRole() == User::ROLE_CLIENT : false);
		$twig->addGlobal('_originalUser', User::originalLoggedInUser());
		$twig->addGlobal('_domain', $domain);
		$twig->addGlobal('_domains', $domains);
		$twig->addGlobal('_edition', [
			'basic' => Utils::isBaseEdition(),
			'extended' => Utils::isExtendedEdition(),
		]);
		$twig->addGlobal('_hostingInterface', Utils::hostingInterface());
		$twig->addGlobal('_themeBack_customCss', Utils::getThemeBack_customCss());
		$twig->addGlobal('_isFrontendActive',true);

		$twig->addGlobal('_docUrl', Utils::getDocUrl($request->get('_route')));

		if (is_object($domain))
		{
			$twig->addGlobal('_isModernManagement',$domain->getManagementStructure());
			$twig->addGlobal('_isFrontendActive',$domain->isFrontendWidgetEnabled());
		}
		$twig->addGlobal('_domainDependant', $controller instanceof DomainDependantController);
		$twig->addGlobal('_adminController', $controller instanceof AdminController);
		$twig->addGlobal('_externalRequest', $controller instanceof ExternalController);
		$twig->addGlobal('_domainSwitchRoute', ($controller instanceof DomainDependantController) ? $request->get('_route') : 'app_dashboard');

		$twig->addGlobal('_metaSidebar', false);

		// Versions-ID/-Name
		$twig->addGlobal('_versionName', Utils::getVersionName());
		$twig->addGlobal('_versionId', Utils::getVersionId());

		// aktuelle Route
		$twig->addGlobal('_route', $request->attributes->get('_route', 'app_root'));
		$twig->addGlobal('_route_params', $request->attributes->get('_route_params', []));

		// Minify-Einstellung
		$twig->addGlobal('_forceDisableMinification', ($domain and $domain->hasCodeMinification() == false));

		// Update-Status
		$twig->addGlobal('_updateInfo', UpdateNotifyHandler::getCachedData());
	}
}
