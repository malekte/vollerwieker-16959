<?php

namespace App\EventSubscriber;

use App\Config;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class UnloadHandler implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::RESPONSE => ['onKernelResponse', 50],
		];
	}

	/**
	 * Am Ende einer Anfrage wird die Session geschlossen, die Konfiguration geschrieben
	 * und ggf. Standard-Header nachgetragen.
	 *
	 * @param ResponseEvent $event
	 */
	public function onKernelResponse(ResponseEvent $event): void
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		/** @var Config $config */
		$config = Config::getInstance();
		$config->flush();

		$session = new Session();
		$session->save();

		$response = $event->getResponse();
		if ($response and !$response->headers->has('Content-Security-Policy')) {
			$response->headers->set('Content-Security-Policy',
				"default-src 'self'; " .
				"connect-src 'self' https://update.ccm19.de; " .
				"script-src 'self' 'unsafe-inline'; " .
				"style-src 'self' 'unsafe-inline'; " .
				"img-src 'self' data:; " .
				"frame-ancestors 'self'; " .
				"form-action 'self'"
			);
			$response->headers->set('X-Frame-Options', 'sameorigin');
		}
	}
}
