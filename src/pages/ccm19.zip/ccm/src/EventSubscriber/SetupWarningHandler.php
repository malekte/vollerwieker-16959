<?php

namespace App\EventSubscriber;

use App\Model\User;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\ControllerArgumentsEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Contracts\Translation\TranslatorInterface;

class SetupWarningHandler implements EventSubscriberInterface
{

	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::CONTROLLER_ARGUMENTS => ['onKernelControllerArgs', -1],
		];
	}

	/**
	 * Wenn das Setup noch existiert, bei jedem eingeloggten Seitenaufruf warnen.
	 *
	 * @param ControllerArgumentsEvent $event
	 */
	public function onKernelControllerArgs(ControllerArgumentsEvent $event): void
	{
		global $kernel;

		if ($event->isMasterRequest() == false) {
			return;
		}
		if (User::loggedInUser() === null) {
			return;
		}

		$projectDir = $kernel->getProjectDir();
		$request = $event->getRequest();
		/** @var Session $session */
		$session = $request->getSession();

		if ($session and $session instanceof Session) {
			// Nicht anzeigen, wenn schon eine Warnmeldung angezeigt wird
			$warnMessages = $session->getFlashBag()->peek('warning');
			if ($warnMessages) {
				return;
			}

			$translator = $kernel->getContainer()->get('translator');

			$this->checkAndWarnSetupPhp($projectDir, $session, $translator);
		}
	}
	
	private function checkAndWarnSetupPhp($projectDir, Session $session, TranslatorInterface $translator): void
	{
		foreach ([$projectDir . DIRECTORY_SEPARATOR . 'setup.php', $projectDir . DIRECTORY_SEPARATOR . '..' . DIRECTORY_SEPARATOR . 'setup.php'] as $file) {
			if (file_exists($file) and is_readable($file)) {
				$session->getFlashBag()->add('warning', $translator->trans('The setup file setup.php still exists. For security reasons you should remove it from the webspace.'));
				break;
			}
		}
	}
}
