<?php

namespace App\EventSubscriber;

use App\Component\Api\HostingApi;
use App\Controller\AdminController;
use App\Controller\DomainDependantController;
use App\Controller\DomainManager;
use App\Controller\ExternalController;
use App\Controller\HostingApiController;
use App\Controller\HostingController;
use App\Controller\LicenseManager;
use App\Controller\Login;
use App\Controller\Setup;
use App\Controller\UniversalController;
use App\Controller\UnrestrictedController;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Dflydev\Hawk\Server\UnauthorizedException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\ControllerEvent;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class AuthenticationHandler extends AbstractController implements EventSubscriberInterface
{
	/** @var bool $apiRequestAuthenticated */
	private $apiRequestAuthenticated;

	/** @var bool $domainAutodetected */
	private $domainAutodetected;

	/** @var HostingApiController|null $apiRequestController */
	private $apiRequestController;

	/** @var Response|null $response */
	private $response;

	public function __construct()
	{
		$this->apiRequestAuthenticated = false;
		$this->domainAutodetected = false;
		$this->apiRequestController = null;
		$this->response = null;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::CONTROLLER => ['onKernelController', 9999],
			KernelEvents::RESPONSE => ['onKernelResponse', 9999],
		];
	}

	/**
	 * Diese Methode gibt die generierte Response zurück, sofern die Anfrage nicht zur Bearbeitung freigegeben wurde.
	 * @return Response
	 */
	public function onUnauthorizedRequest(): Response
	{
		return $this->response;
	}

	/**
	 * Gibt die Domain zurück, von der der auf diese URL verwiesen wurde, soweit bestimmbar.
	 *
	 * Verwendet den Origin-Header, wenn vorhanden, ansonsten Referer.
	 *
	 * @param Request $request
	 * @param bool $removeWWW www. entfernen
	 * @return string|null
	 */
	private function getOriginDomain(Request $request, bool $removeWWW=true): ?string
	{
		$url = $request->headers->get('Origin');
		if (!$url) {
			$url = $request->headers->get('Referer');
		}
		if (!$url) {
			return null;
		}
		$host = parse_url(trim($url), PHP_URL_HOST);
		if ($host) {
			if ($removeWWW) {
				$host = preg_replace('/^www[0-9]?\./', '', $host);
			}
			return strtolower(rtrim($host, '.'));
		}
		else {
			return null;
		}
	}

	/**
	 * Diese Methode überprüft, ob der Seitenbesucher eingeloggt ist und unternimmt u. U. entsprechende Maßnahmen.
	 *
	 * @param ControllerEvent $event
	 * @phan-suppress PhanTypeArraySuspicious
	 */
	public function onKernelController(ControllerEvent $event): void
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		$authorize = true;
		$controller = $event->getController()[0];
		$request = $event->getRequest();
		$user = User::loggedInUser();

		// Alle externen Anfragen zulassen, sofern ein gültiger API-Schlüssel beiliegt
		if ($controller instanceof ExternalController) {
			$apiKey = (string)$request->query->get('apiKey');

			// Fallback: In alten Systemen ohne API-Key und nur einem Benutzer, diesen Benutzer verwenden
			if (empty($apiKey) && Utils::isBaseEdition() && User::count() == 1) {
				/** @var User $user */
				$user = array_values(User::all())[0];
				$apiKey = $user->getApiKey();
			}

			// Domainchecks nur bei gültigem Benutzer durchführen
			if (User::setApiUser($apiKey)) {
				// Aktiven Benutzer und Domaindatenbank umschalten
				$user = User::loggedInUser();
				assert($user instanceof User);
				Domain::switchToUser($user);

				$domainId = (string)$request->query->get('domain');

				// Domain-Autoerkennung
				if (!$domainId and Utils::isExtendedEdition()) {
					$this->domainAutodetected = true;
					$domainName = $this->getOriginDomain($request);
					if ($domainName) {
						$domain = Domain::byMatchedDomain($domainName);
						$domainlimit = $user->getMaxDomainCount();
						// Domain erstellen, wenn nicht bekannt, Feature aktiv und noch genug Domains im Account
						if (!$domain and $user->isAutoAddDomains() and ($domainlimit === -1 or $user->getActualDomainCount() < $domainlimit)) {
							$domain = Domain::createForUser($user)->setName($domainName)->setFrontendWidgetEnabled(false);
							$domain->save();
							$user->setActualDomainCount(Domain::countIncludingShareNames());
							$user->save();
						}
						if ($domain) {
							$domainId = $domain->getId();
						}
					}
				}

				// Fallback: Erste für alte Systeme nachgepflegte Domain verwenden
				if (empty($domainId) && Utils::isBaseEdition() && Domain::count() == 1) {
					/** @var Domain $domain */
					$domain = array_values(Domain::all())[0];
					$domainId = $domain->getId();
				}

				if (Domain::setDomainForRequest($domainId)) {
					return;
				}
				else {
					$this->response = new JsonResponse([
						'error' => '400 Bad Request',
						'description' => 'invalid domain',
					], 400);
					$authorize = false;
				}
			}
			else {
				$this->response = new JsonResponse([
					'error' => '400 Bad Request',
					'description' => 'invalid api key',
				], 400);
				$authorize = false;
			}
		}

		// Zugriffe auf den Login- und Setup-Bereich immer zulassen
		else if ($controller instanceof Login || $controller instanceof Setup) {
			$authorize = true;
		}

		// Zugriffe auf unbeschränkte Bereiche zulassen
		else if ($controller instanceof UnrestrictedController) {
			return;
		}

		// Zugriffe auf API der Hostingversion
		else if ($controller instanceof HostingApiController) {
			$this->apiRequestController = $controller;
			$this->apiRequestAuthenticated = false;

			try {
				HostingApi::getInstance()->authorizeRequest($request);
				$this->apiRequestAuthenticated = true;
				return;
			}
			catch (UnauthorizedException $exception) {
				$this->response = $this->json([
					'error' => 'Unauthorized: '.$exception->getMessage(),
				], 401);
				$authorize = false;
			}
		}

		else if ($user) {

			$isAdmin = $user->getRole() == User::ROLE_ADMIN;

			// Administratoren bei invalider Lizenz zur Lizenzverwaltung leiten; Kunden ausloggen
			if (Utils::isLicensed() == false) {
				if ($isAdmin && $controller instanceof LicenseManager == false) {
					$this->response = $this->redirectToRoute('app_license_manager_index');
					$authorize = false;
				}
				elseif ($isAdmin == false) {
					User::logout();
					$this->addFlash('alert', 'License has expired.');
					$this->response = $this->redirectToRoute('app_login');
					$authorize = false;
				}
			}

			// Administratoren den Zugriff auf den Update-Bereich/Systemeinstellungen generell gewähren
			else if ($controller instanceof AdminController) {
				if ($isAdmin == false) {
					$this->response = $this->redirectToRoute('app_root');
					$authorize = false;
				}
			}
			// Universelle Bereiche, wie z. B. die Kontoeinstellungen, immer freigeben
			else if ($controller instanceof UniversalController) {
				$authorize = true;
			}
			else if ($controller instanceof DomainManager) {
				if (Utils::isBaseEdition() || $isAdmin) {
					$this->response = Utils::isExtendedEdition()
						? $this->redirectToRoute('app_hosting_dashboard')
						: $this->redirectToRoute('app_root');
					$authorize = false;
				}
			}
			else if (Utils::isExtendedEdition()) {
				if ($isAdmin xor $controller instanceof HostingController) {
					$this->response = $isAdmin
						? $this->redirectToRoute('app_hosting_dashboard')
						: $this->redirectToRoute('app_root');
					$authorize = false;
				}
			}
			// Zugriff auf Hostingbereiche in der Basisversion verwehren
			else if ($controller instanceof HostingController) {
				$this->response = $this->redirectToRoute('app_root');
				$authorize = false;
			}
		}
		// Zugriff verwehren, sofern sich der Besucher weder im Login- noch im Setup-Bereich befindet
		else if ($controller instanceof Login == false && $controller instanceof Setup == false) {
			$this->response = $this->redirectToLogin($request);
			$authorize = false;
		}

		if ($authorize == false) {
			$event->setController([$this, 'onUnauthorizedRequest']);
		}
	}

	public function onKernelResponse(ResponseEvent $event): void
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		/** @var Response $response */
		$response = $event->getResponse();

		/** @var Request $request */
		$request = $event->getRequest();

		if ($this->domainAutodetected) {
			$vary = $response->getVary();
			if (!in_array('Origin', $vary)) {
				$vary[] = 'Origin';
			}
			if (!$request->headers->has('Origin')) {
				if (!in_array('Referer', $vary)) {
					$vary[] = 'Referer';
				}
			}
			$response->setVary($vary);
		}

		if ($this->apiRequestController && $this->apiRequestAuthenticated) {
			HostingApi::getInstance()->signResponse($response);
		}
	}

	/**
	 * Weiterleiten zum Login
	 *
	 * @param Request $request
	 * @return RedirectResponse
	 */
	private function redirectToLogin(Request $request): RedirectResponse
	{
		$route = $request->attributes->get('_route', 'app_root');
		$routeParams = $request->attributes->get('_route_params', []);

		if (!in_array($route, ['app_root', 'app_hosting_dashboard', 'app_logout', 'app_logout_post', 'app_login', 'app_login_post'])) {
			return $this->redirectToRoute('app_login', [
				'backTo'=>strtr(base64_encode(json_encode([$route, $routeParams])), ['+'=>'-', '/'=>'_', '='=>''])
			]);
		}
		else {
			return $this->redirectToRoute('app_login', []);
		}
	}
}
