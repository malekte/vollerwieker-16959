<?php

namespace App\EventSubscriber;

use App\Controller\ExternalController;
use App\Utils;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\FilterControllerEvent;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class CorsHandler implements EventSubscriberInterface
{
	/** @var ?object $controller */
	private $controller;

	/**
	 * @return void
	 */
	public function __construct()
	{
		$this->controller = null;
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents()
	{
		return [
			KernelEvents::CONTROLLER => ['onKernelController', 9998],
			KernelEvents::RESPONSE => ['onKernelResponse', 9998],
		];
	}

	/**
	 * Controller für OPTIONS-Requests
	 */
	public function handlePreFlightRequest(): Response
	{
		$response = new Response('', 204);
		Utils::resetCacheControl($response);
		return $response;
	}

	/**
	 * @return void
	 * @phan-suppress PhanTypeArraySuspicious
	 */
	public function onKernelController(FilterControllerEvent $event)
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		$this->controller = $event->getController()[0];
		$request = $event->getRequest();

		$requestMethod = $request->getRealMethod();

		// Handle pre-flight requests
		if ($requestMethod == 'OPTIONS') {
			$event->setController([$this, 'handlePreFlightRequest']);
		}
	}

	/**
	 * @return void
	 */
	public function onKernelResponse(FilterResponseEvent $event)
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		$request = $event->getRequest();
		$requestOrigin = $request->headers->get('Origin');
		$requestedWith = $request->headers->get('X-Requested-With');

		if (empty($requestOrigin) || $this->controller instanceof ExternalController == false) {
			return;
		}

		$allowedHeaders = [
			'Content-Type',
			'X-Requested-With',
			'X-CCM19State',
		];

		$allowedMethods = [
			'GET',
			'POST',
			'PUT',
		];

		// TODO Whitelist implementieren
		$response = $event->getResponse();
		$response->headers->set('Access-Control-Allow-Origin', '*');
		$response->headers->set('Access-Control-Allow-Credentials', 'true');
		$response->headers->set('Access-Control-Allow-Headers', implode(',', $allowedHeaders));
		$response->headers->set('Access-Control-Allow-Methods', implode(',', $allowedMethods));
		$response->headers->set('Access-Control-Max-Age', '3600');
	}
}
