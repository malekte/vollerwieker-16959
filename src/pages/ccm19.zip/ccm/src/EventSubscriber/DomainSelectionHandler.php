<?php

namespace App\EventSubscriber;

use App\Controller\DomainDependantController;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\ControllerEvent;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\Routing\RequestContext;

class DomainSelectionHandler extends AbstractController implements EventSubscriberInterface
{
	/** @var Response|null $response */
	private $response;
	/** @var RequestContext|null $requestContext */
	private $requestContext;

	public function __construct(RequestContext $requestContext = null)
	{
		$this->requestContext = $requestContext;
		$this->response = null;
	}

	/**
	 * @override
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::CONTROLLER => ['onKernelController', 9990],
			//KernelEvents::RESPONSE => ['onKernelResponse', 9999],
		];
	}

	/**
	 * Setzt die Domain in der Session auf die in der URL und setzt die Domain
	 * als Standardparameter fürs Routing.
	 *
	 * @param ControllerEvent $event
	 * @phan-suppress PhanTypeArraySuspicious
	 */
	public function onKernelController(ControllerEvent $event): void
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		$controller = $event->getController()[0];
		$request = $event->getRequest();

		if ($controller instanceof DomainDependantController) {
			$domainId = $request->get('_domainId');
			$domain = Domain::find($domainId);
			$request->getSession()->set('domain', $domainId);

			// Wenn falsche Domain in URL entweder zur einzig richtigen weiterleiten oder zur Domainauswahl
			if (!$domain) {
				if (Utils::isExtendedEdition()) {
					$event->setController([$this, 'redirectToDomainSelection']);
				}
				elseif (Domain::count() > 0) {
					$domain = current(Domain::all());
					Domain::select($domain->getId());
					$event->setController([$this, 'redirectToDomain']);
				}
			}
		}

		// _domainId bei Routen-Erstellung vorgeben (für Redirects und Routen in Twig-Templates)
		$domainId = $request->getSession()->get('domain');
		$this->requestContext->setParameter('_domainId', ($domainId != "") ? $domainId : 'default');
	}

	/**
	 * Weiterleiten zur Route mit richtiger Domain
	 *
	 * @see \App\Component\DomainDependantRoutingLoader::load()
	 * @param Request $request
	 * @return RedirectResponse
	 */
	public function redirectToDomain(Request $request): RedirectResponse
	{
		$route = $request->attributes->get('_route', 'app_dashboard');
		$routeParams = $request->attributes->get('_route_params', []);
		if (strrpos($route, '.nodomain') == strlen($route)-9) {
			$route = substr($route, 0, -9);
		}
		
		$domain = Domain::activeDomain();
		if ($domain == null) {
			if (Utils::isExtendedEdition()) {
				return $this->redirectToRoute('app_domains_index', [], 303);
			}
			else {
				$domain = array_values(Domain::all())[0];
			}
		}
		$routeParams['_domainId'] = $domain->getId();

		return $this->redirectToRoute($route, $routeParams, 307);
	}

	/**
	 * Weiterleiten zur Domainauswahl
	 *
	 * @param Request $request
	 * @return RedirectResponse
	 */
	public function redirectToDomainSelection(Request $request): RedirectResponse
	{
		$route = 'app_domains_index';
		$routeParams = [];

		return $this->redirectToRoute($route, $routeParams, 303);
	}
}
