<?php

namespace App\EventSubscriber;

use App\MailMessage;
use App\Model\User;
use App\Model\Domain;
use ErrorException;
use Swift_Mailer;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\ExceptionEvent;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\KernelEvents;
use Throwable;

class ExceptionHandler implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::EXCEPTION => ['onKernelException', 1],
		];
	}

	/**
	 * Bei Exceptions eine E-Mail versenden, wenn die Environment-Variable
	 * APP_EXCEPTION_MAIL auf eine E-Mail-Adresse gesetzt ist.
	 *
	 * @param ExceptionEvent $event
	 */
	public function onKernelException(ExceptionEvent $event): void
	{
		global $kernel;

		if (empty($_ENV['APP_EXCEPTION_MAIL'])) {
			return;
		}

		try {
			$exception = $event->getException();

			if ($exception instanceof NotFoundHttpException) {
				// 404 ist nicht interessant.
				return;
			}

			/** @var Swift_Mailer $mailer */
			$mailer = $kernel->getContainer()->get('Swift_Mailer');

			$root = $kernel->getProjectDir().'/';
			$file = preg_replace('~^'.preg_quote($root, '~').'~', '', $exception->getFile());
			$line = $exception->getLine();

			if ($exception instanceof ErrorException) {
				$msg = trim(explode("\n", $exception->getMessage(), 2)[0]);
				if (strlen($msg) > 100) {
					$msg = substr($msg, 0, 97).'...';
				}

				$subject = "[CCM19] [Exception] $msg at $file:$line";
				$body = (string)$exception."\n";
			} else {
				$subject = '[CCM19] [Exception] '.get_class($exception)." at $file:$line";
				$body = (string)$exception."\n";
			}

			$user = User::loggedInUser();
			if ($user) {
				$body .= "\nUser: ".$user->getUsername()."\n";

				$domain = Domain::activeDomain();
				if ($domain) {
					$body .= "Domain: ".trim($domain->getName())."\n";
				}
			}

			// Pfade im Text kürzen
			$body = preg_replace('~(\s)'.preg_quote($root, '~').'~', '$1', $body);

			// Footer hinzufügen
			$body .= "\n-- \nAutomatic mail sent by your CCM19 installation at ".$_SERVER['HTTP_HOST'].".\n";

			$mail = new MailMessage($subject, $body, 'text/plain');

			$mail->setTo($_ENV['APP_EXCEPTION_MAIL']);
			$mail->setVoidReplyTo();
			$mail->getHeaders()->addTextHeader('Auto-Submitted', 'auto-generated');

			$mailer->send($mail);
		}
		catch (Throwable $e) {
			// ignore
		}
	}

}
