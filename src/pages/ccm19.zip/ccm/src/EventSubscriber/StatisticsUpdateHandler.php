<?php

namespace App\EventSubscriber;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Contracts\EventDispatcher\Event;
use App\Model\User;
use App\Model\Domain;
use App\Model\Protocol;
use App\Model\AccessCountJournal;
use App\Model\Statistic;
use App\Component\Cron;
use App\Event\ProtocolRotateEvent;
use App\Event\StatisticsDisplayEvent;
use App\Event\StatisticsCronJobEvent;
use App\Utils;

class StatisticsUpdateHandler implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			ProtocolRotateEvent::NAME => ['onProtocolRotate', 10],
			StatisticsDisplayEvent::NAME => ['onStatisticsDisplay', 10],
			StatisticsCronJobEvent::NAME => ['onStatisticsCronJob', 10],
		];
	}

	private function updateCallCount(User $user, Domain $domain): void
	{
		User::beginWrite();
		$journal = AccessCountJournal::byDomainAndKind($domain, 'call');
		$stat = null;
		if (Utils::isExtendedEdition()) {
			$user->resetCallCountForNextMonth();
		}
		foreach ($journal->iterateEntries() as $date => $count) {
			$stat = Statistic::findOrCreate($date);
			$stat->incrementCallCount($count);
			if (Utils::isExtendedEdition()) {
				$user->incrementCallCount($count);
			}
		}
		User::flush();
	}

	private function updateViewCount(Domain $domain): void
	{
		$journal = AccessCountJournal::byDomainAndKind($domain, 'view');
		$stat = null;
		foreach ($journal->iterateEntries() as $date => $count) {
			$stat = Statistic::findOrCreate($date);
			$stat->incrementViewCount($count);
		}
	}

	public function onProtocolRotate(Event $event): void
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		if (!$domain or !$user) {
			return;
		}
		$this->updateStatisticsFull($user, $domain, true);
	}

	public function onStatisticsDisplay(Event $event): void
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		if (!$domain or !$user) {
			return;
		}
		$this->updateStatisticsFull($user, $domain);
	}

	public function onStatisticsCronJob(StatisticsCronJobEvent $event): void
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		if (!$domain or !$user) {
			return;
		}
		if ($event->isFullUpdateRequested()) {
			$this->updateStatisticsFull($user, $domain);
		} else {
			Statistic::beginWrite();
			$this->updateCallCount($user, $domain);
			$this->updateViewCount($domain);
			Statistic::flush();
		}
	}

	public function updateStatisticsFull(User $user, Domain $domain, bool $archiveCounts=false): void
	{
		$protocol = Protocol::byDomain($domain);
		$currentDate = null;
		// Nach Unique-ID gruppieren; immer neuesten Eintrag nehmen
		$byUcid = [];
		$sumsPerDay = [];
		$date = null;

		foreach ($protocol->iterateEntries() as $item) {
			$date = date("Y-m-d", $item['timestamp'] ?? 0);
			$ucid = $item['ucid'];
			unset($item['ucid']);
			unset($item['manipulationPrevention']);
			$item['date'] = $date;

			if ($currentDate !== $date) {
				$sumsPerDay[$date] = [
					'purposes'=>[],
					'embeddings'=>[]
				];
				$currentDate = $date;
			}

			if (isset($byUcid[$ucid])) {
				$olditem = $byUcid[$ucid];
				$item['first_date'] = $olditem['first_date'] ?? $olditem['date'];
			} else {
				$olditem = null;
			}

			// Purposes zählen
			if (isset($item['purposes']) && is_array($item['purposes'])) {
				if ($olditem && isset($olditem['purposes'])) {
					foreach ($olditem['purposes'] as $purposeId) {
						if (!isset($sumsPerDay[$date]['purposes'][$purposeId])) {
							$sumsPerDay[$date]['purposes'][$purposeId] = 0;
						}
						$sumsPerDay[$date]['purposes'][$purposeId]--;
					}
				}
				foreach ($item['purposes'] as $purposeId) {
					if (!isset($sumsPerDay[$date]['purposes'][$purposeId])) {
						$sumsPerDay[$date]['purposes'][$purposeId] = 0;
					}
					$sumsPerDay[$date]['purposes'][$purposeId]++;
				}
			}

			// Embeddings zählen
			if (isset($item['embeddings']) && is_array($item['embeddings'])) {
				if ($olditem && isset($olditem['embeddings'])) {
					foreach ($olditem['embeddings'] as $embeddingId) {
						if (!isset($sumsPerDay[$date]['embeddings'][$embeddingId])) {
							$sumsPerDay[$date]['embeddings'][$embeddingId] = 0;
						}
						$sumsPerDay[$date]['embeddings'][$embeddingId]--;
					}
				}
				foreach ($item['embeddings'] as $embeddingId) {
					if (!isset($sumsPerDay[$date]['embeddings'][$embeddingId])) {
						$sumsPerDay[$date]['embeddings'][$embeddingId] = 0;
					}
					$sumsPerDay[$date]['embeddings'][$embeddingId]++;
				}
			}
			$byUcid[$ucid] = $item;
		}
		// Speicher freigeben
		foreach ($byUcid as $ucid => &$item) {
			$item = null;
		}
		unset($item);
		$lastDate = $date;

		// Statistiken speichern
		Statistic::beginWrite();
		foreach ($sumsPerDay as $date => $row) {
			$stat = Statistic::findOrCreate($date);

			foreach ($row['purposes'] as $purposeId => $count) {
				$stat->setPurposeAcceptCount($purposeId, $count);
			}
			foreach ($row['embeddings'] as $embeddingId => $count) {
				$stat->setEmbeddingAcceptCount($embeddingId, $count);
			}

			if ($archiveCounts and $date == $lastDate) {
				$stat->archivePurposeEmbeddingCounts();
			}
		}

		$this->updateCallCount($user, $domain);
		$this->updateViewCount($domain);

		Statistic::flush();
	}

}
