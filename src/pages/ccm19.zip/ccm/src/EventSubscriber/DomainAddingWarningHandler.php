<?php

namespace App\EventSubscriber;

use App\Model\User;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\ControllerArgumentsEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Contracts\Translation\TranslatorInterface;

class DomainAddingWarningHandler implements EventSubscriberInterface
{

	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::CONTROLLER_ARGUMENTS => ['onKernelControllerArgs', 0],
		];
	}

	/**
	 * Wenn die automatische Domain-Erstellung noch aktiv ist, bei jedem eingeloggten Seitenaufruf informieren.
	 *
	 * @param ControllerArgumentsEvent $event
	 */
	public function onKernelControllerArgs(ControllerArgumentsEvent $event): void
	{
		global $kernel;

		if ($event->isMasterRequest() == false) {
			return;
		}

		$user = User::loggedInUser();
		if ($user === null) {
			return;
		}

		$request = $event->getRequest();
		/** @var Session $session */
		$session = $request->getSession();

		if ($session and $session instanceof Session) {
			// Nicht anzeigen, wenn schon eine Infomeldung angezeigt wird
			$warnMessages = $session->getFlashBag()->peek('info');
			if ($warnMessages) {
				return;
			}

			$translator = $kernel->getContainer()->get('translator');
			$this->checkAndWarn($user, $session, $translator);
		}

	}

	private function checkAndWarn(User $user, Session $session, TranslatorInterface $translator): void
	{
		$user = User::loggedInUser();

		if ($user->isAutoAddDomains()) {
			$session->getFlashBag()->add('info', $translator->trans('Automatic domain creation is still active. Please contact your CCM19 provider if you don\'t need it anymore.'));
		}
	}
}
