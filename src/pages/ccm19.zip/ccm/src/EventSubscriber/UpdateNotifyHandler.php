<?php

namespace App\EventSubscriber;

use App\Config;
use App\Utils;
use App\Component\Update;
use App\Model\User;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpKernel\Event\ControllerEvent;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Contracts\Translation\TranslatorInterface;
use Throwable;

class UpdateNotifyHandler implements EventSubscriberInterface
{
	const CHECK_RANDOMIZATION = 3; // durchschnittlich jeder dritte Backend-Aufruf
	const MIN_CHECK_INTERVAL = 180; // 3 Minuten
	/** @var Update */
	private $updater;
	/** @var Config */
	private $config;

	public function __construct(Update $updater)
	{
		$this->updater = $updater;
		$this->config = Config::getInstance();
	}

	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::CONTROLLER => ['onKernelController', 1050],
		];
	}

	public static function getCacheFilePath(): string
	{
		return Utils::getCacheDir() . DIRECTORY_SEPARATOR . 'availableUpdate.json';
	}

	public static function getCachedData(): array
	{
		return @json_decode(file_get_contents(self::getCacheFilePath()),true) ?: ['available'=>false, 'nextGenAvailable'=>false, 'error'=>false];
	}

	/**
	 * Regelmäßig auf Updates checken, wenn als Admin angemeldet
	 *
	 * @param ControllerEvent $event
	 */
	public function onKernelController(ControllerEvent $event): void
	{
		$request = $event->getRequest();
		$user = User::loggedInUser();
		if ($event->isMasterRequest() == false) {
			return;
		}
		if ($request->getMethod() != 'GET') {
			return;
		}
		if ($user === null or $user->getRole() !== User::ROLE_ADMIN) {
			return;
		}

		// Mit Zufalls-Faktor nach neuen Updates schauen
		if (rand(1, self::CHECK_RANDOMIZATION) == 1) {
			$this->checkNotifyUpdate();
		}
	}

	private function checkNotifyUpdate(): void
	{
		$cachePath = $this->getCacheFilePath();
		// Innerhalb von fünf Minuten seit dem letzten Check nichts tun
		if (file_exists($cachePath) and (time()-filemtime($cachePath) < self::MIN_CHECK_INTERVAL)) {
			return;
		}

		try {
			$updateInfo = $this->updater->checkForUpdate();
			if (!$updateInfo) {
				$updateInfo = ['available'=>false, 'nextGenAvailable'=>false, 'error'=>true];
			}
			else {
				$updateInfo['lastModified'] = $updateInfo['lastModified']->format('Y-m-d H:i:s');
				$updateInfo['available'] = (Utils::getVersionId() != $updateInfo['versionId']);
			}
		}
		catch (Throwable $e) {
			$updateInfo = ['available'=>false, 'nextGenAvailable'=>false, 'error'=>true];
		}
		if (@file_put_contents($cachePath.'.tmp', json_encode($updateInfo), LOCK_EX)) {
			rename($cachePath.'.tmp', $cachePath);
		}
	}
}
