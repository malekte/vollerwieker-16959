<?php

namespace App\EventSubscriber;

use App\Component\ConfigImporterContext;
use App\Config;
use App\Model\Cookie;
use App\Model\Domain;
use App\Model\FoundCookie;
use App\Model\FoundObject;
use App\Model\FoundScript;
use App\Model\FoundStorage;
use App\Model\LegalText;
use App\Model\Locale;
use App\Model\Protocol;
use App\Model\Purpose;
use App\Model\Theme;
use App\Model\User;
use App\Utils;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class BootHandler implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::REQUEST => ['onKernelRequest', 9999],
		];
	}

	public static function updateRoutines(): void
	{
		$user = User::loggedInUser();

		// Updatevorgang nur bei aktivem Benutzer durchlaufen, um benutzerspezifische Konfigurationen zu gewährleisten.
		// TODO Updateroutinen in separaten Handler auslagern, der nach AuthenticationHandler::onKernelController läuft
		if ($user == null) {
			return;
		}

		$config = Config::getInstance();
		$context = new ConfigImporterContext($user);

		// Verhindern, dass Neuinstallationen "aktualisiert" werden
		if (Utils::isBaseEdition() && $config->get('multiDomain', false) == false && User::count() == 1) {
			if (Domain::count() == 0) {
				$domain = Domain::createForUser($user, false);
				$domain->save();

				$context->setDomain($domain);
			}

			Cookie::migratePreMultiUserConfig($context);
			FoundCookie::migratePreMultiUserConfig($context);
			FoundObject::migratePreMultiUserConfig($context);
			FoundScript::migratePreMultiUserConfig($context);
			FoundStorage::migratePreMultiUserConfig($context);
			LegalText::migratePreMultiUserConfig($context);
			Locale::migratePreMultiUserConfig($context);
			Protocol::migratePreMultiUserConfig($context);
			Theme::migratePreMultiUserConfig($context);

			Cookie::migratePreMultiDomainConfig($context);
			FoundCookie::migratePreMultiDomainConfig($context);
			FoundObject::migratePreMultiDomainConfig($context);
			FoundScript::migratePreMultiDomainConfig($context);
			FoundStorage::migratePreMultiDomainConfig($context);
			LegalText::migratePreMultiDomainConfig($context);
			Locale::migratePreMultiDomainConfig($context);
			Protocol::migratePreMultiDomainConfig($context);
			Theme::migratePreMultiDomainConfig($context);
		}

		if ($user->getRole() === User::ROLE_ADMIN and $user->getEmailAddress() == '')
		{
			$user->setEmailAddress($config->get('email'))->save();
		}

		if (Domain::count() > 0 and Domain::activeDomain()) {
			// Migration der unübersetzten Texte in erste Übersetzung
			if (!$config->get('defaultLocale')) {
				$locales = Locale::all();
				if ($locales) {
					reset($locales);
					$locale = current($locales);
					$config->set('defaultLocale', $locale->getId());
					foreach (Purpose::all() as $purpose) {
						$purpose->fillTranslationsFromDefault($locale);
					}
					Purpose::flush();
					$config->flush();
				}
			}
			if (!$user->getDefaultLocale()) {
				$locales = Locale::all();
				if ($locales) {
					reset($locales);
					$locale = current($locales);
					$user->setDefaultLocale($locale);
					foreach (Cookie::all() as $cookie) {
						$cookie->fillTranslationsFromDefault($locale);
					}
					Cookie::flush();
					User::flush();
				}
			}
			// Standardwerte für neu hinzugekommene Übersetzungen
			$locale = Locale::find('de_DE');
			if ($locale) {
				if ($locale->getCookieVendorText() === '') {
					$locale->setCookieVendorText('Herausgeber');
				}
				if ($locale->getCookieDescriptionText() === '') {
					$locale->setCookieDescriptionText('Beschreibung');
				}
				if ($locale->getCookiePrivacyPolicyUrlText() === '') {
					$locale->setCookiePrivacyPolicyUrlText('Link zur Datenschutzerklärung');
				}
				if ($locale->getCookieLifetimeText() === '') {
					$locale->setCookieLifetimeText('Lebensdauer');
				}
				if ($locale->getCookieCollectedDataInfoText() === '') {
					$locale->setCookieCollectedDataInfoText('Welche Daten werden erhoben?');
				}
				if ($locale->getCookiePurposeOfDataCollectionText() === '') {
					$locale->setCookiePurposeOfDataCollectionText('Zweck der Datenerhebung');
				}
				if ($locale->getCookieLegalBasisText() === '') {
					$locale->setCookieLegalBasisText('Rechtliche Grundlage');
				}
				if ($locale->getCookiePlaceOfProcessingText() === '') {
					$locale->setCookiePlaceOfProcessingText('Ort der Verarbeitung');
				}
				if ($locale->getImprintText() === '') {
					$locale->setImprintText('Impressum');
				}
				if ($locale->getPrivacyPolicyText() === '') {
					$locale->setPrivacyPolicyText('Datenschutzerklärung');
				}
				if ($locale->getAccessibilityText() === '') {
					$locale->setAccessibilityText('Barrierefreiheit');
				}
				if ($locale->getBlockedContentTitle() === '') {
					$locale->setBlockedContentTitle('Externe Inhalte blockiert!');
				}
				if ($locale->getBlockedContentText() === '') {
					$locale->setBlockedContentText('An dieser Stelle wurde das Laden einer Ressource von :domain unterbunden. Ob und welche Cookies möglicherweise durch den Aufruf gesetzt würden, können wir Ihnen nicht sagen. Wenn Sie die Inhalte dennoch nachladen möchten, akzeptieren Sie diesen Umstand bitte mit folgender Schaltfläche.');
				}
				if ($locale->getBlockedContentButtonText() === '') {
					$locale->setBlockedContentButtonText('Externe Inhalte nachladen');
				}
				if ($locale->getChangeConsentLabel() === '') {
					$locale->setChangeConsentLabel('Zustimmung ändern');
				}
				$locale->flush();
			}
			$locale = Locale::find('en_US');
			if ($locale) {
				if ($locale->getCookieVendorText() === '') {
					$locale->setCookieVendorText('Vendor');
				}
				if ($locale->getCookieDescriptionText() === '') {
					$locale->setCookieDescriptionText('Description');
				}
				if ($locale->getCookiePrivacyPolicyUrlText() === '') {
					$locale->setCookiePrivacyPolicyUrlText('Link to privacy policy');
				}
				if ($locale->getCookieLifetimeText() === '') {
					$locale->setCookieLifetimeText('Lifetime');
				}
				if ($locale->getCookieCollectedDataInfoText() === '') {
					$locale->setCookieCollectedDataInfoText('What data will be collected?');
				}
				if ($locale->getCookiePurposeOfDataCollectionText() === '') {
					$locale->setCookiePurposeOfDataCollectionText('Purpose of data collection');
				}
				if ($locale->getCookieLegalBasisText() === '') {
					$locale->setCookieLegalBasisText('Legal basis');
				}
				if ($locale->getCookiePlaceOfProcessingText() === '') {
					$locale->setCookiePlaceOfProcessingText('Place of processing');
				}
				if ($locale->getImprintText() === '') {
					$locale->setImprintText('Imprint');
				}
				if ($locale->getPrivacyPolicyText() === '') {
					$locale->setPrivacyPolicyText('Privacy Policy');
				}
				if ($locale->getBlockedContentTitle() === '') {
					$locale->setBlockedContentTitle('Blocked external content!');
				}
				if ($locale->getBlockedContentText() === '') {
					$locale->setBlockedContentText('At this point the loading of a resource from :domain was suppressed. We cannot tell you whether and which cookies would possibly be set by the call. If you still want to load the content, please accept this with the following button.');
				}
				if ($locale->getBlockedContentButtonText() === '') {
					$locale->setBlockedContentButtonText('Load external content');
				}
				if ($locale->getChangeConsentLabel() === '') {
					$locale->setChangeConsentLabel('Change consent');
				}
				$locale->flush();
			}
		}
	}

	/**
	 * Am Anfang einer Anfrage wird die Session gestartet.
	 * @param RequestEvent $event
	 */
	public function onKernelRequest(RequestEvent $event): void
	{
		if ($event->isMasterRequest() == false) {
			return;
		}

		/** @var Request $request */
		$request = $event->getRequest();

		// Hotfix zur Erkennung von HTTPS über Proxies, wie CloudFlare etc.
		Request::setTrustedProxies(['127.0.0.1', $request->server->get('REMOTE_ADDR')], Request::HEADER_X_FORWARDED_PROTO);

		// Routen bestimmen, für die keine Session geöffnet werden muss
		$path = $request->getPathInfo();
		$noSession = (
			$path == '/ccm19.js' or
			$path == '/ccm19.css' or
			$path == '/widget' or
			$path == '/page_check/report' or
			strpos($path, '/logo/') === 0 or
			strpos($path, '/statistics/') === 0
		);

		// Session-Storage vorbereiten
		$storage = new NativeSessionStorage([
			'cookie_samesite'=>'Lax',
			'cookie_httponly'=>true,
			'cookie_secure' => $request->isSecure(),
			'cookie_path' => $request->getBasePath(),
		]);

		// Session öffnen
		$session = new Session($storage);
		$session->setName('ccm_login_session');

		// Session öffnen, nur wenn keine externe Route
		if (!$noSession) {
			$session->start();
		}

		self::updateRoutines();
	}
}
