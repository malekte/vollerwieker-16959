<?php

namespace App\EventSubscriber;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;

class LanguageHandler extends AbstractController implements EventSubscriberInterface
{
	/**
	 * @return array
	 */
	public static function getSubscribedEvents(): array
	{
		return [
			KernelEvents::REQUEST => ['onKernelRequest', 17],
		];
	}

	/**
	 * Am Anfang einer Anfrage wird das Locale aus das aus der Session gesetzt
	 * und das Locale in Templates verfügbar gemacht.
	 *
	 * Wichtig: Die Priority muss > 16 sein, damit das Locale vor dem Laden der
	 * Übersetzungen gesetzt wird.
	 *
	 * @param RequestEvent $event
	 */
	public function onKernelRequest(RequestEvent $event): void
	{
		global $kernel;

		if ($event->isMasterRequest() == false) {
			return;
		}

		$request = $event->getRequest();
		$session = $request->getSession();

		if (!$session) { return; }

		// Locale aus Session holen
		$locale = $session->get('locale');
		if ($locale) {
			$request->setLocale($locale);
		}

		// Locale in Twig-Variablen schreiben
		$twig = $kernel->getContainer()->get('twig');
		$twig->addGlobal('_locale', $request->getLocale());
	}

}
