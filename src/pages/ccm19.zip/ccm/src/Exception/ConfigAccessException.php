<?php

namespace App\Exception;

use RuntimeException;

class ConfigAccessException extends RuntimeException
{
}
