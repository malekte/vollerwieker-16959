<?php
namespace App\Exception;

class DownloaderHTTPException extends DownloaderException
{}
