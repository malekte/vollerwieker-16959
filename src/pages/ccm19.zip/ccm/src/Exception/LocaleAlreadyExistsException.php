<?php

namespace App\Exception;

use Exception;
use Throwable;

class LocaleAlreadyExistsException extends Exception
{
	public function __construct(string $localeName, $code = 0, Throwable $previous = null)
	{
		parent::__construct("Locale $localeName already exists.", $code, $previous);
	}
}
