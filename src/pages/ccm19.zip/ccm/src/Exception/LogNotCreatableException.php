<?php

namespace App\Exception;

use Throwable;

class LogNotCreatableException extends LogAccessException
{
	public function __construct(string $filename, $code = 0, Throwable $previous = null)
	{
		parent::__construct("Log file $filename could not be created, please check directory permissions and disk quota", $code, $previous);
	}
}
