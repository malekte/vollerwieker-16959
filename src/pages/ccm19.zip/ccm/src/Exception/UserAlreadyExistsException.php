<?php

namespace App\Exception;

use Exception;
use Throwable;

class UserAlreadyExistsException extends Exception
{
	public function __construct(string $username, $code = 0, Throwable $previous = null)
	{
		parent::__construct("User with username $username already exists.", $code, $previous);
	}
}
