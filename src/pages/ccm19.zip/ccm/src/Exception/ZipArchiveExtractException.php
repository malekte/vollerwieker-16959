<?php

namespace App\Exception;

use RuntimeException;
use Throwable;

class ZipArchiveExtractException extends RuntimeException
{
	public function __construct(string $fileName, $code = 0, Throwable $previous = null)
	{
		parent::__construct($fileName, $code, $previous);
	}
}
