<?php

namespace App\Exception;

use Throwable;

class LogNotReadableException extends LogAccessException
{
	public function __construct(string $filename, $code = 0, Throwable $previous = null)
	{
		parent::__construct("Log file $filename could not be read, please check permissions.", $code, $previous);
	}
}
