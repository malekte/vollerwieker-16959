<?php

namespace App\Exception;

use RuntimeException;
use Throwable;

class TempFileNotWritableException extends RuntimeException
{
	public function __construct(string $fileName, $code = 0, Throwable $previous = null)
	{
		parent::__construct($fileName, $code, $previous);
	}
}
