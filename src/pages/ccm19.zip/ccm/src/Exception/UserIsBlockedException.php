<?php

namespace App\Exception;

use RuntimeException;
use Throwable;

class UserIsBlockedException extends RuntimeException
{
	public function __construct(string $username, $code = 0, Throwable $previous = null)
	{
		parent::__construct('User is blocked from logging into the system.', $code, $previous);
	}
}
