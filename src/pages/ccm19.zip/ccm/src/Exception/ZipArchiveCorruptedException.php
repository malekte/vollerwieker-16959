<?php

namespace App\Exception;

class ZipArchiveCorruptedException extends ZipArchiveException
{
}
