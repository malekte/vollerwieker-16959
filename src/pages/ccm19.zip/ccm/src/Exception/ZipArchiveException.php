<?php

namespace App\Exception;

use RuntimeException;

class ZipArchiveException extends RuntimeException
{
}
