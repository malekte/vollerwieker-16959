<?php

namespace App\Exception;

use Throwable;

class LogNotDeletableException extends LogAccessException
{
	public function __construct(string $filename, $code = 0, Throwable $previous = null)
	{
		parent::__construct("Log file $filename could not be removed, please check permissions.", $code, $previous);
	}
}
