<?php

namespace App\Exception;

class ZipArchiveNoFileException extends ZipArchiveException
{
}
