<?php

namespace App\Exception;

use RuntimeException;
use Throwable;

class LicenseInvalidException extends RuntimeException
{
	private $reason;
	private $versionId;

	public function __construct(string $message='License invalid or expired', $code = 403, ?string $reason = null, ?string $versionId = null, Throwable $previous = null)
	{
		parent::__construct($message, $code, $previous);
		$this->reason = $reason;
		$this->versionId = $versionId;
	}

	public function getReason(): ?string
	{
		return $this->reason;
	}

	public function getUpdateVersionId(): ?string
	{
		return $this->versionId;
	}
}
