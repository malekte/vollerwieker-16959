<?php

namespace App\Exception;

use RuntimeException;

class LogAccessException extends RuntimeException
{
}
