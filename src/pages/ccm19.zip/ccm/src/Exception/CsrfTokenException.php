<?php

namespace App\Exception;

use RuntimeException;

class CsrfTokenException extends RuntimeException
{}
