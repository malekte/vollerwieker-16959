<?php

namespace App\Exception;

use Throwable;

class ConfigNotReadableException extends ConfigAccessException
{
	public function __construct(string $filename, string $extra_message='', $code = 0, Throwable $previous = null)
	{
		$message = "Configuration file $filename could not be read, please check permissions.";
		if ($extra_message) {
			$message .= ' '.$extra_message;
		}
		parent::__construct($message, $code, $previous);
	}
}
