<?php

namespace App\Exception;

use RuntimeException;
use Throwable;

class ConfigNotWritableException extends ConfigAccessException
{
	public function __construct(string $filename, $code = 0, Throwable $previous = null)
	{
		parent::__construct("Configuration file $filename could not be written, check permissions and disk quota.", $code, $previous);
	}
}
