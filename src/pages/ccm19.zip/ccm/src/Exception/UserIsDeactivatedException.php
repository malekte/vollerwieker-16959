<?php

namespace App\Exception;

use RuntimeException;
use Throwable;

class UserIsDeactivatedException extends RuntimeException
{
	public function __construct(string $username, $code = 0, Throwable $previous = null)
	{
		parent::__construct('User is deactivated from logging into the system.', $code, $previous);
	}
}
