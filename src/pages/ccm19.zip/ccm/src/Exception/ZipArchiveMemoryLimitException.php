<?php

namespace App\Exception;

class ZipArchiveMemoryLimitException extends ZipArchiveException
{
}
