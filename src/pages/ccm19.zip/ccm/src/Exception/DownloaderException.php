<?php
namespace App\Exception;

use RuntimeException;

class DownloaderException extends RuntimeException
{}
