<?php

namespace App\Exception;

class ZipArchiveAccessException extends ZipArchiveException
{
}
