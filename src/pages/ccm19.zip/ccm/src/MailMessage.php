<?php

namespace App;

use App\Config;
use \Swift_Message;

/**
 * E-Mail-Nachricht
 */
class MailMessage extends Swift_Message
{

	/**
	 * @param ?string $subject Betreff
	 * @param ?string $body Inhalt
	 * @param ?string $contentType Content-Type
	 * @param ?string $charset Charset
	 * @phan-suppress PhanTypeMismatchArgument
	 *
	 * Wie Swift_Message, setzt aber automatisch den Absender.
	 */
	public function __construct($subject = null, $body = null, $contentType = null, $charset = null)
	{
		parent::__construct($subject, $body, $contentType, $charset);
		$config = Config::getInstance();
		$sender = $config->get('senderEmail');
		$senderName = $config->get('senderName', '');
		$replyTo = $config->get('replyTo');

		if (!$sender) {
			$sender = $config->get('email');
		}
		if ($senderName != '') {
			$sender = [$sender => $senderName];
		}

		$this->setFrom($sender);

		if ($replyTo) {
			$this->setReplyTo($replyTo);
		}

		$this->getHeaders()->addTextHeader('X-Face', 'C#x"pQhvrI4K*<4%v6[Lz[8[uDt0@Aju+SQcp|Htc`\%<kQgsm)p/78;pT*eQWjXV|$AU@]/Xe>P0|t|&@+hgqWhSpmR:+yG_uJUP(j/qTWfh*$aaGCxkA@MpZKp0M;9EyP?b`9u\'7"UW9#lMn)@#@ju#u');
	}

	/**
	 * @param string $html HTML
	 * @return string Plaintext
	 */
	public static function html2text(string $html): string
	{
		// HTML to Text
		$result = strtr($html, array("\r\n"=>' ', "\n"=>' ', "\r"=>' '));
		$result = preg_replace('/.*<body/i', "<body", $result);
		$result = preg_replace('/<br ?\/?'.'>/i', "$0\n", $result);
		$result = preg_replace('/<li.*?>/i', "- $0", $result);
		$result = preg_replace('/<\/(?:p|pre|div|h[1-6]|aside|article|section|main|address|nav|ul|ol|li|blockquote|form|tr|dd)>/i', "$0\n\n", $result);
		$result = preg_replace('/<script.*?<\/script>/i', "\n", $result);
		$result = preg_replace('/<a[^>]*?href="([^"]*)"[^>]*?>\s*<img.*?<\/a>/i', '', $result);
		$result = preg_replace('/<a[^>]*?href="([^"]*)"[^>]*?>(.*?)<\/a>/i', '$0: $1', $result);
		$result = preg_replace('/<style.*?<\/style>/i', "\n", $result);
		$result = preg_replace('/<\/(?:td|th|dt)>/i', "$0 ", $result);
		$result = strip_tags($result);
		$result = html_entity_decode($result, ENT_HTML5|ENT_COMPAT, 'UTF-8');
		// Leading Spaces auf jeder Zeile entfernen
		$result = preg_replace('/^[ \t]+/m', "", $result);
		// Trailing Spaces auf jeder Zeile entfernen
		$result = preg_replace('/[ \t]+$/m', "", $result);
		// Newlines zusammenziehen
		$result = preg_replace('/\n\n+/is', "\n\n", $result);
		return trim($result)."\n";
	}

	public function setVoidReplyTo(): void
	{
		$this->setReplyTo([]);
		$headers = $this->getHeaders();
		$headers->addTextHeader('Reply-To', '<>');
	}
}
