<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\Domain;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/domains/{_domainId}/declarationtable", name="app_declarationtable")
 */
class DeclarationTable extends DomainDependantController
{
	/**
	 * @Route("", methods={"GET", "HEAD"}, name="")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function index(Request $request, TranslatorInterface $translator): Response
	{

		return $this->render('declarationtable/index.html.twig', [
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("", methods={"POST"}, name="_post")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function formSubmit(Request $request, TranslatorInterface $translator): Response
	{
		$domain = Domain::activeDomain();
		assert($domain !== null);

		$domain->setConsentTablePrependIntroText($request->request->getBoolean('prependIntroText'));
		$domain->setConsentTablePrependConsentChangeLink($request->request->getBoolean('prependConsentChangeLink'));
		$domain->setConsentTableHeadingStartLevel($request->request->getInt('headingStartLevel', 3));

		try {
			CsrfToken::get()->checkRequest($request);
			$domain->save();

			$this->addFlash('success', $translator->trans('Settings have been saved successfully.'));
			return $this->redirectToRoute('app_declarationtable', [], 303);
		}
		catch (ConfigNotWritableException $exception) {
			$this->addFlash('danger', $translator->trans('Settings could not be saved.'));
		}
		catch (CsrfTokenException $exception) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
		}
		return $this->render('declarationtable/index.html.twig', [
			'csrfToken' => CsrfToken::get(),
		]);
	}
}
