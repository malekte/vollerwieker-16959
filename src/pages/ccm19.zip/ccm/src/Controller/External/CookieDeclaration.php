<?php

namespace App\Controller\External;

use App\Component\HttpFoundation\CssResponse;
use App\Component\HttpFoundation\JavascriptResponse;
use App\Component\LoggerInterface;
use App\Config;
use App\Controller\ExternalController;
use App\MailMessage;
use App\Model\Cookie;
use App\Model\Domain;
use App\Model\Embedding;
use App\Model\EmbeddingAsset;
use App\Model\Locale;
use App\Model\Purpose;
use App\Model\Theme;
use App\Model\User;
use App\Utils;
use Exception;
use Swift_Mailer;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use DateTime;

class CookieDeclaration extends ExternalController
{
	/** @var LoggerInterface $logger */
	private $logger;

	/**
	 * @param LoggerInterface $logger
	 * @param Swift_Mailer $mailer
	 */
	public function __construct(LoggerInterface $logger)
	{
		$this->logger = $logger;
	}

	/**
	 * @Route("/cookie-declaration", name="app_external_cookie_declaration", methods={"HEAD", "GET", "OPTIONS"})
	 * @param Request $request
	 * @return Response
	 */
	public function cookieDeclaration(Request $request): Response
	{
		/** @var Domain $domain */
		$domain = Domain::activeDomain();
		if ($domain == null) {
			return new JsonResponse(['error' => 'Active domain could not be determined.'], 500);
		}

		// Je nach Einstellung entweder auf Embedding-Implementierung wechseln oder mit Cookies fortfahren
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			return $this->cookieDeclaration_managementStructureEmbedding($request);
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JsonResponse(['error' => 'No theme set as active.'], 500);
		}

		$localeName = (string)$request->query->get('lang', '');
		$localeSpecified = strlen($localeName) > 0;

		if (!$localeName) {
			// Locale raten
			$localeName = (string)Utils::guessLocaleFromBrowser($request);
			// Vary-Header für Caching bearbeiten
		}

		/** @var Locale $locale */
		$locale = Locale::find((string)$localeName);
		if ($locale == null) {
			return new JsonResponse(['error' => 'Locale not found.'], 500);
		}

		// Nur aktive Cookies berücksichtigen
		$cookies = array_filter(Cookie::all(), function ($cookie) {
			/** @var Cookie $cookie */
			return $cookie->isActive();
		});

		// Purposes anhand selektierter Cookies ermitteln
		$purposes = array_reduce(
			$cookies,
			function ($purposes, $cookie) {
				/** @var Purpose $purpose */
				$purpose = $cookie->getPurpose();

				if ($purpose) {
					$purposes[$purpose->getId()] = $purpose;
				}

				return $purposes;
			},
			[]
		);

		// ORDER BY mandatory, name
		usort($purposes, function ($a, $b) {
			/**
			 * @var Purpose $a
			 * @var Purpose $b
			 */
			if ($a->isMandatory() xor $b->isMandatory()) {
				return $a->isMandatory() ? -1 : 1;
			}
			else {
				return strnatcasecmp($a->getName(), $b->getName());
			}
		});

		// Daten für das Template zusammenstellen
		$parameters = [
			'domain' => $domain,
			'theme' => $theme,
			'locale' => $locale,
			'locales' => Locale::enabledLocales(),
			'cookies' => $cookies,
			'purposes' => $purposes,
			'whitelabel' => Utils::hasWhitelabelLicense() && $theme->getWhitelabel(),
			'poweredByText' => Utils::getPoweredByText(),
			'poweredByTooltip' => Utils::getPoweredByTooltip(),
			'poweredByUrl' => Utils::getPoweredByUrl(),
			'h' => $domain->getHeadingStartLevel(),
		];

		$response = $this->render('external/cookiedeclaration/index.html.twig', $parameters);

		if (!$localeSpecified) {
			$vary = $response->getVary();
			$vary[] = 'Accept-Language';
			$response->setVary($vary);
		}

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		// Hier nicht text/html verwenden. Einige Proxies (z.B. in Mobilnetzen)
		// können sonst das unvollständige HTML "reparieren" und Werbung etc.
		// einbauen
		$response->headers->set('Content-Type', 'text/x-html-fragment; charset=utf-8');

		// Robots sollen das nicht crawlen
		$response->headers->set('X-Robots-Tag', 'noindex');

		// Letzten Zeitstempel einer möglichen CSS-Anpassung ermitteln
		$cssLastModifiedTimestamp = (int)max(
			filemtime(realpath(Utils::getBaseDir().'/templates/external/cookie-management.css.twig')),
			$theme->getLastModifiedTimestamp()
		);
		$response->headers->set('Link', '<'.$this->generateUrl('app_external_main_css_file', [
			'apiKey' => $request->query->get('apiKey'),
			'domain' => $request->query->get('domain'),
			'theme' => $theme->getId(),
			'v' => $cssLastModifiedTimestamp
		]).'>;rel="stylesheet"');


		$language = $locale->getLanguage();
		if ($language) {
			$response->headers->set('Content-Language', $language->getIsoCode());
		}

		return $response->setCache([
			'max_age'=>120,
			'public'=>true,
		]);
	}

	/**
	 * @param Request $request
	 * @return Response
	 */
	public function cookieDeclaration_managementStructureEmbedding(Request $request): Response
	{
		/** @var Domain $domain */
		$domain = Domain::activeDomain();
		if ($domain == null) {
			return new JsonResponse(['error' => 'Active domain could not be determined.'], 500);
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JsonResponse(['error' => 'No theme set as active.'], 500);
		}

		$localeName = (string)$request->query->get('lang', '');
		$localeSpecified = strlen($localeName) > 0;

		if (!$localeName) {
			// Locale raten
			$localeName = (string)Utils::guessLocaleFromBrowser($request);
			// Vary-Header für Caching bearbeiten
		}

		/** @var Locale $locale */
		$locale = Locale::find((string)$localeName);
		if ($locale == null) {
			return new JsonResponse(['error' => 'Locale not found.'], 500);
		}

		// Nur aktive Embeddings berücksichtigen
		$embeddings = array_filter(Embedding::all(), function (Embedding $embedding) {
			return $embedding->isActive();
		});

		// Purposes anhand selektierter Cookies ermitteln
		$purposes = array_reduce(
			$embeddings,
			function (array $purposes, Embedding $embedding) {
				/** @var Purpose $purpose */
				$purpose = $embedding->getPurpose();

				if ($purpose) {
					$purposes[$purpose->getId()] = $purpose;
				}

				return $purposes;
			},
			[]
		);

		// ORDER BY mandatory, name
		usort($purposes, function ($a, $b) {
			/**
			 * @var Purpose $a
			 * @var Purpose $b
			 */
			if ($a->isMandatory() xor $b->isMandatory()) {
				return $a->isMandatory() ? -1 : 1;
			}
			else {
				return strnatcasecmp($a->getName(), $b->getName());
			}
		});

		// Daten für das Template zusammenstellen
		$parameters = [
			'domain' => $domain,
			'theme' => $theme,
			'locale' => $locale,
			'locales' => Locale::enabledLocales(),
			'embeddings' => $embeddings,
			'purposes' => $purposes,
			'whitelabel' => Utils::hasWhitelabelLicense() && $theme->getWhitelabel(),
			'poweredByText' => Utils::getPoweredByText(),
			'poweredByTooltip' => Utils::getPoweredByTooltip(),
			'poweredByUrl' => Utils::getPoweredByUrl(),
			'h' => $domain->getConsentTableHeadingStartLevel(),
		];

		$response = $this->render('external/cookiedeclaration/index_using-embeddings.html.twig', $parameters);

		if (!$localeSpecified) {
			$vary = $response->getVary();
			$vary[] = 'Accept-Language';
			$response->setVary($vary);
		}

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		// Hier nicht text/html verwenden. Einige Proxies (z.B. in Mobilnetzen)
		// können sonst das unvollständige HTML "reparieren" und Werbung etc.
		// einbauen
		$response->headers->set('Content-Type', 'text/x-html-fragment; charset=utf-8');

		// Robots sollen das nicht crawlen
		$response->headers->set('X-Robots-Tag', 'noindex');

		// Letzten Zeitstempel einer möglichen CSS-Anpassung ermitteln
		$cssLastModifiedTimestamp = (int)max(
			filemtime(realpath(Utils::getBaseDir().'/templates/external/cookie-management.css.twig')),
			$theme->getLastModifiedTimestamp()
		);
		$response->headers->set('Link', '<'.$this->generateUrl('app_external_main_css_file', [
			'apiKey' => $request->query->get('apiKey'),
			'domain' => $request->query->get('domain'),
			'theme' => $theme->getId(),
			'v' => $cssLastModifiedTimestamp
		]).'>;rel="stylesheet"');

		$language = $locale->getLanguage();
		if ($language) {
			$response->headers->set('Content-Language', $language->getIsoCode());
		}

		return $response->setCache([
			'max_age'=>120,
			'public'=>true,
		]);

	}

}
