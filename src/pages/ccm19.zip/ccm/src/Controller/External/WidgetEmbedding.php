<?php

namespace App\Controller\External;

use App\Component\HttpFoundation\CssResponse;
use App\Component\HttpFoundation\JavascriptResponse;
use App\Component\LoggerInterface;
use App\Config;
use App\Controller\ExternalController;
use App\MailMessage;
use App\Model\AccessCountJournal;
use App\Model\Cookie;
use App\Model\Domain;
use App\Model\Embedding;
use App\Model\EmbeddingAsset;
use App\Model\FoundCookie;
use App\Model\FoundScript;
use App\Model\FoundObject;
use App\Model\FoundStorage;
use App\Model\GeoIp;
use App\Model\LegalText;
use App\Model\Locale;
use App\Model\Protocol;
use App\Model\Purpose;
use App\Model\Script;
use App\Model\Theme;
use App\Model\User;
use App\Utils;
use Exception;
use Swift_Mailer;
use Symfony\Component\Asset\Packages;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use DateTime;
use Twig\Environment;

class WidgetEmbedding extends ExternalController
{
	const SCRIPT_COUNT_LIMIT = 100;
	const FOUND_REPO_BYTES_LIMIT = 524288;

	private $EXCLUDE_LOCALSTORAGE = [
		'_piggy.*',
		'panel-positions_*',
		'jiraBaseUrl',
		't3-*',
		'ec_*_ec_details',
	];
	private $MERGE_LOCALSTORAGE = [
		'optimizely_data$$',
		'st_shares_',
		'at-lojson-cache-',
		'_at.hist.',
		'widget-settings-shopware-',
	];

	/** @var LoggerInterface $logger */
	private $logger;
	/** @var Swift_Mailer $mailer */
	private $mailer;

	/**
	 * @param LoggerInterface $logger
	 * @param Swift_Mailer $mailer
	 */
	public function __construct(LoggerInterface $logger, Swift_Mailer $mailer)
	{
		$this->logger = $logger;
		$this->mailer = $mailer;
	}

	/**
	 * @Route("/ccm19.js", name="app_external_main_javascript_file", methods={"HEAD", "GET", "OPTIONS"})
	 * @param Request $request
	 * @return JavascriptResponse
	 */
	public function mainJavascriptFile(Request $request, Packages $assetManager): JavascriptResponse
	{
		$config = Config::getInstance();

		$scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme().'://';
		$baseUrl = $scheme.$request->getHttpHost();
		$webPath = $request->getBasePath();

		$response = new JavascriptResponse();
		$response->headers->set('X-Robots-Tag', 'noindex, nofollow');

		// Verwende angeforderte Sprache, sofern vorhanden, andernfalls rate das Locale
		$localeName = (string)$request->query->get('lang', '');
		$localeSpecified = strlen($localeName) > 0;

		if (!$localeName) {
			// Locale raten
			$localeName = (string)Utils::guessLocaleFromBrowser($request);
			// Vary-Header für Caching bearbeiten
			$vary = $response->getVary();
			$vary[] = 'Accept-Language';
			$response->setVary($vary);
		}

		// Wenn ein nicht-existentes Locale angegeben wird, Fallback zu de_DE
		if (Locale::exists($localeName) == false) {
			$localeName = 'de_DE';
		}

		$locales = Locale::enabledLocales();
		$locale = Locale::find($localeName);

		// Im weiteren Verlauf unbenötigte Variablen aus dem Scope entfernen
		unset($localeName);

		if ($locale == null || $locale->isEnabled() == false) {
			// Wenn keine Sprache geladen und keine spezifische angefragt wurde, eine beliebige aktive Sprache wählen
			if ($localeSpecified == false && count($locales) > 0) {
				$locale = reset($locales);
			}
			else {
				$message = $locale ? "Translation '{$locale->getName()}' disabled" : 'Translation not found';
				return new JavascriptResponse('console.error(\'[CCM19] '.addcslashes($message, '\'').'\');');
			}
		}

		// Benutzer anhand des verwendeten API-Schlüssels ermitteln - siehe AuthenticationHandler
		$apiUser = User::loggedInUser();
		$domain = Domain::activeDomain();

		// Je nach Einstellung entweder auf Embedding-Implementierung wechseln oder mit Cookies fortfahren
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			return $this->mainJavascriptFile_managementStructureEmbedding($request, $assetManager);
		}

		$apiParams = [
			'apiKey' => $apiUser->getApiKey(),
			'domain' => $domain->getId(),
			'gen' => 1,
		];

		if (strlen(Utils::getLicenseKey()) < 10) {
			//aussteigen
			return new JavascriptResponse('console.error("[CCM19] Not licensed / Nicht lizensiert");');
		};

		// Anzahl der Aufrufe nach Tarif limitieren
		AccessCountJournal::byDomainAndKind($domain, 'call')->increment();
		if (Utils::isExtendedEdition()) {
			$this->sendQuotaReport($apiUser);

			if ($apiUser->callCountReached()) {
				return new JavascriptResponse('console.warn(\'[CCM19] Quota exceeded\');');
			}
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JavascriptResponse('console.error(\'[CCM19] No theme set as active.\');', 200);
		}

		// Nur aktive Cookies berücksichtigen
		$cookies = array_filter(Cookie::all(), function ($cookie) {
			/** @var Cookie $cookie */
			return $cookie->isActive();
		});

		$activeCookiesNames = array_values(array_map(function ($cookie) {
			/** @var Cookie $cookie */
			return $cookie->getHttpCookieName();
		}, $cookies));

		$widgetUrls = array_reduce($locales, function ($widgetUrls, $locale) use ($baseUrl, $apiParams) {
			$widgetUrls[$locale->getName()] = $baseUrl.$this->generateUrl('app_external_widget', $apiParams + ['lang' => $locale->getName()]);
			return $widgetUrls;
		}, []);

		if ($domain->isNewScriptsBlocked()) {
			$allowedScripts = array_values(array_map(function ($script) {
				return $script->getId();
			}, Script::byEnabled(true)));

			$deniedScripts = [];
		}
		else {
			$deniedScripts = array_values(array_map(function ($script) {
				return $script->getId();
			}, Script::byEnabled(false)));

			$allowedScripts = [];
		}

		// Letzten Zeitstempel einer möglichen CSS-Anpassung ermitteln
		$cssLastModifiedTimestamp = (int)max(
			filemtime(realpath(Utils::getBaseDir().'/templates/external/cookie-management.css.twig')),
			$theme->getLastModifiedTimestamp()
		);

		// Zu sperrende Scripte pro Zweck holen
		$blockPurposeScriptMarkers = [];
		foreach ($cookies as $cookie) {
			/** @var Cookie $cookie */
			$purpose = $cookie->getPurpose() ? $cookie->getPurpose()->getId() : null;
			$mandatory = $cookie->getPurpose() ? $cookie->getPurpose()->isMandatory() : true;

			if (!$mandatory) {
				if (!isset($blockPurposeScriptMarkers[$purpose])) {
					$blockPurposeScriptMarkers[$purpose] = $cookie->getCodeBlock();
				}
				else {
					$blockPurposeScriptMarkers[$purpose] = array_merge($blockPurposeScriptMarkers[$purpose], $cookie->getCodeBlock());
				}
			}
		}

		// GeoIP-Überprüfung, wenn aktiviert
		if ($theme->getOnlyInEu())
		{
			$geoip = GeoIp::find($request->getClientIp());
			$noConsentRequired = ($geoip and !$geoip->isInEu());
		}
		else {
			$noConsentRequired = false;
		}
		$behavior = [
			'respectDoNotTrack' => $theme->isComplyingDoNotTrack(),
			'noConsentRequired' => $noConsentRequired
		];

		// URLs für Javascript-Dateien, die im public-Verzeichnis zur Einbindung im Frontend liegen, vorbereiten
		$scriptAssets = array_map(
			function ($asset) use ($assetManager, $baseUrl) {
				$timestamp = (int)filemtime(realpath(Utils::getBaseDir().'/public/'.$asset));
				return $baseUrl.$assetManager->getUrl($asset).'?'.http_build_query(['v' => $timestamp]);
			}, [
				'js/frontend/ccm19.component.tcf-v2.0.js',
			]
		);

		$parameters = [
			'domain' => Domain::activeDomain(),
			'uniqueCookieId' => Utils::generateUniqueCookieId(),
			'theme' => $theme,
			'scripts' => $scriptAssets,
			'styles' => [
				$baseUrl.$this->generateUrl('app_external_main_css_file', $apiParams + [
					'theme' => $theme->getId(),
					'v' => $cssLastModifiedTimestamp,
				]),
			],
			'widgetUrls' => $widgetUrls,
			'statisticsUrl' => $baseUrl.$this->generateUrl('app_external_statistics_consent', $apiParams),
			'consentValidateUrl' => $baseUrl.$this->generateUrl('app_external_statistics_consent_validate', $apiParams),
			'pageCheckUrl' => $baseUrl.$this->generateUrl('app_external_page_check_report', $apiParams),
			'cookieDeclarationUrl' => $baseUrl.$this->generateUrl('app_external_cookie_declaration', $apiParams),
			'contentBlockedUrl' =>
				$baseUrl.$this->generateUrl('app_external_x_content_blocked', $apiParams + [
					'lang' => $locale->getName(),
				]),
			'cronUrl' => $baseUrl.$this->generateUrl('app_cron', $apiParams),
			'locale' => $locale,
			'ccmOrigin' => $baseUrl,
			'cookieDataActive' => $activeCookiesNames,
			'allowedScripts' => $allowedScripts,
			'deniedScripts' => $deniedScripts,
			'blockPurposeScriptMarkers' => $blockPurposeScriptMarkers,
			'behavior' => $behavior,
			'isWidgetPreview' => $request->query->get('preview') == 'true',
		];

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		$response = $this->render('external/cookie-management.js.twig', $parameters, $response)->setCache([
			'max_age'=>0,
			'private'=>true,
		]);
		foreach ($parameters['styles'] as $styleUrl) {
			$response->headers->set('Link', sprintf('<%s>; rel="preload";as="style";nopush', substr($styleUrl, strlen($baseUrl))), false);
		}
		foreach ($scriptAssets as $scriptUrl) {
			$response->headers->set('Link', sprintf('<%s>; rel="preload";as="script";nopush', substr($scriptUrl, strlen($baseUrl))), false);
		}
		return $response;
	}

	/**
	 * @param Request $request
	 * @return JavascriptResponse
	 */
	public function mainJavascriptFile_managementStructureEmbedding(Request $request, Packages $assetManager): JavascriptResponse
	{
		$config = Config::getInstance();

		$scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme().'://';
		$baseUrl = $scheme.$request->getHttpHost();
		$webPath = $request->getBasePath();

		$response = new JavascriptResponse();
		$response->headers->set('X-Robots-Tag', 'noindex, nofollow');

		// Verwende angeforderte Sprache, sofern vorhanden, andernfalls rate das Locale
		$localeName = (string)$request->query->get('lang', '');
		$localeSpecified = strlen($localeName) > 0;

		if (!$localeName) {
			// Locale raten
			$localeName = (string)Utils::guessLocaleFromBrowser($request);
			// Vary-Header für Caching bearbeiten
			$vary = $response->getVary();
			$vary[] = 'Accept-Language';
			$response->setVary($vary);
		}

		// Wenn ein nicht-existentes Locale angegeben wird, Fallback zu de_DE
		if (Locale::exists($localeName) == false) {
			$localeName = 'de_DE';
		}

		$locales = Locale::enabledLocales();
		$locale = Locale::find($localeName);

		// Im weiteren Verlauf unbenötigte Variablen aus dem Scope entfernen
		unset($localeName);

		if ($locale == null || $locale->isEnabled() == false) {
			// Wenn keine Sprache geladen und keine spezifische angefragt wurde, eine beliebige aktive Sprache wählen
			if ($localeSpecified == false && count($locales) > 0) {
				$locale = reset($locales);
			}
			else {
				$message = $locale ? "Translation '{$locale->getName()}' disabled" : 'Translation not found';
				return new JavascriptResponse('console.error(\'[CCM19] '.addcslashes($message, '\'').'\');');
			}
		}

		// Benutzer anhand des verwendeten API-Schlüssels ermitteln - siehe AuthenticationHandler
		$apiUser = User::loggedInUser();
		$domain = Domain::activeDomain();

		$apiParams = [
			'apiKey' => $apiUser->getApiKey(),
			'domain' => $domain->getId(),
			'gen' => 2,
		];

		if (strlen(Utils::getLicenseKey()) < 10) {
			//aussteigen
			return new JavascriptResponse('console.error("[CCM19] Not licensed / Nicht lizensiert");');
		};

		// Anzahl der Aufrufe nach Tarif limitieren
		if (Utils::isExtendedEdition()) {
			$domain->beginWrite();
			$apiUser
				->resetCallCountForNextMonth()
				->incrementCallCount()
				->save();

			$this->sendQuotaReport($apiUser);

			if ($apiUser->callCountReached()) {
				return new JavascriptResponse('console.warn(\'[CCM19] Quota exceeded\');');
			}
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JavascriptResponse('console.error(\'[CCM19] No theme set as active.\');', 200);
		}

		// Nur aktive Embeddings berücksichtigen
		$embeddings = array_filter(Embedding::all(), function (Embedding $embedding) {
			return $embedding->isActive();
		});

		// Dieses Array wird JSON-kodiert im Template ausgegeben, um den Zugriff über Javascript zu erleichtern
		$embeddingRepository = array_map(function (Embedding $embedding) {
			$purposeId = $embedding->getPurpose() ? $embedding->getPurpose()->getId() : null;
			$mandatory = $embedding->getPurpose() ? $embedding->getPurpose()->isMandatory() : true;

			return [
				'id' => $embedding->getId(),
				'name' => $embedding->getName(),
				'code' => $embedding->getCodeSnippet(),
				'purpose' => $purposeId,
				'mandatory' => $mandatory,
				'assets' => array_map(function (EmbeddingAsset $asset) { return [
					'id' => $asset->getId(),
					'name' => $asset->getName(),
					'type' => $asset->getStorageType(),
					'glob' => $asset->isDynamic(),
					'lifetime' => $asset->getLifetime(),
					'hours' => $asset->getLifetimeHours(),
				]; }, $embedding->getAssets()),
			];
		}, $embeddings);

		$widgetUrls = array_reduce($locales, function ($widgetUrls, $locale) use ($baseUrl, $apiParams) {
			$widgetUrls[$locale->getName()] = $baseUrl.$this->generateUrl('app_external_widget', $apiParams + ['lang' => $locale->getName()]);
			return $widgetUrls;
		}, []);

		if ($domain->isNewScriptsBlocked()) {
			$allowedScripts = array_values(array_map(function ($script) {
				return $script->getId();
			}, Script::byEnabled(true)));

			$deniedScripts = [];
		}
		else {
			$deniedScripts = array_values(array_map(function ($script) {
				return $script->getId();
			}, Script::byEnabled(false)));

			$allowedScripts = [];
		}

		// Letzten Zeitstempel einer möglichen CSS-Anpassung ermitteln
		$cssLastModifiedTimestamp = (int)max(
			filemtime(realpath(Utils::getBaseDir().'/templates/external/cookie-management.css.twig')),
			$theme->getLastModifiedTimestamp()
		);

		// Sammle zu sperrende Skripte pro Embedding
		$blockEmbeddingScriptMarkers = [];
		foreach ($embeddings as $embedding) {
			/** @var Embedding $embedding */
			$mandatory = $embedding->getPurpose() ? $embedding->getPurpose()->isMandatory() : true;

			if (!$mandatory) {
				$blockEmbeddingScriptMarkers[$embedding->getId()] = array_merge(
					$blockEmbeddingScriptMarkers[$embedding->getId()] ?? [],
					$embedding->getCodeBlock()
				);
			}
		}

		// GeoIP-Überprüfung, wenn aktiviert
		if ($theme->getOnlyInEu())
		{
			$geoip = GeoIp::find($request->getClientIp());
			$noConsentRequired = ($geoip and !$geoip->isInEu());
		}
		else {
			$noConsentRequired = false;
		}
		$behavior = [
			'respectDoNotTrack' => $theme->isComplyingDoNotTrack(),
			'noConsentRequired' => $noConsentRequired
		];

		// URLs für Javascript-Dateien, die im public-Verzeichnis zur Einbindung im Frontend liegen, vorbereiten
		$scriptAssets = array_map(
			function ($asset) use ($assetManager, $baseUrl) {
				$timestamp = (int)filemtime(realpath(Utils::getBaseDir().'/public/'.$asset));
				return $baseUrl.$assetManager->getUrl($asset).'?'.http_build_query(['v' => $timestamp]);
			}, [
				'js/frontend/ccm19.component.tcf-v2.0.js',
			]
		);

		$parameters = [
			'domain' => Domain::activeDomain(),
			'uniqueCookieId' => Utils::generateUniqueCookieId(),
			'theme' => $theme,
			'embeddingRepository' => $embeddingRepository,
			'scripts' => $scriptAssets,
			'styles' => [
				$baseUrl.$this->generateUrl('app_external_main_css_file', $apiParams + [
					'theme' => $theme->getId(),
					'v' => $cssLastModifiedTimestamp,
				]),
			],
			'widgetUrls' => $widgetUrls,
			'statisticsUrl' => $baseUrl.$this->generateUrl('app_external_statistics_consent', $apiParams),
			'consentValidateUrl' => $baseUrl.$this->generateUrl('app_external_statistics_consent_validate', $apiParams),
			'pageCheckUrl' => $baseUrl.$this->generateUrl('app_external_page_check_report', $apiParams),
			'cookieDeclarationUrl' => $baseUrl.$this->generateUrl('app_external_cookie_declaration', $apiParams),
			'contentBlockedUrl' =>
				$baseUrl.$this->generateUrl('app_external_x_content_blocked', $apiParams + [
					'lang' => $locale->getName(),
					'v' => $theme->getLastModifiedTimestamp(),
				]),
			'cronUrl' => $baseUrl.$this->generateUrl('app_cron', $apiParams),
			'locale' => $locale,
			'ccmOrigin' => $baseUrl,
			'allowedScripts' => $allowedScripts,
			'deniedScripts' => $deniedScripts,
			'blockEmbeddingScriptMarkers' => $blockEmbeddingScriptMarkers,
			'behavior' => $behavior,
			'isWidgetPreview' => $request->query->get('preview') == 'true',
		];

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		$response = $this->render('external/cookie-management_using-embeddings.js.twig', $parameters, $response)->setCache([
			'max_age'=>0,
			'private'=>true,
		]);

		foreach ($parameters['styles'] as $styleUrl) {
			$response->headers->set('Link', sprintf('<%s>;rel="preload";as="style";nopush', substr($styleUrl, strlen($baseUrl))), false);
		}
		foreach ($scriptAssets as $scriptUrl) {
			$response->headers->set('Link', sprintf('<%s>;rel="preload";as="script";nopush', substr($scriptUrl, strlen($baseUrl))), false);
		}

		return $response;
	}

	/**
	 * @Route("/ccm19.css", name="app_external_main_css_file", methods={"HEAD", "GET", "OPTIONS"})
	 * @return CssResponse
	 */
	public function mainCssFile(): CssResponse
	{
		$response = new CssResponse();

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		// Lebensdauer der CSS-Datei auf ein Jahr setzen, da ein Zeitstempel an die CSS-Route angehängt wird
		$response->headers->remove('Cache-Control');
		$response->setCache([
			'max_age' => 31536000,
			'immutable' => true,
			'public' => true,
		]);

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new CssResponse('/* No theme set as active. */', 500);
		}

		$parameters = [
			'theme' => $theme,
			'breakpoints' => [
				'mobileMax' => '40em',
				'tabletMax' => '64em',
				'desktop' => '64.0625em',
			],
		];

		return $this->render('external/cookie-management.css.twig', $parameters, $response);
	}

	/**
	 * @Route("/widget", name="app_external_widget", methods={"HEAD", "GET", "OPTIONS"})
	 * @param Request $request
	 * @return Response
	 */
	public function widget(Request $request): Response
	{
		/** @var Domain $domain */
		$domain = Domain::activeDomain();
		if ($domain == null) {
			return new JsonResponse(['error' => 'Active domain could not be determined.'], 500);
		}

		// Je nach Einstellung entweder auf Embedding-Implementierung wechseln oder mit Cookies fortfahren
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			return $this->widget_managementStructureEmbedding($request);
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JsonResponse(['error' => 'No theme set as active.'], 500);
		}

		/** @var Locale $locale */
		$locale = Locale::find((string)$request->query->get('lang'));
		if ($locale == null) {
			return new JsonResponse(['error' => 'Locale not found.'], 500);
		}

		/** @var LegalText $legalText */
		$legalText = LegalText::byLocale($locale);
		if ($legalText == null) {
			return new JsonResponse(['error' => 'Legal texts aren\'t translated.'], 500);
		}

		if ($request->headers->get('X-CCM19State') == 'new-view') {
			AccessCountJournal::byDomainAndKind($domain, 'view')->increment();
		}

		// Nur aktive Cookies berücksichtigen
		$cookies = array_filter(Cookie::all(), function ($cookie) {
			/** @var Cookie $cookie */
			return $cookie->isActive();
		});

		// Purposes anhand selektierter Cookies ermitteln
		$purposes = array_reduce(
			$cookies,
			function ($purposes, $cookie) {
				/** @var Purpose $purpose */
				$purpose = $cookie->getPurpose();

				if ($purpose) {
					$purposes[$purpose->getId()] = $purpose;
				}

				return $purposes;
			},
			[]
		);

		// ORDER BY mandatory, name
		usort($purposes, function ($a, $b) {
			/**
			 * @var Purpose $a
			 * @var Purpose $b
			 */
			if ($a->isMandatory() xor $b->isMandatory()) {
				return $a->isMandatory() ? -1 : 1;
			}
			else {
				return strnatcasecmp($a->getName(), $b->getName());
			}
		});

		// Dieses Array wird JSON-kodiert im Template ausgegeben, um den Zugriff über Javascript zu erleichtern
		$scriptRepository = array_map(function ($cookie) {
			/** @var Cookie $cookie */
			$purpose = $cookie->getPurpose() ? $cookie->getPurpose()->getId() : null;
			$mandatory = $cookie->getPurpose() ? $cookie->getPurpose()->getId() : null;

			return [
				'name' => $cookie->getHttpCookieName(),
				'code' => $cookie->getCodeSnippet(),
				'purpose' => $cookie->getPurpose()->getId(),
				'mandatory' => $cookie->getPurpose()->isMandatory(),
			];
		}, $cookies);

		$baseUrl = $request->getScheme().'://'.$request->getHttpHost();

		// Daten für das Template zusammenstellen
		$parameters = [
			'baseUrl' => $baseUrl,
			'domain' => $domain,
			'theme' => $theme,
			'locale' => $locale,
			'locales' => Locale::enabledLocales(),
			'legalText' => $legalText,
			'cookies' => $cookies,
			'purposes' => $purposes,
			'scriptRepository' => $scriptRepository,
			'whitelabel' => Utils::hasWhitelabelLicense() && $theme->getWhitelabel(),
			'poweredByText' => Utils::getPoweredByText(),
			'poweredByTooltip' => Utils::getPoweredByTooltip(),
			'poweredByUrl' => Utils::getPoweredByUrl(),
		];

		$response = $this->render('external/widget/index.html.twig', $parameters);

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		// Hier nicht text/html verwenden. Einige Proxies (z.B. in Mobilnetzen)
		// können sonst das unvollständige HTML "reparieren" und Werbung etc.
		// einbauen
		$response->headers->set('Content-Type', 'text/x-html-fragment; charset=utf-8');

		// Robots sollen das Widget nicht crawlen
		$response->headers->set('X-Robots-Tag', 'noindex');

		$language = $locale->getLanguage();
		if ($language) {
			$response->headers->set('Content-Language', $language->getIsoCode());
		}

		return $response->setCache([
			'max_age'=>120,
			'private'=>true,
		]);
	}

	/**
	 * @param Request $request
	 * @return Response
	 */
	public function widget_managementStructureEmbedding(Request $request): Response
	{
		/** @var Domain $domain */
		$domain = Domain::activeDomain();
		if ($domain == null) {
			return new JsonResponse(['error' => 'Active domain could not be determined.'], 500);
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JsonResponse(['error' => 'No theme set as active.'], 500);
		}

		/** @var Locale $locale */
		$locale = Locale::find((string)$request->query->get('lang'));
		if ($locale == null) {
			return new JsonResponse(['error' => 'Locale not found.'], 500);
		}

		/** @var LegalText $legalText */
		$legalText = LegalText::byLocale($locale);
		if ($legalText == null) {
			return new JsonResponse(['error' => 'Legal texts aren\'t translated.'], 500);
		}

		if ($request->headers->get('X-CCM19State') == 'new-view') {
			AccessCountJournal::byDomainAndKind($domain, 'view')->increment();
		}

		// Nur aktive Embeddings berücksichtigen
		$embeddings = array_filter(Embedding::all(), function (Embedding $embedding) {
			return $embedding->isActive();
		});

		// Purposes anhand selektierter Cookies ermitteln
		$purposes = array_reduce(
			$embeddings,
			function (array $purposes, Embedding $embedding) {
				/** @var Purpose $purpose */
				$purpose = $embedding->getPurpose();

				if ($purpose) {
					$purposes[$purpose->getId()] = $purpose;
				}

				return $purposes;
			},
			[]
		);

		// ORDER BY mandatory, name
		usort($purposes, function ($a, $b) {
			/**
			 * @var Purpose $a
			 * @var Purpose $b
			 */
			if ($a->isMandatory() xor $b->isMandatory()) {
				return $a->isMandatory() ? -1 : 1;
			}
			else {
				return strnatcasecmp($a->getName(), $b->getName());
			}
		});

		$baseUrl = $request->getScheme().'://'.$request->getHttpHost();

		// Daten für das Template zusammenstellen
		$parameters = [
			'baseUrl' => $baseUrl,
			'domain' => $domain,
			'theme' => $theme,
			'locale' => $locale,
			'locales' => Locale::enabledLocales(),
			'legalText' => $legalText,
			'embeddings' => $embeddings,
			'purposes' => $purposes,
			'whitelabel' => Utils::hasWhitelabelLicense() && $theme->getWhitelabel(),
			'poweredByText' => Utils::getPoweredByText(),
			'poweredByTooltip' => Utils::getPoweredByTooltip(),
			'poweredByUrl' => Utils::getPoweredByUrl(),
		];

		$response = $this->render('external/widget/index_using-embeddings.html.twig', $parameters);

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		// Hier nicht text/html verwenden. Einige Proxies (z.B. in Mobilnetzen)
		// können sonst das unvollständige HTML "reparieren" und Werbung etc.
		// einbauen
		$response->headers->set('Content-Type', 'text/x-html-fragment; charset=utf-8');

		// Robots sollen das Widget nicht crawlen
		$response->headers->set('X-Robots-Tag', 'noindex');

		$language = $locale->getLanguage();
		if ($language) {
			$response->headers->set('Content-Language', $language->getIsoCode());
		}

		return $response->setCache([
			'max_age'=>120,
			'private'=>true,
		]);
	}

	/**
	 * @Route("/page_check/report", name="app_external_page_check_report", methods={"OPTIONS", "POST"})
	 * @param Request $request
	 * @return JsonResponse
	 * @phan-suppress PhanUndeclaredProperty
	 */
	public function pageCheckReport(Request $request): JsonResponse
	{
		$now = new DateTime('now');
		$domain = Domain::activeDomain();

		if (Utils::decodeJsonRequest($request, $data, false, 5) == false) {
			/** @var JsonResponse $data ($data ist im Fehlerfall eine Fehlermeldung) */
			assert($data instanceof JsonResponse);
			return $data;
		}

		try {
			if (isset($data->url) and is_string($data->url)) {
				$pageUrl = preg_replace('/#[^#]*$/', '', $data->url);
			} else {
				return $this->json(['success'=>false, 'message'=>'invalid data: url missing'], 400);
			}

			// Cookies verarbeiten
			if (isset($data->c) and is_array($data->c)) {
				foreach ($data->c as $cookie) {
					if (is_string($cookie)) {

						if (FoundCookie::exists($cookie)) {
							$item = FoundCookie::find($cookie);
						}
						// Nur neue Einträge speichern, wenn Dateigrößenlimit noch nicht erreicht
						elseif (FoundCookie::persistedRepositorySize() <= self::FOUND_REPO_BYTES_LIMIT) {
							$item = FoundCookie::create($cookie);
						}
						else {
							$item = null;
						}

						if ($item) {
							$item->setLastSeenOn($now);
							if (count($item->getFoundOnPages()) < 10) {
								$item->addFoundOnPage($pageUrl);
							}
						}

					}
				}
				FoundCookie::flush();
			}

			// Skripte verarbeiten
			if (isset($data->s) and is_array($data->s)) {
				foreach ($data->s as $script) {
					if (is_string($script)) {
						// Parameter und Fragment aus URL entfernen
						$script = preg_replace('/#[^#]*$/', '', $script);
						$script = preg_replace('/\?[^?]*$/', '?', $script);
						// Weitere Pfad-Parameter entfernen
						$script = preg_replace('%/(intl/|releases/|viewthroughconversion/|www-widgetapi-)[^/]+/%', '/\1…/', $script);
						// Ergebnis speichern
						if (preg_match('%^(?:https:|http:|ftp:)?//%', $script)) {

							if (FoundScript::exists($script)) {
								$item = FoundScript::find($script);
							}
							// Nur neue Einträge speichern, wenn Dateigrößenlimit noch nicht erreicht
							elseif (FoundScript::persistedRepositorySize() <= self::FOUND_REPO_BYTES_LIMIT) {
								$item = FoundScript::create($script);
							}
							else {
								$item = null;
							}

							if ($item) {
								$item->setLastSeenOn($now);
								if (count($item->getFoundOnPages()) < 10) {
									$item->addFoundOnPage($pageUrl);
								}
							}

						}
					}
				}
				FoundScript::flush();
			}

			// Objekte/IFrames verarbeiten
			if (isset($data->o) and is_array($data->o)) {
				foreach ($data->o as $object) {
					if (is_string($object)) {
						// Parameter und Fragment aus URL entfernen
						$object = preg_replace('/#[^#]*$/', '', $object);
						$object = preg_replace('/\?[^?]*$/', '?', $object);
						// URL weiter bereinigen (Sonderfall Google SafeFrame)
						$object = preg_replace('/\/\/[0-9a-f]{16,}\.safeframe\./', '//….safeframe.', $object);

						if (preg_match('%^(?:https:|http:|ftp:)?//%', $object)) {

							if (FoundObject::exists($object)) {
								$item = FoundObject::find($object);
							}
							// Nur neue Einträge speichern, wenn Dateigrößenlimit noch nicht erreicht
							elseif (FoundObject::persistedRepositorySize() <= self::FOUND_REPO_BYTES_LIMIT) {
								$item = FoundObject::create($object);
							}
							else {
								$item = null;
							}

							if ($item) {
								$item->setLastSeenOn($now);
								if (count($item->getFoundOnPages()) < 10) {
									$item->addFoundOnPage($pageUrl);
								}
							}

						}
					}
				}
				FoundObject::flush();
			}

			// LocalStorage verarbeiten
			if (isset($data->ls) and is_array($data->ls)) {
				foreach ($data->ls as $object) {
					if (is_string($object)) {
						$drop = false;
						foreach ($this->EXCLUDE_LOCALSTORAGE as $pattern) {
							if (fnmatch($pattern, $object)) {
								$drop = true;
								break;
							}
						}
						if ($drop) {
							continue;
						}
						foreach ($this->MERGE_LOCALSTORAGE as $prefix) {
							if (strpos($object, $prefix) === 0) {
								$object = $prefix.'…';
							}
						}

						if (FoundStorage::exists($object)) {
							$item = FoundStorage::find($object);
						}
						// Nur neue Einträge speichern, wenn Dateigrößenlimit noch nicht erreicht
						elseif (FoundStorage::persistedRepositorySize() <= self::FOUND_REPO_BYTES_LIMIT) {
							$item = FoundStorage::create($object);
						}
						else {
							$item = null;
						}

						if ($item) {
							$item->setLastSeenOn($now)->setIsSessionStorage(false);
							if (count($item->getFoundOnPages()) < 10) {
								$item->addFoundOnPage($pageUrl);
							}
						}
					}
				}
				FoundStorage::flush();
			}

			// SessionStorage verarbeiten
			if (isset($data->ss) and is_array($data->ss)) {
				foreach ($data->ss as $object) {
					if (is_string($object)) {
						$drop = false;
						foreach ($this->EXCLUDE_LOCALSTORAGE as $pattern) {
							if (fnmatch($pattern, $object)) {
								$drop = true;
								break;
							}
						}
						if ($drop) {
							continue;
						}
						foreach ($this->MERGE_LOCALSTORAGE as $prefix) {
							if (strpos($object, $prefix) === 0) {
								$object = $prefix.'…';
							}
						}

						if (FoundStorage::exists($object)) {
							$item = FoundStorage::find($object);
						}
						// Nur neue Einträge speichern, wenn Dateigrößenlimit noch nicht erreicht
						elseif (FoundStorage::persistedRepositorySize() <= self::FOUND_REPO_BYTES_LIMIT) {
							$item = FoundStorage::create($object);
						}
						else {
							$item = null;
						}

						if ($item) {
							$item->setLastSeenOn($now)->setIsSessionStorage(true);
							if (count($item->getFoundOnPages()) < 10) {
								$item->addFoundOnPage($pageUrl);
							}
						}
					}
				}
				FoundStorage::flush();
			}

			// Blockierbare Scripte verarbeiten
			if (isset($data->as) and is_object($data->as)) {
				$added = false;
				$enable = !($domain->isNewScriptsBlocked());
				foreach ((array)$data->as as $key => $script) {
					$code = null;
					if (is_string($script)) {
						$code = $script;
						$cookies = [];
					}
					elseif (is_object($script)) {
						$code = $script->s;
						$cookies = (array)$script->c;
					}
					else {
						continue;
					}
					if ($code && Script::count() < self::SCRIPT_COUNT_LIMIT) {
						if (preg_match('%^<script\b%i', $code)) {
							$script = Script::find($key);
							if (!$script) {
								$added = true;
								$script = Script::create($key)->setContent($code)->addCookies($cookies)->setEnableScript($enable)->addFoundOnPage($pageUrl);
							}
							elseif ($cookies) {
								$new_cookies = array_diff($cookies, $script->getCookies());
								if ($new_cookies) {
									$script->addCookies($new_cookies);
									$added = true;
								}
							}
						}
					}
				}
				if ($added) {
					Script::flush();
				}
			}

		}
		catch (Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		$response = $this->json(['success'=>true]);

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		$response->setCache([
			'max_age'=>30,
			'private'=>true,
		]);

		return $response;
	}

	/**
	 * Diese Methode benachrichtigt einen Benutzer über den Stand des Aufruflimits, sofern eine bestimmte
	 * Grenze überschritten wurde.
	 * @param User $user
	 */
	private function sendQuotaReport(User $user): void
	{
		$callCount = $user->getActualCallCount();
		$callMaxCount = $user->getMaxCallCount();

		//print_r($callMaxCount);exit();

        // Wenn die Anzahl der Widgetausgabe nicht limitiert ist, sofort raus
		if ($callMaxCount == -1) {
			return;
		}

		$quota = $callMaxCount > 0
			? min((int)floor($callCount / $callMaxCount * 100), 100)
			: 100;

		$matchedQuota = array_reduce(range(90, 100, 2), function ($match, $item) use ($quota) {
			return $item <= $quota && $item > $match ? $item : $match;
		});



		// Wenn eine bestimmte Grenze noch nicht erreicht ist, keine Benachritigung verschicken
		if ($matchedQuota <= $user->getLastCallReportQuota()) {
			return;
		}

		/** @var Environment $twig */
		$twig = $this->container->get('twig');

		$config 	= Config::getInstance();

		if ($matchedQuota < 100)
		{
			$subject  	= $config->get('sub_max_traffic_email_betreff');
			$body  		= $config->get('sub_max_traffic_email_content');
		}
		else
		{
			$subject  	= $config->get('max_traffic_email_betreff');
			$body  		= $config->get('max_traffic_email_content');
		}

		if (!empty($body) && !empty($subject))
		{
			$body = str_ireplace('{{ quota }}', (string)$matchedQuota, $body);
			//$callMaxCount
			$body = str_ireplace('{{ callMaxCount }}', (string)$callMaxCount, $body);
		}
		else{
			$subject = $matchedQuota.'% of your quota exceeded';
			$body = $twig->render('emails/quota_exceeded.txt.twig', [
				'quota' => $matchedQuota,
			]);
		}

		$addr = $user->getEmailAddress();
		if (!$addr) {
			$addr = $user->getUsername();
		}

		$mail = new MailMessage($subject, $body, 'text/plain');

		try {
			$mail->setTo($addr);
			$sender = array_keys($mail->getFrom())[0];

			// BCC setzen wenn Kopie-Funktion aktiviert
			if ($config->get('sendQuotaCopies')) {
				$mail->setBcc($config->get('email'));
			}

			$this->mailer->send($mail);

            // Loggen
			$this->logger->logInfo("QuotaReport", "QuotaReport an ".$addr." - ".$subject." - Von: ".$sender);
		} catch (Exception $exception) {
			$this->logger->logWarning('QuotaReport', 'Could not send email. '.$exception->getMessage());
		}

		$user->setLastCallReportQuota($matchedQuota)->save();
	}

	/**
	 * @Route("/page_check/report", name="app_external_page_check_report_get", methods={"HEAD", "GET"})
	 * @param Request $request
	 * @return JsonResponse
	 *
	 * Dummy-Methode: Vermeidet Exceptions bei GET auf die Report-Route
	 */
	public function pageCheckReportGet(Request $request): JsonResponse
	{
		return $this->json(['error'=>'GET not allowed for this action']);
	}
}
