<?php

namespace App\Controller\External;

use App\Controller\ExternalController;
use App\Model\Cookie;
use App\Model\Domain;
use App\Model\Embedding;
use App\Model\Protocol;
use App\Model\Purpose;
use App\Model\Theme;
use App\Utils;
use RuntimeException;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

class Statistics extends ExternalController
{
	/**
	 * @Route("/statistics/consent", name="app_external_statistics_consent", methods={"OPTIONS", "POST"})
	 * @return JsonResponse
	 */
	public function logConsentUpdate(Request $request): JsonResponse
	{
		if (Utils::decodeJsonRequest($request, $data) == false) {
			/** @var JsonResponse $data */
			assert($data instanceof JsonResponse);
			return $data;
		}

		$uniqueCookieId = (string)($data['ucid'] ?? '');
		if (Utils::validateUniqueCookieId($uniqueCookieId) == false) {
			return new JsonResponse(['error' => 'ucid is invalid'], 400);
		}

		/** @var Purpose[] $purposes */
		$purposes = array_values(array_map(
			function ($purposeId) {
				return Purpose::find((string)$purposeId);
			},
			array_filter((array)($data['purposes'] ?? []), function ($purposeId) {
				return Purpose::exists((string)$purposeId);
			})
		));

		/** @var Cookie[] $cookies */
		$cookies = array_values(array_reduce($purposes, function ($cookies, $purpose) {
			/** @var Purpose $purpose */
			return array_merge($cookies, Cookie::byPurpose($purpose));
		}, []));

		/** @var Theme $theme */
		$theme = Theme::activeTheme();

		$logData = [
			'consent' => (bool)($data['consent'] ?? false),
			'ucid' => $uniqueCookieId,
			'timestamp' => time(),
			'purposes' => array_map(function ($purpose) {
				/** @var Purpose $purpose */
				return $purpose->getId();
			}, $purposes),
			'cookies' => array_map(function ($cookie) {
				/** @var Cookie $cookie */
				return $cookie->getId();
			}, $cookies),
			'manipulationPrevention' => ($theme ? $theme->getManipulationPrevention() : null),
		];

		// Domain über Benutzer anhand des verwendeten API-Schlüssels ermitteln - siehe AuthenticationHandler
		$domain = Domain::activeDomain();

		// Je nach Einstellung entweder auf Embedding-Implementierung wechseln oder fortfahren
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			return $this->logConsentUpdate_managementStructureEmbedding($request);
		}

		try {
			if ($domain) {
				Protocol::byDomain($domain)->append($logData);
			}
		}
		catch (RuntimeException $exception) {}

		return new JsonResponse(['success' => true]);
	}

	/**
	 * @param Request $request
	 * @return JsonResponse
	 */
	public function logConsentUpdate_managementStructureEmbedding(Request $request): JsonResponse
	{
		if (Utils::decodeJsonRequest($request, $data) == false) {
			/** @var JsonResponse $data */
			assert($data instanceof JsonResponse);
			return $data;
		}

		$uniqueCookieId = (string)($data['ucid'] ?? '');
		if (Utils::validateUniqueCookieId($uniqueCookieId) == false) {
			return new JsonResponse(['error' => 'ucid is invalid'], 400);
		}

		/** @var Purpose[] $purposes */
		$purposes = array_values(array_map(
			function ($purposeId) {
				return Purpose::find((string)$purposeId);
			},
			array_filter((array)($data['purposes'] ?? []), function ($purposeId) {
				return Purpose::exists((string)$purposeId);
			})
		));

		/** @var Embedding[] $embeddings */
		$embeddings = array_values(array_filter(array_map(
			function ($embeddingId) {
				return Embedding::find((string)$embeddingId);
			},
			(array)($data['embeddings'] ?? [])
		)));

		/** @var Theme $theme */
		$theme = Theme::activeTheme();

		$logData = [
			'consent' => (bool)($data['consent'] ?? false),
			'ucid' => $uniqueCookieId,
			'timestamp' => time(),
			'purposes' => array_map(function (Purpose $purpose) {
				return $purpose->getId();
			}, $purposes),
			'embeddings' => array_map(function (Embedding $embedding) {
				return $embedding->getId();
			}, $embeddings),
			'manipulationPrevention' => ($theme ? $theme->getManipulationPrevention() : null),
		];

		// Domain über Benutzer anhand des verwendeten API-Schlüssels ermitteln - siehe AuthenticationHandler
		$domain = Domain::activeDomain();

		try {
			if ($domain) {
				Protocol::byDomain($domain)->append($logData);
			}
		}
		catch (RuntimeException $exception) {}

		return new JsonResponse(['success' => true]);
	}

	/**
	 * @Route("/statistics/consent", name="app_external_statistics_consent_get", methods={"HEAD", "GET"})
	 * @return JsonResponse
	 *
	 * Dummy-Methode: Vermeidet Exceptions bei GET auf die Consent-Route
	 */
	public function dummyConsentUpdate(Request $request): JsonResponse
	{
		return $this->json(['error'=>'Cannot give consent over HEAD/GET']);
	}

	/**
	 * @Route("/statistics/consent/validate", name="app_external_statistics_consent_validate", methods={"OPTIONS", "POST"})
	 * @return JsonResponse
	 *
	 * Dient dem Validieren von Cross-Domain-Consent.
	 */
	public function validateConsent(Request $request): Response
	{
		$consentData = $request->getContent();
		$purposes = explode('|', $consentData);
		$consentId = array_shift($purposes);
		sort($purposes);

		// Domain über Benutzer anhand des verwendeten API-Schlüssels ermitteln - siehe AuthenticationHandler
		$domain = Domain::activeDomain();

		// Je nach Einstellung entweder auf Embedding-Implementierung wechseln oder fortfahren
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			return $this->validateConsent_managementStructureEmbedding($request);
		}

		try {
			if ($domain) {
				$result = Protocol::byDomain($domain)->search($consentId);
				if ($result) {
					$item = array_pop($result);

					if (empty($item['purposes'])) {
						$item['purposes'] = [];
					}

					sort($item['purposes']);
					if ($item['consent'] && $item['purposes'] == $purposes) {
						$response = new Response('', 204);
						Utils::resetCacheControl($response);
						$response->headers->set('Content-Security-Policy', "default-src: 'none'; img-src 'self'; form-action 'none'");
						return $response->setCache([
							'max_age'=>120,
							'private'=>true,
						]);
						return $response;
					}
				}

			}
		}
		catch (RuntimeException $exception) {
		}

		$response = new Response('', 205);
		Utils::resetCacheControl($response);
		return $response->setCache([
			'max_age'=>3,
			'private'=>true,
		]);
		return $response;
	}

	/**
	 * @param Request $request
	 * @return JsonResponse
	 *
	 * Dient dem Validieren von Cross-Domain-Consent.
	 */
	public function validateConsent_managementStructureEmbedding(Request $request): Response
	{
		$consentData = $request->getContent();
		$embeddingIds = explode('|', $consentData);
		$consentId = array_shift($embeddingIds);
		sort($embeddingIds);

		// Domain über Benutzer anhand des verwendeten API-Schlüssels ermitteln - siehe AuthenticationHandler
		$domain = Domain::activeDomain();

		try {
			if ($domain) {
				$result = Protocol::byDomain($domain)->search($consentId);
				if ($result) {
					$item = array_pop($result);

					if (empty($item['embeddings'])) {
						$item['embeddings'] = [];
					}

					sort($item['embeddings']);
					if ($item['consent'] && $item['embeddings'] == $embeddingIds) {
						$response = new Response('', 204);
						Utils::resetCacheControl($response);
						$response->headers->set('Content-Security-Policy', "default-src: 'none'; img-src 'self'; form-action 'none'");
						return $response->setCache([
							'max_age'=>120,
							'private'=>true,
						]);
					}
				}

			}
		}
		catch (RuntimeException $exception) {
		}

		$response = new Response('', 205);
		Utils::resetCacheControl($response);
		return $response->setCache([
			'max_age'=>3,
			'private'=>true,
		]);
	}
}
