<?php

namespace App\Controller\External;

use App\Component\HttpFoundation\CssResponse;
use App\Component\ThumbnailExtractor\ThumbnailExtractorService;
use App\Component\ThumbnailExtractor\AbstractThumbnailExtractor;
use App\Config;
use App\Controller\ExternalController;
use App\Model\Theme;
use App\Model\Locale;
use App\Utils;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\File\Exception\FileNotFoundException;
use Symfony\Component\Routing\Annotation\Route;

class ContentBlocker extends ExternalController
{
	/**
	 * @Route("/x-content-blocked.html", name="app_external_x_content_blocked", methods={"HEAD", "GET", "OPTIONS"})
	 * @return Response
	 */
	public function contentBlocked(ThumbnailExtractorService $thumbnailer): Response
	{
		/** @var Request $request */
		global $request;
		$parsedRefererUrl = parse_url($request->headers->get('Referer'));
		$iframeUrl = $request->query->get('url', '');
		$apiKey = $request->query->get('apiKey', '');
		$domainId = $request->query->get('domain', '');

		$config = Config::getInstance();

		$scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme().'://';
		$baseUrl = $scheme.$request->getHttpHost();

		$apiParams = [
			'apiKey' => $apiKey,
			'domain' => $domainId,
		];

		$referer = '';
		if (is_array($parsedRefererUrl)) {
			$scheme = $parsedRefererUrl['scheme'] ?? '';
			$host = $parsedRefererUrl['host'] ?? '';

			if ($scheme && $host) {
				$referer = $scheme.'://'.$host;
			}
		}

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new JsonResponse([
				'error' => 'No theme set as active.',
			], 500);
		}

		// Verwende angeforderte Sprache, sonst de_DE
		$localeName = (string)$request->query->get('lang', '');
		if (Locale::exists($localeName) == false) {
			$localeName = 'de_DE';
		}

		// Thumbnails von IFrame holen, falls möglich und Referer gesetzt
		if ($referer) {
			$embedInfo = $thumbnailer->getEmbedInformation($iframeUrl);
			if ($embedInfo and count($embedInfo->getUsableThumbnails()) == 0) {
				$embedInfo = null;
			}
		} else {
			$embedInfo = null;
		}

		$parameters = [
			'theme' => $theme,
			'locale' => Locale::find($localeName),
			'embedInfo' => $embedInfo,
			'apiKey' => $apiKey,
			'breakpoints' => [
				'desktop' => '64.0625em',
			],
			'customCssUrl' => $baseUrl.$this->generateUrl('app_external_x_content_blocked_css', $apiParams + [
					'v' => $theme->getLastModifiedTimestamp(),
				]),
		];

		$response = $this->render('external/content-blocked.html.twig', $parameters);
		Utils::resetCacheControl($response);
		$response->setCache([
			'max_age'=>300,
			'public'=>true,
		]);
		$vary = $response->getVary();
		$vary[] = 'Referer';
		$response->setVary($vary);

		$response->headers->set('Content-Security-Policy',
			"default-src 'self'; ".
			"script-src 'self' 'unsafe-inline'; " .
			"style-src 'self' 'unsafe-inline'; " .
			"img-src 'self' data:; " .
			//"frame-ancestors 'self' $referer; " .
			"frame-src 'self' $referer;"
		);
		$response->headers->set('X-Robots-Tag', 'noindex');

		return $response;
	}

	/**
	 * @Route("/x-content-blocked.css", name="app_external_x_content_blocked_css", methods={"HEAD", "GET", "OPTIONS"})
	 * @return CssResponse
	 */
	public function customCss(): CssResponse
	{
		$response = new CssResponse();

		// Workaround: HTTP-Header Cache-Control würde sonst auf private, must-revalidate etc. gesetzt
		Utils::resetCacheControl($response);

		// Lebensdauer der CSS-Datei auf ein Jahr setzen, da ein Zeitstempel an die CSS-Route angehängt wird
		$response->headers->remove('Cache-Control');
		$response->setCache([
			'max_age' => 31536000,
			'immutable' => true,
			'public' => true,
		]);

		/** @var Theme $theme */
		$theme = Theme::activeTheme();
		if ($theme == null) {
			return new CssResponse('/* No theme set as active. */', 500);
		}

		$response->setContent($theme->getCustomCssForIframeBlocker());

		return $response;
	}

	/**
	 * @Route("/iframe-thumbnail/{urlHash}-{width}.jpeg", name="app_external_iframe_thumbnail", methods={"HEAD", "GET", "OPTIONS"})
	 * @return Response
	 */
	public function backgroundImage(string $urlHash, int $width): Response
	{
		$path = AbstractThumbnailExtractor::getThumbnailCachePath($urlHash, $width);
		try {
			$response = new BinaryFileResponse($path);
		}
		catch (FileNotFoundException $e) {
			$response = new Response(base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNiYAAAAAkAAxkR2eQAAAAASUVORK5CYII='), 404, ['content-type'=>'image/png']);
		}

		Utils::resetCacheControl($response);
		$response->setCache([
			'max_age'=>300,
			'public'=>true,
		]);
		$response->headers->set('X-Robots-Tag', 'noindex');
		return $response;
	}
}
