<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\Domain;
use App\Model\User;
use App\Model\Script;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/domains/{_domainId}/scripts", name="app_scripts_")
 */
class Scripts extends DomainDependantController
{
	/**
	 * @Route("", methods={"GET", "HEAD"}, name="list")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Script-File erfolgen kann
	 *
	 * @return Response
	 */
	public function listScripts(Request $request, TranslatorInterface $translator): Response
	{
		// Scripte holen
		$scripts = Script::all();

		//Die Daten aus dem Form
		$enableScriptPostDat = $request->request->get('enableScript');

		return $this->render('scripts/list.html.twig', [
			'scripts' => $scripts,
		]);
	}

	/**
	 * @Route("", methods={"POST"}, name="list_post")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Script-File erfolgen kann
	 *
	 * @return Response
	 */
	public function updateScriptsStatus(Request $request, TranslatorInterface $translator): Response
	{
		Script::beginWrite();
		// Scripte und Domain holen
		$domain = Domain::activeDomain();
		$scripts = Script::all();

		//Die Daten aus dem Form
		$enableScripts = (array)$request->request->get('enableScript');

		//Einträge durchloopen
		foreach ($scripts as $id=>$script)
		{
			//key gibts - dann aktiv - ansonsten inaktiv
			$data = $script->setEnableScript(array_key_exists($id, $enableScripts));
		}
		// Und Änderungen speichern
		Script::flush();

		// Inline-Script-Ausnahmen speichern
		$markers = explode("\n", trim((string)$request->request->get('allowedScriptMarkers', '')));
		$markers = array_filter($markers, function ($line) {
			return trim($line) !== '';
		});
		$markers = array_values(array_map(function ($line) {
			return trim($line);
		}, $markers));
		$domain->setAllowedScriptMarkers($markers)->save();

		$this->addFlash('success', $translator->trans('The settings have been saved.'));
		return $this->redirectToRoute('app_scripts_list');
	}

	/**
	 * @Route("/{id}/delete", methods={"GET", "HEAD"}, name="delete")
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function deleteScriptPage(string $id, Request $request, TranslatorInterface $translator): Response
	{
		$script = Script::find($id);
	
		if (!$script) {
			return $this->redirectToRoute('app_scripts_list');
		}

		return $this->render('scripts/delete.html.twig', [
			'user' => User::loggedInUser(),
			'script' => $script,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/{id}/delete", methods={"POST"}, name="delete_post")
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function deleteScript(string $id, Request $request, TranslatorInterface $translator): Response
	{
		Script::beginWrite();
		$script = Script::find($id);
	
		if (!$script) {
			return $this->redirectToRoute('app_scripts_list');
		}

		$scriptHash = $script->getId();

		try {
			CsrfToken::get()->checkRequest($request);
			Script::delete($id);
			$this->addFlash('success', 'Das Skript mit dem Hash "' . $scriptHash . '" wurde erfolgreich gelöscht!');
		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
		}
		return $this->redirectToRoute('app_scripts_list');
	}


}
