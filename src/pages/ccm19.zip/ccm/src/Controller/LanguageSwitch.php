<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;

class LanguageSwitch extends UniversalController
{
	/**
	 * @Route("/switch_language", methods={"HEAD", "GET"}, name="app_language_switch")
	 *
	 * @return RedirectResponse
	 */
	public function doBackToIndex(Request $request): RedirectResponse
	{
		return $this->redirectToRoute('app_root');
	}

	/**
	 * @Route("/switch_language", methods={"POST"}, name="app_language_switch")
	 *
	 * @return RedirectResponse
	 */
	public function doSwitchLanguage(Request $request): RedirectResponse
	{
		$session = $request->getSession();

		if ($session) {
			// Locale-Wechsel bei POST mit locale
			$wantedLocale = $request->request->get('switchToLocale');
			if ($wantedLocale) {
				$session->set('locale', $wantedLocale);
				$request->setLocale($wantedLocale);
			}
		}

		// Routen-Parameter bestimmen
		$parameters = json_decode($request->request->get('backToArgs', '[]'), true, 10);
		if (!$parameters or !is_array($parameters)) {
			$parameters = [];
		}

		// Redirect zurück
		try {
			return $this->redirectToRoute(
				$request->request->get('backToRoute', 'app_root'),
				$parameters,
				303
			);
		} catch (\Throwable $e) {
			return $this->redirectToRoute('app_root', [], 303);
		}
	}
}
