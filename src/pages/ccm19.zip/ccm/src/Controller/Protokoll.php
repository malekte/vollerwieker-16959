<?php

namespace App\Controller;

use App\Component\Pagination;
use App\Model\Cookie;
use App\Model\Domain;
use App\Model\Embedding;
use App\Model\EmbeddingAsset;
use App\Model\Locale;
use App\Model\Protocol;
use App\Model\Purpose;
use App\Model\Statistic;
use App\Model\User;
use RuntimeException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use DateTime;

class Protokoll extends DomainDependantController
{
	const ASSUMED_SESSION_COOKIE_LIFETIME = 14*24;
	const ASSUMED_UNKNOWN_COOKIE_LIFETIME = 365*24;

	/**
	 * @param iterable $protocolEntries
	 * @return int
	 */
	private function calculateMaxCookieLifetimeHours(iterable $protocolEntries): int
	{
		// Lebenszeit aller definierten Cookies bestimmen
		$cookieLifetimes = array_map(function ($cookie) {
			return $cookie->getLifetimeHours(self::ASSUMED_SESSION_COOKIE_LIFETIME, self::ASSUMED_UNKNOWN_COOKIE_LIFETIME);
		}, Cookie::all());

		$maxCookieLifetime = 0;

		// Lebenszeit der im Protokoll vorhandenen Cookies berücksichtigen
		foreach ($protocolEntries as $row) {
			try {
				$maxCookieLifetime = max($maxCookieLifetime, max(array_map(function ($id) use ($cookieLifetimes) { return $cookieLifetimes[$id] ?? self::ASSUMED_UNKNOWN_COOKIE_LIFETIME; }, $row['cookies'] ?? [])));
			} catch (\Throwable $e) {
				$maxCookieLifetime = self::ASSUMED_UNKNOWN_COOKIE_LIFETIME;
			}
		}

		return $maxCookieLifetime;
	}

	/**
	 * @param iterable $protocolEntries
	 * @return int
	 */
	private function calculateMaxCookieLifetimeHours_managementStructureEmbedding(iterable $protocolEntries): int
	{
		// Maximale Lebenszeit aller definierten Cookies pro Embedding bestimmen
		$cookieLifetimes = array_map('max', array_filter(
			array_map(
				function (Embedding $embedding) {
					return array_map(
						function (EmbeddingAsset $asset) {
							return $asset->getLifetimeHours(self::ASSUMED_SESSION_COOKIE_LIFETIME, self::ASSUMED_UNKNOWN_COOKIE_LIFETIME);
						},
						array_filter(
							$embedding->getAssets(),
							function (EmbeddingAsset $asset) {
								return $asset->getStorageType() == 'cookie';
							}
						)
					);
				},
				Embedding::all()
			)
		));

		$maxCookieLifetime = 0;

		// Lebenszeit der im Protokoll vorhandenen Cookies berücksichtigen
		foreach ($protocolEntries as $row) {
			// Verhindere leeres Array in max-Funktion
			if (count($row['embeddings'] ?? []) == 0) {
				continue;
			}

			try {
				$maxCookieLifetime = max($maxCookieLifetime, max(array_map(function ($id) use ($cookieLifetimes) {
					return $cookieLifetimes[$id] ?? self::ASSUMED_UNKNOWN_COOKIE_LIFETIME;
				}, $row['embeddings'] ?? [])));
			} catch (\Throwable $e) {
				$maxCookieLifetime = self::ASSUMED_UNKNOWN_COOKIE_LIFETIME;
			}
		}

		return $maxCookieLifetime;
	}

	/**
	 * @Route("/domains/{_domainId}/protokoll", methods={"HEAD", "GET"}, name="app_protokoll")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function protocol(Request $request, TranslatorInterface $translator): Response
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		assert($domain !== null);
		$protocolEntries = [];

		// Je nach Einstellung entweder auf Embedding-Implementierung wechseln oder mit Cookies fortfahren
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			return $this->protocol_managementStructureEmbedding($request, $translator);
		}

		//Search
		$usersearch = trim((string)$request->query->get("search"));
		if(!empty($usersearch))
		{
			$protocol = array();
			$protocol = Protocol::byDomain($domain);
			//$protocol_data = $protocol->search($usersearch);
			$protocolEntries = array_reverse($protocol->search($usersearch));

		}

		try {
			if (empty($protocolEntries) && empty($usersearch))
			{
				$protocol = Protocol::byDomain($domain);
				// TODO Logdatei nicht komplett in den Speicher laden, ggf. SQLite oder ähnliches verwenden
				$protocolEntries = array_reverse($protocol->all());
			}

		}
		catch (RuntimeException $exception) {
			$this->addFlash('danger', $translator->trans('Logfile %file% could not be read, check permissions.', [
				'%file%' => Protocol::staticPathname($domain),
			]));
		}

		$pagination = new Pagination($protocolEntries, 20);
		if ($pagination->getCurrentPage() > 1 && $pagination->getItemCount() == 0) {
			return $this->redirectToRoute('app_protokoll');
		}

		$maxCookieLifetimeHours = $this->calculateMaxCookieLifetimeHours($protocolEntries);
		$earliestDeleteHours = $maxCookieLifetimeHours + 3*24;
		$earliestDeleteDate = new DateTime('now - '.(int)$earliestDeleteHours.' hours');

		$locale = Locale::yieldAny([
			// Versuche, Locale anhand aktiver Backend-Sprache zu ermitteln
			$request->getLocale() == 'de' ? 'de_DE' : $request->getLocale(),
			'en_US',
			'de_DE',
		]);

		return $this->render('protokoll/index.html.twig', [
			'locale' => $locale,
			'purposes' => Purpose::all(),
			'earliestDeleteDate' => $earliestDeleteDate,
			'pagination' => $pagination,
			'usersearch' => $usersearch,
			'totalCount' => count($protocolEntries),
		]);
	}

	/**
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function protocol_managementStructureEmbedding(Request $request, TranslatorInterface $translator): Response
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		assert($domain !== null);
		$protocolEntries = [];

		//Search
		$usersearch = trim((string)$request->query->get("search"));
		if(!empty($usersearch))
		{
			$protocol = array();
			$protocol = Protocol::byDomain($domain);
			//$protocol_data = $protocol->search($usersearch);
			$protocolEntries = array_reverse($protocol->search($usersearch));

		}

		try {
			if (empty($protocolEntries) && empty($usersearch))
			{
				$protocol = Protocol::byDomain($domain);
				$protocolEntries = array_reverse($protocol->all());
			}
		}
		catch (RuntimeException $exception) {
			$this->addFlash('danger', $translator->trans('Logfile %file% could not be read, check permissions.', [
				'%file%' => Protocol::staticPathname($domain),
			]));
		}

		$pagination = new Pagination($protocolEntries, 20);
		if ($pagination->getCurrentPage() > 1 && $pagination->getItemCount() == 0) {
			return $this->redirectToRoute('app_protokoll');
		}

		$embeddings = Embedding::all();
		usort($embeddings, function (Embedding $a, Embedding $b) {
			return strnatcasecmp($a->getName(), $b->getName());
		});

		$maxCookieLifetimeHours = $this->calculateMaxCookieLifetimeHours_managementStructureEmbedding($protocolEntries);
		$earliestDeleteHours = $maxCookieLifetimeHours + 3*24;
		$earliestDeleteDate = new DateTime('now - '.(int)$earliestDeleteHours.' hours');

		$locale = Locale::yieldAny([
			// Versuche, Locale anhand aktiver Backend-Sprache zu ermitteln
			$request->getLocale() == 'de' ? 'de_DE' : $request->getLocale(),
			'en_US',
			'de_DE',
		]);

		return $this->render('protokoll/index_using-embeddings.html.twig', [
			'locale' => $locale,
			'purposes' => Purpose::all(),
			'embeddings' => $embeddings,
			'earliestDeleteDate' => $earliestDeleteDate,
			'pagination' => $pagination,
			'usersearch' => $usersearch,
			'totalCount' => count($protocolEntries),
		]);
	}

	/**
	 * @Route("/domains/{_domainId}/protokoll", methods={"POST"}, name="app_protokoll_action")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function protocolAction(Request $request, TranslatorInterface $translator): Response
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		$action = $request->request->get("action");
		assert($domain !== null);

		switch ($action) {
			case "archive":
				$clearStatistics = $request->request->getBoolean("clearStatistics");
				try {
					$protocol = Protocol::byDomain($domain);
					$protocol->rotateProtocol();
					$protocol->close();
					$this->addFlash('success', $translator->trans('Protocol was successfully archived.'));
				}
				catch (RuntimeException $e) {
					$this->addFlash('danger', $translator->trans('Archiving the protocol failed, please check file system permissions.'));
					return $this->redirectToRoute('app_protokoll', [], 303);
				}

				try {
					if ($clearStatistics) {
						Statistic::clear();
						$this->addFlash('success', $translator->trans('Domain statistics were successfully cleared.'));
					}
				}
				catch (RuntimeException $e) {
					$this->addFlash('danger', $translator->trans('Clearing domain statistics failed, please check file system permissions.'));
					return $this->redirectToRoute('app_protokoll', [], 303);
				}
				break;

			default:
				break;
		}
		$response = $this->redirectToRoute('app_protokoll', [], 303);
		$response->headers->set('Clear-Site-Data', '"cache"');
		return $response;
	}

}
