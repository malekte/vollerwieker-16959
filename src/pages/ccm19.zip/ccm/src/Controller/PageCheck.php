<?php

namespace App\Controller;

use App\Exception\CsrfTokenException;
use App\Model\User;
use App\Model\Cookie;
use App\Model\CsrfToken;
use App\Model\Domain;
use App\Model\Embedding;
use App\Model\EmbeddingAsset;
use App\Model\FoundCookie;
use App\Model\FoundScript;
use App\Model\FoundObject;
use App\Model\FoundStorage;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use DateTime;

/**
 *
 * @Route("/domains/{_domainId}/page_check", name="app_page_check")
 *
 */
class PageCheck extends DomainDependantController
{
	/**
	 * @Route("/", name="")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Cookie-File erfolgen kann
	 * @return Response
	 */
	public function doPagesCheck(TranslatorInterface $translator, Request $request): Response
	{

		$this->cleanupFoundScripts();
		$this->cleanupFoundObjects();
		$this->cleanupFoundStorage();

		//$this->addRequestCookiesToFound($request);
		$uncontrolledCookies = $this->listUncontrolledCookies($request);
		$uncontrolledStorage = $this->listUncontrolledStorage($request);

		return $this->render('pagecheck/index.html.twig', [
			'user' => User::loggedInUser(),
			'uncontrolledCookies' => $this->sortedById($uncontrolledCookies),
			'uncontrolledStorage' => $this->sortedById($uncontrolledStorage),
			'uncontrolledScripts' => $this->sortedById(FoundScript::all()),
			'uncontrolledObjects' => $this->sortedById(FoundObject::all()),
			'dateTimeFormat' => $translator->trans('Y-m-d H:i:s'),
			'csrfToken' => CsrfToken::get()
		]);

	}

	/**
	 * @param $iterable array|\Traversable
	 * @return array
	 */
	private function sortedById($iterable): array
	{
		if (is_array($iterable)) {
			$array = $iterable;
		}
		else {
			$array = [];
			foreach ($iterable as $key=>$value) {
				$array[$key] = $value;
			}
		}
		usort($array, function ($a,$b) {
			$aid = $a->getId();
			$bid = $b->getId();
			if ($aid === $bid) {
				return 0;
			}
			return ($aid < $bid) ? -1 : 1;
		});
		return $array;
	}

	/**
	 * Fasst Scripte, die bis auf den Query-Teil gleich sind, zusammen
	 *
	 * Das bereinigt Einträge aus älteren Versionen des Page Reports
	 */
	private function cleanupFoundScripts(): void
	{
		$startts = time();
		$flush = false;
		$scripts = FoundScript::all();
		$foundNames = [];
		foreach ($scripts as $item) {
			$name = $item->getName();
			$cleanName = preg_replace('/\?[^?]*$/', '?', $name);

			if (isset($foundNames[$cleanName])) {
				$canonicalItem = FoundScript::find($foundNames[$cleanName]);
				$canonicalItem->setLastSeenOn(max($canonicalItem->getLastSeenOn(), $item->getLastSeenOn()));
				foreach ($item->getFoundOnPages() as $page) {
					$canonicalItem->addFoundOnPage($page);
				}
				FoundScript::delete($name, false);
				$flush = true;
			}
			else {
				$foundNames[$cleanName] = $name;
			}
			if ((time() - $startts) > 5) {
				break;
			}
		}
		if ($flush) {
			FoundScript::flush();
		}
	}

	/**
	 * Fasst externe URLs, die bis auf den Query-Teil gleich sind, zusammen
	 *
	 * Das bereinigt Einträge aus älteren Versionen des Page Reports
	 */
	private function cleanupFoundObjects(): void
	{
		$startts = time();
		$flush = false;
		$objects = FoundObject::all();
		$foundNames = [];
		foreach ($objects as $item) {
			$name = $item->getName();
			$cleanName = preg_replace('/\?[^?]*$/', '?', $name);

			if (isset($foundNames[$cleanName])) {
				$canonicalItem = FoundObject::find($foundNames[$cleanName]);
				$canonicalItem->setLastSeenOn(max($canonicalItem->getLastSeenOn(), $item->getLastSeenOn()));
				foreach ($item->getFoundOnPages() as $page) {
					$canonicalItem->addFoundOnPage($page);
				}
				FoundObject::delete($name, false);
				$flush = true;
			}
			else {
				$foundNames[$cleanName] = $name;
			}
			if ((time() - $startts) > 5) {
				break;
			}
		}
		if ($flush) {
			FoundObject::flush();
		}
	}

	/**
	 * Fasst LocalStorage-Elemente, die einen bekannten Präfix haben, zusammen
	 *
	 * Das bereinigt Einträge aus älteren Versionen des Page Reports
	 */
	private function cleanupFoundStorage(): void
	{
		$prefixes = [
			't3-tabs-DTM-',
			'optimizely_data$$',
			'st_shares_',
			'_piggy.',
			'at-lojson-cache-',
			't3-icon_',
			'_at.hist.',
		];
		$startts = time();
		$flush = false;
		$items = FoundStorage::all();
		$foundNames = [];
		foreach ($items as $item) {
			$name = $item->getName();
			$cleanName = null;
			foreach ($prefixes as $prefix) {
				if (strpos($name, $prefix) === 0) {
					$cleanName = $prefix.'…';
					break;
				}
			}
			if ($cleanName === null) {
				continue;
			}

			if (isset($foundNames[$cleanName])) {
				$canonicalItem = FoundStorage::find($foundNames[$cleanName]);
				$canonicalItem->setLastSeenOn(max($canonicalItem->getLastSeenOn(), $item->getLastSeenOn()));
				foreach ($item->getFoundOnPages() as $page) {
					$canonicalItem->addFoundOnPage($page);
				}
				FoundStorage::delete($name, false);
				$flush = true;
			}
			else {
				if ($cleanName === $name) {
					$canonicalItem = $item;
				} else {
					$canonicalItem = FoundStorage::create($cleanName)
						->setLastSeenOn($item->getLastSeenOn())
						->setFoundOnPages($item->getFoundOnPages())
						->setIsSessionStorage($item->getIsSessionStorage());
					FoundStorage::delete($name, false);
				}
				$foundNames[$cleanName] = $cleanName;
			}
			if ((time() - $startts) > 7) {
				break;
			}
		}
		if ($flush) {
			FoundStorage::flush();
		}
	}

	/**
	 * @Route("/all", methods={"DELETE"}, name="_delete_all")
	 *
	 * @return JsonResponse|RedirectResponse
	 */
	public function doDeleteAll(Request $request, TranslatorInterface $translator): Response
	{
		try {
			CsrfToken::get()->checkRequest($request);
			FoundCookie::clear();
			FoundScript::clear();
			FoundStorage::clear();
			FoundObject::clear();
		}
		catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			if ($request->getRealMethod() === 'POST') {
				$this->addFlash('danger', $error);
				return $this->redirectToRoute('app_page_check', [], 303);
			}
			else {
				return $this->json(['success'=>false, 'message'=>$error]);
			}
		}
		catch (\Exception $e) {
			if ($request->getRealMethod() === 'POST') {
				$this->addFlash('danger', $e->getMessage());
				return $this->redirectToRoute('app_page_check', [], 303);
			}
			else {
				return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
			}
		}

		// Wenn über POST-Formular ausgelöst, umleiten, ansonsten JSON zurückgeben
		if ($request->getRealMethod() === 'POST') {
			$this->addFlash('success', $translator->trans('All page check entries were successfully cleared.'));
			return $this->redirectToRoute('app_page_check', [], 303);
		}
		else {
			return $this->json(['success'=>true]);
		}
	}

	/**
	 * @Route("/cookie/{cookie}", methods={"DELETE"}, name="_delete_cookie", requirements={"cookie"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doDeleteCookie(Request $request, string $cookie): JsonResponse
	{
		$cookie = base64_decode(strtr($cookie, '-_', '+/'));

		try {
			FoundCookie::delete($cookie);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		return $this->json(['success'=>true]);
	}

	/**
	 * @Route("/cookie/{cookie}", methods={"GET","HEAD"}, name="_get_cookie", requirements={"cookie"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doGetCookie(Request $request, string $cookie): JsonResponse
	{
		$cookie = base64_decode(strtr($cookie, '-_', '+/'));

		try {
			$object = FoundCookie::find($cookie);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		if ($object) {
			return $this->json(['name'=>$object->getName(), 'last_seen_on'=>$object->getLastSeenOn()->format('Y-m-d H:i:s')]);
		} else {
			return $this->json(null, 404);
		}
	}

	/**
	 * @Route("/script/{script}", methods={"DELETE"}, name="_delete_script", requirements={"script"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doDeleteScript(Request $request, string $script): JsonResponse
	{
		$script = base64_decode(strtr($script, '-_', '+/'));

		try {
			FoundScript::delete($script);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		return $this->json(['success'=>true]);
	}

	/**
	 * @Route("/script/{script}", methods={"GET","HEAD"}, name="_get_script", requirements={"script"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doGetScript(Request $request, string $script): JsonResponse
	{
		$script = base64_decode(strtr($script, '-_', '+/'));

		try {
			$object = FoundScript::find($script);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		if ($object) {
			return $this->json(['name'=>$object->getName(), 'last_seen_on'=>$object->getLastSeenOn()->format('Y-m-d H:i:s')]);
		} else {
			return $this->json(null, 404);
		}
	}

	/**
	 * @Route("/object/{object}", methods={"DELETE"}, name="_delete_object", requirements={"object"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doDeleteObject(Request $request, string $object): JsonResponse
	{
		$object = base64_decode(strtr($object, '-_', '+/'));

		try {
			FoundObject::delete($object);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		return $this->json(['success'=>true]);
	}

	/**
	 * @Route("/object/{object}", methods={"GET","HEAD"}, name="_get_object", requirements={"object"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doGetObject(Request $request, string $object): JsonResponse
	{
		$object = base64_decode(strtr($object, '-_', '+/'));

		try {
			$theObject = FoundScript::find($object);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		if ($theObject) {
			return $this->json(['name'=>$theObject->getName(), 'last_seen_on'=>$theObject->getLastSeenOn()->format('Y-m-d H:i:s')]);
		} else {
			return $this->json(null, 404);
		}
	}

	/**
	 * @Route("/storage/{storage}", methods={"DELETE"}, name="_delete_storage", requirements={"storage"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doDeleteStorage(Request $request, string $storage): JsonResponse
	{
		$storage = base64_decode(strtr($storage, '-_', '+/'));

		try {
			FoundStorage::delete($storage);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		return $this->json(['success'=>true]);
	}

	/**
	 * @Route("/storage/{storage}", methods={"GET","HEAD"}, name="_get_storage", requirements={"storage"=".+"})
	 *
	 * @return JsonResponse
	 */
	public function doGetStorage(Request $request, string $storage): JsonResponse
	{
		$storage = base64_decode(strtr($storage, '-_', '+/'));

		try {
			$theObject = FoundStorage::find($storage);
		}
		catch (\Exception $e) {
			return $this->json(['success'=>false, 'message'=>$e->getMessage()], 500);
		}

		if ($theObject) {
			return $this->json(['name'=>$theObject->getName(), 'last_seen_on'=>$theObject->getLastSeenOn()->format('Y-m-d H:i:s')]);
		} else {
			return $this->json(null, 404);
		}
	}

	/**
	 * Fügt alle Cookies, die aktuell im Request sind, der Liste gefundener
	 * Cookies hinzu.
	 *
	 * @deprecated
	 * @param Request $request
	 * @return void
	 */
	private function addRequestCookiesToFound(Request $request): void
	{
		$now = new DateTime('now');
		$foundCookies = [];
		foreach ($request->cookies as $cookieName => $cookieContent) {
			FoundCookie::create($cookieName)->setLastSeenOn($now)->save();
		}
	}

	/**
	 * @param Request $request
	 * @return FoundCookie[]
	 */
	private function listUncontrolledCookies(Request $request): array
	{
		// Uns bekannte Cookies sammeln
		$domain = Domain::activeDomain();
		assert($domain !== null);
		$knownCookies = [];
		// Embedding-Verwaltung
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			foreach (Embedding::all() as $embedding) {
				foreach ($embedding->getAssetsWithType('cookie') as $asset) {
					$knownCookies[$asset->getName()] = $asset;
				}
			}
		}
		// Legacy-Verwaltung
		else {
			// Uns bekannte Cookies sammeln
			foreach (Cookie::all() as $cookie) {
				$cookieName = $cookie->getHttpCookieName();
				$knownCookies[$cookieName] = $cookie;
			}
		}

		// Vorhandene Cookies sammeln
		$foundCookies = [];
		foreach (FoundCookie::all() as $cookie) {
			$foundCookies[$cookie->getName()] = $cookie;
		}

		// Unsere eigene Session sollte nicht auftauchen
		$session = $request->getSession();
		if ($session) {
			unset($foundCookies[$session->getName()]);
		}
		// Unser eigenes Consent-Cookie sollte nicht auftauchen
		unset($foundCookies['ccm_consent']);

		// Unkontrollierte Cookies bestimmen
		$uncontrolledCookies = array_filter($foundCookies, function (string $key) use ($knownCookies) {
			foreach ($knownCookies as $cookie) {
				if ($cookie->matchName($key)) {
					return false;
				}
			}
			return true;
		}, ARRAY_FILTER_USE_KEY);

		return $uncontrolledCookies;
	}

	/**
	 * @param Request $request
	 * @return FoundStorage[]
	 */
	private function listUncontrolledStorage(Request $request): array
	{
		// Uns bekannte Storage-Keys sammeln
		$domain = Domain::activeDomain();
		assert($domain !== null);
		/** @var Cookie[]|EmbeddingAsset[] */
		$knownLocalStorage = [];
		/** @var Cookie[]|EmbeddingAsset[] */
		$knownSessionStorage = [];
		// Embedding-Verwaltung
		if ($domain->getManagementStructure() == Domain::MANAGEMENT_STRUCTURE_EMBEDDING) {
			foreach (Embedding::all() as $embedding) {
				foreach ($embedding->getAssetsWithType('localStorage') as $asset) {
					$knownLocalStorage[$asset->getName()] = $asset;
				}
				foreach ($embedding->getAssetsWithType('sessionStorage') as $asset) {
					$knownSessionStorage[$asset->getName()] = $asset;
				}
			}
		}
		// Legacy-Verwaltung
		else {
			// Uns bekannte Cookies sammeln
			foreach (Cookie::all() as $cookie) {
				$cookieName = $cookie->getHttpCookieName();
				$knownLocalStorage[$cookieName] = $cookie;
			}
			$knownSessionStorage = $knownLocalStorage;
		}

		// Vorhandene Storage-Keys sammeln
		$foundStorage = [];
		foreach (FoundStorage::all() as $storage) {
			$foundStorage[$storage->getName()] = $storage;
		}

		// Unkontrollierte Storage bestimmen
		$uncontrolledStorage = array_filter($foundStorage, function (FoundStorage $value, string $key) use ($knownLocalStorage, $knownSessionStorage) {
			$knownStorage = ($value->getIsSessionStorage()) ? $knownSessionStorage : $knownLocalStorage;
			foreach ($knownStorage as $storage) {
				if ($storage->matchName($key)) {
					return false;
				}
			}
			return true;
		}, ARRAY_FILTER_USE_BOTH);

		return $uncontrolledStorage;
	}

}
