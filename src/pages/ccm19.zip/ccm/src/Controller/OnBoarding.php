<?php

namespace App\Controller;

use App\Config;
use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\Cookie;
use App\Model\Cookie as CookieModel;
use App\Model\CsrfToken;
use App\Model\Domain;
use App\Model\LegalText;
use App\Model\Locale;
use App\Model\Placeholder as PlaceholderModel;
use App\Model\Purpose;
use App\Model\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use ErrorException;
use Exception;
use RuntimeException;
use App\Model\OnBoarding as OnBoardingModel;

class OnBoarding extends DomainDependantController
{
    const API_URL = 'https://www.ccm19.de/crawler/cookie_crawler/crawl.php';

    /**
     * @Route("/{_domainId}/onboarding/", name="app_onboarding")
     * @param Request $request
     * @return Response
     */
    public function startOnBoarding(Request $request): Response
    {
		if (!empty($request->request->get("action"))) {
			$_SESSION['form_domain'] = $request->request->get('domain');

			return $this->render('onboarding/install.html.twig', [
				'actualDomain' => $_SESSION['form_domain'] ,
			]);
		}
		else
		{
			//Die Domain Daten holen
			$domain = Domain::activeDomain();


			return $this->render('onboarding/install.html.twig', [
				'actualDomain' => $domain->getName(),
			]);
		}


    }

    /**
     * @Route("/{_domainId}/onboarding/manual", name="app_onboarding_manual")
     * @param Request $request
     * @return Response
     */
    public function stopOnBoarding(Request $request): Response
    {
        //Die Domain Daten holen
        $domain = Domain::activeDomain();

        //auf set setzen...
        $domain->setOnBoarding(true);
        $domain->flush();

        return $this->redirectToRoute('app_dashboard');
    }


    /**
     * @Route("/{_domainId}/onboarding/scan", name="app_onboarding_scan")
     * @param Request $request
     * @return Response
     */
    public function OnBoardingScan(Request $request): Response
    {
        //Daten speichern und zum nächsten Schritt
        if (!empty($request->request->get("action"))) {
            //print_r("SAVE");
            $this->saveCookieData($request);

            //Nächste Seite...
            return $this->redirectToRoute('app_onboarding_text');
        }

        //Die Domain Daten holen
        $domain = Domain::activeDomain();

        if (empty($domain->getName()))
		{
			$domain_name = $_SESSION['form_domain'];
		}
        else{
			$domain_name = $domain->getName();
		}

        //Die purposes holen
        $purposes = Purpose::all();

        //Daten holen
        $data = OnBoardingModel::getDataFromRemote($request, $domain_name);

        //Abgleich mit ccm19 DB
        $kat_data = OnBoardingModel::getDataFromCCM19Database($data);

        //neu sortieren zur Ausgabe...
        $sort_data = OnBoardingModel::sortDataForCategories($data, $kat_data);
        //print_r($sort_data);

        if (empty($sort_data)) {

            //Für die Domain auf geonboarded setzen
            $domain->setOnBoarding(true);
            $domain->flush();

            return $this->render('onboarding/install_scan.html.twig', [

                'screenshot_data' => $data['screenshot'] ?? null,
                'count_cookies' => count($data['cookies'] ?? []),
                'actualDomain' => $domain->getName(),

            ]);
        } else {
            return $this->render('onboarding/install_scan.html.twig', [

                'screenshot_data' => $data['screenshot'],
                'count_cookies' => count($data['cookies']),
                'cookies' => $sort_data['sortdata'],
                'cookies_count' => $sort_data['count'],
                'purposes' => $purposes,
                'actualDomain' => $domain->getName(),

            ]);
        }
    }

    /**
     * @Route("/{_domainId}/onboarding/text", name="app_onboarding_text")
     * @param Request $request
     * @param TranslatorInterface $translator
     * @return Response
     */
    public function startOnBoardingText(Request $request, TranslatorInterface $translator): Response
    {
        //Daten speichern und zum nächsten Schritt
        if (!empty($request->request->get("action"))) {
            //Daten speichern
            $this->saveTextData($request, $translator);

            //Nächste Seite...
            return $this->redirectToRoute('app_onboarding_settings');
        }

        $locales = Locale::enabledLocales();
        $imprintL10n = (array)$request->request->get('imprint_l10n');


        return $this->render('onboarding/install_text.html.twig', [
            'locales' => $locales,
            'legalTexts' => LegalText::all(),
            'csrfToken' => CsrfToken::get(),
        ]);
    }

    /**
     * @Route("/{_domainId}/onboarding/settings", name="app_onboarding_settings")
     * @param Request $request
     * @param TranslatorInterface $translator
     * @return Response
     */
    public function startOnBoardingSettings(Request $request, TranslatorInterface $translator): Response
    {
        //Daten speichern und zum nächsten Schritt
        if (!empty($request->request->get("action"))) {
            //Daten speichern
            $this->saveSettingsData($request, $translator);

            //Nächste Seite...
            return $this->redirectToRoute('app_onboarding_finish');
        }


        $placeholders = PlaceholderModel::all();


        return $this->render('onboarding/install_settings.html.twig', [
            'placeholders' => $placeholders,
            'csrfToken' => CsrfToken::get(),
        ]);
    }


    /**
     * @Route("/{_domainId}/onboarding/finish", name="app_onboarding_finish")
     * @param Request $request
     * @return Response
     */
    public function startOnBoardingFinish(Request $request): Response
    {

        $user = User::loggedInUser();
        $domain = Domain::activeDomain();
        $config = Config::getInstance();


        $scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme() . '://';
        $baseUrl = $scheme . $request->getHttpHost();

        $locales = Locale::enabledLocales();
        $localeNames = [];
        $embedCodeSnippets = [];
        foreach ($locales as $locale) {
            /** @var Locale $locale */
            $localeName = $locale->getName();

            $embedScriptUrl = $baseUrl . $this->generateUrl(
                    'app_external_main_javascript_file',
                    [
                        'apiKey' => $user->getApiKey(),
                        'domain' => $domain->getId(),
                        'lang' => $localeName,
                    ]
                );
            $embedCodeSnippets[$localeName] = '<script src="' . htmlspecialchars($embedScriptUrl) . '" referrerpolicy="origin"></script>';
            $language = $locale->getLanguage();
            $localeNames[$localeName] = ($language ? $language->getDisplayName($request->getLocale()) : $localeName);
        }
        $embedCodeSnippetAuto = '<script src="' . htmlspecialchars($baseUrl . $this->generateUrl(
                    'app_external_main_javascript_file',
                    [
                        'apiKey' => $user->getApiKey(),
                        'domain' => $domain->getId(),
                    ]
                )) . '" referrerpolicy="origin"></script>';

        //Für die Domain auf geonboarded setzen
        $domain->setOnBoarding(true);
        $domain->flush();

        return $this->render('onboarding/install_finish.html.twig', [
            'embedCodeSnippets' => $embedCodeSnippets,
            'embedCodeSnippetAuto' => $embedCodeSnippetAuto,
            'localeNames' => $localeNames,
        ]);

    }


    /**
     * @param Request $request
     * @param TranslatorInterface $translator
     */
    public function saveSettingsData(Request $request, TranslatorInterface $translator)
    {
        $placeholders = PlaceholderModel::all();

        // Löschen
        $toDelete = (array)$request->request->get('delete_placeholder', []);
        foreach ($toDelete as $key) {
            PlaceholderModel::delete($key);
        }

        // Bestehende aktualisieren
        foreach ((array)$request->request->get('set_placeholder', []) as $key => $value) {
            $key = urldecode($key);
            PlaceholderModel::create($key)->setValue($value);
        }

        // Neu hinzufügen
        $newItems = array_combine(
            (array)$request->request->get('add_placeholder_name', []),
            (array)$request->request->get('add_placeholder_value', [])
        );
        foreach ($newItems as $key => $value) {
            if ($key !== '' and $key !== null) {
                PlaceholderModel::create($key)->setValue($value);
            }
        }
        PlaceholderModel::flush();

    }


    /**
     * @param Request $request
     * @param TranslatorInterface $translator
     * @return \Symfony\Component\HttpFoundation\RedirectResponse
     */
    public function saveTextData(Request $request, TranslatorInterface $translator)
    {
        /** @var Locale[] $locales */
        $locales = Locale::enabledLocales();
        $imprintL10n = (array)$request->request->get('imprint_l10n');
        $privacyPolicyL10n = (array)$request->request->get('privacy_policy_l10n');

        if ($request->getRealMethod() === 'POST') {
            foreach ($locales as $locale) {
                /** @var LegalText|null $legalText */
                $legalText = LegalText::byLocale($locale);

                if ($legalText === null) {
                    $legalText = LegalText::create()->setLocale($locale);
                }

                $legalText
                    ->setImprint($imprintL10n[$locale->getId()] ?? '')
                    ->setPrivacyPolicy($privacyPolicyL10n[$locale->getId()] ?? '');
            }

            try {
                CsrfToken::get()->checkRequest($request);
                LegalText::flush();

                $this->addFlash('success', $translator->trans('Localizations have been written successfully.'));
                return $this->redirectToRoute('app_onboarding_settings');
            } catch (ConfigNotWritableException $exception) {
                $this->addFlash('danger', $translator->trans('Localizations could not be written to disk.'));
            } catch (CsrfTokenException $exception) {
                $this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
            }
        }

    }


    /**
     * @param Request $request
     */
    public function saveCookieData(Request $request)
    {
        //Alles zurücksetzen
        CookieModel::clear();

        //Daten aus dem Formular
        $rdata = $request->request->all();


        foreach ($rdata['data'] as $purpose_k => $purpose_v) {
            foreach ($purpose_v as $k => $v) {


                $cookie = CookieModel::create();

                $codeBlock = explode("\n", trim((string)($v['code_block'] ?? '')));
                $codeBlock = array_filter($codeBlock, function ($line) {
                    return trim($line) !== '';
                });
                $codeBlock = array_values(array_map(function ($line) {
                    return trim($line);
                }, $codeBlock));

                // Zweck
                $purpose = Purpose::find($v['purpose']);

                // Allgemeines speichern
                $cookie
                    ->setName($v['name'] ?? '')
                    ->setDescription($v['description'] ?? '')
                    ->setCodeSnippet($v['code_snippet'] ?? '')
                    ->setCodeBlock($codeBlock)
                    ->setCookieVendor($v['cookie_vendor'] ?? '')
                    ->setPrivacyPolicyUrl($v['privacy_policy_url'] ?? '')
                    ->setHttpCookieName($v['http_cookie_name'] ?? '')
                    ->setLifetime($v['lifetime'] ?? '')
                    ->setCollectedDataInfo($v['collected_data_info'] ?? '')
                    ->setPurposeOfDataCollection($v['purpose_of_data_collection'] ?? '')
                    ->setLegalBasis($v['legal_basis'] ?? '')
                    ->setPlaceOfProcessing($v['place_of_processing'] ?? '')
                    ->setActive($v['active'] ?? false)
                    ->setPurpose($purpose);

                // Übersetzungen speichern
                foreach (Locale::enabledLocales() as $locale) {
                    $localeId = $locale->getId();
                    if (!isset($v['description'])) {
                        continue; // Wenn description in der Sprache komplett fehlt, ist die Sprache wohl nicht dabei
                    }
                    $cookie
                        ->setTranslatedDescription($locale, $v['description'] ?? '')
                        ->setTranslatedPrivacyPolicyUrl($locale, $v['privacy_policy_url'] ?? '')
                        ->setTranslatedLifetime($locale, $v['lifetime'] ?? '')
                        ->setTranslatedCollectedDataInfo($locale, $v['collected_data_info'] ?? '')
                        ->setTranslatedPurposeOfDataCollection($locale, $v['purpose_of_data_collection'] ?? '')
                        ->setTranslatedLegalBasis($locale, $v['legal_basis'] ?? '')
                        ->setTranslatedPlaceOfProcessing($locale, $v['place_of_processing'] ?? '');
                }

                $cookie->flush();
            }
        }
        return true;
    }
}
