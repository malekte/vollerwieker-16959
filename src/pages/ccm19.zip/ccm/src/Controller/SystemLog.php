<?php

namespace App\Controller;

use App\Component\Pagination;
use App\Model\SystemLog as SystemLogModel;
use DateTime;
use RuntimeException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class SystemLog extends AdminController
{
	/**
	 * @Route("/systemlog", methods={"HEAD", "GET"}, name="app_systemlog")
	 * @Route("/systemlog/{year<\d{4,5}>}/{month<\d{1,2}>}", methods={"HEAD", "GET"}, name="app_systemlog_month")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @param int|null $year
	 * @param int|null $month
	 * @return Response
	 */
	public function logPage(Request $request, TranslatorInterface $translator, ?int $year=null, ?int $month=null): Response
	{
		$date = ($year === null or $month === null) ? new DateTime('now') : new DateTime("$year-$month-01 12:00:00 Z");

		$dates = SystemLogModel::listDateRanges();

		$logEntries = [];
		try {
			$protocol = SystemLogModel::byDate($date);
			$logEntries = array_reverse($protocol->all());
		}
		catch (RuntimeException $exception) {
			$this->addFlash('danger', $translator->trans('Logfile %file% could not be read, check permissions.', [
				'%file%' => SystemLogModel::staticPathname($date),
			]));
		}

		$pagination = new Pagination($logEntries, 20);
		if ($pagination->getCurrentPage() > 1 && $pagination->getItemCount() == 0) {
			return $this->redirectToRoute('app_systemlog');
		}

		return $this->render('systemlog/index.html.twig', [
			'pagination' => $pagination,
			'date' => $date,
			'dates' => $dates,
		]);
	}


}
