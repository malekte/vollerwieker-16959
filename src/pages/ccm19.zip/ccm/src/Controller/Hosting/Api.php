<?php

namespace App\Controller\Hosting;

use App\Component\LoggerInterface;
use App\Controller\HostingApiController;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class Api extends HostingApiController
{
	/**
	 * @Route("/hosting/api/client", name="app_hosting_api_client_create", methods={"POST"})
	 * @param Request $request
	 * @return Response
	 */
	public function clientCreate(Request $request, LoggerInterface $logger): Response
	{
		if (Utils::decodeJsonRequest($request, $payload) == false) {
			/** @var JsonResponse $payload */
			return $payload;
		}

		$username = trim((string)($payload['username'] ?? ''));
		$password = trim((string)($payload['password'] ?? ''));
		$passwordHash = trim((string)($payload['passwordHash'] ?? ''));
		$isActive = (bool)($payload['active'] ?? false);

		$domainMaxCount = max(-1, (int)($payload['domainMaxCount'] ?? 0));
		$whitelabelMaxCount = max(-1, (int)($payload['whitelabelMaxCount'] ?? 0));
		$widgetDisplayMaxCount = max(-1, (int)($payload['widgetDisplayMaxCount'] ?? 0));

		$emailAddress = trim((string)($payload['emailAddress'] ?? ''));
		$firstName = trim((string)($payload['firstName'] ?? ''));
		$lastName = trim((string)($payload['lastName'] ?? ''));
		$company = trim((string)($payload['company'] ?? ''));

		if (empty($username) || empty($password) && empty($passwordHash)) {
			return $this->json([
				'code' => 1,
				'error' => 'The client\'s username and password may not be empty.',
			], 400);
		}

		if (User::exists($username)) {
			return $this->json([
				'code' => 2,
				'error' => 'The client\'s username is already in use.'
			], 400);
		}

		elseif (empty($emailAddress) || Utils::validateEmailAddress($emailAddress) == false) {
			return $this->json([
				'code' => 3,
				'error' => 'The client\'s email address is either empty or invalid.',
			], 400);
		}

		/** @var User $user */
		$user = User::create($username)
			->setPassword($password)
			->setFirstName($firstName)
			->setLastName($lastName)
			->setEmailAddress($emailAddress)
			->setCompany($company)
			->setMaxDomainCount($domainMaxCount)
			->setMaxWLCount($whitelabelMaxCount)
			->setMaxCallCount($widgetDisplayMaxCount)
			->setActive($isActive)
			->setRole(User::ROLE_CLIENT)
		;

		// Ein Passwort in Klartext wird einem Passwort-Hash vorgezogen
		if (empty($password)) {
			$user->setPasswordHash($passwordHash);
		}

		$user->save();

		$logger->logInfo("ClientsAPI","Created user: ".$username);

		return $this->json([
			'id' => $user->getId(),
			'username' => $user->getUsername(),
			'active' => $user->isActive(),
			'firstName' => $user->getFirstName(),
			'lastName' => $user->getLastName(),
			'emailAddress' => $user->getEmailAddress(),
			'company' => $user->getCompany(),
			'domainMaxCount' => $user->getMaxDomainCount(),
			'whitelabelMaxCount' => $user->getMaxWLCount(),
			'widgetDisplayMaxCount' => $user->getMaxCallCount(),
		], 201);
	}

	/**
	 * @Route("/hosting/api/client/{userId}", name="app_hosting_api_client_read", methods={"GET"})
	 * @param string $userId
	 * @return Response
	 */
	public function clientRead(string $userId): Response
	{
		/** @var User|null $user */
		$user = User::byId($userId);

		if ($user && $user->getRole() == User::ROLE_CLIENT) {
			Domain::switchToUser($user);

			$domainCount = Domain::count();
			$whitelabelCount = Domain::whitelabelCountForAllDomains();

			return $this->json([
				'id' => $user->getId(),
				'username' => $user->getUsername(),
				'active' => $user->isActive(),
				'firstName' => $user->getFirstName(),
				'lastName' => $user->getLastName(),
				'emailAddress' => $user->getEmailAddress(),
				'company' => $user->getCompany(),
				'domainCount' => $domainCount,
				'domainMaxCount' => $user->getMaxDomainCount(),
				'whitelabelCount' => $whitelabelCount,
				'whitelabelMaxCount' => $user->getMaxWLCount(),
				'widgetDisplayCount' => $user->getActualCallCount(),
                'widgetDisplayMaxCount' => $user->getMaxCallCount(),
				'userPasswordHash' => $user->getPasswordHash(),
			], 200);
		}
		else {
			return $this->json([
				'error' => 'Client not found.',
			], 404);
		}
	}

	/**
	 * @Route("/hosting/api/client/{userId}", name="app_hosting_api_client_update", methods={"PUT"})
	 * @param string $userId
	 * @param Request $request
	 * @return Response
	 */
	public function clientUpdate(string $userId, Request $request, LoggerInterface $logger): Response
	{
		if (Utils::decodeJsonRequest($request, $payload) == false) {
			/** @var JsonResponse $payload */
			return $payload;
		}

		/** @var User|null $user */
		$user = User::byId($userId);

		if ($user == null || $user->getRole() != User::ROLE_CLIENT) {
			return $this->json([
				'error' => 'Client not found.',
			], 404);
		}

		if (array_key_exists('passwordHash', $payload)) {
			$passwordHash = trim((string)($payload['passwordHash'] ?? ''));

			if (strlen($passwordHash) > 0) {
				$user->setPasswordHash($passwordHash);
			}
		}
		if (array_key_exists('password', $payload)) {
			$password = trim((string)($payload['password'] ?? ''));

			if (strlen($password) > 0) {
				$user->setPassword($password);
			}
		}
		if (array_key_exists('active', $payload)) {
			$user->setActive((bool)($payload['active'] ?? false));
		}
		if (array_key_exists('firstName', $payload)) {
			$user->setFirstName(trim((string)($payload['firstName'] ?? '')));
		}
		if (array_key_exists('lastName', $payload)) {
			$user->setLastName(trim((string)($payload['lastName'] ?? '')));
		}
		if (array_key_exists('emailAddress', $payload)) {
			$emailAddress = trim((string)($payload['emailAddress'] ?? ''));

			if (empty($emailAddress) || Utils::validateEmailAddress($emailAddress) == false) {
				return $this->json([
					'code' => 3,
					'error' => 'The client\'s email address is either empty or invalid.',
				], 400);
			}

			$user->setEmailAddress($emailAddress);
		}
		if (array_key_exists('company', $payload)) {
			$user->setCompany(trim((string)($payload['company'] ?? '')));
		}
		if (array_key_exists('domainMaxCount', $payload)) {
			$user->setMaxDomainCount(max(-1, (int)($payload['domainMaxCount'] ?? 0)));
		}
		if (array_key_exists('whitelabelMaxCount', $payload)) {
			$user->setMaxWLCount(max(-1, (int)($payload['whitelabelMaxCount'] ?? 0)));
		}
		if (array_key_exists('widgetDisplayMaxCount', $payload)) {
			$user->setMaxCallCount(max(-1, (int)($payload['widgetDisplayMaxCount'] ?? 0)));
		}

		if (array_key_exists('isUpgrade', $payload)) {
			$user->resetCallCountForNextMonth();
		}

		$user->save();

		$logger->logInfo("ClientsAPI","Updated user: ".$user->getUsername());

		return $this->json([
			'id' => $user->getId(),
			'username' => $user->getUsername(),
			'active' => $user->isActive(),
			'firstName' => $user->getFirstName(),
			'lastName' => $user->getLastName(),
			'emailAddress' => $user->getEmailAddress(),
			'company' => $user->getCompany(),
			'domainMaxCount' => $user->getMaxDomainCount(),
			'whitelabelMaxCount' => $user->getMaxWLCount(),
			'widgetDisplayMaxCount' => $user->getMaxCallCount(),
		], 200);
	}

	/**
	 * @Route("/hosting/api/client/{userId}", name="app_hosting_api_client_delete", methods={"DELETE"})
	 * @param string $userId
	 * @return Response
	 */
	public function clientDelete(string $userId, LoggerInterface $logger): Response
	{
		/** @var User|null $user */
		$user = User::byId($userId);

		if ($user && $user->getRole() == User::ROLE_CLIENT) {
			$username = $user->getUsername();
			User::delete($userId);
			$logger->logInfo("ClientsAPI","Deleted user: ".$user->getUsername());
			return new Response('', 204);
		}
		else {
			return $this->json([
				'error' => 'Client not found.',
			], 404);
		}
	}
}
