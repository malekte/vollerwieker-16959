<?php

namespace App\Controller\Hosting;

use App\Controller\HostingController;
use App\Config;
use App\Utils;
use MaxMind\Db\Reader\Util;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Yaml\Exception\ParseException as YamlParseException;
use Symfony\Component\Yaml\Parser as YamlParser;
use Symfony\Component\Yaml\Unescaper as YamlUnescaper;
use Symfony\Component\Yaml\Escaper as YamlEscaper;
use Symfony\Contracts\Translation\TranslatorInterface;
use RuntimeException;

/**
 * @Route("/hosting/settings", name="app_hosting_settings")
 */
class Settings extends HostingController
{
	/**
	 * @Route("", methods={"HEAD","GET"}, name="")
	 * @return Response
	 */
	public function settingsForm(Request $request): Response
	{
		$config = Config::getInstance();

		//powerdByUrl
		$formData = [
			'poweredByText' => Utils::getPoweredByText(),
			'poweredByTooltip' => Utils::getPoweredByTooltip(),
			'poweredByUrl' => Utils::getPoweredByUrl(),
			'themeBack_customCss' => Utils::getThemeBack_customCss(),
			'Search' => "",
			'Replace' => "",
		];

		return $this->render('hosting/settings/index.html.twig', [
			'formData' => $formData,
			'langSelect' => (string)$request->request->get('langSelect'),
		]);
	}

	/**
	 * @Route("", methods={"POST"}, name="_post")
	 * @return Response
	 */
	public function settingsPost(Request $request, TranslatorInterface $translator): Response
	{
		$config 		= 	Config::getInstance();

		//Das Backend Logo hochladen
		$image 			= 	$request->files->get('image');
		try {
			if ($image) {
				$this->handleUploadErrors($image, $translator);
				$logoFilename = 'logo.' . $image->getClientOriginalExtension();
				$destination = Utils::getVarDir();

				Utils::assertDirectoryWritable($destination);
				if ($image->move($destination, $logoFilename)) {
					$config->set('backendLogo', $logoFilename);
				}
			}
		}
		catch (RuntimeException $e) {
			return $this->settingsForm($request);
		}

		//Das LoginLogo hochladen.
		$imageLogo 			= 	$request->files->get('imageLogin');
		//print_r($imageLogo);
		try {
			if ($imageLogo) {
				$this->handleUploadErrors($imageLogo, $translator);
				$logoFilename = 'loginlogo.' . $imageLogo->getClientOriginalExtension();
				$destination = Utils::getVarDir();
				//print_r($destination);

				Utils::assertDirectoryWritable($destination);
				if ($imageLogo->move($destination, $logoFilename)) {
					$config->set('loginLogo', $logoFilename);
				}
			}
		}
		catch (RuntimeException $e) {
			return $this->settingsForm($request);
		}
		//exit();

		$config->set('poweredByText', (string)$request->request->get('poweredByText'));
		$config->set('poweredByTooltip', (string)$request->request->get('poweredByTooltip'));
		$config->set('poweredByUrl', (string)$request->request->get('poweredByUrl'));

		//neuer Kram
		$config->set('themeBack_customCss', (string)$request->request->get('themeBack_customCss'));

		if ((string)$request->request->get('action') == "edit")
		{
			// Übersetzungen
			$lang = (string)$request->request->get('langSelect');
			$escaper = new YamlEscaper();
			$translations = $this->getTranslationData($lang);
			$translationResult = [];
			$translationChanges = (array)$request->request->get('yaml');
			// Bestimmen, was sich im Vergleich zum Original geändert hat
			foreach ($translationChanges as $key => $value) {
				header('Content-Type: text/plain;charset=utf-8');
				$key = urldecode($key);
				$value = str_replace("\r\n", "\n", $value);
				$stockValue = str_replace("\r\n", "\n", $translations[$key]['stock'] ?? '');
				if ($value !== '' and $value !== $stockValue) {
					// YAML-Zeilen bauen
					$key = $escaper->escapeWithDoubleQuotes($key);
					$value = $escaper->escapeWithDoubleQuotes($value);
					$translationResult[] = "$key: $value\n";
				}
			}

			@mkdir(Utils::getVarDir() . '/translations');
			$tmpPath = Utils::getVarDir() . '/translations/messages.'.$lang.'.yaml.tmp';
			$savePath = Utils::getVarDir() . '/translations/messages.'.$lang.'.yaml';
			file_put_contents($tmpPath, $translationResult, LOCK_EX);
			rename($tmpPath, $savePath);
			$this->clearTranslationsCache();
		}

		$this->addFlash('success', $translator->trans(
			'The settings were saved successfully!'));
		return $this->redirectToRoute('app_hosting_settings', [], 303);
	}

	/**
	 * Übersetzungen-Cache leeren.
	 *
	 * Reicht aus, solange alle Dateien bereits existierten. Veränderungen werden
	 * dann erkannt, aber neu hinzugekommene Dateien von Symfony nicht
	 * berücksichtigt. Dafür muss der komplette Cache geleert werden.
	 */
	private function clearTranslationsCache(): void
	{
		$baseCacheDir = Utils::getCacheDir();
		$cacheDir = $baseCacheDir . DIRECTORY_SEPARATOR . 'translations';
		$rnd = bin2hex(random_bytes(3));
		$suffix = '~'.date('Ymd').'-'.$rnd;

		if (@rename($cacheDir, $cacheDir.$suffix)) {
			Utils::removeDirectory($cacheDir.$suffix);
		}
	}

	/**
	 * Lädt eine YAML-Übersetzungsdatei und gibt den Inhalt zurück
	 *
	 * Wenn sie nicht existiert, wird ein leeres Array zurückgegeben.
	 *
	 * @param string $path Dateipfad
	 * @return array YAML-Daten
	 */
	private function loadTranslationYaml(string $path): array
	{
		try {
			$parser = new YamlParser();
			$unescaper = new YamlUnescaper();
			$data = $parser->parseFile($path);
			if (is_array($data)) {
				$unescaped = [];
				foreach ($data as $key => $value) {
					if (substr($key, 0, 1) == '"') {
						$key = $unescaper->unescapeDoubleQuotedString(substr($key, 1, -1));
					}
					if (substr($value, 0, 1) == '"') {
						$value = $unescaper->unescapeDoubleQuotedString(substr($value, 1, -1));
					}
					$unescaped[$key] = $value;
				}
				return $unescaped;
			} else {
				return [];
			}
		}
		catch (YamlParseException $e) {
			if (stripos($e->getMessage(), ' not exist') !== false) {
				return [];
			} else {
				throw $e;
			}
		}
	}

	private function getTranslationData(string $lang): array
	{
		$customPath = Utils::getVarDir() . '/translations/messages.'.$lang.'.yaml';
		$originalPath = Utils::getBaseDir() . '/translations/messages.'.$lang.'.yaml';

		$originalData = $this->loadTranslationYaml($originalPath);

		// Sonderfall Englisch: zusätzlich Schlüssel aus Deutsch holen
		if ($lang === 'en') {
			foreach ($this->loadTranslationYaml(Utils::getBaseDir() . '/translations/messages.de.yaml') as $key => $text) {
				if (!isset($originalData[$key])) {
					$originalData[$key] = null;
				}
			}
		}

		$customData = $this->loadTranslationYaml($customPath);
		$data = [];
		foreach ($originalData as $key => $text) {
			$data[$key] = [
				'stock'=>$text,
				'custom'=>$customData[$key] ?? null
			];
		}
		foreach ($customData as $key => $text) {
			if (!isset($data[$key])) {
				$data[$key] = [
					'stock'=>null,
					'custom'=>$text
				];
			}
		}
		ksort($data);

		return $data;
	}

	/**
	 * @Route("/translations/{lang<[a-z]{2,4}>}.json", methods={"HEAD","GET"}, name="_ajax_translation")
	 * @return JsonResponse
	 */
	public function ajaxTranslation(string $lang, Request $request): JsonResponse
	{
		$customPath = Utils::getVarDir() . '/translations/messages.'.$lang.'.yaml';
		$originalPath = Utils::getBaseDir() . '/translations/messages.'.$lang.'.yaml';

		if (!file_exists($originalPath)) {
			return $this->json([], 404);
		}

		$data = $this->getTranslationData($lang);

		return $this->json($data);
	}

	/**
	 * @param UploadedFile $image
	 * @param TranslatorInterface $translator
	 * @return void
	 */
	private function handleUploadErrors(UploadedFile $image, TranslatorInterface $translator): void
	{
		if ($image->getError() != UPLOAD_ERR_OK) {
			$this->addFlash(
				'danger',
				$translator->trans('The image could not be uploaded! (Error code %errorcode% %errormessage%)', [
					'%errorcode%' => $image->getError(),
					'%errormessage%' => $image->getErrorMessage()
				])
			);
			throw new RuntimeException('upload failed');
		}

		if (preg_match('/^image\/.*$/', $image->getMimeType()) == false) {
			$this->addFlash('danger', $translator->trans('The uploaded file is not an image!'));
			throw new RuntimeException('not an image');
		}
	}
}
