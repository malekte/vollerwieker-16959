<?php

namespace App\Controller\Hosting;

use App\Component\Api\HostingApi;
use App\Controller\HostingController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class ApiDocs extends HostingController
{
	/**
	 * @Route("/hosting/api/docs", name="app_hosting_api_docs")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function api(Request $request, TranslatorInterface $translator): Response
	{
		return $this->render('hosting/api/index.html.twig', [
			'api' => HostingApi::getInstance(),
			'baseUrl' => $request->getScheme().'://'.$request->getHttpHost(),
		]);
	}

	/**
	 * @Route("/hosting/api/update_key", name="app_hosting_api_update_key", methods={"POST"})
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function updateApiKey(Request $request, TranslatorInterface $translator): Response
	{
		$apiKey = trim((string)$request->request->get('apiKey'));

		if (strlen($apiKey) >= HostingApi::API_KEY_LENGTH) {
			HostingApi::getInstance()->setApiKey($apiKey);
		}
		else {
			$this->addFlash('danger', $translator->trans('The API key must be at least :x characters long.', [
				':x' => HostingApi::API_KEY_LENGTH,
			]));
		}

		return $this->redirectToRoute('app_hosting_api_docs', [], 303);
	}

	/**
	 * @Route("/hosting/api/update_hawk", name="app_hosting_api_update_hawk", methods={"POST"})
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function updateHawkHttpAuthentication(Request $request, TranslatorInterface $translator): Response
	{
		$useHawk = (bool)$request->request->get('useHawk');
		$sharedSecret = trim((string)$request->request->get('sharedSecret'));

		$api = HostingApi::getInstance();

		$api->setUseHawk($useHawk);

		if (strlen($sharedSecret) >= HostingApi::SHARED_SECRET_LENGTH) {
			$api->setSharedSecret($sharedSecret);
		}
		else {
			$this->addFlash('danger', $translator->trans('The shared secret should be at least :x characters long.', [
				':x' => HostingApi::SHARED_SECRET_LENGTH,
			]));
		}

		return $this->redirectToRoute('app_hosting_api_docs', [], 303);
	}
}
