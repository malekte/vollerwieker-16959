<?php

namespace App\Controller\Hosting;

use App\Controller\HostingController;
use App\Component\HttpFoundation\JavascriptResponse;
use App\Model\User;
use App\Model\Domain;
use App\Model\Purpose;
use App\Model\Statistic;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpKernel\EventListener\SessionListener;
use RuntimeException;


class Dashboard extends HostingController
{
	/**
	 * @Route("/hosting/dashboard", name="app_hosting_dashboard")
	 * @return Response
	 */
	public function dashboard(): Response
	{
		$domainCount 		= 	0;
		$userCount 			= 	0;
		$diffCookies 		= 	0;
		$usedCookies 		=	0;
		$userStats 			= 	[];

		$loggedInUser = User::loggedInUser();
		Utils::getSession()->save();

		// Statistik über alle User erstellen
		try {
			foreach (User::all() as $user) {
				if ($user->getRole() == User::ROLE_CLIENT)
				{
					Domain::switchToUser($user);
					$userStats[$user->getUserName()] = Domain::count();
					$domainCount += Domain::count();
					$userCount++;
				}
			}
		}
		finally {
			Domain::switchToUser($loggedInUser);
		}

		return $this->render('hosting/dashboard/index.html.twig', [
			'userStats' => $userStats,
			'domainCountTotal' => $domainCount,
			'userCount' => $userCount,
			'diffcookies' => $diffCookies,
			'usedcookies' => $usedCookies
		]);
	}

	/**
	 * @Route("/hosting/chart.js", methods={"HEAD","GET"}, name="app_hosting_dashboard_chart_js")
	 * @return JavascriptResponse
	 */
	public function chartJs(Request $request): JavascriptResponse
	{
		$response = new JavascriptResponse();
		Utils::resetCacheControl($response);
		$response->setMaxAge(120);
		$response->setCache([
			'max_age'=>120,
			'public'=>false
		]);
		$loggedInUser = User::loggedInUser();

		$purposes = Purpose::all();
		$statistics = [];
		foreach ($purposes as $purpose) {
			$statistics[$purpose->getId()] = 0;
		}

		// Session schließen
		$request->getSession()->save();

		$count = 0;
		// Statistik über alle User erstellen
		try {
			foreach (User::all() as $user) {
				Domain::switchToUser($user);
				foreach (Domain::all() as $domain) {
					Domain::setDomainForRequest($domain->getId());
					Statistic::reloadRepository();
					$statList = Statistic::all();
					foreach ($statList as $date => $stat) {
						foreach ($purposes as $purpose) {
							$statistics[$purpose->getId()] += $stat->getPurposeAcceptCount($purpose->getId());
						}
						$count += $stat->getViewCount();
					}
				}
			}
		}
		catch (RuntimeException $exception) {}
		finally {
			Domain::switchToUser($loggedInUser);
			Domain::setDomainForRequest('');
		}

		$parameters = [
			'purposes' => $purposes,
			'statistics' => $statistics,
			'countTotal' => $count,
		];

		return $this->render('dashboard/chart.js.twig', $parameters, $response);
	}
}
