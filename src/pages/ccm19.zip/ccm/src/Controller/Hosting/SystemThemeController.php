<?php

namespace App\Controller\Hosting;

use App\Component\LoggerInterface;
use App\Controller\HostingController;
use App\Model\Domain;
use App\Model\SystemTheme;
use App\Model\Theme;
use App\Model\ThemeBase;
use App\Model\User;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class SystemThemeController extends HostingController
{
	/**
	 * @Route("/hosting/system_theme", name="app_hosting_system_theme_index")
	 * @param Request $request
	 * @return Response
	 */
	public function themeIndex(Request $request): Response
	{
		return $this->render('hosting/system_theme/index.html.twig', [
			'themes' => SystemTheme::all(),
		]);
	}

	/**
	 * @Route("/hosting/system_theme/{id}/default", name="app_hosting_system_theme_default", methods={"POST"})
	 * @param string $id
	 * @return Response
	 */
	public function setDefaultTheme(string $id): Response
	{
		$theme = SystemTheme::find($id);

		if ($theme) {
			$theme->makeDefault();
		}

		return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
	}

	/**
	 * @Route("/hosting/system_theme/deploy", name="app_hosting_system_theme_deploy", methods={"POST"})
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @param LoggerInterface $logger
	 * @return Response
	 */
	public function deployThemes(Request $request, TranslatorInterface $translator,  LoggerInterface $logger): Response
	{
		$systemThemes = SystemTheme::all();
		$clients = User::byRole(User::ROLE_CLIENT);

		try {
			array_walk($clients, function ($user) use ($systemThemes) {
				// Zu Domain-Repo des aktuellen Kunden wechseln, altes Repo nicht speichern
				Domain::switchToUser($user, false);

				foreach (Domain::all() as $domain) {
					// Themes pro Domain durchgehen und Repos speichern, um Themes zu aktualisieren
					Theme::switchRepository($user, $domain, true);

					foreach ($systemThemes as $systemTheme) {
						// Finde das Theme, das das aktuelle System-Theme referenziert; erstelle notfalls ein neues
						$theme = Theme::bySystemTheme($systemTheme) ?? Theme::create();

						// Daten des System-Themes in das referenzierende Theme kopieren
						$theme->setSystemTheme($systemTheme);
					}
				}
			});

			$this->addFlash('success', $translator->trans('System-wide themes have been deployed into each client account.'));
			$logger->logInfo('ThemeDeployment', 'System themes have been deployed successfully.');
		} catch (Exception $exception) {
			$this->addFlash('danger', $translator->trans('Oops! An error has occurred. Please refer to the system log for further information.'));
			$logger->logException('ThemeDeployment', $exception, 'An error occurred while deploying system-wide themes.');
		} finally {
			// Theme-Repo schließen und Domain-Repo zurücksetzen, auch wenn das bei Admins zwecklos ist
			Theme::closeRepository(true);
			Domain::switchToUser(User::loggedInUser(), true);
		}

		return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
	}

	/**
	 * @Route("/hosting/system_theme/new", name="app_hosting_system_theme_new")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function themeCreate(Request $request, TranslatorInterface $translator): Response
	{
		$formData = $this->formDataTemplate();
		$mayGeoIP = (phpversion('bcmath') !== false or extension_loaded('bcmath') !== false or phpversion('gmp') !== false or extension_loaded('gmp') !== false);

		if ($request->getRealMethod() == 'POST') {
			// Benutzereingaben einlesen und validieren; $formData und $formErrors per Referenz
			$this->validateFormInput($request, $translator, $formData, $formErrors);

			if ($formErrors) {
				// Im Fehlerfall entsprechende Meldungen ausgeben
				array_walk($formErrors, function ($error) {
					$this->addFlash('danger', $error);
				});
			}
			else {
				// Neues Theme anlegen
				$theme = SystemTheme::create();
				$this->injectFormData($theme, $formData);

				// Das erste Theme wird automatisch zum Standard
				if (SystemTheme::count() == 1) {
					$theme->makeDefault();
				}

				$theme->save();

				$this->addFlash('success', $translator->trans(
					'The theme "%themename%" has been created successfully!', [
						'%themename%' => $theme->getName(),
					]
				));

				return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
			}
		}

		return $this->render('hosting/system_theme/new.html.twig', [
			'formData' => $formData,
			'mayGeoIP' => $mayGeoIP,
		]);
	}

	/**
	 * @Route("/hosting/system_theme/{id}", name="app_hosting_system_theme_edit")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function themeEdit(string $id, Request $request, TranslatorInterface $translator): Response
	{
		$theme = SystemTheme::find($id);

		if ($theme === null) {
			return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
		}

		$formData = $this->formDataTemplate($theme);
		$mayGeoIP = (phpversion('bcmath') !== false or extension_loaded('bcmath') !== false or phpversion('gmp') !== false or extension_loaded('gmp') !== false);

		if ($request->getRealMethod() == 'POST') {
			// Benutzereingaben einlesen und validieren; $formData und $formErrors per Referenz
			$this->validateFormInput($request, $translator, $formData, $formErrors);

			if ($formErrors) {
				// Im Fehlerfall entsprechende Meldungen ausgeben
				array_walk($formErrors, function ($error) {
					$this->addFlash('danger', $error);
				});
			}
			else {
				// Theme aktualisieren
				$this->injectFormData($theme, $formData);
				$theme->save();

				$this->addFlash('success', $translator->trans(
					'The theme "%themename%" has been edited successfully!', [
						'%themename%' => $theme->getName(),
					]
				));

				return $this->redirectToRoute('app_hosting_system_theme_edit', [
					'id' => $theme->getId(),
				], 303);
			}
		}

		return $this->render('hosting/system_theme/edit.html.twig', [
			'theme' => $theme,
			'formData' => $formData,
			'mayGeoIP' => $mayGeoIP,
		]);
	}

	/**
	 * @Route("/hosting/system_theme/{id}/delete", name="app_hosting_system_theme_delete")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function themeDelete(string $id, Request $request, TranslatorInterface $translator): Response
	{
		$theme = SystemTheme::find($id);

		if ($theme === null) {
			return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
		}

		if (SystemTheme::count() <= 1) {
			$this->addFlash('danger', $translator->trans('You cannot delete the last theme!'));
			return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
		}

		if ($request->getRealMethod() == 'POST') {
			// Sofern das Standardtheme gelöscht wird, das erstbeste als neuen Standard festlegen
			if ($theme->isDefaultTheme()) {
				foreach (SystemTheme::all() as $currentTheme) {
					if ($currentTheme->getId() != $theme->getId()) {
						$currentTheme->makeDefault();
						$this->addFlash(
							'info',
							$translator->trans('The theme "%themename%" has now been set as default.', [
								'%themename%' => $currentTheme->getName(),
							])
						);
						break;
					}
				}
			}

			// Theme entfernen
			$themeName = $theme->getName();
			SystemTheme::delete($theme->getId());

			$this->addFlash('success', $translator->trans('The theme "%themename%" has been deleted successfully!', [
				'%themename%' => $themeName,
			]));

			return $this->redirectToRoute('app_hosting_system_theme_index', [], 303);
		}

		return $this->render('hosting/system_theme/delete.html.twig', [
			'theme' => $theme,
		]);
	}

	/**
	 * Diese Methode erstellt ein assoziatives Array, das sämtliche Parameter enthält, die für die Theme-Konfiguration
	 * relevant sind. Wenn ein Objekt übergeben wird, werden anstelle von Standardwerten die des Objekts hinterlegt.
	 * @param SystemTheme|null $theme
	 * @return array
	 */
	private function formDataTemplate(?SystemTheme $theme = null): array
	{
		return [
			'name' => $theme ? $theme->getName() : '',
			'position' => $theme ? $theme->getPosition() : '',
			'selectType' => $theme ? $theme->getSelectType() : '',
			'showPurposesInMainWindow' => $theme ? $theme->isShowPurposesInMainWindow() : false,
			'blocking' => $theme ? $theme->isBlocking() : false,
			'showAcceptAllButtonInControlPanel' => $theme ? $theme->isShowAcceptAllButtonInControlPanel() : false,
			'settingsIconEnabled' => $theme ? $theme->isSettingsIconEnabled() : false,
			'settingsIconTarget' => $theme ? $theme->getSettingsIconTarget() : '',
			'showDeclineButton' => $theme ? $theme->isShowDeclineButton() : false,
			'complyingDoNotTrack' => $theme ? $theme->isComplyingDoNotTrack() : false,
			'onlyInEu' => $theme ? $theme->getOnlyInEu() : false,
			'okButtonBackgroundColor' => $theme ? $theme->getOkButtonBackgroundColor() : '#000000',
			'okButtonColor' => $theme ? $theme->getOkButtonColor() : '#000000',
			'okButtonBorderColor' => $theme ? $theme->getOkButtonBorderColor() : '#000000',
			'declineButtonBackgroundColor' => $theme ? $theme->getDeclineButtonBackgroundColor() : '#000000',
			'declineButtonTextColor' => $theme ? $theme->getDeclineButtonTextColor() : '#000000',
			'declineButtonBorderColor' => $theme ? $theme->getDeclineButtonBorderColor() : '#000000',
			'moreInfoButtonBackgroundColor' => $theme ? $theme->getMoreInfoButtonBackgroundColor() : '#000000',
			'moreInfoButtonColor' => $theme ? $theme->getMoreInfoButtonColor() : '#000000',
			'moreInfoButtonBorderColor' => $theme ? $theme->getMoreInfoButtonBorderColor() : '#000000',
			'windowBackgroundColor' => $theme ? $theme->getWindowBackgroundColor() : '#000000',
			'infotextColor' => $theme ? $theme->getInfotextColor() : '#000000',
			'windowBorderColor' => $theme ? $theme->getWindowBorderColor() : '#000000',
			'linkInInfotextColor' => $theme ? $theme->getLinkInInfotextColor() : '#000000',
			'iframeBlockerBackgroundColor' => $theme ? $theme->getIframeBlockerBackgroundColor() : '#000000',
			'iframeBlockerForegroundColor' => $theme ? $theme->getIframeBlockerForegroundColor() : '#000000',
			'iframeBlockerButtonBackgroundColor' => $theme ? $theme->getIframeBlockerButtonBackgroundColor() : '#000000',
			'iframeBlockerButtonForegroundColor' => $theme ? $theme->getIframeBlockerButtonForegroundColor() : '#000000',
			'customCss' => $theme ? $theme->getCustomCss() : '',
			'customCssForIframeBlocker' => $theme ? $theme->getCustomCssForIframeBlocker() : '',
			'manipulationPrevention' => $theme ? $theme->getManipulationPrevention() : true,
		];
	}

	/**
	 * Diese Methoden validiert die Benutzereingaben und generiert u. U. Fehlermeldungen.
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @param array $formData [Referenz]
	 * @param null|array $formErrors [Referenz] @phan-output-reference
	 */
	private function validateFormInput(Request $request, TranslatorInterface $translator, array &$formData, ?array &$formErrors): void
	{
		$formErrors = [];

		array_walk($formData, function (&$value, $fieldName) use ($request, $translator, &$formErrors) {
			$value = trim((string)$request->request->get($fieldName));

			if ($fieldName == 'name' && empty($value)) {
				$formErrors[] = $translator->trans('Theme name may not be empty.');
			}
			elseif (preg_match('~Color$~', $fieldName) && preg_match('~^#[0-9a-f]{6}$~i', $value) == false) {
				$formErrors[] = $translator->trans('Invalid color values! Please use the color picker and/or provide hex color codes.');
			}
		});

		$formErrors = array_unique($formErrors);
	}

	/**
	 * Diese Methode überträgt die Benutzereingaben in das übergebene Theme-Objekt, ohne das Repository zu speichern.
	 * @param ThemeBase $theme
	 * @param array $formData
	 */
	private function injectFormData(ThemeBase $theme, array $formData): void
	{
		$theme
			->touchLastModifiedTimestamp()
			->setName($formData['name'])
			->setPosition($formData['position'])
			->setSelectType($formData['selectType'])
			->setShowPurposesInMainWindow((bool)$formData['showPurposesInMainWindow'])
			->setBlocking((bool)$formData['blocking'])
			->setShowAcceptAllButtonInControlPanel((bool)$formData['showAcceptAllButtonInControlPanel'])
			->setSettingsIconEnabled((bool)$formData['settingsIconEnabled'])
			->setSettingsIconTarget($formData['settingsIconTarget'])
			->setShowDeclineButton((bool)$formData['showDeclineButton'])
			->setComplyingDoNotTrack((bool)$formData['complyingDoNotTrack'])
			->setOnlyInEu((bool)$formData['onlyInEu'])
			->setOkButtonBackgroundColor($formData['okButtonBackgroundColor'])
			->setOkButtonColor($formData['okButtonColor'])
			->setOkButtonBorderColor($formData['okButtonBorderColor'])
			->setDeclineButtonBackgroundColor($formData['declineButtonBackgroundColor'])
			->setDeclineButtonTextColor($formData['declineButtonTextColor'])
			->setDeclineButtonBorderColor($formData['declineButtonBorderColor'])
			->setMoreInfoButtonBackgroundColor($formData['moreInfoButtonBackgroundColor'])
			->setMoreInfoButtonColor($formData['moreInfoButtonColor'])
			->setMoreInfoButtonBorderColor($formData['moreInfoButtonBorderColor'])
			->setWindowBackgroundColor($formData['windowBackgroundColor'])
			->setInfotextColor($formData['infotextColor'])
			->setWindowBorderColor($formData['windowBorderColor'])
			->setLinkInInfotextColor($formData['linkInInfotextColor'])
			->setIframeBlockerBackgroundColor($formData['iframeBlockerBackgroundColor'])
			->setIframeBlockerForegroundColor($formData['iframeBlockerForegroundColor'])
			->setIframeBlockerButtonBackgroundColor($formData['iframeBlockerButtonBackgroundColor'])
			->setIframeBlockerButtonForegroundColor($formData['iframeBlockerButtonForegroundColor'])
			->setCustomCss($formData['customCss'])
			->setCustomCssForIframeBlocker($formData['customCssForIframeBlocker'])
			->setManipulationPrevention((bool)($formData['manipulationPrevention'] ?? false))
		;
	}
}
