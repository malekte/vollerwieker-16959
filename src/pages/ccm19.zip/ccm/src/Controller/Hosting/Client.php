<?php

namespace App\Controller\Hosting;

use App\Component\LoggerInterface;
use App\Component\Pagination;
use App\Component\ThumbnailExtractor\ThumbnailExtractorService;
use App\Controller\HostingController;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\User;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class Client extends HostingController
{
	/**
	 * @Route("/hosting/client", methods={ "HEAD", "GET" }, name="app_hosting_client_index")
	 * @param Request $request
	 * @return Response
	 */
	public function clientIndex(Request $request): Response
	{
		// Die Session wird hier schon nicht mehr benötigt.
		Utils::getSession()->save();

		$clients = User::byRole(User::ROLE_CLIENT);

		//Search
		$usersearch = trim((string)$request->query->get("search", ''));
		if ($usersearch) {
			$clients = User::search($usersearch);
		}

		$pagination = new Pagination($clients);
		if ($pagination->getCurrentPage() > 1 && $pagination->getItemCount() == 0) {
			return $this->redirectToRoute('app_hosting_client_index');
		}

		return $this->render('hosting/client/index.html.twig', [
			'pagination' => $pagination,
			'usersearch' => $usersearch,
		]);
	}

	/**
	 * @Route("/hosting/client/new", name="app_hosting_client_new")
	 * @param Request $request
	 * @return Response
	 */
	public function clientCreate(Request $request, TranslatorInterface $translator): Response
	{
		$formData = [
			'username' => '',
			'password' => '',
			'emailAddress' => '',
			'firstName' => '',
			'lastName' => '',
			'company' => '',
			'useractive' =>'1',
			'maxDomainCount' => '10',
			'maxWLCount' => '0',
			'maxCallCount' => '1000',
			'autoAddDomains' => false,
		];

		if ($request->getRealMethod() == 'POST') {
			foreach (array_keys($formData) as $fieldName) {
				$formData[$fieldName] = trim((string)$request->request->get($fieldName));
			}

			try {
				CsrfToken::get()->checkRequest($request);

				User::beginWrite();

				if (User::exists($formData['username'])) {
					$this->addFlash('danger', $translator->trans('Username %username% already exists.', [
						'%username%' => $formData['username'],
					]));
				}
				elseif (Utils::validateEmailAddress($formData['emailAddress']) == false) {
					$this->addFlash('danger', $translator->trans('Invalid email address, check format.'));
				}
				elseif (empty($formData['username']) || empty($formData['password'])) {
					$this->addFlash('danger', $translator->trans('Please fill out all fields marked with an asterisk.'));
				}
				else {
					User::create($formData['username'])
						->setPassword($formData['password'])
						->setEmailAddress($formData['emailAddress'])
						->setFirstName($formData['firstName'])
						->setLastName($formData['lastName'])
						->setCompany($formData['company'])
						->setMaxDomainCount((int)$formData['maxDomainCount'])
						->setRole(User::ROLE_CLIENT)
						->setMaxWLCount((int)$formData['maxWLCount'])
						->setMaxCallCount((int)$formData['maxCallCount'])
						->setAutoAddDomains((bool)$formData['autoAddDomains'])
						->setActive((bool)$formData['useractive'])
						->save();

					$this->addFlash('success', $translator->trans('Client %username% has been created!', [
						'%username%' => $formData['username'],
					]));

					return $this->redirectToRoute('app_hosting_client_index');
				}
			} catch (CsrfTokenException $e) {
				$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
				$this->addFlash('danger', $error);
			}
		}

		return $this->render('hosting/client/new.html.twig', [
			'formData' => $formData,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/hosting/client/{id}", methods={ "HEAD", "GET" }, name="app_hosting_client_edit_form")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function clientEditForm(string $id, Request $request, TranslatorInterface $translator): Response
	{
		/** @var User|null $client */
		$client = User::byId($id);

		if ($client == null || $client->getRole() != User::ROLE_CLIENT) {
			return $this->redirectToRoute('app_hosting_client_index');
		}

		return $this->render('hosting/client/edit.html.twig', [
			'user' => User::loggedInUser(),
			'client' => $client,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/hosting/client/{id}", methods={ "PATCH" }, name="app_hosting_client_edit")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function clientEdit(string $id, Request $request, TranslatorInterface $translator): Response
	{
		User::beginWrite();
		/** @var User|null $client */
		$client = User::byId($id);

		if ($client == null || $client->getRole() != User::ROLE_CLIENT) {
			return $this->redirectToRoute('app_hosting_client_index');
		}

		$formData = [
			'password' => '',
			'emailAddress' => '',
			'firstName' => '',
			'lastName' => '',
			'company' => '',
			'useractive' =>'',
			'maxDomainCount' => '10',
			'maxWLCount' => '0',
			'maxCallCount' => '1000',
			'autoAddDomains' => false,
		];

		foreach (array_keys($formData) as $fieldName) {
			$formData[$fieldName] = trim((string)$request->request->get($fieldName));
		}

		// Daten temporär zuweisen, damit im Fehlerfall die Benutzereingaben im Formular ausgegeben werden
		$client
			->setEmailAddress($formData['emailAddress'])
			->setFirstName($formData['firstName'])
			->setLastName($formData['lastName'])
			->setCompany($formData['company'])
			->setMaxWLCount((int)$formData['maxWLCount'])
			->setMaxDomainCount((int)$formData['maxDomainCount'])
			->setMaxCallCount((int)$formData['maxCallCount'])
			->setAutoAddDomains((bool)$formData['autoAddDomains'])
			->setActive((bool)$formData['useractive'])
		;

		$ok = true;

		try {
			CsrfToken::get()->checkRequest($request);
		} catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			$this->addFlash('danger', $error);
			$ok = false;
		}


		if (! Utils::validateEmailAddress($formData['emailAddress'])) {
			$this->addFlash('danger', $translator->trans('Invalid email address, check format.'));
			$ok = false;
		}

		if ($ok) {
			if (strlen($formData['password']) > 0) {
				$client->setPassword($formData['password']);
			}

			$client->save();

			$this->addFlash('success', $translator->trans('Client %username% has been edited!', [
				'%username%' => $client->getUsername(),
			]));

			return $this->redirectToRoute('app_hosting_client_index', [], 303);
		}

		return $this->render('hosting/client/edit.html.twig', [
			'user' => User::loggedInUser(),
			'client' => $client,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/hosting/client/{id}/resetCallCount", methods={ "POST" }, name="app_hosting_client_reset_cc")
	 * @param string $id
	 * @param Request $request
	 * @return JsonResponse
	 */
	public function clientResetCC(string $id, Request $request): JsonResponse
	{
		User::beginWrite();
		/** @var User|null $client */
		$client = User::byId($id);

		if ($client == null || $client->getRole() != User::ROLE_CLIENT) {
			return $this->json([
				'error'=>'client not found'
			], 404);
		}

		$client->setCallCount(0);
		$client->save();

		return $this->json([
			'success'=>true,
			'callCount'=>$client->getActualCallCount()
		]);
	}

	/**
	 * @Route("/hosting/client/{id}/login", methods={"POST"}, name="app_hosting_client_login")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function clientLogin(string $id, Request $request, TranslatorInterface $translator, LoggerInterface $logger): Response
	{
		/** @var User|null $client */
		$client = User::byId($id);
		$currentUser = User::loggedInUser();

		if ($client == null || $client->getRole() != User::ROLE_CLIENT) {
			return $this->redirectToRoute('app_hosting_client_index');
		}

		$client->switchTo(true);

		$logger->logInfo("Login", "User ".$currentUser->getUsername()." logged into account ".$client->getUsername());

		$this->addFlash('success', $translator->trans('You are now in the account “%USER%”. You may switch back to the admin account using the account menu in the top right corner.', ['%USER%' => $client->getUsername()]));

		$response = $this->redirectToRoute('app_root', [], 303);
		$response->headers->set('Clear-Site-Data', '"cache"');
		return $response;
	}

	/**
	 * @Route("/hosting/client/{id}/delete", methods={"HEAD", "GET"}, name="app_hosting_client_delete_form")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function clientDeleteForm(string $id, Request $request, TranslatorInterface $translator, ThumbnailExtractorService $thumbnails): Response
	{
		/** @var User|null $client */
		$client = User::byId($id);

		if ($client == null || $client->getRole() != User::ROLE_CLIENT) {
			return $this->redirectToRoute('app_hosting_client_index');
		}

		return $this->render('hosting/client/delete.html.twig', [
			'user' => User::loggedInUser(),
			'client' => $client,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/hosting/client/{id}", methods={"DELETE"}, name="app_hosting_client_delete")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function clientDelete(string $id, Request $request, TranslatorInterface $translator, ThumbnailExtractorService $thumbnails): Response
	{
		try {
			CsrfToken::get()->checkRequest($request);
		} catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			$this->addFlash('danger', $error);
			return $this->redirectToRoute('app_hosting_client_delete_form', ['id'=>$id], 303);
		}

		User::beginWrite();
		/** @var User|null $client */
		$client = User::byId($id);

		if ($client == null || $client->getRole() != User::ROLE_CLIENT) {
			return $this->redirectToRoute('app_hosting_client_index');
		}

		$thumbnails->clearCache($client);

		$username = $client->getUsername();
		User::delete($client->getId());

		$this->addFlash('success', $translator->trans('Account %username% has been terminated.', [
			'%username%' => $username,
		]));

		return $this->redirectToRoute('app_hosting_client_index', [], 303);

	}
}
