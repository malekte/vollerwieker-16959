<?php

namespace App\Controller;

use App\Exception\CsrfTokenException;
use App\Model\User;
use App\Model\CsrfToken;
use App\Utils;
use App\Config;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class Account extends UniversalController
{
	/**
	 * @Route("/account", name="app_account", methods={"HEAD", "GET"})
	 * @return Response
	 */
	public function account(): Response
	{
		return $this->render('account/index.html.twig', [
			'csrfToken' => CsrfToken::get(),
			'_metaSidebar' => true,
		]);
	}

	/**
	 * @Route("/account/password", name="app_account_password", methods={"POST"})
	 * @param Request $request
	 * @return Response
	 */
	public function changePassword(Request $request, TranslatorInterface $translator): Response
	{
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			return $this->redirectToRoute('app_account');
		}

		$password = trim($request->request->get('current_password'));
		$newPassword = trim($request->request->get('new_password'));
		$newPasswordRetyped = trim($request->request->get('new_password_retyped'));

		$user = User::loggedInUser();

		if ($user->checkPassword($password) == false) {
			$this->addFlash('danger', $translator->trans('The password you\'ve entered is incorrect.'));
		}
		else if (empty($newPassword)) {
			$this->addFlash('danger', $translator->trans('New password may not be empty.'));
		}
		else if ($newPassword != $newPasswordRetyped) {
			$this->addFlash('danger', $translator->trans('Retyped password doesn\'t match new password.'));
		}
		else {
			$user->setPassword($newPassword)->save();
			$this->addFlash('success', $translator->trans('Your password has been updated!'));
		}

		return $this->redirectToRoute('app_account');
	}

	/**
	 * @Route("/account", name="app_account_userdata", methods={"POST"})
	 * @param Request $request
	 * @return Response
	 */
	public function changeUserdata(Request $request, TranslatorInterface $translator): Response
	{
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			return $this->redirectToRoute('app_account');
		}

		$email = trim($request->request->get('email'));
		$firstName = trim($request->request->get('firstName'));
		$lastName = trim($request->request->get('lastName'));
		$company = trim($request->request->get('company'));

		$user = User::loggedInUser();

		$user->setEmailAddress($email)
			 ->setFirstName($firstName)
			 ->setLastName($lastName)
			 ->setCompany($company)
			 ->save();

		if ($user->getRole() === User::ROLE_ADMIN)
		{
			$config = Config::getInstance();
			$config->set('email', $email);
		}

		$this->addFlash('success', $translator->trans('Your user information has been updated!'));

		return $this->redirectToRoute('app_account');
	}
}
