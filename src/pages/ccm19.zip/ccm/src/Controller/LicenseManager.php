<?php

namespace App\Controller;

use App\Component\Ccm19LicensingApiClient;
use App\Config;
use App\Utils;
use RuntimeException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class LicenseManager extends AdminController
{
	/**
	 * @Route("/license_manager", name="app_license_manager_index")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function index(Request $request, TranslatorInterface $translator): Response
	{
		if ($request->getRealMethod() == 'POST') {
			$this->updateLicense($request, $translator);

			return $this->redirectToRoute('app_license_manager_index', [], 303);
		}

		return $this->render('license_manager/index.html.twig', [
			'_metaSidebar' => true,
			'licenseKey' => Utils::getLicenseKey(),
			'whitelabel' => Utils::hasWhitelabelLicense(),
		]);
	}

	/**
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 */
	private function updateLicense(Request $request, TranslatorInterface $translator): void
	{
		$oldLicenseKey = Utils::getLicenseKey();
		$oldWhitelabelState = Utils::hasWhitelabelLicense();

		$newLicenseKey = trim($request->request->get('licenseKey'));
		$newWhitelabelState = (bool)$request->request->get('whitelabel');

		$api = new Ccm19LicensingApiClient();

		$licensed = strlen($oldLicenseKey) > 0;
		$edition = $_ENV['APP_EDITION'] ?? '';

		if ($oldLicenseKey != $newLicenseKey) {
			// Registrierung der u. U. aktiven Lizenz inkl. Whitelabel zunächst aufheben
			if ($licensed) {
				$api->unregisterLicense($oldLicenseKey, $request->getHttpHost());
				$licensed = false;
				$edition = '';

				if ($api->isError()) {
					$this->addFlash('danger', $translator->trans($api->getErrorMessage()));
				}
			}

			// Versuche neuen Lizenzschlüssel zu registrieren
			if (strlen($newLicenseKey) > 0) {
				$licensed = $api->registerLicense($newLicenseKey, $request->getHttpHost());
				$edition = $api->getEdition();

				Config::getInstance()
					->set('licensekey', $api->isSuccess() ? $newLicenseKey : '')
					->set('whitelabel', $api->hasWhitelabel())
				;
				Utils::setLocalEnvironment([
					'APP_EDITION' => $api->getEdition(),
				]);

				if ($licensed) {
					$this->addFlash('success', $translator->trans('License key has been activated successfully.'));
				}
				else {
					$this->addFlash('warning', $translator->trans($api->getErrorMessage()));
				}
			}

			// Wenn nicht mehr lizenziert, sämtliche Lizenzdaten zurücksetzen und raus
			if ($licensed == false) {
				Config::getInstance()
					->set('licensekey', '')
					->set('whitelabel', false)
				;
				Utils::setLocalEnvironment([
					'APP_EDITION' => '',
				]);

				if (empty($newLicenseKey)) {
					$this->addFlash('success', $translator->trans('License data has been reset.'));
				}

				return;
			}
		}

		if ($licensed && $edition != 'extended') {
			if ($newWhitelabelState) {
				$api->registerWhitelabel($newLicenseKey, $request->getHttpHost());
			}
			else {
				$api->unregisterWhitelabel($newLicenseKey, $request->getHttpHost());
			}

			if ($api->isSuccess()) {
				Config::getInstance()
					->set('whitelabel', $api->hasWhitelabel())
				;

				$keyChanged = $oldLicenseKey != $newLicenseKey;
				$wlChanged = $oldWhitelabelState != $newWhitelabelState;

				if ($keyChanged == false && $wlChanged || $keyChanged && $newWhitelabelState) {
					$this->addFlash('success', $translator->trans(
						$newWhitelabelState
							? 'Whitelabel has been registered successfully.'
							: 'Whitelabel has been unregistered successfully.'
					));
				}
			}
			else {
				$this->addFlash('danger', $translator->trans($api->getErrorMessage()));
			}
		}
	}
}
