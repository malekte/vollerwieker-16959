<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\User;
use App\Model\Placeholder as PlaceholderModel;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/domains/{_domainId}/placeholders", name="app_placeholder_")
 */
class Placeholder extends DomainDependantController
{
	/**
	 * @Route("", methods={"GET","HEAD"}, name="list")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Placeholder-File erfolgen kann
	 *
	 * @return Response
	 */
	public function listPlaceholders(): Response
	{
		$placeholders = PlaceholderModel::all();

		return $this->render('placeholder/index.html.twig', [
			'placeholders' => $placeholders,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("", methods={"POST"}, name="list_post")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Placeholder-File erfolgen kann
	 *
	 * @return RedirectResponse
	 */
	public function updatePlaceholders(Request $request): RedirectResponse
	{
		$placeholders = PlaceholderModel::all();

		// Löschen
		$toDelete = (array)$request->request->get('delete_placeholder', []);
		foreach ($toDelete as $key) {
			PlaceholderModel::delete($key);
		}

		// Bestehende aktualisieren
		foreach ((array)$request->request->get('set_placeholder', []) as $key => $value) {
			$key = urldecode($key);
			PlaceholderModel::create($key)->setValue($value);
		}

		// Neu hinzufügen
		$newItems = array_combine(
			(array)$request->request->get('add_placeholder_name', []),
			(array)$request->request->get('add_placeholder_value', [])
		);
		foreach ($newItems as $key => $value) {
			if ($key !== '' and $key !== null) {
				PlaceholderModel::create($key)->setValue($value);
			}
		}
		PlaceholderModel::flush();

		return $this->redirectToRoute('app_placeholder_list', [], 303);
	}
}
