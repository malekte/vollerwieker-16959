<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\LegalText;
use App\Model\Locale;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class Datenschutz extends DomainDependantController
{
	/**
	 * @Route("/domains/{_domainId}/datenschutz", name="app_datenschutz")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function privacyPolicy(Request $request, TranslatorInterface $translator): Response
	{
		/** @var Locale[] $locales */
		$locales = Locale::enabledLocales();
		$privacyPolicyL10n = (array)$request->request->get('privacy_policy_l10n');
		$privacyScheme = $request->request->get('privacyScheme');
		$privacyUrl = (array)$request->request->get('privacyUrl');

		if ($request->getRealMethod() === 'POST') {
			foreach ($locales as $locale) {
				/** @var LegalText|null $legalText */
				$legalText = LegalText::byLocale($locale);

				if ($legalText === null) {
					$legalText = LegalText::create()->setLocale($locale);
				}

				$legalText
					->setPrivacyPolicy($privacyPolicyL10n[$locale->getId()] ?? '')
					->setPrivacyScheme($privacyScheme ?? '')
					->setPrivacyUrl($privacyUrl[$locale->getId()] ?? '')
				;
			}

			try {
				CsrfToken::get()->checkRequest($request);
				LegalText::flush();

				$this->addFlash('success', $translator->trans('Localizations have been written successfully.'));
				return $this->redirectToRoute('app_datenschutz');
			}
			catch (ConfigNotWritableException $exception) {
				$this->addFlash('danger', $translator->trans('Localizations could not be written to disk.'));
			}
			catch (CsrfTokenException $exception) {
				$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			}
		}

		foreach ($locales as $locale) {
			$legalText = LegalText::byLocale($locale);
			if ($legalText === null) {
				$legalText = LegalText::create()->setLocale($locale);
			}
			break;
		}

		return $this->render('datenschutz/index.html.twig', [
			'locales' => $locales,
			'legalTexts' => LegalText::all(),
			'csrfToken' => CsrfToken::get(),
			'privacyScheme' =>$legalText->getPrivacyScheme()
		]);
	}
}
