<?php

namespace App\Controller;

use App\Component\Update;
use App\Config;
use App\Event\StatisticsDisplayEvent;
use App\Model\Domain;
use App\Model\Locale;
use App\Model\User;
use App\Model\Cookie;
use App\Model\FoundCookie;
use App\Model\FoundScript;
use App\Model\FoundObject;
use App\Model\FoundStorage;
use App\Model\Purpose;
use App\Model\Statistic;
use App\Component\HttpFoundation\JavascriptResponse;
use App\Utils;
use RuntimeException;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\EventListener\SessionListener;
use Symfony\Component\Routing\Annotation\Route;
use Throwable;
use App\Component\Update as UpdateComponent;

/**
 * @Route("/domains/{_domainId}/dashboard", name="app_dashboard")
 */
class Dashboard extends DomainDependantController
{
	/**
	 * @Route("", name="")
	 * @param Request $request
	 * @return Response
	 */
	public function index(Request $request): Response
	{
		$user = User::loggedInUser();
		$domain = Domain::activeDomain();
		$config = Config::getInstance();

		$scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme().'://';
		$baseUrl = $scheme.$request->getHttpHost();

		$locales = Locale::enabledLocales();
		$localeNames = [];
		$embedCodeSnippets = [];
		foreach ($locales as $locale) {
			/** @var Locale $locale */
			$localeName = $locale->getName();

			$embedScriptUrl = $baseUrl.$this->generateUrl(
				'app_external_main_javascript_file',
				[
					'apiKey' => $user->getApiKey(),
					'domain' => $domain->getId(),
					'lang' => $localeName,
				]
			);
			$embedCodeSnippets[$localeName] = '<script src="' . htmlspecialchars($embedScriptUrl) . '" referrerpolicy="origin"></script>';
			$language = $locale->getLanguage();
			$localeNames[$localeName] = ($language ? $language->getDisplayName($request->getLocale()) : $localeName);
		}
		$embedCodeSnippetAuto = '<script src="'.htmlspecialchars($baseUrl.$this->generateUrl(
			'app_external_main_javascript_file',
			[
				'apiKey' => $user->getApiKey(),
				'domain' => $domain->getId(),
			]
		)).'" referrerpolicy="origin"></script>';

		$cookieCounts = [];
		$cookieCountTotal = 0;
		foreach (Purpose::all() as $purpose) {
			$count = count(Cookie::byPurpose($purpose));
			$cookieCounts[$purpose->getName()] = $count;
			$cookieCountTotal += $count;
		}

		// Auf Update prüfen
		$this->checkForUpdateGlobal();

        //nur dann wenn mehrere Domains verwaltet werden... Einzelplatz Version macht keinen Sinn da kein Domname vorhanden ist
        if (!empty($domain->getName()))
        {
            $firstLogin = $domain->isOnBoarding();
        }
        else{
            $firstLogin = true;
        }

        //First Login
		if ($firstLogin==false)
		{
			return $this->redirectToRoute('app_onboarding', [], 303);
		}
		else{
			return $this->render('dashboard/index.html.twig', [
				'embedCodeSnippets' => $embedCodeSnippets,
				'embedCodeSnippetAuto' => $embedCodeSnippetAuto,
				'localeNames' => $localeNames,
				'cookieCounts' => $cookieCounts,
				'cookieCountTotal' => $cookieCountTotal,
				'uncontrolledCookieCount' => FoundCookie::count(),
				'uncontrolledStorageCount' => FoundStorage::count(),
				'uncontrolledScriptCount' => FoundScript::count(),
				'uncontrolledObjectCount' => FoundObject::count(),
				'update_notifier' =>$_SESSION['update_notifier']??null,
			]);
		}
	}

	/**
	 * @return false
	 */
	private function checkForUpdateGlobal()
	{
		$config = Config::getInstance();

		//AutoUpdate - dann nix checken
		if($config->get("enableAutoUpdate")==true)
		{
			return false;
		}

		if (!isset($_SESSION['update_notifier']))
		{
			$_SESSION['update_notifier']= false;
		}

		$updater = new Update();
		$config = Config::getInstance();
		try {
			$updateInfo = $updater->checkForUpdate();
			$_SESSION['update_notifier'] = ($updateInfo and Utils::getVersionId() != $updateInfo['versionId']);
		}
		catch (Throwable $e) {
			$_SESSION['update_notifier'] = false;
		}
	}
	
	/**
	 * @Route("/chart.js", name="_chart_js")
	 * @param Request $request
	 * @return JavascriptResponse
	 */
	public function chartJs(Request $request): JavascriptResponse
	{
		$response = new JavascriptResponse();
		Utils::resetCacheControl($response);
		$response->setCache([
			'max_age'=>90,
			'public'=>false
		]);

		Utils::dispatchEvent(StatisticsDisplayEvent::NAME, new StatisticsDisplayEvent());
		$purposes = Purpose::all();
		$statistics = [];
		$count = 0;
		foreach ($purposes as $purpose) {
			$statistics[$purpose->getId()] = 0;
		}

		try {
			$domain = Domain::activeDomain();
			assert($domain !== null);

			foreach (Statistic::all() as $date => $stat) {
				//$stat = new Statistic();
				$count += $stat->getViewCount();
				foreach ($purposes as $purpose) {
					$statistics[$purpose->getId()] += $stat->getPurposeAcceptCount($purpose->getId());
				}
			}
		}
		catch (RuntimeException $exception) {}

		// Session schließen
		$request->getSession()->save();

		$parameters = [
			'purposes' => $purposes,
			'statistics' => $statistics,
			'countTotal' => $count,
		];

		return $this->render('dashboard/chart.js.twig', $parameters, $response);
	}
}
