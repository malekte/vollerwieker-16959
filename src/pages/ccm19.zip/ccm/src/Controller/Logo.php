<?php

namespace App\Controller;

use App\Config;
use App\Model\Domain;
use App\Model\Theme;
use App\Model\User;
use App\Utils;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class Logo extends UnrestrictedController
{
	/**
	 * @Route("/logo/{userId}/{domainId}/{themeId}", name="app_theme_logo")
	 * @return Response
	 */
	public function logo(Request $request, string $userId, string $domainId, string $themeId): Response
	{
		if (
			($user = User::byId($userId)) == null ||
			User::setApiUser($user->getApiKey()) == false ||
			Domain::setDomainForRequest($domainId) == false ||
			($theme = Theme::find($themeId)) == null
		) {
			return new Response('File not found.', 404);
		}

		$domain = Domain::activeDomain();
		$imagePathname = $domain->logoDir().'/'.$theme->getLogoFilename();

		if (is_file($imagePathname) == false) {
			return new Response('File not found.', 404);
		}
		else if (is_readable($imagePathname) == false) {
			return new Response('Reading file not permitted.', 403);
		}

		$response = new BinaryFileResponse($imagePathname, 200, [], true, null, true, true);

		// Caching
		if ($request->query->has('nocache')) {
			Utils::resetCacheControl($response);
			$response->setCache(['max_age'=>0, 'public'=>true]);
			$response->headers->addCacheControlDirective('no-cache');
			$response->headers->addCacheControlDirective('must-revalidate');
		} else {
			Utils::resetCacheControl($response);
			$response->setCache([
				'max_age'=>450,
				'public'=>true,
			]);
		}

		return $response;
	}

	/**
	 * @Route("/logo/backend", name="app_backend_logo")
	 * @return Response
	 */
	public function backendLogo(Request $request): Response
	{
		$config = Config::getInstance();
		$path = Utils::getVarDir() . DIRECTORY_SEPARATOR . $config->get('backendLogo', 'logo.png');

		if (!Utils::isBaseEdition() and is_file($path) and is_readable($path)) {
			$response = new BinaryFileResponse($path, 200, [], true, null, true, true);
		}
		else {
			$response = new BinaryFileResponse(Utils::getBaseDir() . '/public/img/ccm19_logo_weiss_klein.png', 200, [], true, null, true, true);
		}

		// Caching
		if ($request->query->has('nocache')) {
			Utils::resetCacheControl($response);
			$response->setCache(['max_age'=>0, 'public'=>true]);
			$response->headers->addCacheControlDirective('no-cache');
			$response->headers->addCacheControlDirective('must-revalidate');
		} else {
			Utils::resetCacheControl($response);
			$response->setCache([
				'max_age'=>600,
				'public'=>true,
			]);
		}

		return $response;
	}

	/**
	 * @Route("/logo/login", name="app_login_logo")
	 * @return Response
	 */
	public function loginLogo(Request $request): Response
	{
		$config = Config::getInstance();
		$path = Utils::getVarDir() . DIRECTORY_SEPARATOR . $config->get('loginLogo', 'loginlogo.png');

		if (!Utils::isBaseEdition() and is_file($path) and is_readable($path)) {
			$response = new BinaryFileResponse($path, 200, [], true, null, true, true);
		}
		else {
			$response = new BinaryFileResponse(Utils::getBaseDir() . '/public/img/10-ccm-19-logo-02-a.png', 200, [], true, null, true, true);
		}

		// Caching
		if ($request->query->has('nocache')) {
			Utils::resetCacheControl($response);
			$response->setCache(['max_age'=>0, 'public'=>true]);
			$response->headers->addCacheControlDirective('no-cache');
			$response->headers->addCacheControlDirective('must-revalidate');
		} else {
			Utils::resetCacheControl($response);
			$response->setCache([
				'max_age'=>600,
				'public'=>true,
			]);
		}

		return $response;
	}
}
