<?php

namespace App\Controller;

use App\Config;
use App\Component\Update as UpdateComponent;
use App\Component\LoggerInterface;
use App\Model\CsrfToken;
use App\Model\VersionLog;
use App\Downloader;
use App\Exception\CsrfTokenException;
use App\Exception\TempFileNotWritableException;
use App\Exception\ZipArchiveException;
use App\Exception\ZipArchiveAccessException;
use App\Exception\ZipArchiveCorruptedException;
use App\Exception\ZipArchiveExtractException;
use App\Exception\ZipArchiveMemoryLimitException;
use App\Exception\ZipArchiveNoFileException;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\JSONResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use Throwable;
use ZipArchive;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;

/**
 * Controller für die Update-Backend-Seite
 *
 * @Route("/update", name="app_update")
 */
class Update extends AdminController
{
	const UPDATE_CHECK_URL = 'https://update.ccm19.de/';
	const UPDATE_ZIP_URL = 'https://update.ccm19.de/';

	/**
	 * @Route("/", methods={"HEAD", "GET"}, name="")
	 * @param Request $request
	 * @return Response
	 */
	public function index(Request $request, TranslatorInterface $translator): Response
	{
		// Unsere Version bestimmen
		$versionId = Utils::getVersionId();

		// Prüfe Verzeichnisse rekursiv auf Schreibzugriff
		$notWriteableDirectories = UpdateComponent::checkDirectoryAccess();

		// Falls möglich, setze den Zugriff
		foreach($notWriteableDirectories as &$directory) {
			try {
				if (@chmod($directory, 0775)) {
					$directory = false;
				}
			}
			// Exception verstecken, da wir die Ordner eh dem User ins Frontend berichten
			catch (\ErrorException $e) {}
		}
		unset($directory);

		// leere Elemente entfernen
		$notWriteableDirectories = array_filter($notWriteableDirectories);

		// Wenn es noch Ordner ohne Zugriff gibt, dann dem User in Frontend Bericht erstatten
		if (count($notWriteableDirectories) > 0) {
			$directoryList = '<ul class="pl15 ml15">'
				. implode(array_map(function($entry){return '<li>' . $entry . '</li>';}, $notWriteableDirectories))
				. '</ul>';
			$this->addFlash(
				'danger',
				$translator->trans('Please check write access to the following directories:') . $directoryList
			);
		}

		// Versionslog öffnen
		$previousVersions = VersionLog::all();
		usort($previousVersions, function (VersionLog $a, VersionLog $b) {
			return $b->getFirstInstallDate() <=> $a->getFirstInstallDate();
		});
		$previousVersions = array_filter($previousVersions, function (VersionLog $item) use ($versionId) {
			return $item->getId() != $versionId;
		});

		// Changelog Daten holen - kommen von webseite
		$changelog = UpdateComponent::getChangeLog();

		return $this->render('update/index.html.twig', [
			'preventUpdate' => count($notWriteableDirectories) > 0,
			'update_check_url' => self::UPDATE_CHECK_URL.'?'.http_build_query([
				'version'=>$versionId,
				'license'=>Utils::getLicenseKey(),
				'channel'=>Utils::getUpdateChannel(),
			]),
			'update_download_url' => $this->generateUrl('app_update_ajax_download'),
			'update_install_url' => $this->generateUrl('app_update_ajax_install'),
			'csrfToken' => CsrfToken::get(),
			'versionId' => $versionId,
			'changelog' => $changelog,
			'autoUpdateEnabled' => Utils::isAutoUpdateEnabled(),
			'updateChannel' => Utils::getUpdateChannel(),
			'previousVersions' => $previousVersions,
		]);
	}

	/**
	 * @Route("/", methods={"POST"}, name="_post")
	 * @param Request $request
	 * @return RedirectResponse
	 */
	public function developerOptions(Request $request): RedirectResponse
	{
		// Update-Kanal wechseln
		if ($request->request->has('updateChannel')) {
			Utils::setLocalEnvironment([
				'APP_UPDATE_CHANNEL' => $request->request->get('updateChannel')
			]);
		}

		// Installation markieren, dass Entwickleroptionen verwendet wurden
		$config = Config::getInstance();
		$config->set('tainted', true);
		return $this->redirectToRoute('app_update', [], 303);
	}

	/**
	 * @Route("/auto", name="_auto_get", methods={"HEAD","GET"})
	 * @return JSONResponse
	 */
	public function getAutoUpdate(Request $request): JSONResponse
	{
		return $this->json([
			'state' => Utils::isAutoUpdateEnabled(),
		]);
	}

	/**
	 * @Route("/auto", name="_auto", methods={"POST"})
	 * @return JSONResponse
	 */
	public function toggleAutoUpdate(Request $request): JSONResponse
	{
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			return $this->json([
				'result' => 'error',
				'message' => 'Invalid CSRF token. Please reload the page and try again.'
			], 403);
		}

		$config = Config::getInstance()->set('enableAutoUpdate', $request->request->get('enableAutoUpdate') == 'true');

		return $this->json([
			'success' => true,
			'newState' => Utils::isAutoUpdateEnabled(),
		]);
	}

	/**
	 * Diese Methode gibt den Zieldateipfad der ZIP-Datei zurück.
	 * @return string
	 */
	private static function getZipDestinationFilename(): string
	{
		/** @var Kernel $kernel */
		global $kernel;
		return $kernel->getProjectDir().'/var/update.zip';
	}

	/**
	 * Diese Methode gibt den Dateipfad des Symphony-Caches zurück.
	 * @return string
	 */
	private static function getCachePath(): string
	{
		/** @var Kernel $kernel */
		global $kernel;
		$env = preg_replace('/[^a-zA-Z0-9_-]/', '', $_ENV['APP_ENV']);
		return $kernel->getProjectDir().'/var/cache/'.$env;
	}

	/**
	 * Gibt einen Pfad für ein temporäres Verzeichnis zum Extrahieren zurück.
	 *
	 * @param string $suffix Verzeichnis-Suffix
	 * @return string Vollständiger Pfad zum temporären Verzeichnis
	 */
	private static function getTemporaryDir(string $suffix): string
	{
		/** @var Kernel $kernel */
		global $kernel;
		$suffix = preg_replace('%[\\/\0]%', '', $suffix);
		$result = $kernel->getProjectDir().'/var/cache/update.'.$suffix;
		return $result;
	}

	/**
	 * Diese Methode gibt den Dateipfad für die Fortschrittsdatei beim Download zurück.
	 * @return string
	 */
	private static function getDownloadProgressFilename(): string
	{
		/** @var Kernel $kernel */
		global $kernel;
		return $kernel->getProjectDir().'/public/update-progress-download.json';
	}

	/**
	 * @Route("/download", methods={"POST"}, name="_ajax_download")
	 * @param Request $request
	 * @return JSONResponse
	 */
	public function download(TranslatorInterface $translator, LoggerInterface $logger, UpdateComponent $updater, Request $request): JSONResponse
	{
		set_time_limit(600);

		$logger->logInfo('Update', "Starting update...");

		$zipPath = $this->getZipDestinationFilename();

		$forceVersionId = $request->request->get('forceVersionId');
		if ($forceVersionId) {
			Config::getInstance()->set('enableAutoUpdate', false);
		}

		try {
			CsrfToken::get()->checkRequest($request);
			session_commit();
			$success = $updater->downloadUpdate($zipPath, $this->getDownloadProgressFilename(), $forceVersionId);
			if (!$success) {
				return $this->json([
					'result' => 'error',
					'message' => $translator->trans('No update available')
				]);
			}
			$stat = stat($zipPath);
		}
		catch (CsrfTokenException $e) {
			return $this->json([
				'result' => 'error',
				'message' => 'Invalid CSRF token. Please reload the page and try again.'
			], 403);
		}
		catch (TempFileNotWritableException $e) {
			$logger->logException('Update', $e, "Update aborted because of error");
			$fileName = $e->getMessage();
			$cause = $e->getPrevious()->getMessage();
			$message = $translator->trans(
				'Could not download update. Error message was "%message%".'."\n".'Please check the permissions of the var directory.',
				[ '%message%'=> $cause ]
			);
			$logger->logError('Update', "Update aborted because of errors");
			return $this->json([
				'result' => 'error',
				'message' => $message,
			], 500);
		}
		catch (Throwable $e) {
			$logger->logException('Update', $e, "Update aborted because of error");
			return $this->json([
				'result' => 'error',
				'message' => $e->getMessage()
			], 500);
		}
		return $this->json([
			'result' => 'success',
			'size' => $stat['size']
		]);
	}

	/**
	 * @Route("/install/", methods={"POST"}, name="_ajax_install")
	 *
	 * Vorbereiten des Updates, nachdem das ZIP heruntergeladen wurde.
	 *
	 * @param TranslatorInterface $translator
	 * @param Request $request
	 * @return JSONResponse
	 */
	public function installBeginAction(LoggerInterface $logger, TranslatorInterface $translator, Request $request): JSONResponse
	{
		$updater = new UpdateComponent;
		$zipPath = $this->getZipDestinationFilename();

		// CSRF-Token prüfen
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			return $this->json([
				'result' => 'error',
				'message' => 'Invalid CSRF token. Please reload the page and try again.'
			], 403);
		}

		session_commit();

		$message = null;
		$exception = null;
		try {
			$result = $updater->prepareUpdateExtraction($zipPath);
			$token = $result['token'];
			$fileCount = $result['fileCount'];
		}
		catch (ZipArchiveCorruptedException $e) {
			$message = $translator->trans('Update archive corrupted. Please try again later.');
			$exception = $e;
		}
		catch (ZipArchiveMemoryLimitException $e) {
			$message = $translator->trans('Memory limit exceeded. Please increase the PHP memory limits.');
			$exception = $e;
		}
		catch (ZipArchiveNoFileException $e) {
			$message = $translator->trans('No update downloaded.');
			$exception = $e;
		}
		catch (ZipArchiveAccessException $e) {
			$message = $translator->trans('Cannot open downloaded archive. Please check the server file permissions.');
			$exception = $e;
		}
		catch (ZipArchiveException $e) {
			$message = $translator->trans('An error occured while opening the update archive. Please try again later.');
			$exception = $e;
		}
		catch (TempFileNotWritableException $e) {
			$message = $translator->trans('Cannot create temporary directory in var/cache/');
			$exception = $e;
		}
		catch (Throwable $e) {
			$message = $e->getMessage();
			$exception = $e;
		}

		if ($message) {
			$logger->logException('Update', $exception, "Update aborted because of error");
			return $this->json([
				'result' => 'error',
				'message' => $message
			], 500);
		}

		return $this->json([
			'result' => 'success',
			'token' => $token,
			'total' => $fileCount,
		]);
	}

	/**
	 * @Route("/install/{suffix}/{offset<\d+>}", methods={"POST"}, name="_ajax_install_extract")
	 *
	 * Extrahieren der Dateien aus dem ZIP
	 *
	 * @param TranslatorInterface $translator
	 * @param Request $request
	 * @return JSONResponse
	 */
	public function installExtractAction(string $suffix, int $offset, LoggerInterface $logger, TranslatorInterface $translator, Request $request): JSONResponse
	{
		$updater = new UpdateComponent;
		$zipPath = $this->getZipDestinationFilename();

		// CSRF-Token prüfen
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			return $this->json([
				'result' => 'error',
				'message' => 'Invalid CSRF token. Please reload the page and try again.'
			], 403);
		}

		session_commit();
		set_time_limit(300);

		// Entpacken mit Zeitlimit 3 Sekunden
		try {
			$result = $updater->extractUpdate($zipPath, $suffix, $offset, 3);
			$done = $result['done'];
			$nextOffset = $result['nextOffset'];
			$countFiles = $result['total'];
		}
		catch (ZipArchiveExtractException $e) {
			$logger->logException('Update', $e, "Update aborted because of error");
			return $this->json([
				'result' => 'error',
				'message' =>  $translator->trans('Extracting %file% failed. Update aborted.', ['%file%'=>$e->getMessage()])
			], 500);
		}
		catch (ZipArchiveException $e) {
			$logger->logException('Update', $e, "Update aborted because of error");
			return $this->json([
				'result' => 'error',
				'message' => $translator->trans('Error while extracting the update file')
			], 403);
		}
		catch (TempFileNotWritableException $e) {
			$logger->logException('Update', $e, "Update aborted because of error");
			return $this->json([
				'result' => 'error',
				'message' =>  $translator->trans('Writing temporary file %file% failed. Update aborted.', ['%file%'=>$e->getMessage()])
			], 500);
		}

		if ($done) {
			return $this->json([
				'result' => 'success',
				'done' => true,
				'total' => $countFiles,
			]);
		}
		else {
			return $this->json([
				'result' => 'success',
				'done' => false,
				'nextOffset' => $nextOffset,
				'total' => $countFiles,
			]);
		}
	}

	/**
	 * @Route("/install/{suffix}/finish", methods={"POST"}, name="_ajax_install_finish")
	 *
	 * Abschließen des Updates
	 *
	 * @param TranslatorInterface $translator
	 * @param Request $request
	 * @return JSONResponse
	 */
	public function installFinishAction(string $suffix, LoggerInterface $logger, TranslatorInterface $translator, Request $request): JSONResponse
	{
		$zipPath = $this->getZipDestinationFilename();
		$message = (string)$translator->trans('update succeeded');
		$oldVersion = Utils::getVersionName();

		// CSRF-Token prüfen
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			return $this->json([
				'result' => 'error',
				'message' => 'Invalid CSRF token. Please reload the page and try again.'
			], 403);
		}

		$updater = new UpdateComponent;

		// Output-Buffering ausschalten.
		@ob_end_clean();

		session_commit();
		ignore_user_abort(true);
		set_time_limit(300);

		// Update abschließen und Cache leeren
		$updater->finishUpdate($zipPath, $suffix);
		$newVersion = Utils::getVersionName();
		$logger->logInfo('Update', "Update from $oldVersion to $newVersion finished");

		$filesystem = new Filesystem();
		$projectDir = $this->getParameter('kernel.project_dir');

		//Bapperl auf off setzen im Menü
		$_SESSION['update_notifier'] = false;

		//Embeddings automatisch umstellen - needs testing... - derzeit noch auskommentiert...
		//$embeddings = new Embeddings();
		//$embeddings->autoUpdate();

		// Manuelles Ausgeben mit echo+exit ist notwendig
		// weil sich durch das Update Klassen verändert haben
		// können.
		header('Content-Type: application/json');
		header('Clear-Site-Data: "cache"');
		echo(json_encode([
			'result' => 'success',
			'message' => $message,
			'oldVersion' => $oldVersion,
			'newVersion' => $newVersion
		]));
		exit();
	}

	/**
	 * @Route("/install/{suffix}/finish", methods={"GET"}, name="_ajax_install_finish_page")
	 *
	 * Dummy-Endpoint nach Abschließen des Updates. Dient dem Cache-Regenerieren.
	 *
	 * @param TranslatorInterface $translator
	 * @param Request $request
	 * @return JSONResponse
	 */
	public function installFinishPage(string $suffix, TranslatorInterface $translator, Request $request): JSONResponse
	{
		return $this->json(['status'=>'success']);
	}
}
