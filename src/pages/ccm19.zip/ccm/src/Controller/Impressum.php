<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\LegalText;
use App\Model\Locale;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class Impressum extends DomainDependantController
{
	/**
	 * @Route("/domains/{_domainId}/impressum", name="app_impressum")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function imprint(Request $request, TranslatorInterface $translator): Response
	{
		/** @var Locale[] $locales */
		$locales = Locale::enabledLocales();
		$imprintL10n = (array)$request->request->get('imprint_l10n');
		$imprintScheme = $request->request->get('imprintScheme');
		$imprintUrl = (array)$request->request->get('imprintUrl');

		if ($request->getRealMethod() === 'POST') {
			foreach ($locales as $locale) {
				/** @var LegalText|null $legalText */
				$legalText = LegalText::byLocale($locale);

				if ($legalText === null) {
					$legalText = LegalText::create()->setLocale($locale);
				}

				$legalText
					->setImprint($imprintL10n[$locale->getId()] ?? '')
					->setImprintScheme($imprintScheme ?? '')
					->setImprintUrl($imprintUrl[$locale->getId()] ?? '')
				;
			}

			try {
				CsrfToken::get()->checkRequest($request);
				LegalText::flush();

				$this->addFlash('success', $translator->trans('Localizations have been written successfully.'));
				return $this->redirectToRoute('app_impressum');
			}
			catch (ConfigNotWritableException $exception) {
				$this->addFlash('danger', $translator->trans('Localizations could not be written to disk.'));
			}
			catch (CsrfTokenException $exception) {
				$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			}
		}
		foreach ($locales as $locale) {
			$legalText = LegalText::byLocale($locale);
			if ($legalText === null) {
				$legalText = LegalText::create()->setLocale($locale);
			}
			break;
		}

		return $this->render('impressum/index.html.twig', [
			'locales' => $locales,
			'legalTexts' => LegalText::all(),
			'csrfToken' => CsrfToken::get(),
			'imprintScheme' =>$legalText->getImprintScheme()
		]);
	}
}
