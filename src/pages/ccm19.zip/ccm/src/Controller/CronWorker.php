<?php

namespace App\Controller;

use App\Component\Cron\Cron;
use App\Component\Cron\Job;
use App\Config;
use App\Model\User;
use App\Utils;
use App\Component\Curl;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class CronWorker extends ExternalController
{
	/**
	 * @required
	 */
	public function init()
	{
		// Einige Klassen laden, damit der Autoloader während eines Updates nicht anspringen muss.
		class_exists('\\App\\Component\\Curl', true);
		class_exists('\\Curl\\Curl', true);
		class_exists('\\Symfony\\Bundle\\SwiftmailerBundle\\EventListener\\EmailSenderListener', true);
		class_exists('\\Symfony\\Component\\HttpKernel\\EventListener\\ExceptionListener', true);
		class_exists('\\Symfony\\Component\\HttpKernel\\Log\\Logger', true);
	}

	/**
	 * @Route("/cron", name="app_cron", methods={"OPTIONS", "POST"})
	 * @param Request $request
	 * @return Response
	 */
	public function cron(Request $request): Response
	{
		ignore_user_abort(true);
		set_time_limit(300);

		// Sicherstellen, dass immer nur ein Cronjob zeitgleich abgearbeitet wird
		$lockf = fopen(Utils::getVarDir().'/.cron.lock', 'wb');
		flock($lockf, LOCK_EX);

		// Immer auf frischen Daten arbeiten; Jobs in Warteschlange berücksichtigen
		$config = Config::getInstance();
		$config->reload();

		try {
			/** @var Job[] $jobs */
			$jobs = Cron::dueJobs();

			// Wenn es fällige Aufgaben gibt, eine zufällig ausgewählte ausführen.
			if ($jobs) {
				shuffle($jobs);
				reset($jobs)->run($request);
			}

		}
		finally {
			// Konfiguration schreiben, damit sie im nächsten Cronjob direkt verfügbar ist
			$config->flush();

			// Nächsten Cronjob freigeben
			flock($lockf, LOCK_UN);
			fclose($lockf);
		}

		$this->runDeferredJobs($request);

		return new Response('', 204);
	}

	/**
	 * @Route("/cron/{jobName}", name="app_cron_job", methods={"OPTIONS", "GET", "POST"})
	 * @param Request $request
	 * @return Response
	 */
	public function cronOne(Request $request, string $jobName): Response
	{
		ignore_user_abort(true);
		set_time_limit(300);

		// Sicherstellen, dass immer nur ein Cronjob zeitgleich abgearbeitet wird
		$lockf = fopen(Utils::getVarDir().'/.cron.lock', 'wb');
		flock($lockf, LOCK_EX);

		// Immer auf frischen Daten arbeiten; Jobs in Warteschlange berücksichtigen
		$config = Config::getInstance();
		$config->reload();

		try {
			/** @var Job[] $jobs */
			$job = Cron::jobByName($jobName);

			if ($job) {
				$job->run($request);
			} else {
				return $this->json(['error'=>'404 Not found', 'description'=>'No cronjob with this name'], 404);
			}
		}
		finally {
			// Konfiguration schreiben, damit sie im nächsten Cronjob direkt verfügbar ist
			$config->flush();

			// Nächsten Cronjob freigeben
			flock($lockf, LOCK_UN);
			fclose($lockf);
		}

		$this->runDeferredJobs($request);

		return new Response('', 204);
	}

	/**
	 * @param Request $request
	 */
	private function runDeferredJobs(Request $request): void
	{
		foreach (Cron::deferredJobs() as $job) {
			$url = $this->generateUrl('app_cron_job', [
				'jobName' => $job->getName(),
				'apiKey' => $request->query->get('apiKey'),
				'domain' => $request->query->get('domain'),
			], UrlGeneratorInterface::ABSOLUTE_URL);

			$f = @fopen('/dev/null', 'ab');
			if (!$f) {
				$f = fopen('php://temp', 'wb');
			}
			$curl = new Curl();
			$curl->setOpt(CURLOPT_CONNECTTIMEOUT, 4);
			$curl->setOpt(CURLOPT_TIMEOUT, 4);
			$curl->setOpt(CURLOPT_RETURNTRANSFER, false);
			$curl->setOpt(CURLOPT_FILE, $f);
			$curl->post($url, []);
			fclose($f);
		}
	}
}
