<?php

namespace App\Controller\Settings;

use App\Config;
use App\Controller\AdminController;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class Network extends AdminController
{
	/**
	 * @Route("/settings/network", methods={"HEAD", "GET"}, name="app_settings_network")
	 * @param Request $request
	 * @return Response
	 */
	public function networkSettings(Request $request): Response
	{
		$config = Config::getInstance();

		return $this->render('settings/network/index.html.twig', [
			'forceHttpsConnection' => $config->isForceHttpsConnection(),
			'proxyUrl' => $_ENV['APP_PROXY'] ?? ''
		]);
	}

	/**
	 * @Route("/settings/network", methods={"POST"}, name="app_settings_network_save")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function networkSettingsSave(Request $request, TranslatorInterface $translator): Response
	{
		$config = Config::getInstance();

		// Force-HTTPS setzen
		$config
			->setForceHttpsConnection((bool)$request->request->get('forceHttpsConnection'))
			->flush();

		// Proxy setzen
		if (!empty($_ENV['APP_PROXY']) or $request->request->get('proxyUrl')) {
			Utils::setLocalEnvironment([
				'APP_PROXY' => $request->request->get('proxyUrl')
			]);
		}

		$this->addFlash('success', $translator->trans('Settings have been saved.'));

		return $this->redirectToRoute('app_settings_network', [], 303);
	}
}
