<?php

namespace App\Controller\Settings;

use App\Component\ThumbnailExtractor\ThumbnailExtractorService;
use App\Controller\DomainDependantController;
use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/domains/{_domainId}/settings/frontend")
 */
class Frontend extends DomainDependantController
{
	/**
	 * @Route("", methods={"GET", "HEAD"}, name="app_settings_frontend")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function frontendSettings(Request $request, TranslatorInterface $translator): Response
	{
		/** @var User $user */
		$user = User::loggedInUser();
		/** @var Domain $domain */
		$domain = Domain::activeDomain();

		$activeWidgetsCount = Domain::frontendWidgetCountForAllDomains();
		$domainMaxCount = $user->getMaxDomainCount();

		$allowFrontendWidget = Utils::isExtendedEdition()
			? $domainMaxCount < 0 || $activeWidgetsCount < $domainMaxCount || $domain->isFrontendWidgetEnabled()
			: true;

		if ($allowFrontendWidget == false) {
			$this->addFlash('warning', $translator->trans('You cannot activate the frontend widget at the moment due to insufficient domains in your plan.'));
		}

		if ($domain->isFrontendWidgetEnabled())
		{
			$domain
				->setFrontendLegalEnabled(true)
				->flush();
		}

		return $this->render('settings/frontend/index.html.twig', [
			'allowFrontendWidget' => $allowFrontendWidget,
			'frontendLegalEnabled' => $domain->isFrontendLegalEnabled()
		]);
	}

	/**
	 * @Route("", methods={"POST"}, name="app_settings_frontend_post")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function saveFrontendSettings(Request $request, TranslatorInterface $translator, ThumbnailExtractorService $thumbnails): Response
	{
		/** @var User $user */
		$user = User::loggedInUser();
		/** @var Domain $domain */
		$domain = Domain::activeDomain();
		Domain::beginWrite();

		if ($request->request->get('action') == 'clearThumbnails')
		{
			$thumbnails->clearCache($user);
			$this->addFlash('success', $translator->trans('Thumbnail cache was cleared.'));
			return $this->redirectToRoute('app_settings_frontend', [], 303);
		}

		$activeWidgetsCount = Domain::frontendWidgetCountForAllDomains();
		$domainMaxCount = $user->getMaxDomainCount();

		$allowFrontendWidget = Utils::isExtendedEdition()
			? $domainMaxCount < 0 || $activeWidgetsCount < $domainMaxCount || $domain->isFrontendWidgetEnabled()
			: true;

		$allowFrontendLegal = $domain->isFrontendLegalEnabled();
		if (!$allowFrontendLegal)
		{
			$allowFrontendLegal = (bool)$request->request->get('enableFrontendLegal');
		}


		// Iframe-Ausnahmen
		$markers = explode("\n", trim((string)$request->request->get('iframeMarkers', '')));
		$markers = array_filter($markers, function ($line) {
			return trim($line) !== '';
		});
		$markers = array_values(array_map(function ($line) {
			return trim($line);
		}, $markers));

		if ($domain->isManagementStructurePreLegalConsent()) {
			$domain->setManagementStructure($request->request->get('managementStructure', Domain::MANAGEMENT_STRUCTURE_COOKIE));
		}

		$domain
			->setFrontendWidgetEnabled($allowFrontendWidget && (bool)$request->request->get('enableFrontendWidget'))
			->setManagementStructurePreLegalConsent($domain->isManagementStructurePreLegalConsent() || (bool)$request->request->get('managementStructurePreLegalConsent'))
			->setFrontendLegalEnabled($allowFrontendLegal)
			->setDeleteUnknownCookies((bool)$request->request->get('deleteUnkownCookies'))
			->setDeleteUnknownCookiesForceReload((bool)$request->request->get('deleteUnkownCookiesForceReload'))
			->setIframesBlocked((bool)$request->request->get('blockIframes'))
			->setRememberIframeConsentPerDomain((bool)$request->request->get('rememberIframeConsentPerDomain'))
			->setIframeBlockMode($request->request->get('iframeBlockMode'))
			->setNewScriptsBlocked((bool)$request->request->get('blockScripts'))
			->setSameDomainScriptsBlocked((bool)$request->request->get('blockSameDomainScripts'))
			->setInlineScriptsBlocked((bool)$request->request->get('blockInlineScripts'))
			->setIframeMarkers($markers)
			->setCodeMinification((bool)$request->request->get('codeMinification'))
			->save();

		$this->addFlash('success', $translator->trans('Settings have been saved.'));

		return $this->redirectToRoute('app_settings_frontend', [], 303);
	}
}
