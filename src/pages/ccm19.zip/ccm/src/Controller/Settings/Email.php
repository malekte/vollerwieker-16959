<?php

namespace App\Controller\Settings;

use App\Config;
use App\Component\MailerConfigurator;
use App\Controller\AdminController;
use App\Exception\CsrfTokenException;
use App\MailMessage;
use App\Model\CsrfToken;
use App\Utils;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JSONResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use Swift_Mailer;

/**
 * @Route("/settings/email", name="app_setting_email")
 */
class Email extends AdminController
{

	/**
	 * @Route("", name="", methods={"GET","HEAD"})
	 * @return Response
	 */
	public function showSettings(Request $request): Response
	{
		$config = Config::getInstance();

		$mailer_url = $_ENV['MAILER_URL'] ?? 'null://localhost';
		$mailer_data = parse_url($mailer_url);
		$mailer_options = [];
		parse_str($mailer_data['query'] ?? '', $mailer_options);

		//Alle Variablen fürs Template setzen
		$variables = [
			'email' => $config->get('email'),
			'senderEmail' => $config->get('senderEmail'),
			'senderName' => $config->get('senderName'),
			'replyTo' => $config->get('replyTo'),
			'emailScheme' => $mailer_data['scheme'],
			'emailHost' => $mailer_data['host'] ?? '',
			'emailPort' => $mailer_data['port'] ?? '',
			'emailUser' => $mailer_options['username'] ?? '',
			'emailPass' => $mailer_options['password'] ?? '',
			'emailEncryption' => $mailer_options['encryption'] ?? '',
			'emailAuthMode' => $mailer_options['auth_mode'] ?? '',
			'csrfToken' => CsrfToken::get(),
			'sendQuotaCopies' => (bool)$config->get('sendQuotaCopies'),
			'sendUpdateNotifications' => (bool)$config->get('sendUpdateNotifications', false),
			'max_traffic_email_betreff' => $config->get("max_traffic_email_betreff"),
			'max_traffic_email_content' => $config->get("max_traffic_email_content"),
			'sub_max_traffic_email_betreff' => $config->get("sub_max_traffic_email_betreff"),
			'sub_max_traffic_email_content' => $config->get("sub_max_traffic_email_content"),
			'sub_update_email_betreff' => $config->get("sub_update_email_betreff"),
			'sub_update_email_content' => $config->get("sub_update_email_content"),
		];

		return $this->render('settings/email/index.html.twig', $variables);
	}

	/**
	 * @Route("", name="_post", methods={"POST"})
	 * @return Response
	 */
	public function saveSettings(Request $request, MailerConfigurator $configurator, TranslatorInterface $translator): Response
	{
		try {
			(CsrfToken::get())->checkRequest($request);
		} catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			return $this->redirectToRoute('app_setting_email', [], 303);
		}

		$config = Config::getInstance();

		if (Utils::isExtendedEdition())
		{
			if (empty($request->request->get('max_traffic_email_betreff')) || empty($request->request->get('max_traffic_email_content')))
			{
				$this->addFlash('danger', $translator->trans('Subject or content of a mail template is empty. Please fill out these fields.'));
				return $this->redirectToRoute('app_setting_email', [], 303);
			}
			$config->set('max_traffic_email_betreff', $request->request->get('max_traffic_email_betreff'));
			$config->set('max_traffic_email_content', $request->request->get('max_traffic_email_content'));
			$config->set('sub_max_traffic_email_betreff', $request->request->get('sub_max_traffic_email_betreff'));
			$config->set('sub_max_traffic_email_content', $request->request->get('sub_max_traffic_email_content'));
			$config->set('sub_update_email_betreff', $request->request->get('sub_update_email_betreff'));
			$config->set('sub_update_email_content', $request->request->get('sub_update_email_content'));
			$config->set('sendQuotaCopies', (bool)$request->request->get('sendQuotaCopies'));
			$config->set('sendUpdateNotifications', (bool)$request->request->get('sendUpdateNotifications'));
		}

		$scheme = $request->request->get('emailScheme', 'null');
		$host = $request->request->get('emailHost');
		$port = $request->request->get('emailPort');
		$user = $request->request->get('emailUser', '');
		$pass = $request->request->get('emailPass', '');
		$encryption = $request->request->get('emailEncryption', '');
		$auth_mode = $request->request->get('emailAuthMode', '');

		// Absender und Reply-To setzen
		$config->set('senderEmail', $request->request->get('senderEmail'));
		$config->set('senderName', $request->request->get('senderName'));
		$config->set('replyTo', $request->request->get('replyTo'));

		// Mailer-Konfiguration setzen
		$configurator->setMailer($scheme, $host, $port, $encryption, $auth_mode, $user, $pass);

		$config->flush();

		return $this->redirectToRoute('app_setting_email', [], 303);
	}

	/**
	 * @Route("/sendTestEmail", name="_sendmail", methods={"POST"})
	 * @return JSONResponse
	 */
	public function sendTestEmail(Request $request, Swift_Mailer $mailer, TranslatorInterface $translator)
	{
		$config = Config::getInstance();
		$recipient = $request->request->get('recipient');

		if (!$recipient) {
			return $this->json(['error'=>'no recipient'], 400);
		}

		$message = (new MailMessage($translator->trans('CCM19 Test Email')))
		->setTo($recipient)
		->setBody($translator->trans("This is a CCM19 test mail, sent to check if emails sent from CCM19 can be delivered."), 'text/plain');

		try {
			$mailer->send($message);
		} catch (Exception $e) {
			return $this->json(['status'=>'failed', 'error'=>htmlspecialchars($e->getMessage()), 'errno'=>$e->getCode()]);
		}
		return $this->json(['status'=>'ok']);
	}

	/**
	 * @Route("/autoconfig", name="_autoconfig", methods={"POST"})
	 * @return JSONResponse
	 * @phan-suppress PhanTypeInvalidDimOffset, PhanTypeMismatchArgumentInternal
	 */
	public function smtpAutoconfig(Request $request, MailerConfigurator $configurator)
	{
		try {
			(CsrfToken::get())->checkRequest($request);
		} catch (CsrfTokenException $e) {
			return $this->json(['error'=>'invalid csrf token'], 403);
		}

		$result = [];
		$email = $request->request->get('email');
		$host = $request->request->get('host');
		$domain = substr($email, strrpos($email, '@')+1);

		if (!$domain) {
			return $this->json(['error'=>'no email domain', 400]);
		}

		$urls = [
			'https://autoconfig.%s/mail/config-v1.1.xml?emailaddress=%s',
			'https://%s/.well-known/autoconfig/mail/config-v1.1.xml',
			'https://autoconfig.%s/mail/config-v1.1.xml',
			'http://%s/.well-known/autoconfig/mail/config-v1.1.xml',
			'https://autoconfig.thunderbird.net/v1.1/%s',
		];
		$config = [];
		foreach ($urls as $url)
		{
			$url = sprintf($url, rawurlencode($domain), rawurlencode($email));
			$config = $configurator->readConfigXml($url);
			if ($config) {
				break;
			}
		}

		if ($config) {
			if (isset($config[strtolower($domain)])) {
				$data = $config[strtolower($domain)][0];
			}
			else {
				reset($config);
				$data = current($config)[0];
			}

			$host = $configurator->autoconfigReplaceVars($data['hostname'], $email);
			$port = $data['port'];
			$ssl = (strtoupper($data['socketType']) == 'SSL');
			$starttls = (strtoupper($data['socketType']) == 'STARTTLS');
			$username = $configurator->autoconfigReplaceVars($data['username'], $email);
			$testdata = $configurator->testEmailServer($host, $port, $ssl);

			if ($testdata && $testdata['auth']) {
				// Direkten Test und Autoconfig-Datei abgleichen
				if (isset($data['authentication']['password-encrypted']) and isset($testdata['auth']['CRAM-MD5'])) {
					$auth = 'cram-md5';
				}
				elseif (isset($data['authentication']['secure']) and isset($testdata['auth']['CRAM-MD5'])) {
					$auth = 'cram-md5';
				}
				elseif (isset($data['authentication']['password-cleartext']) and isset($testdata['auth']['LOGIN'])) {
					$auth = 'login';
				}
				elseif (isset($data['authentication']['password-cleartext']) and isset($testdata['auth']['PLAIN'])) {
					$auth = 'plain';
				}
				elseif (isset($data['authentication']['oauth2'])) {
					$auth = 'oauth';
				}
				elseif (isset($data['authentication']['client-ip-address'])) {
					$auth = 'null';
				}
				elseif (isset($data['authentication']['none'])) {
					$auth = 'null';
				}
				else {
					$auth = 'plain';
				}
			}
			else {
				// Wenn kein direkter Test möglich, beste Variante aus der Autoconfig-Datei raten
				if (isset($data['authentication']['password-encrypted'])) {
					$auth = 'cram-md5';
				}
				elseif (isset($data['authentication']['secure'])) {
					$auth = 'cram-md5';
				}
				elseif (isset($data['authentication']['password-cleartext'])) {
					$auth = 'login';
				}
				elseif (isset($data['authentication']['oauth2'])) {
					$auth = 'oauth';
				}
				elseif (isset($data['authentication']['client-ip-address'])) {
					$auth = 'null';
				}
				elseif (isset($data['authentication']['none'])) {
					$auth = 'null';
				}
				else {
					$auth = 'plain';
				}
			}
			$result = [
				'emailHost' => $host,
				'emailPort' => $port,
				'emailEncryption' => ($ssl ? 'ssl' : ($starttls ? 'tls' : 'null')),
				'emailAuthMode' => $auth,
				'emailUser' => $username,
			];
		}
		else {
			// E-Mail-Server raten, wenn keine Autoconfig-Informationen
			if ($host) {
				$hosts = [$host, 'mail.'.$domain, $domain];
			}
			else {
				$hosts = ['mail.'.$domain, $domain];
			}
			$data = null;
			foreach ($hosts as $server) {
				$data = $configurator->testEmailServer($server, 587, false);
				if ($data) {
					$data['host'] = $server;
					$data['port'] = 587;
					$data['ssl'] = false;
					break;
				}
				$data = $configurator->testEmailServer($server, 465, true);
				if ($data) {
					$data['host'] = $server;
					$data['port'] = 465;
					$data['ssl'] = true;
					break;
				}
				$data = $configurator->testEmailServer($server, 25, false);
				if ($data) {
					$data['host'] = $server;
					$data['port'] = 25;
					$data['ssl'] = false;
					break;
				}
			}
			if ($data) {
				// Host zu IP und zurück auflösen, um den *richtigen* Hostnamen zu bekommen
				$resolvedHost = @gethostbyaddr(gethostbyname($data['host']));
				if ($resolvedHost) {
					$data['host'] = $resolvedHost;
				}
				$result = [
					'emailHost' => $data['host'],
					'emailPort' => $data['port'],
					'emailEncryption' => ($data['ssl'] ? 'ssl' : ($data['starttls'] ? 'tls' : 'null')),
					'emailAuthMode' => ($data['auth']['CRAM-MD5'] ?? $data['auth']['LOGIN'] ?? $data['auth']['PLAIN']),
				];
			}
		}

		return $this->json($result, ($result ? 200 : 404));
	}
}
