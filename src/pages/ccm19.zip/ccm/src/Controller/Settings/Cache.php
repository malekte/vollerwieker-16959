<?php

namespace App\Controller\Settings;

use App\Component\Update;
use App\Component\ThumbnailExtractor\ThumbnailExtractorService;
use App\Config;
use App\Controller\AdminController;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use FilesystemIterator;
use DirectoryIterator;

class Cache extends AdminController
{
	/**
	 * @Route("/settings/cache", methods={"HEAD", "GET"}, name="app_settings_cache")
	 * @param Request $request
	 * @return Response
	 */
	public function cacheView(Request $request): Response
	{
		$config = Config::getInstance();

		$cacheDir = Utils::getCacheDir();

		$cacheTotal = $this->calculateDirSize($cacheDir);
		$tmplSize = $this->calculateDirSize($cacheDir.'/twig');
		$i18nSize = $this->calculateDirSize($cacheDir.'/translations');
		$thumbSize = $this->calculateDirSize($cacheDir.'/thumbnails');
		$symfonySize = $cacheTotal - $tmplSize - $i18nSize - $thumbSize;

		$opCacheSize = $this->getOpcacheSize();
		$cacheTotal += $opCacheSize;

		return $this->render('settings/cache/index.html.twig', [
			'tmplSize' => $tmplSize,
			'i18nSize' => $i18nSize,
			'thumbSize' => $thumbSize,
			'symfonySize' => $symfonySize,
			'opCacheSize' => $opCacheSize,
			'cacheTotal' => $cacheTotal,
		]);
	}

	private function getOpcacheSize(): int
	{
		if (!function_exists('opcache_get_status')) {
			return 0;
		}
		$baseDir = Utils::getBaseDir();
		$size = 0;

		$status = opcache_get_status();
		foreach ($status['scripts'] as $script) {
			if (strpos($script['full_path'], $baseDir) === 0) {
				$size += $script['memory_consumption'];
			}
		}
		return $size;
	}

	private function calculateDirSize(string $path): int
	{
		if (file_exists($path)) {
			return $this->_calculateDirSizeRecurse(new FilesystemIterator($path));
		} else {
			return 0;
		}
	}

	private function _calculateDirSizeRecurse(DirectoryIterator $it): int
	{
		$size = 0;

		foreach ($it as $fileinfo) {
			if ($fileinfo->isLink()) {
				continue;
			}
			elseif ($fileinfo->isDir()) {
				$size += $this->_calculateDirSizeRecurse(new FilesystemIterator($fileinfo->getPathname()));
			}
			elseif ($fileinfo->isFile()) {
				$size += $fileinfo->getSize();
			}
		}

		return $size;
	}

	/**
	 * @Route("/settings/cache", methods={"POST"}, name="app_settings_cache_save")
	 * @param Request $request
	 * @param ?TranslatorInterface $translator
	 * @param ?ThumbnailExtractorService $thumbnails
	 * @return Response
	 */
	public function cacheSave(Request $request, ?TranslatorInterface $translator, ?ThumbnailExtractorService $thumbnails): Response
	{
		$trans = ($translator) ? [$translator, 'trans'] : function ($x) { return $x; };

		$clear = $request->request->get('clear');

		if ($clear == 'all') {
			$updater = new Update;
			$updater->deleteFullCacheOnExit();

			if (function_exists('opcache_reset')) {
				opcache_reset();
			}

			$this->addFlash('success', $trans('All CCM19 caches were cleared.'));
			$response = $this->redirectToRoute('app_settings_cache', [], 303);
			$response->headers->set('Clear-Site-Data', '"cache"');
			return $response;
		}

		if ($clear == 'opcache') {
			if (function_exists('opcache_reset')) {
				opcache_reset();
				$this->addFlash('success', $trans('Zend OPcache was reset.'));
			}
			else {
				$this->addFlash('danger', $trans('Zend OPcache could not be cleared.'));
			}
			return $this->redirectToRoute('app_settings_cache', [], 303);
		}

		if ($clear == 'thumbnails') {
			if ($thumbnails) {
				$thumbnails->clearCache();
				$this->addFlash('success', $trans('The thumbnail caches of all users were cleared.'));
			} else {
				$this->addFlash('danger', $trans('An error occured while clearing the thumbnail caches. Please try to clear all caches.'));
			}
			return $this->redirectToRoute('app_settings_cache', [], 303);
		}

		return $this->redirectToRoute('app_settings_cache', [], 303);
	}
}
