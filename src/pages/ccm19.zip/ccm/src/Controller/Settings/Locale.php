<?php

namespace App\Controller\Settings;

use App\Controller\DomainDependantController;
use App\Exception\LocaleAlreadyExistsException;
use App\Model\Locale as LocaleModel;
use App\Model\Language as Language;
use App\Model\User;
use App\Model\Purpose;
use Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/domains/{_domainId}/settings/locale", name="app_setting_locale_")
 */
class Locale extends DomainDependantController
{
	/**
	 * @Route("", name="list")
	 * @return Response
	 */
	public function listLocales(): Response
	{
		$locales = LocaleModel::all();

		return $this->render('settings/locale/list.html.twig', [
			'user' => User::loggedInUser(),
			'locales' => $locales,
		]);
	}

	/**
	 * @Route("/new", name="new")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function createLocale(Request $request, TranslatorInterface $translator): Response
	{
		if ($request->getRealMethod() === 'POST') {
			$localeName = $request->get('locale_name');
			$fields = self::getStandardFields($translator);

			try {
				$locale = LocaleModel::create($localeName);

				$locale
					->setEnabled((bool)$request->request->get('localeEnabled'))
				;

				// Alle Daten in den Feldern speichern
				foreach ($fields as $fieldset) {
					foreach ($fieldset as $field) {
						$setter = 'set'.preg_replace_callback('/(?:^|_)([a-z])/',
							function ($match) { return strtoupper($match[1]); },
							$field['field_id']
						);
						$value = trim($request->request->get($field['field_id'], ''));
						if (strpos($setter, 'setPurposeName-') === 0) {
							$purpose = Purpose::find(substr($setter, 15));
							$setter = substr($setter, 0, 14);
							$locale->$setter($purpose, $value);
						} elseif (preg_match('~^setPurposeDescription-(?<purposeId>[0-9a-f]+)$~', $setter, $match)) {
							if ($purpose = Purpose::find($match['purposeId'])) {
								$locale->setPurposeDescription($purpose, $value);
							}
						} else {
							$locale->$setter($value);
						}
					}
				}
				$locale->save();

				$this->addFlash('success',
					$translator->trans('Locale %locale% has been updated.', ['%locale%' => $localeName])
				);

				return $this->redirectToRoute('app_setting_locale_list');
			}
			catch (LocaleAlreadyExistsException $e) {
				$this->addFlash('danger',
					$translator->trans('Locale %locale% already exists.', ['%locale%' => $localeName])
				);
			}
			catch (Exception $e) {
				$this->addFlash('danger',
					$translator->trans('An unknown error has occured.')
				);
			}
		}

		$fields = self::getStandardFields($translator);
		$fields = array_map(function ($fieldset) use ($request) {
			return array_map(function ($field) use ($request) {
					$field['user_input'] = $request->request->get($field['field_id'], '');
					return $field;
				}, $fieldset);
		}, $fields);

		$used_names = array_map(function ($item) { return $item->getName(); }, LocaleModel::all());

		return $this->render('settings/locale/new.html.twig', [
			'user' => User::loggedInUser(),
			'fields' => $fields,
			'used_names' => $used_names,
			'languages' => Language::all(),
			'locale_name' => $request->request->get('locale_name', ''),
			'localeEnabled' => (bool)$request->request->get('localeEnabled'),
		]);
	}

	/**
	 * @Route("/{id}", name="edit")
	 *
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function editLocale(string $id, Request $request, TranslatorInterface $translator): Response
	{
		$locale = LocaleModel::byId($id);
		if ($locale === null) {
			return $this->redirectToRoute('app_setting_locale_list');
		}

		if ($request->getRealMethod() === 'POST') {
			$fields = self::getStandardFields($translator);
			try {
				$locale
					->setEnabled((bool)$request->request->get('localeEnabled'))
				;

				// Alle Daten in den Feldern speichern
				foreach ($fields as $fieldset) {
					foreach ($fieldset as $field) {
						$setter = 'set'.preg_replace_callback('/(?:^|_)([a-z])/',
							function ($match) { return strtoupper($match[1]); },
							$field['field_id']
						);
						$value = trim($request->request->get($field['field_id'], ''));
						if (strpos($setter, 'setPurposeName-') === 0) {
							$purpose = Purpose::find(substr($setter, 15));
							$setter = substr($setter, 0, 14);
							$locale->$setter($purpose, $value);
						} elseif (preg_match('~^setPurposeDescription-(?<purposeId>[0-9a-f]+)$~', $setter, $match)) {
							if ($purpose = Purpose::find($match['purposeId'])) {
								$locale->setPurposeDescription($purpose, $value);
							}
						} else {
							$locale->$setter($value);
						}
					}
				}
				$locale->save();

				$this->addFlash('success',
					$translator->trans('Locale %locale% has been updated.', ['%locale%' => $locale->getName()])
				);

				return $this->redirectToRoute('app_setting_locale_list');
			}
			catch (Exception $e) {
				$this->addFlash('danger', $translator->trans('An unknown error has occured.'));
			}
		}

		// Gespeicherte Werte setzen
		$fields = self::getStandardFields($translator);
		$fields = array_map(function ($fieldset) use ($locale) {
			return array_map(function ($field) use ($locale) {
				$getter = 'get'.preg_replace_callback('/(?:^|_)([a-z])/',
					function ($match) { return strtoupper($match[1]); },
					$field['field_id']
				);
				if (strpos($getter, 'getPurposeName-') === 0) {
					$purpose = Purpose::find(substr($getter, 15));
					$getter = substr($getter, 0, 14);
					$field['user_input'] = $locale->$getter($purpose) ?? '';
				} elseif (preg_match('~^getPurposeDescription-(?<purposeId>[0-9a-f]+)$~', $getter, $match)) {
					if ($purpose = Purpose::find($match['purposeId'])) {
						$field['user_input'] = $locale->getPurposeDescription($purpose);
					}
				} else {
					$field['user_input'] = $locale->$getter() ?? '';
				}
				return $field;
			}, $fieldset);
		}, $fields);

		return $this->render('settings/locale/edit.html.twig', [
			'user' => User::loggedInUser(),
			'locale' => $locale,
			'fields' => $fields,
		]);
	}

	/**
	 * @Route("/{id}/delete", name="delete")
	 *
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 * @throws \App\Exception\ConfigNotWritableException
	 */
	public function deleteLocale(string $id, Request $request, TranslatorInterface $translator): Response
	{
		$locale = LocaleModel::byId($id);
		if ($locale === null) {
			return $this->redirectToRoute('app_setting_locale_list');
		}

		$localeName = $locale->getName();
		$localeBlacklist = [
			'de_DE',
			'en_US',
		];

		// Bestimmte Übersetzungen dürfen nicht gelöscht werden
		if (in_array($localeName, $localeBlacklist)) {
			$this->addFlash('info',
				$translator->trans('Locale %locale% may not be deleted.', ['%locale%' => $localeName])
			);
			return $this->redirectToRoute('app_setting_locale_list');
		}

		if ($request->getRealMethod() === 'POST') {
			LocaleModel::delete($locale->getId());

			$this->addFlash('success',
				$translator->trans('Locale %locale% has been deleted.', ['%locale%' => $localeName])
			);

			return $this->redirectToRoute('app_setting_locale_list');
		}

		return $this->render('settings/locale/delete.html.twig', [
			'user' => User::loggedInUser(),
			'locale' => $locale,
		]);
	}

	/**
	 * @param TranslatorInterface $translator
	 * @return array
	 */
	private static function getStandardFields(TranslatorInterface $translator)
	{
		$result = [
			$translator->trans('Cookie widget texts') => [
				'widget_title' => [
					'field_description' => $translator->trans('Cookie layer headline'),
					'field_id' => 'widget_title',
					'type' => 'input_text',
					'required' => true
				],
				'widget_introduction' => [
					'field_description' => $translator->trans('Layer intro text'),
					'field_id' => 'widget_introduction',
					'type' => 'textarea',
					'required' => true
				],
				'widget_consent_button_text' => [
					'field_description' => $translator->trans('Button for "consent"'),
					'field_id' => 'widget_consent_button_text',
					'type' => 'input_text',
					'required' => true
				],
				'widget_decline_button_text' => [
					'field_description' => $translator->trans('Button: Decline cookies'),
					'field_id' => 'widget_decline_button_text',
					'type' => 'input_text',
					'required' => true
				],
				'widget_settings_button_text' => [
					'field_description' => $translator->trans('Text for Link to control panel'),
					'field_id' => 'widget_settings_button_text',
					'type' => 'input_text',
					'required' => true
				],
				'control_panel_title' => [
					'field_description' => $translator->trans('Control panel headline'),
					'field_id' => 'control_panel_title',
					'type' => 'input_text',
					'required' => true
				],
				'control_panel_cancel_button_text' => [
					'field_description' => $translator->trans('Control panel cancel button text'),
					'field_id' => 'control_panel_cancel_button_text',
					'type' => 'input_text',
					'required' => true
				],
				'control_panel_save_button_text' => [
					'field_description' => $translator->trans('Control panel save button text'),
					'field_id' => 'control_panel_save_button_text',
					'type' => 'input_text',
					'required' => true
				],
				'imprint_text' => [
					'field_description' => $translator->trans('Link text for “Imprint”'),
					'field_id' => 'imprint_text',
					'type' => 'input_text',
					'required' => true
				],
				'privacy_policy_text' => [
					'field_description' => $translator->trans('Link text for “Privacy notes”'),
					'field_id' => 'privacy_policy_text',
					'type' => 'input_text',
					'required' => true
				],
			],
			$translator->trans('Widget category view texts') => [
				'categories_accept_all_button_text' => [
					'field_description' => $translator->trans('"Accept all" button'),
					'field_id' => 'categories_accept_all_button_text',
					'type' => 'input_text',
					'required' => true,
				],
			],
			$translator->trans('Widget detail view texts') => [
				'details_title' => [
					'field_description' => $translator->trans('Detail view headline'),
					'field_id' => 'details_title',
					'type' => 'input_text',
					'required' => true
				],
				'details_close_button_text' => [
					'field_description' => $translator->trans('Detail view close button text'),
					'field_id' => 'details_close_button_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_vendor_text' => [
					'field_description' => $translator->trans('Cookie ”Vendor” label'),
					'field_id' => 'cookie_vendor_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_description_text' => [
					'field_description' => $translator->trans('Cookie “Description” label'),
					'field_id' => 'cookie_description_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_privacy_policy_url_text' => [
					'field_description' => $translator->trans('Cookie “Privacy policy url” label'),
					'field_id' => 'cookie_privacy_policy_url_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_lifetime_text' => [
					'field_description' => $translator->trans('Cookie “Lifetime” label'),
					'field_id' => 'cookie_lifetime_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_collected_data_info_text' => [
					'field_description' => $translator->trans('Cookie „What data will be collected?“ label'),
					'field_id' => 'cookie_collected_data_info_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_purpose_of_data_collection_text' => [
					'field_description' => $translator->trans('Cookie „Purpose of data collection“ label'),
					'field_id' => 'cookie_purpose_of_data_collection_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_legal_basis_text' => [
					'field_description' => $translator->trans('Cookie „Legal basis“ label'),
					'field_id' => 'cookie_legal_basis_text',
					'type' => 'input_text',
					'required' => true
				],
				'cookie_place_of_processing_text' => [
					'field_description' => $translator->trans('Cookie „Place of processing“ label'),
					'field_id' => 'cookie_place_of_processing_text',
					'type' => 'input_text',
					'required' => true
				],
			],
			$translator->trans('Embedded cookie declaration') => [
				'change_consent_label' => [
					'field_description' => $translator->trans('Change consent'),
					'field_id' => 'change_consent_label',
					'type' => 'input_text',
					'required' => false
				],
			],
			$translator->trans('Blocking dialog for external content') => [
				'blocked_content_title' => [
					'field_description' => $translator->trans('Dialog title'),
					'field_id' => 'blocked_content_title',
					'type' => 'input_text',
					'required' => true
				],
				'blocked_content_text' => [
					'field_description' => $translator->trans('Dialog text'),
					'field_id' => 'blocked_content_text',
					'type' => 'textarea',
					'required' => true,
					'field_note' => $translator->trans('<strong>Note:</strong> You can use <code>:domain</code> as a placeholder for the domain from which content was blocked.')
				],
				'blocked_content_button_text' => [
					'field_description' => $translator->trans('Confirm button'),
					'field_id' => 'blocked_content_button_text',
					'type' => 'input_text',
					'required' => true
				],
			],
		];
		$purposes = array_reduce(Purpose::all(), function ($purposes, $purpose) use ($translator) {
			$purposes[] = [
				'field_description' => $purpose->getName(),
				'field_id' => 'purpose_name-'.$purpose->getId(),
				'type' => 'input_text',
				'required' => true
			];
			$purposes[] = [
				'field_description' => $translator->trans('Description'),
				'field_id' => 'purpose_description-'.$purpose->getId(),
				'type' => 'textarea',
				'required' => false,
			];
			return $purposes;
		}, []);
		$result[$translator->trans('Cookie purposes')] = array_combine(array_column($purposes, 'field_id'), $purposes);
		return $result;
	}
}
