<?php

namespace App\Controller\Settings;

use App\Component\ThumbnailExtractor\ThumbnailExtractorService;
use App\Controller\DomainDependantController;
use App\Exception\CsrfTokenException;
use App\Model\Domain;
use App\Model\User;
use App\Model\CsrfToken;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * @Route("/domains/{_domainId}/settings/consentstorage")
 */
class ConsentStorage extends DomainDependantController
{
	/**
	 * @Route("", methods={"GET", "HEAD"}, name="app_settings_consentstorage")
	 * @param Request $request
	 * @return Response
	 */
	public function showSettings(Request $request): Response
	{
		/** @var User $user */
		$user = User::loggedInUser();
		/** @var Domain $domain */
		$domain = Domain::activeDomain();

		$exampleDomain = preg_replace('/^www[0-9]?\./', '', explode(' ', strtolower(trim($domain->getName())), 2)[0]) ?: 'example.com';

		$crossDomainSharingAllowed = (Utils::isExtendedEdition() or $_ENV['APP_ALLOW_CROSS_DOMAIN_SHARING'] ?? false);
		$maxDomains = $user->getMaxDomainCount() ?: 1;
		$availableDomains = ($maxDomains < 0) ? 2147483647 : max($maxDomains - $user->getActualDomainCount() + $domain->getDomainNamesCount(), 1);

		return $this->render('settings/consentstorage/index.html.twig', [
			'domain' => $domain,
			'exampleDomain' => $exampleDomain,
			'csrfToken' => CsrfToken::get(),
			'crossDomainSharingAllowed' => $crossDomainSharingAllowed,
			'availableDomains' => $availableDomains,
		]);
	}

	/**
	 * @Route("", methods={"POST"}, name="app_settings_consentstorage_post")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function saveSettings(Request $request, TranslatorInterface $translator, ThumbnailExtractorService $thumbnails): Response
	{
		try {
			CsrfToken::get()->checkRequest($request);
			/** @var User $user */
			$user = User::loggedInUser();
			/** @var Domain $domain */
			$domain = Domain::activeDomain();
			Domain::beginWrite();

			$maxDomains = (Utils::isBaseEdition() and $_ENV['APP_ALLOW_CROSS_DOMAIN_SHARING'] ?? false) ? 2147483647 : ($user->getMaxDomainCount() ?: 1);
			$availableDomains = ($maxDomains < 0) ? 2147483647 : max($maxDomains - $user->getActualDomainCount() + $domain->getDomainNamesCount(), 1);

			$domainNames = [];
			$ipAddresses = [];
			foreach ((array)$request->request->get('shareDomain') as $domainName) {
				$domainName = strtolower(trim(trim($domainName), '.'));
				if (!$domainName) {
					continue;
				}

				// Sonderfall: Klammern um IPv6-Adresse setzen
				if (filter_var($domainName, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false) {
					$domainName = '['.$domainName.']';
				}

				// Nochmal mit parse_url sicherstellen, dass nur ein Hostname drin steht
				$url = (strpos($domainName, '//') === false) ? 'http://'.$domainName : $domainName;
				$domainName = @trim(parse_url($url, PHP_URL_HOST), '.');

				// IP-Adressen getrennt verarbeiten
				if (filter_var($domainName, FILTER_VALIDATE_IP) !== false) {
					$ipAddresses[$domainName] = $domainName;
					continue;
				}
				if (substr($domainName, 0, 1) == '[' and filter_var(substr($domainName, 1, -1), FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false) {
					$ipAddresses[$domainName] = $domainName;
					continue;
				}

				foreach ($domainNames as $i => $otherName) {
					if ($otherName == $domainName or strpos($domainName, '.'.$otherName) !== false) {
						$domainName = '';
						break;
					}
					elseif (strpos($otherName, '.'.$domainName) !== false) {
						if ($availableDomains >= 0) {
							unset($domainNames[$i]);
							$availableDomains += 1;
						}
					}
				}
				if ($domainName) {
					$availableDomains -= 1;

					if ($availableDomains < 0) {
						continue;
					}

					$domainNames[] = $domainName;
				}
			}

			if ($availableDomains < 0) {
				$this->addFlash('warning', $translator->trans('Some domain names could not be saved as you don\'t have enough domains available in your plan.'));
			}

			$domain
				->setShareDomainNames(array_merge($domainNames, array_values($ipAddresses)))
				->setConsentStorage((string)$request->request->get('storageMedium', 'localStorage'))
				->setConsentCookieLifetime((int)$request->request->get('cookieLifetime'))
				->setSecureConsentCookie((bool)$request->request->get('cookieSecure'))
				->setCrossDomainSharing((bool)$request->request->get('cookieLinkSharing'))
				->save();

			$user->setActualDomainCount(Domain::countIncludingShareNames())->save();

			$this->addFlash('success', $translator->trans('Settings have been saved.'));

		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
		}

		return $this->redirectToRoute('app_settings_consentstorage', [], 303);
	}
}
