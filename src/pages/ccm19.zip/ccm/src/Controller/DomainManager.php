<?php

namespace App\Controller;

use App\Component\Pagination;
use App\Config;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\Domain;
use App\Model\User;
use App\Model\FoundCookie;
use App\Model\FoundScript;
use App\Model\FoundStorage;
use App\Model\FoundObject;
use App\Utils;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class DomainManager extends AbstractController
{
	/**
	 * @Route("/domains", name="app_domains_index", methods={"HEAD", "GET"})
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function domainIndex(Request $request, TranslatorInterface $translator): Response
	{
		/** @var Domain[] $domains */
		$domains = Domain::all();
		$config = Config::getInstance();

		// Sortiere Domains dem Namen nach
		usort($domains, function (Domain $a, Domain $b) {
			return strnatcasecmp($a->getName(), $b->getName());
		});

		$pagination = new Pagination($domains);
		if ($pagination->getCurrentPage() > 1 && $pagination->getItemCount() == 0) {
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		/** @var User $user */
		$user = User::loggedInUser();
		$domNames = [];

		//Liste der Domains in User Daten übertragen für die auswertung
		foreach($domains as $k=>$v)
		{
			$domNames[]=($v->getName());
		}

		// Session hier schon zu machen, um Seitenaufbau in anderen Tabs zu beschleunigen
		Utils::getSession()->save();

		//Array mit Dom Namen
		$user->setDomList($domNames);
		//Anzahl der Domains setzen
		$user->setActualWLCount(Domain::whitelabelCountForAllDomains());
		$user->setActualDomainCount(Domain::countIncludingShareNames());
		$user->save();

		$domainLimitString = $user->getMaxDomainCount() < 0
			? $translator->trans('unlimited')
			: (string)$user->getMaxDomainCount();

		$maxWLCount = $user->getMaxWLCount();
		$maxCallCount = $user->getMaxCallCount();
		$actualCallCount = $user->getActualCallCount();

		$maxWLCount = $maxWLCount < 0 ? $translator->trans('unlimited') : $maxWLCount;
		$maxCallCount = $maxCallCount < 0 ? $translator->trans('unlimited') : $maxCallCount;

		if ($user->isAutoAddDomains()) {
			$scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme().'://';
			$baseUrl = $scheme.$request->getHttpHost();
			$embedCodeSnippetAutoDomain = '<script src="'.htmlspecialchars($baseUrl.$this->generateUrl(
				'app_external_main_javascript_file',
				[
					'apiKey' => $user->getApiKey(),
				]
			)).'" referrerpolicy="origin"></script>';
		}
		else {
			$embedCodeSnippetAutoDomain = '';
		}

		return $this->render('domain/index.html.twig', [
			'pagination' => $pagination,
			'domainCount' => Domain::countIncludingShareNames(),
			'domainLimit' => $domainLimitString,
			'_metaSidebar' => true,
			'whitelabelUsedCount' => Domain::whitelabelCountForAllDomains(),
			'maxWLCount' => $maxWLCount,
			'maxCallCount' => $maxCallCount,
			'actualCallCount' => $actualCallCount,
			'embedCodeSnippetAutoDomain' => $embedCodeSnippetAutoDomain,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/domains", name="app_domains_bulk_action", methods={"POST"})
	 */
	public function domainBulkAction(Request $request, TranslatorInterface $translator): RedirectResponse
	{
		$user = User::loggedInUser();
		$activeDomain = Domain::activeDomain();
		$action = $request->request->get('action');
		$targetIds = $request->request->get('targets', '');
		if (!is_array($targetIds)) {
			if ($targetIds !== '*') {
				$targetIds = explode(',', $targetIds);
			}
		}
		/** @var Domain[] $targets */
		$targets = ($targetIds === '*') ? Domain::all() : array_filter(array_map(function ($id) {
			return Domain::find(trim($id));
		}, $targetIds));

		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			$this->addFlash('danger', $error);
			return $this->redirectToRoute('app_page_check', [], 303);
		}

		switch ($action) {
			case 'clear-page-check':
				foreach ($targets as $domain) {
					Domain::select($domain->getId());
					FoundCookie::reloadRepository();
					FoundScript::reloadRepository();
					FoundStorage::reloadRepository();
					FoundObject::reloadRepository();
					FoundCookie::clear();
					FoundScript::clear();
					FoundStorage::clear();
					FoundObject::clear();
					gc_collect_cycles();
				}

				$this->addFlash('success', $translator->trans('All page check entries were successfully cleared.'));
				break;

			case 'delete':
				$count = 0;
				foreach ($targets as $domain) {
					Domain::delete($domain->getId(), false);
					$count++;
				}
				Domain::flush();

				// Benutzer aktualisieren
				$domNames = array_map(function ($domain) {
					return $domain->getName();
				}, Domain::all());
				$user->setDomList($domNames);
				$user->setActualWLCount(Domain::whitelabelCountForAllDomains());
				$user->setActualDomainCount(Domain::countIncludingShareNames());
				$user->save();

				if ($count > 0) {
					$this->addFlash('success', $translator->trans('The selected :n domain(s) were successfully deleted.', [':n' => $count]));
				}
				break;
			default:
				// unbekannte Aktion... ignorieren
		}

		// aktive Domain zurücksetzen
		if ($activeDomain) {
			Domain::select($activeDomain->getId());
		}
		return $this->redirectToRoute('app_domains_index', [], 303);
	}

	/**
	 * @Route("/domains/bulk_delete", name="app_domains_bulk_delete", methods={"HEAD", "GET"})
	 * @return Response
	 */
	public function domainBulkDeleteForm(Request $request): Response
	{
		/** @var Domain[] $domains */
		$domains = array_filter(Domain::all(), function ($domain) {
			return ! $domain->isFrontendWidgetEnabled();
		});

		// Sortiere Domains dem Namen nach
		usort($domains, function (Domain $a, Domain $b) {
			return strnatcasecmp($a->getName(), $b->getName());
		});

		return $this->render('domain/bulk_delete.html.twig', [
			'domains' => $domains,
			'_metaSidebar' => true,
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @param User $user
	 * @return int
	 */
	private static function whitelabelAvailableCountForUser(User $user): int
	{
		$maxWhitelabelCount = $user->getMaxWLCount();
		return $maxWhitelabelCount >= 0
			? max(0, $maxWhitelabelCount - Domain::whitelabelCountForAllDomains())
			: -1;
	}

	/**
	 * @Route("/domains/list.json", name="app_domains_list_ajax")
	 * @param Request $request
	 * @return JsonResponse
	 */
	public function ajaxDomainSearch(Request $request)
	{
		$activeDomain = Domain::activeDomain();
		Utils::getSession()->save();

		$list = array_map(function ($domain) use ($activeDomain) {
			return [
				'id' => $domain->getId(),
				'name' => $domain->getName(),
				'widgetEnabled' => $domain->isFrontendWidgetEnabled(),
				'whitelabel' => $domain->hasWhitelabel(),
				'active' => ($activeDomain) ? ($domain->getId() === $activeDomain->getId()) : false,
				'shareDomains' => $domain->getShareDomainNames(),
				'urls' => [
					'delete' => $this->generateUrl('app_domains_delete_form', ['id'=>$domain->getId()]),
					'edit' => $this->generateUrl('app_domains_edit_form', ['id'=>$domain->getId()]),
					'copy' => $this->generateUrl('app_domains_copy', ['id'=>$domain->getId()]),
					'select' => $this->generateUrl('app_dashboard', ['_domainId'=>$domain->getId()]),
				],
			];
		}, array_values(Domain::all()));

		return $this->json([
			'data' => $list
		]);
	}

	/**
	 * @Route("/domains/create", name="app_domains_create")
	 * @param Request $request
	 * @return Response
	 */
	public function domainCreate(Request $request, TranslatorInterface $translator): Response
	{
		$id = 0;

		/** @var User $user */
		$user = User::loggedInUser();

		//verfügnare WL Lizenzen
		$verfuegbarWhitelabelCount = self::whitelabelAvailableCountForUser($user);
		$verfuegbarWhitelabel = $verfuegbarWhitelabelCount != 0;

		if ($user->getMaxDomainCount() >= 0 && Domain::countIncludingShareNames() >= $user->getMaxDomainCount()) {
			$this->addFlash('danger', $translator->trans('You\'ve reached the domain limit. Please contact your provider to raise that limit.'));
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		$formData = [
			'domainName' => '',
			'whitelabel' => '',
			'whitelabel_verfuegbar' => $verfuegbarWhitelabel,
			'whitelabel_verfuegbar_count' => $verfuegbarWhitelabelCount < 0 ? $translator->trans('unlimited') : $verfuegbarWhitelabelCount,
		];

		if ($request->getRealMethod() == 'POST') {
			foreach (array_keys($formData) as $fieldName) {
				$formData[$fieldName] = trim((string)$request->request->get($fieldName));
			}

			if ($formData['domainName']) {
				$domain = Domain::createForUser($user);
				$domain
					->setName($formData['domainName'])
					->setFrontendWidgetEnabled(false)
					->setWhitelabel((bool)$formData['whitelabel'])
					->setInlineScriptsBlocked(false)
					->setSameDomainScriptsBlocked(false)
					->setManagementStructure("embedding")
					->save();

				$this->addFlash('success', $translator->trans('Domain :name has been created!', [
					':name' => $formData['domainName'],
				]));

				return $this->redirectToRoute('app_domains_index', [], 303);
			}
			else {
				$this->addFlash('danger', $translator->trans('Please fill out all fields marked with an asterisk.'));
			}
		}

		return $this->render('domain/create.html.twig', [
			'formData' => $formData,
			'csrfToken' => CsrfToken::get(),
			'_metaSidebar' => true,
		]);
	}

	/**
	 * @Route("/domains/{id}", methods={"HEAD", "GET"}, name="app_domains_edit_form")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function domainEditForm(string $id, Request $request, TranslatorInterface $translator): Response
	{
		/** @var User $user */
		$user = User::loggedInUser();
		/** @var Domain|null $domain */
		$domain = Domain::find($id);

		if ($domain == null) {
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		$whitelabelAvailableCount = self::whitelabelAvailableCountForUser($user);
		$whitelabelAvailable = $whitelabelAvailableCount != 0 || $domain->hasWhitelabel();

		$formData = [
			'domainName' => '',
			'whitelabel' => '',
			'whitelabel_verfuegbar' => $whitelabelAvailable,
			'whitelabel_verfuegbar_count' => $whitelabelAvailableCount < 0 ? $translator->trans('unlimited') : $whitelabelAvailableCount,
		];

		return $this->render('domain/edit.html.twig', [
			'domain' => $domain,
			'csrfToken' => CsrfToken::get(),
			'_metaSidebar' => true,
			'formData' => $formData
		]);
	}

	/**
	 * @Route("/domains/{id}/copy", methods={"HEAD", "GET"}, name="app_domains_copy")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function copyEditForm(string $id, Request $request, TranslatorInterface $translator): Response
	{

		/** @var User $user */
		$user = User::loggedInUser();
		/** @var Domain|null $domain */
		$domain = Domain::find($id);
		$oldDomainId = $domain->getId();
		$oldDomainName = $domain->getName();

		/**
		 * ok - neue Domain erzeugen mit dem aktuellen Namen und Copy hinten dran...
		 *
		 */

		//OK? - sonst raus...
		if ($user->getMaxDomainCount() >= 0 && Domain::countIncludingShareNames() >= $user->getMaxDomainCount()) {
			$this->addFlash('danger', $translator->trans('You\'ve reached the domain limit. Please contact your provider to raise that limit.'));
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		//Dann erstellen
		$domain = Domain::createForUser($user);
		$domain
			->setName($oldDomainName." COPY")
			->setFrontendWidgetEnabled(false)
			->setWhitelabel(false)
			->save();

		//Id der neuen DOmain
		$newDomainId = $domain->getId();
		$varDir = str_ireplace("src/Controller","",__DIR__);
		$srcDir = $varDir."var/user_data/".$user->getId()."/domains/".$oldDomainId."/";
		$destDir = $varDir."var/user_data/".$user->getId()."/domains/".$newDomainId."/";

		Utils::copyDirectory($srcDir,$destDir);

		$this->addFlash('success', $translator->trans('Domain :name has been copyied.', [
			':name' => $oldDomainName,
		]));

		return $this->redirectToRoute('app_domains_index', [], 303);
	}

	/**
	 * @Route("/domains/{id}", methods={"PATCH"}, name="app_domains_edit")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function domainEdit(string $id, Request $request, TranslatorInterface $translator): Response
	{
		Domain::beginWrite();
		/** @var User $user */
		$user = User::loggedInUser();
		/** @var Domain|null $domain */
		$domain = Domain::find($id);

		if ($domain == null) {
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		$whitelabelAvailableCount = self::whitelabelAvailableCountForUser($user);
		$whitelabelAvailable = $whitelabelAvailableCount != 0 || $domain->hasWhitelabel();

		$formData = [
			'domainName' => '',
			'whitelabel' => '',
			'whitelabel_verfuegbar' => $whitelabelAvailable,
			'whitelabel_verfuegbar_count' => $whitelabelAvailableCount < 0 ? $translator->trans('unlimited') : $whitelabelAvailableCount,
		];

		foreach (array_keys($formData) as $fieldName) {
			$formData[$fieldName] = trim((string)$request->request->get($fieldName));
		}

		// Daten temporär zuweisen, damit im Fehlerfall die Benutzereingaben im Formular ausgegeben werden whitelabel
		$domain
			->setName($formData['domainName'])
			->setWhitelabel((bool)$formData['whitelabel'])
		;

		$ok = true;
		try {
			CsrfToken::get()->checkRequest($request);
		} catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			$this->addFlash('danger', $error);
			$ok = false;
		}

		if (!$formData['domainName']) {
			$this->addFlash('danger', $translator->trans('Please fill out all fields marked with an asterisk.'));
			$ok = false;
		}

		if ($ok) {
			$domain->save();

			$this->addFlash('success', $translator->trans('Domain :name has been updated!', [
				':name' => $formData['domainName'],
			]));

			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		return $this->render('domain/edit.html.twig', [
			'domain' => $domain,
			'csrfToken' => CsrfToken::get(),
			'_metaSidebar' => true,
			'formData' => $formData
		]);
	}

	/**
	 * @Route("/domains/{id}/delete", methods={"HEAD", "GET"}, name="app_domains_delete_form")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function domainDeleteForm(string $id, Request $request, TranslatorInterface $translator): Response
	{
		/** @var Domain|null $domain */
		$domain = Domain::find($id);

		if ($domain == null) {
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		return $this->render('domain/delete.html.twig', [
			'domain' => $domain,
			'csrfToken' => CsrfToken::get(),
			'_metaSidebar' => true,
		]);
	}

	/**
	 * @Route("/domains/{id}", methods={"DELETE"}, name="app_domains_delete")
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function domainDelete(string $id, Request $request, TranslatorInterface $translator): Response
	{
		try {
			CsrfToken::get()->checkRequest($request);
		} catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			$this->addFlash('danger', $error);
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		Domain::beginWrite();
		/** @var Domain|null $domain */
		$domain = Domain::find($id);

		if ($domain == null) {
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		$domainName = $domain->getName();
		Domain::delete($domain->getId());

		$this->addFlash('success', $translator->trans('Domain :name has been deleted.', [
			':name' => $domainName,
		]));

		return $this->redirectToRoute('app_domains_index', [], 303);
	}

	/**
	 * @Route("/domains/{id}/select", name="app_domains_select")
	 * @deprecated
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function domainSelect(string $id, Request $request, TranslatorInterface $translator): Response
	{
		if (Domain::select($id)) {
			/** @var Domain|null $domain */
			$domain = Domain::find($id);

			$this->addFlash('success', $translator->trans('Domain :name has been selected.', [
				':name' => $domain->getName(),
			]));
			return $this->redirectToRoute('app_dashboard', ['_domainId'=>$domain->getId()], 303);
		}
		else {
			$this->addFlash('danger', $translator->trans('Invalid domain selected, please try again.'));
			return $this->redirectToRoute('app_domains_index', [], 303);
		}
	}
}
