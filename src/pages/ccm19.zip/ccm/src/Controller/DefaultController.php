<?php

namespace App\Controller;

use App\Model\Domain;
use App\Model\User;
use App\Utils;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DefaultController extends AbstractController
{
	/**
	 * @Route("/", name="app_root")
	 * @param Request $request
	 * @return Response
	 */
	public function index(Request $request): Response
	{
		if (Utils::isExtendedEdition() && Domain::activeDomain() == null) {
			return $this->redirectToRoute('app_domains_index', [], 303);
		}

		//Nur falls keine Domain vorhanden ist... Notfall - tritt eigentlich nur auf wenn Verzeichnisse außerhalb gelöscht wurden
		if (Domain::count()==0) {
			$domain = Domain::createForUser(User::loggedInUser());
			$domain
				->setName("")
				->setWhitelabel(false)
				->save();
		}

		return $this->redirectToRoute('app_dashboard', [], 303);
	}

}
