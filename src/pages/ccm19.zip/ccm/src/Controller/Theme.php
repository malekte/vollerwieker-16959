<?php
/** @noinspection PhpUnused */
/** @noinspection PhpRouteMissingInspection */
/** @noinspection PhpTemplateMissingInspection */

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Model\Domain;
use App\Model\Purpose;
use App\Model\User;
use App\Model\Theme as ThemeModel;
use App\Utils;
use App\Config;
use RuntimeException;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Theme-Verwaltung
 * @package App\Controller
 *
 * @Route("/domains/{_domainId}/themes", name="app_theme_")
 */
class Theme extends DomainDependantController
{
	/**
	 * @Route("", name="list")
	 *
	 * @return Response
	 */
	public function listThemes(): Response
	{
		$themes = ThemeModel::all();

		// ORDER BY systemTheme, userTheme, name
		usort($themes, function ($a, $b) {
			/**
			 * @var ThemeModel $a
			 * @var ThemeModel $b
			 */
			if ($a->getSystemTheme() xor $b->getSystemTheme()) {
				return $a->getSystemTheme() ? -1 : 1;
			} elseif ($a->getUserTheme() xor $b->getUserTheme()) {
				return $a->getUserTheme() ? -1 : 1;
			} else {
				return strnatcasecmp($a->getName(), $b->getName());
			}
		});

		return $this->render('theme/list.html.twig', [
			'user' => User::loggedInUser(),
			'themes' => $themes,
		]);
	}

	/**
	 * @Route("/{id}/setDefault", name="default", methods={"POST"})
	 *
	 * @param string $id
	 *
	 * @return Response
	 */
	public function setDefaultTheme(string $id): Response
	{
		if (ThemeModel::exists($id)) {
			$theme = ThemeModel::find($id);
			$theme->makeDefault();
		}

		return $this->redirectToRoute('app_theme_list');
	}

	/**
	 * @Route("/{id}/preview", name="preview" )
	 *
	 * @param string $id
	 * @param Request $request
	 *
	 * @return Response
	 */
	public function previewTheme(string $id, Request $request): Response
	{
		if (ThemeModel::exists($id)) {
			$theme = ThemeModel::find($id);
			$theme->makeDefault();

			$domain = Domain::activeDomain();
			$config = Config::getInstance();
			$user = User::loggedInUser();

			$scheme = $config->isForceHttpsConnection() ? 'https://' : $request->getScheme() . '://';
			$baseUrl = $scheme . $request->getHttpHost();

			$embedScriptUrl = $baseUrl . $this->generateUrl(
					'app_external_main_javascript_file',
					[
						'apiKey' => $user->getApiKey(),
						'domain' => $domain->getId(),
						'lang' => "",
					]
				);
			$embedCodeSnippets = '<script src="' . ($embedScriptUrl) . '&preview=true" referrerpolicy="origin"></script>';
			//print_r($embedCodeSnippets);
			return $this->render('theme/preview.html.twig', [
				'user' => User::loggedInUser(),
				'embedScript' => $embedCodeSnippets,
			]);
		} else {
			return $this->redirectToRoute('app_theme_list');
		}


	}

	/**
	 * @Route("/new", name="new")
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function createTheme(Request $request, TranslatorInterface $translator): Response
	{
		$mayWhitelabel = Utils::hasWhitelabelLicense();

		$mayGeoIP = (phpversion('bcmath') !== false or extension_loaded('bcmath') !== false or phpversion('gmp') !== false or extension_loaded('gmp') !== false);

		if ($request->getRealMethod() === 'POST') {
			$themeData = $request->request->all();

			$theme = ThemeModel::create();
			$this->setThemeObjectAttributes($theme, $themeData, '', $request);

			try {
				$this->handleNameError($themeData['name'], $translator);
				$this->handleColorErrors($themeData, $translator);
				$this->handlePositionError($themeData['position'], $translator);

				/** @var UploadedFile $image */
				$image = $request->files->get('image');
				if ($image) {
					$this->handleUploadErrors($image, $translator);
					$logoFilename = $theme->getId() . '.' . $image->getClientOriginalExtension();

					$domain = Domain::activeDomain();
					$destination = $domain->logoDir() . '/' . $logoFilename;

					Utils::assertDirectoryWritable(dirname($destination));
					if (move_uploaded_file($image->getPathname(), $destination)) {
						$theme->setLogoFilename($logoFilename);
					}
				}
			} catch (RuntimeException $e) {
				return $this->render('theme/new.html.twig', [
					'theme' => $theme,
					'whitelabel' => $mayWhitelabel,
					'mayGeoIP' => $mayGeoIP,
				]);
			}
			$theme->save();

			$this->addFlash('success', $translator->trans(
				'The theme "%themename%" has been created successfully!', [
					'%themename%' => $themeData['name']
				]
			));

			return $this->redirectToRoute('app_theme_list');
		}

		return $this->render('theme/new.html.twig', [
			'whitelabel' => $mayWhitelabel,
			'mayGeoIP' => $mayGeoIP,
		]);
	}

	/**
	 * @Route("/{id}/copy", name="copy", methods={"POST"})
	 *
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function copyTheme(string $id, Request $request, TranslatorInterface $translator): Response
	{
		$theme = ThemeModel::find($id);

		if ($theme == null) {
			return $this->redirectToRoute('app_theme_list', [], 303);
		}

		$domain = Domain::activeDomain();
		$user = User::loggedInUser();

		$themeData = [];
		$themeData['name'] = $theme->getName();
		$themeData['position'] = $theme->getPosition();
		$themeData['blocking'] = $theme->isBlocking();
		$themeData['complyingDoNotTrack'] = $theme->isComplyingDoNotTrack();
		$themeData['LogoFilename'] = $theme->getLogoFilename();
		$themeData['logoDisplayed'] = $theme->isLogoDisplayed();
		$themeData['okButtonBackgroundColor'] = $theme->getOkButtonBackgroundColor();
		$themeData['okButtonBorderColor'] = $theme->getOkButtonBorderColor();
		$themeData['moreInfoButtonColor'] = $theme->getMoreInfoButtonColor();
		$themeData['moreInfoButtonBackgroundColor'] = $theme->getMoreInfoButtonBackgroundColor();
		$themeData['windowBackgroundColor'] = $theme->getWindowBackgroundColor();
		$themeData['windowBorderColor'] = $theme->getWindowBorderColor();
		$themeData['linkInInfotextColor'] = $theme->getLinkInInfotextColor();
		$themeData['okButtonColor'] = $theme->getOkButtonColor();
		$themeData['moreInfoButtonBorderColor'] = $theme->getMoreInfoButtonBorderColor();
		$themeData['infotextColor'] = $theme->getInfotextColor();
		$themeData['infotextFontFamily'] = $theme->getInfotextFontFamily();
		$themeData['infotextFontSize'] = $theme->getInfotextFontSize();
		$themeData['customCss'] = $theme->getCustomCss();
		$themeData['whitelabel'] = $theme->getWhitelabel();
		$themeData['onlyInEu'] = $theme->getOnlyInEu();
		$themeData['manipulationPrevention'] = $theme->getManipulationPrevention();

		$domain = Domain::activeDomain();
		$from = $domain->logoDir() . '/' . $themeData['LogoFilename'];
		$destination = $domain->logoDir() . '/' . "cp_" . $themeData['LogoFilename'];

		if (!empty($themeData['LogoFilename'])) {
			@copy($from, $destination);
			$themeData['LogoFilename'] = "cp_" . $themeData['LogoFilename'];
		}

		$themeCopy = ThemeModel::create()
			->setSystemTheme(null)
			->setUserTheme(null)
			->setLastModifiedTimestamp($theme->getLastModifiedTimestamp())
			->setName("COPY: " . trim($themeData['name']))
			->setPosition($themeData['position'] ?? '')
			->setShowPurposesInMainWindow($theme->isShowPurposesInMainWindow())
			->setBlocking((bool)($themeData['blocking'] ?? false))
			->setShowAcceptAllButtonInControlPanel($theme->isShowAcceptAllButtonInControlPanel())
			->setSettingsIconEnabled($theme->isSettingsIconEnabled())
			->setSettingsIconTarget($theme->getSettingsIconTarget())
			->setComplyingDoNotTrack((bool)($themeData['complyingDoNotTrack'] ?? false))
			->setLogoFilename($themeData['LogoFilename'] ?? '')
			->setLogoDisplayed((bool)($themeData['logoDisplayed'] ?? false))
			->setOkButtonBackgroundColor($themeData['okButtonBackgroundColor'] ?? '')
			->setMoreInfoButtonBackgroundColor($themeData['moreInfoButtonBackgroundColor'] ?? '')
			->setWindowBackgroundColor($themeData['windowBackgroundColor'] ?? '')
			->setWindowBorderColor($themeData['windowBorderColor'] ?? '')
			->setLinkInInfotextColor($themeData['linkInInfotextColor'] ?? '')
			->setOkButtonColor($themeData['okButtonColor'] ?? '')
			->setMoreInfoButtonColor($themeData['moreInfoButtonColor'] ?? '')
			->setOkButtonBorderColor($themeData['okButtonBorderColor'] ?? '')
			->setMoreInfoButtonBorderColor($themeData['moreInfoButtonBorderColor'] ?? '')
			->setInfotextColor($themeData['infotextColor'] ?? '')
			->setInfotextFontFamily($themeData['infotextFontFamily'] ?? '')
			->setInfotextFontSize($themeData['infotextFontSize'] ?? '')
			->setIframeBlockerBackgroundColor($theme->getIframeBlockerBackgroundColor())
			->setIframeBlockerForegroundColor($theme->getIframeBlockerForegroundColor())
			->setIframeBlockerButtonBackgroundColor($theme->getIframeBlockerButtonBackgroundColor())
			->setIframeBlockerButtonForegroundColor($theme->getIframeBlockerButtonForegroundColor())
			->setCustomCss($themeData['customCss'] ?? '')
			->setCustomCssForIframeBlocker($theme->getCustomCssForIframeBlocker())
			->setWhitelabel((bool)($themeData['whitelabel'] ?? false))
			->setOnlyInEu((bool)($themeData['onlyInEu'] ?? false))
			->setManipulationPrevention((bool)($themeData['manipulationPrevention'] ?? false));

		$themeCopy->save();

		return $this->redirectToRoute('app_theme_list');
	}

	/**
	 * @Route("/{id}", name="edit")
	 *
	 * @param string $id
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function editTheme(string $id, Request $request, TranslatorInterface $translator): Response
	{
		if (ThemeModel::exists($id) == false) {
			return $this->redirectToRoute('app_theme_list');
		}

		$theme = ThemeModel::find($id);
		$domain = Domain::activeDomain();
		$user = User::loggedInUser();

		$mayWhitelabel = Utils::hasWhitelabelLicense();

		$mayGeoIP = (phpversion('bcmath') !== false or extension_loaded('bcmath') !== false or phpversion('gmp') !== false or extension_loaded('gmp') !== false);

		$logoUrl = $this->generateUrl('app_theme_logo', [
			'userId' => $user->getId(),
			'domainId' => $domain->getId(),
			'themeId' => $theme->getId(),
		]);



		if ($request->getRealMethod() === 'POST') {
			$themeData = $request->request->all();

			if ($mayWhitelabel == false) {
				$themeData['whitelabel'] = false;
			}

			$logoFilename = $theme->getLogoFilename();
			$this->setThemeObjectAttributes($theme, $themeData, $logoFilename, $request);

			try {
				// Überprüfe die Felder nur, wenn das Theme kein System-Theme oder User-Theme referenziert
				if (!$theme->getSystemTheme() && !$theme->getUserTheme()) {
					$this->handleNameError($themeData['name'], $translator);
					$this->handleColorErrors($themeData, $translator);
					$this->handlePositionError($themeData['position'], $translator);
				}

				/** @var UploadedFile $image */
				$image = $request->files->get('image');
				if ($image) {
					$this->handleUploadErrors($image, $translator);
					$logoFilename = $theme->getId() . '.' . $image->getClientOriginalExtension();

					$destination = $domain->logoDir() . '/' . $logoFilename;

					Utils::assertDirectoryWritable(dirname($destination));
					if (move_uploaded_file($image->getPathname(), $destination)) {
						$theme->setLogoFilename($logoFilename);
					}
				}
			} catch (RuntimeException $e) {
				return $this->render('theme/edit.html.twig', [
					'user' => User::loggedInUser(),
					'theme' => $theme,
					'logoPath' => $logoUrl,
					'whitelabel' => $mayWhitelabel,
					'mayGeoIP' => $mayGeoIP
				]);
			}

			$theme->setLogoFilename($logoFilename);
			$theme->save();

			$this->addFlash(
				'success',
				$translator->trans(
					'The theme "%themename%" has been edited successfully!', [
						'%themename%' => $theme->getName(),
					]
				));
			return $this->redirectToRoute('app_theme_edit', ['id' => $theme->getId()]);
		}

		$purposes = Purpose::all();

		if ($theme->getSystemTheme() || $theme->getUserTheme()) {
			$this->addFlash('info',
				$translator->trans('Please note that e. g. the positioning and coloring of global themes may not be edited. Duplicate the theme to change those parameters.')
			);
		}

		return $this->render('theme/edit.html.twig', [
			'user' => User::loggedInUser(),
			'theme' => $theme,
			'purposes' => $purposes,
			'logoUrl' => $logoUrl,
			'whitelabel' => $mayWhitelabel,
			'mayGeoIP' => $mayGeoIP,
			'themeId' => $theme->getId(),
		]);
	}

	/**
	 * @Route("/{id}/delete", name="delete")
	 * @param string $id
	 * @param Request $request
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function deleteTheme(string $id, Request $request, TranslatorInterface $translator): Response
	{
		if (ThemeModel::exists($id) == false) {
			return $this->redirectToRoute('app_theme_list');
		}

		$theme = ThemeModel::find($id);
		$allThemes = ThemeModel::all();
		$themeName = $theme->getName();

		if ($theme->getSystemTheme()) {
			$this->addFlash('danger', $translator->trans('System themes cannot be deleted.'));
			return $this->redirectToRoute('app_theme_list', [], 303);
		} elseif ($theme->getUserTheme()) {
			$this->addFlash('danger', $translator->trans('Manage your global themes <a href=":url">here</a>.', [
				':url' => $this->generateUrl('app_user_theme_index'),
			]));
			return $this->redirectToRoute('app_theme_list', [], 303);
		}

		if (count($allThemes) <= 1) {
			$this->addFlash('danger', $translator->trans('You cannot delete the last theme!'));
			return $this->redirectToRoute('app_theme_list');
		}

		if ($request->getRealMethod() === 'POST') {
			// wenn das Theme als Standard registriert ist, dann das erstbeste Theme als Standard setzen
			if ($theme->isDefaultTheme()) {
				/** @var ThemeModel[] $allThemes */
				foreach ($allThemes as $themeId => $themeObject) {
					if ($id !== $themeId) {
						$themeObject->makeDefault();
						$this->addFlash(
							'info',
							$translator->trans('The theme "%themename%" has now been set as default.', [
								'%themename%' => $themeObject->getName()
							])
						);
						break;
					}
				}
			}

			$domain = Domain::activeDomain();
			$imageFilename = $domain->logoDir() . '/' . $theme->getLogoFilename();
			ThemeModel::delete($id);

			// Hier keine Warnung an den Benutzer ausgeben, weil beim Anlegen eines neuen Themes mit derselben ID das
			// existierende Bild überschrieben wird: https://www.php.net/manual/en/function.move-uploaded-file.php
			if (is_file($imageFilename)) {
				@unlink($imageFilename);
			}

			$this->addFlash('success', $translator->trans(
				'The theme "%themename%" has been deleted successfully!', [
					'%themename%' => $themeName
				]
			));
			return $this->redirectToRoute('app_theme_list');
		}

		return $this->render('theme/delete.html.twig', [
			'user' => User::loggedInUser(),
			'theme' => $theme
		]);
	}

	/**
	 * @param ThemeModel $theme
	 * @param array $themeData
	 * @param string $newImageName
	 * @param Request $request
	 * @return void
	 */
	private function setThemeObjectAttributes(ThemeModel $theme, array $themeData, string $newImageName, Request $request): void
	{
		$theme
			->setLogoFilename($newImageName)
			->setLogoDisplayed((bool)($themeData['logoDisplayed'] ?? false))
			->setWhitelabel((bool)($themeData['whitelabel'] ?? false));

		// Parameter nur aktualisieren, wenn kein System- oder User-Theme referenziert wird.
		if (!$theme->getSystemTheme() && !$theme->getUserTheme()) {
			$theme
				->touchLastModifiedTimestamp()
				->setName(trim($request->request->get('name', '')))
				->setPosition($themeData['position'] ?? '')
				->setShowPurposesInMainWindow((bool)$request->request->get('showPurposesInMainWindow'))
				->setBlocking((bool)($themeData['blocking'] ?? false))
				->setShowAcceptAllButtonInControlPanel((bool)($themeData['showAcceptAllButtonInControlPanel'] ?? false))
				->setSettingsIconEnabled((bool)($request->request->get('settingsIconEnabled')))
				->setSettingsIconTarget((string)$request->request->get('settingsIconTarget'))
				->setShowDeclineButton((bool)($request->request->get('showDeclineButton')))
				->setSelectType((string)($request->request->get('selectType')))
				->setComplyingDoNotTrack((bool)($themeData['complyingDoNotTrack'] ?? false))
				->setOkButtonBackgroundColor($themeData['okButtonBackgroundColor'] ?? '')
				->setMoreInfoButtonBackgroundColor($themeData['moreInfoButtonBackgroundColor'] ?? '')
				->setWindowBackgroundColor($themeData['windowBackgroundColor'] ?? '')
				->setWindowBorderColor($themeData['windowBorderColor'] ?? '')
				->setLinkInInfotextColor($themeData['linkInInfotextColor'] ?? '')
				->setOkButtonColor($themeData['okButtonColor'] ?? '')
				->setMoreInfoButtonColor($themeData['moreInfoButtonColor'] ?? '')
				->setOkButtonBorderColor($themeData['okButtonBorderColor'] ?? '')
				->setMoreInfoButtonBorderColor($themeData['moreInfoButtonBorderColor'] ?? '')
				->setDeclineButtonBackgroundColor(trim($request->request->get('declineButtonBackgroundColor', '')))
				->setDeclineButtonBorderColor(trim($request->request->get('declineButtonBorderColor', '')))
				->setDeclineButtonTextColor(trim($request->request->get('declineButtonTextColor', '')))
				->setInfotextColor($themeData['infotextColor'] ?? '')
				->setInfotextFontFamily($themeData['infotextFontFamily'] ?? '')
				->setInfotextFontSize($themeData['infotextFontSize'] ?? '')
				->setIframeBlockerBackgroundColor(trim($request->request->get('iframeBlockerBackgroundColor')))
				->setIframeBlockerForegroundColor(trim($request->request->get('iframeBlockerForegroundColor')))
				->setIframeBlockerButtonBackgroundColor(trim($request->request->get('iframeBlockerButtonBackgroundColor')))
				->setIframeBlockerButtonForegroundColor(trim($request->request->get('iframeBlockerButtonForegroundColor')))
				->setCustomCss($themeData['customCss'] ?? '')
				->setCustomCssForIframeBlocker(trim($request->request->get('customCssForIframeBlocker')))
				->setOnlyInEu((bool)($themeData['onlyInEu'] ?? false))
				->setManipulationPrevention((bool)($themeData['manipulationPrevention'] ?? false));
		}
	}

	/**
	 * @param UploadedFile $image
	 * @param TranslatorInterface $translator
	 * @return void
	 */
	private function handleUploadErrors(UploadedFile $image, TranslatorInterface $translator): void
	{
		if ($image->getError() != UPLOAD_ERR_OK) {
			$this->addFlash(
				'danger',
				$translator->trans('The image could not be uploaded! (Error code %errorcode% %errormessage%)', [
					'%errorcode%' => $image->getError(),
					'%errormessage%' => $image->getErrorMessage()
				])
			);
			throw new RuntimeException();
		}

		if (preg_match('/^image\/.*$/', $image->getMimeType()) == false) {
			$this->addFlash('danger', $translator->trans('The uploaded file is not an image!'));
			throw new RuntimeException();
		}
	}

	/**
	 * @param array $themeData
	 * @param TranslatorInterface $translator
	 * @return void
	 */
	private function handleColorErrors(array $themeData, TranslatorInterface $translator): void
	{
		foreach ($themeData as $name => $value) {
			if (preg_match('~Color$~', $name) == false || preg_match('~^#[0-9a-f]{6}$~i', $value)) {
				continue;
			}

			$this->addFlash('danger', $translator->trans('Invalid color values! Please use the color picker and/or provide hex color codes.'));
			throw new RuntimeException();
		}
	}

	/**
	 * @param string $name
	 * @param TranslatorInterface $translator
	 * @return void
	 * @throws RuntimeException
	 */
	private function handleNameError($name, TranslatorInterface $translator): void
	{
		if (trim($name) === '') {
			$this->addFlash('warning', $translator->trans('A theme cannot be saved without a name!'));
			throw new RuntimeException();
		}
	}

	/**
	 * @param string $position
	 * @param TranslatorInterface $translator
	 * @return void
	 * @throws RuntimeException
	 */
	private function handlePositionError($position, TranslatorInterface $translator): void
	{
		if (in_array($position, ['top', 'center', 'bottom',]) == false) {
			$this->addFlash('danger', $translator->trans('The value for field "%field%" is invalid!', ['%field%' => 'Position']));
			throw new RuntimeException();
		}
	}
}
