<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\Cookie as CookieModel;
use App\Model\CsrfToken;
use App\Model\Domain;
use App\Model\EmbeddingAsset;
use App\Model\Placeholder as PlaceholderModel;
use App\Model\Purpose;
use App\Model\User;
use App\Model\Embedding as EmbeddingModel;
use App\Model\Locale as Locale;
use App\Utils;
use App\Component\Tcf\v2\Model\Vendor as TcfVendor;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Controller zur Embedding-Verwaltung
 * @Route("/domains/{_domainId}/embeddings", name="app_embeddings_")
 */
class Embeddings extends DomainDependantController
{
	/**
	 * @Route("", name="list")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Embedding-File erfolgen kann
	 *
	 * @return Response
	 */
	public function listEmbeddings(): Response
	{
		Utils::getSession()->save();

		$embeddings = EmbeddingModel::all();
		$purposes = Purpose::all();

		return $this->render('embedding/list.html.twig', [
			'embeddings' => $embeddings,
			'purposes' => $purposes,
		]);
	}

	/**
	 * Methode führt ein Autoupdate durch
	 */
	public function autoUpdate()
	{
		$cookies 	= CookieModel::all();
		$embeddingData = array();
		$embeds = array();
		$defaultLocale = Locale::getDefault();
		$defaultLocaleId = $defaultLocale->getId();


		//die versch. Purposes
		$remotePurposes = [
			1 => Purpose::findByName('Technisch notwendig')->getId(),
			2 => Purpose::findByName('Anzeigen / Ads')->getId(),
			3 => Purpose::findByName('Analyse')->getId(),
			4 => Purpose::findByName('Personalisierung')->getId(),
			5 => Purpose::findByName('Statistik')->getId(),
			6 => Purpose::findByName('Sonstiges')->getId()
		];

		if (!empty($cookies))
		{
			foreach ($cookies as $k=>$v)
			{
				$name = $v->getHttpCookieName();
				//Daten holen...
				//check ob es Daten dazu gibt...
				$remoteDataMIX = EmbeddingModel::getCookeDBInformation($name);

				if (empty($remoteDataMIX['cookie_daten']['de'][$name]))
				{
					return false;
				}

				//Alle Sprachdateien aus dem Export rausholen...
				foreach (Locale::all() as $locale) {
					$localeId = $locale->getId();
					$localeName = $locale->getName();
					$localeNameAr = explode("_",$localeName);
					$localeShort = $localeNameAr['0'];

					if (!empty($remoteDataMIX['cookie_daten'][$localeShort]))
					{
						$remoteData = $remoteDataMIX['cookie_daten'][$localeShort][$name]['Wirdvonverwendet_49'];
					} else {
						$remoteData = [];
						continue;
					}

					if (empty($remoteData['Zweck_35'])) {
						$remoteData['Zweck_35'] = 0;
					}

					//wenn remote Daten vorhanden - diese einbauen...
					if (!empty($remoteData['BeschreibungderEinbindung_39']))
					{
						if (empty($embeddingData['purpose']))
						{
							//print_r($localeId);
							$embeddingData['purpose'] = $remotePurposes[$remoteData['Zweck_35']] ?? null;
							$embeddingData['http_embedding_name'] = $remoteData['BezeichnungderEinbindung_34'] ?? '';
							$embeddingData['embedding_vendor'] = $remoteData['HerstellerAnbieter_36'] ?? '';
							$embeddingData['name'] = $remoteData['BezeichnungderEinbindung_34'] ?? '';
							$embeddingData['active'] = true;
						}
					}
					else {
						if (empty($embeddingData['purpose'])) {
							$embeddingData['purpose'] = $remotePurposes[$remoteData['Zweck_35']] ?? null;
						}
					}

					//Sprachdaten
					if (!empty($remoteData['BezeichnungderEinbindung_34'])) {
						$embeddingData['description'][$localeId] = $remoteData['BeschreibungderEinbindung_39'] ;
						$embeddingData['privacy_policy_url'][$localeId] = $remoteData['DatenschutzURL_40'] ?? '';
						$embeddingData['lifetime'][$localeId] = "";
						$embeddingData['collected_data_info'][$localeId] = $remoteData['WelcheDatenwerdengesammelt_41'] ?? '';
						$embeddingData['purpose_of_data_collection'][$localeId] = $remoteData['ZweckderSammlung_42'] ?? '';
						$embeddingData['legal_basis'][$localeId] = $remoteData['RechtlicheGrundlage_43'] ?? '';
						$embeddingData['place_of_processing'][$localeId] = $remoteData['OrtderVerarbeitung_44'] ?? '';
					}

					//Sprachten der Assets
					foreach ( $remoteData['nutztelement_50'] ?? array() as $data)
					{
						$langAsset[$data['name']]['name']			=	$data['name'];
						$langAsset[$data['name']]['storageType']	=	$data['storageType'];
						$langAsset[$data['name']]['dynamic']		=	$data['dynamic'];
						$langAsset[$data['name']]['description'][$localeId]	=	$data['description'];
						$langAsset[$data['name']]['lifetime'][$localeId]	=	$data['lifetime'];
						$addLangAsset = $langAsset;
					}
					$embeddingData['add_asset']=$addLangAsset ?? array();
				}
				$embeds[]= $embeddingData;
			}
		}

		//Wenn wir hier sind wurden alle gefunden und alles ist sauber!
		if(!empty($embeds))
		{
			foreach ($embeds as $k=>$v)
			{
				$embedding = $this->applyChanges(EmbeddingModel::create(),$v, $defaultLocaleId);
				$embedding->save();
				EmbeddingAsset::flush();
			}
		}

		//Struktur auf Embedding setzen
		$domain = Domain::activeDomain();
		$domain->setManagementStructure("embedding");
		$domain->save();

		//alles konnte gefunden und gespeichert werden - also top...
		return true;
	}

	/**
	 * Embeddings aus der CCM19.de Datenbank anzeigen zur Auswahl...
	 * @Route("/db", name="from_db" )
	 * @return Response
	 */
	public function listEmbeddingsFromDatabase(): Response
	{
		Utils::getSession()->save();

		$embeddingsDB = EmbeddingModel::getEmbeddingsDBCompleteInformation();
		$purposes = Purpose::all();

		$defaultLocale = Locale::getDefault();
		$defaultLocaleName = $defaultLocale->getName();
		$localeNameAr = explode("_",$defaultLocaleName);
		$localeShort = $localeNameAr['0'];

		return $this->render('embedding/list_db.html.twig', [
			'embeddings' => $embeddingsDB['embeddings'][$localeShort],
			'purposes' => $purposes,
		]);

	}

	/**
	 * Daten aus dem Array $embeddingData in $embedding übertragen
	 */
	private function applyChanges(EmbeddingModel $embedding, array $embeddingData, string $defaultLocaleId): EmbeddingModel
	{
		// Script-Blocking
		$codeBlock = explode("\n", trim((string)($embeddingData['code_block'] ?? '')));
		$codeBlock = array_filter($codeBlock, function ($line) {
			return trim($line) !== '';
		});
		$codeBlock = array_values(array_map(function ($line) {
			return trim($line);
		}, $codeBlock));
		// Zweck
		$purpose = Purpose::find($embeddingData['purpose'] ?? '');

		// Allgemeines speichern
		$embedding
			->setName($embeddingData['name'] ?? '')
			->setDescription($embeddingData['description'][$defaultLocaleId] ?? '')
			->setCodeSnippet($embeddingData['code_snippet'] ?? '')
			->setCodeBlock($codeBlock)
			->setEmbeddingVendor($embeddingData['embedding_vendor'] ?? '')
			->setPrivacyPolicyUrl($embeddingData['privacy_policy_url'][$defaultLocaleId] ?? '')
			->setHttpEmbeddingName($embeddingData['http_embedding_name'] ?? '')
			->setLifetime($embeddingData['lifetime'][$defaultLocaleId] ?? '')
			->setCollectedDataInfo($embeddingData['collected_data_info'][$defaultLocaleId] ?? '')
			->setPurposeOfDataCollection($embeddingData['purpose_of_data_collection'][$defaultLocaleId] ?? '')
			->setLegalBasis($embeddingData['legal_basis'][$defaultLocaleId] ?? '')
			->setPlaceOfProcessing($embeddingData['place_of_processing'][$defaultLocaleId] ?? '')
			->setActive($embeddingData['active'] ?? false)
		;
		if ($purpose) {
			$embedding->setPurpose($purpose);
		}

		// TCF-Vendor speichern
		$embedding->setTcfVendor(TcfVendor::find($embeddingData['tcf_vendor_id'] ?? $embedding->getTcfVendor()->getId()));

		// Assets bearbeiten
		foreach ($embeddingData['asset'] ?? [] as $assetId => $data) {
			$asset = $embedding->getAsset($assetId);
			$assetName = (string)($data['name'] ?? '');

			if ($asset === null || empty($assetName)) {
				continue;
			}

			$asset
				->setName($assetName)
				->setDynamic((bool)($data['dynamic'] ?? false))
				->setStorageType((string)($data['storageType'] ?? ''))
				->setLifetime((string)($data['lifetime'][$defaultLocaleId] ?? ''))
				->setDescription((string)($data['description'][$defaultLocaleId] ?? ''))
			;

			//assets lang Data
			foreach (Locale::enabledLocales() as $locale) {
				$localeId = $locale->getId();
				if (!isset($data['description'][$localeId])) {
					continue; // Wenn description in der Sprache komplett fehlt, ist die Sprache wohl nicht dabei
				}
				$asset
					->setTranslatedDescription($locale, $data['description'][$localeId] ?? '')
					->setTranslatedLifetime($locale, $data['lifetime'][$localeId] ?? '')
				;
			}
		}

		// Assets hinzufügen
		foreach ($embeddingData['add_asset'] ?? [] as $data) {
			$assetName = (string)($data['name'] ?? '');
			if (empty($assetName)) {
				continue;
			}
			$asset = EmbeddingAsset::create()
				->setName($assetName)
				->setDynamic((bool)($data['dynamic'] ?? false))
				->setStorageType((string)($data['storageType'] ?? ''))
				//->setLifetime((string)($data['lifetime'] ?? ''))
				//->setDescription((string)($data['description'] ?? ''))
			;

			//assets lang Data
			foreach (Locale::enabledLocales() as $locale) {
				$localeId = $locale->getId();
				if (!isset($data['description'][$localeId])) {
					continue; // Wenn description in der Sprache komplett fehlt, ist die Sprache wohl nicht dabei
				}
				$asset
					->setTranslatedDescription($locale, $data['description'][$localeId] ?? '')
					->setTranslatedLifetime($locale, $data['lifetime'][$localeId] ?? '');
			}
			//embed now...
			$embedding->addAsset($asset);
		}

		// Assets löschen
		foreach ($embeddingData['delete_asset'] ?? [] as $assetId) {
			$embedding->removeAsset($assetId);
		}

		// Übersetzungen speichern
		foreach (Locale::enabledLocales() as $locale) {
			$localeId = $locale->getId();
			if (!isset($embeddingData['description'][$localeId])) {
				continue; // Wenn description in der Sprache komplett fehlt, ist die Sprache wohl nicht dabei
			}
			$embedding
				->setTranslatedDescription($locale, $embeddingData['description'][$localeId] ?? '')
				->setTranslatedPrivacyPolicyUrl($locale, $embeddingData['privacy_policy_url'][$localeId] ?? '')
				->setTranslatedLifetime($locale, $embeddingData['lifetime'][$localeId] ?? '')
				->setTranslatedCollectedDataInfo($locale, $embeddingData['collected_data_info'][$localeId] ?? '')
				->setTranslatedPurposeOfDataCollection($locale, $embeddingData['purpose_of_data_collection'][$localeId] ?? '')
				->setTranslatedLegalBasis($locale, $embeddingData['legal_basis'][$localeId] ?? '')
				->setTranslatedPlaceOfProcessing($locale, $embeddingData['place_of_processing'][$localeId] ?? '')
			;
		}

		return $embedding;
	}

	/**
	 * @Route("/new", name="new", methods={"HEAD","GET"})
	 *
	 * @param Request $request
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function createEmbeddingForm(Request $request, TranslatorInterface $translator): Response
	{
		$csrfToken = CsrfToken::get();
		$embeddingData = [];
		$purposes = Purpose::all();
		$defaultLocale = Locale::getDefault();
		$defaultLocaleId = $defaultLocale->getId();

		Utils::getSession()->save();

		$rawName = $request->query->get('embeddingname');
		if ($rawName) {
			$rawNameData = explode(";",$rawName);
			//print_r($rawNameData);
			$name=trim($rawNameData[0]);
			if(!empty($rawNameData[1]))
			{
				$daType=trim($rawNameData[1]);
			}
			else
			{
				$daType=1;
			}


			//sanitized Name holen
			$name = $embeddingData['name'] = EmbeddingModel::getNameFromGet($name);

			//check ob es Daten dazu gibt...
			$remoteDataMIX = EmbeddingModel::getCookeDBInformation($name);

			if (!empty($remoteDataMIX['cookie_daten']['de']))
			{
				$embeddingData['hinweis']="hinweis_remote";
			}

			//die versch. Purposes
			$remotePurposes = [
				1 => Purpose::findByName('Technisch notwendig')->getId(),
				2 => Purpose::findByName('Anzeigen / Ads')->getId(),
				3 => Purpose::findByName('Analyse')->getId(),
				4 => Purpose::findByName('Personalisierung')->getId(),
				5 => Purpose::findByName('Statistik')->getId(),
				6 => Purpose::findByName('Sonstiges')->getId()
			];

			//Alle Sprachdateien aus dem Export rausholen...
			foreach (Locale::all() as $locale) {
				$localeId = $locale->getId();
				$localeName = $locale->getName();
				$localeNameAr = explode("_",$localeName);
				$localeShort = $localeNameAr['0'];
				$name = str_ireplace("*","",$name);

				if (!empty($remoteDataMIX['cookie_daten'][$localeShort][$name]))
				{
					$remoteData = $remoteDataMIX['cookie_daten'][$localeShort][$name]['Wirdvonverwendet_49'];
				}
				else
				{
					continue;
				}

				if (empty($remoteData['Zweck_35'])) {
					$remoteData['Zweck_35'] = 0;
				}

				//wenn remote Daten vorhanden - diese einbauen...
				if (!empty($remoteData['BeschreibungderEinbindung_39']))
				{
					if (empty($embeddingData['purpose']))
					{
						//print_r($localeId);
						$embeddingData['purpose'] = $remotePurposes[$remoteData['Zweck_35']] ?? null;
						$embeddingData['http_embedding_name'] = $remoteData['BezeichnungderEinbindung_34'] ?? '';
						$embeddingData['embedding_vendor'] = $remoteData['HerstellerAnbieter_36'] ?? '';
						$embeddingData['name'] = $remoteData['BezeichnungderEinbindung_34'] ?? '';
						$embeddingData['active'] = true;
					}
				}
				else {
					if (empty($embeddingData['purpose'])) {
						$embeddingData['purpose'] = $remotePurposes[$remoteData['Zweck_35']] ?? null;
					}
				}

				//Sprachdaten
				if (!empty($remoteData['BezeichnungderEinbindung_34'])) {
					$embeddingData['description'][$localeId] = $remoteData['BeschreibungderEinbindung_39'] ;
					$embeddingData['privacy_policy_url'][$localeId] = $remoteData['DatenschutzURL_40'] ?? '';
					$embeddingData['lifetime'][$localeId] = "";
					$embeddingData['collected_data_info'][$localeId] = $remoteData['WelcheDatenwerdengesammelt_41'] ?? '';
					$embeddingData['purpose_of_data_collection'][$localeId] = $remoteData['ZweckderSammlung_42'] ?? '';
					$embeddingData['legal_basis'][$localeId] = $remoteData['RechtlicheGrundlage_43'] ?? '';
					$embeddingData['place_of_processing'][$localeId] = $remoteData['OrtderVerarbeitung_44'] ?? '';
				}

				//assets nach Sprachen übergeben...
				foreach ( $remoteData['nutztelement_50'] ?? array() as $data)
				{
					$langAsset[$data['name']]['name']			=	$data['name'];
					$langAsset[$data['name']]['storageType']	=	$data['storageType'];
					$langAsset[$data['name']]['dynamic']		=	$data['dynamic'];
					$langAsset[$data['name']]['description'][$localeId]	=	$data['description'];
					$langAsset[$data['name']]['lifetime'][$localeId]	=	$data['lifetime'];
					$addLangAsset = $langAsset;
				}
				$embeddingData['add_asset']=$addLangAsset ?? array();

			}

			if (!empty($name) && empty($embeddingData['add_asset']))
			{
				$embeddingData['add_asset']=array(array(
					"name"=>$name,
					"storageType"=>$daType,
					"dynamic"=>0,
					"id"=>0,
					"description"=>"",
					"lifetime"=>""
				));
			}


		}
		else {
			$embeddingData = [];
		}

		$addVar="add_";

		return $this->render('embedding/new.html.twig', [
			'purposes' => $purposes,
			'locales' => Locale::enabledLocales(),
			'csrfToken' => $csrfToken,
			'embedding' => $this->applyChanges(EmbeddingModel::create(), $embeddingData, $defaultLocaleId),
			'tcfVendors' => TcfVendor::all(),
			'add_var' => $addVar,
		]);
	}

	/**
	 * @Route("/new", name="new_post", methods={"POST"})
	 *
	 * @param Request $request
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function createEmbedding(Request $request, TranslatorInterface $translator): Response
	{
		$csrfToken = CsrfToken::get();
		$embeddingData = [];
		$purposes = Purpose::all();
		$defaultLocale = Locale::getDefault();
		$defaultLocaleId = $defaultLocale->getId();

		$embedding = $this->applyChanges(EmbeddingModel::create(), $request->request->all(), $defaultLocaleId);

		try {
			$csrfToken->checkRequest($request);

			// ohne Namen nicht speichern
			if (trim($embedding->getName()) === '') {
				$this->addFlash('warning', 'Ein Embedding kann nicht ohne Namen gespeichert werden');
				return $this->render('embedding/new.html.twig', [
					'embedding' => $embedding,
					'purposes' => $purposes,
					'locales' => Locale::enabledLocales(),
					'csrfToken' => $csrfToken,
				]);
			}

			// ohne Verwendungszweck nicht speichern
			if (!$embedding->getPurpose()) {
				$this->addFlash('warning', 'Ein Embedding kann nicht ohne Verwendungszweck gespeichert werden');
				return $this->render('embedding/new.html.twig', [
					'embedding' => $embedding,
					'purposes' => $purposes,
					'locales' => Locale::enabledLocales(),
					'csrfToken' => $csrfToken,
					'tcfVendors' => TcfVendor::all(),
				]);
			}

			// Speichern
			$embedding->save();
			EmbeddingAsset::flush();

			$this->addFlash('success', 'Das Embedding "' . $embedding->getName() . '" wurde erfolgreich erstellt!');
			Utils::getSession()->save();

			return $this->redirectToRoute('app_embeddings_edit', ['id'=>$embedding->getId()]);
		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
		}

		return $this->render('embedding/new.html.twig', [
			'purposes' => $purposes,
			'locales' => Locale::enabledLocales(),
			'csrfToken' => $csrfToken,
			'formData' => $embeddingData ?? [],
			'tcfVendors' => TcfVendor::all(),
			'add_var' => "",
		]);
	}

	/**
	 * @Route("/{id}/edit", methods={"HEAD", "GET"}, name="edit")
	 *
	 * @param string $id
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function editEmbedding(string $id, Request $request): Response
	{
		if (EmbeddingModel::exists($id) == false) {
			return $this->redirectToRoute('app_embeddings_list');
		}

		$embedding = EmbeddingModel::find($id);
		//print_r($embedding);exit();

		$purposes = Purpose::all();

		return $this->render('embedding/edit.html.twig', [
			'embedding' => $embedding,
			'purposes' => $purposes,
			'locales' => Locale::enabledLocales(),
			'csrfToken' => CsrfToken::get(),
			'tcfVendors' => TcfVendor::all(),
			'add_var' => "",
		]);
	}

	/**
	 * @Route("/{id}/edit", methods={"POST"}, name="edit_post")
	 *
	 * @param string $id
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function editEmbeddingPost(string $id, Request $request, TranslatorInterface $translator): Response
	{
		EmbeddingModel::beginWrite();
		if (EmbeddingModel::exists($id) == false) {
			return $this->redirectToRoute('app_embeddings_list');
		}

		$defaultLocale = Locale::getDefault();
		$defaultLocaleId = $defaultLocale->getId();
		$embedding = EmbeddingModel::find($id);

		try {
			CsrfToken::get()->checkRequest($request);

			// Embedding-Daten holen und aufbereiten
			$embeddingData = $request->request->all();

			// ohne Verwendungszweck nicht speichern
			if (Purpose::exists($embeddingData['purpose']) == false) {
				$this->addFlash('warning', 'Ein Embedding kann nicht ohne Verwendungszweck gespeichert werden');
				return $this->redirectToRoute('app_embeddings_edit', ['id' => $embedding->getId()]);
			}

			$purpose = Purpose::find($embeddingData['purpose']);

			// Script-Blocking
			$codeBlock = explode("\n", trim((string)($embeddingData['code_block'] ?? '')));
			$codeBlock = array_filter($codeBlock, function ($line) {
				return trim($line) !== '';
			});
			$codeBlock = array_values(array_map(function ($line) {
				return trim($line);
			}, $codeBlock));

			// ohne Namen nicht speichern
			if (trim($embeddingData['name']) === '') {
				$this->addFlash('warning', 'Ein Embedding kann nicht ohne Namen gespeichert werden');
				return $this->redirectToRoute('app_embeddings_edit', ['id' => $embedding->getId()]);
			}



			// Speichern
			$embedding = $this->applyChanges($embedding, $embeddingData, $defaultLocaleId);
			$embedding->save();
			EmbeddingAsset::flush();

			$this->addFlash('success', 'Das Embedding "' . $embeddingData['name'] . '" wurde erfolgreich bearbeitet!');
		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
		}

		return $this->redirectToRoute('app_embeddings_edit', ['id' => $embedding->getId()]);
	}

	/**
	 * @Route("/{id}/delete", name="delete")
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function deleteEmbedding(string $id, Request $request, TranslatorInterface $translator): Response
	{
		EmbeddingModel::beginWrite();
		if (EmbeddingModel::exists($id) == false) {
			return $this->redirectToRoute('app_embeddings_list');
		}

		$embedding = EmbeddingModel::find($id);
		$embeddingName = $embedding->getName();

		if ($request->getRealMethod() === 'POST') {
			try {
				CsrfToken::get()->checkRequest($request);
				EmbeddingModel::delete($id);
				$this->addFlash('success', 'Das Embedding "' . $embeddingName . '" wurde erfolgreich gelöscht!');
				return $this->redirectToRoute('app_embeddings_list');
			}
			catch (CsrfTokenException $e) {
				$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			}
		}

		return $this->render('embedding/delete.html.twig', [
			'user' => User::loggedInUser(),
			'embedding' => $embedding,
			'csrfToken' => CsrfToken::get(),
		]);
	}
}
