<?php

namespace App\Controller;

use App\Component\Ccm19LicensingApiClient;
use App\Component\LoggerInterface;
use App\Component\MailerConfigurator;
use App\Config;
use App\Model\Domain;
use App\Model\User;
use App\Model\VersionLog;
use App\Utils;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

class Setup extends AbstractController
{
	/**
	 * Diese Methode bildet den Einstiegspunkt der Setuproutine.
	 * @Route("/setup", name="app_setup")
	 */
	public function setup(TranslatorInterface $translator, LoggerInterface $logger, MailerConfigurator $mailconfig, Request $request): Response
	{
		/** @var Config $config */
		$config = Config::getInstance();

		// Wenn es bereits Benutzer gibt, gilt das Setup als durchgeführt
		if (User::count() > 0) {
			return $this->render('setup/already_done.html.twig');
		}

		$username = 'admin';
		$password = Utils::randomString(16);
		$licensekey = '';
		$email = '';
		$errors = [];
		$proxyUrl = $_ENV['APP_PROXY'] ?? $_ENV['HTTP_PROXY'] ?? '';

		// Wenn das Formular abgeschickt wurde, Daten prüfen und ggf. Einrichtung des Systems vornehmen
		if ($request->getRealMethod() === 'POST') {
			$username = trim($request->request->get('username'));
			$password = trim($request->request->get('password'));
			$licensekey = trim($request->request->get('licensekey'));
			$email = trim($request->request->get('email'));
			$proxyUrl = trim($request->request->get('proxyUrl'));
			// Proxy direkt verwenden, wenn eingerichtet
			$_ENV['APP_PROXY'] = $proxyUrl;

			// Lizenzschlüssel prüfen
			$api = new Ccm19LicensingApiClient();
			$api->registerLicense($licensekey, $request->getHttpHost());

			if ($api->isSuccess() && $username && $password && $email) {
				User::create($username)
					->setPassword($password)
					->setRole(User::ROLE_ADMIN)
					->save()
				;
				$user = User::login($username, $password);
				assert($user instanceof User);

				Utils::setLocalEnvironment([
					'APP_SECRET' => bin2hex(random_bytes(16)),
					'APP_EDITION' => $api->getEdition(),
				]);
				$config->set('multiDomain', true); // Zum Unterscheiden alter und neuer Versionen (Updateroutinen)
				$config->set('licensekey', $licensekey);
				$config->set('email', $email);
				$config->set('whitelabel', $api->hasWhitelabel());

				$domain = Domain::createForUser($user);
				$domain
					->setName("")
					->setWhitelabel(false)
					->setFrontendWidgetEnabled(false)
					->setInlineScriptsBlocked(false)
					->setSameDomainScriptsBlocked(false)
					->setManagementStructure("embedding")
					->save();

				// Sendmail-Pfad setzen
				if ($_ENV['MAILER_URL'] === 'sendmail:') {
					$mailconfig->setMailer('sendmail');
				}

				Utils::setLocalEnvironment([
					'APP_PROXY' => $proxyUrl
				]);

				// Versions-Installation merken
				VersionLog::logCurrentVersion();

				$logger->logInfo('Setup', "Installation successful");
				return $this->redirectToRoute('app_root');
			}

			if ($api->isError()) {
				$logger->logError('Setup', "Installation failed: ".$api->getErrorMessage());
				$errors[] = $translator->trans($api->getErrorMessage());
			}
		}

		return $this->render('setup/index.html.twig', [
			'username' => $username,
			'password' => $password,
			'licensekey' => $licensekey,
			'email' => $email,
			'proxyUrl' => $proxyUrl,
			'errors' => $errors,
		]);
	}
}
