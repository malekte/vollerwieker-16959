<?php

namespace App\Controller;

use App\Exception\ConfigNotWritableException;
use App\Exception\CsrfTokenException;
use App\Model\CsrfToken;
use App\Model\Domain;
use App\Model\Purpose;
use App\Model\User;
use App\Model\Cookie as CookieModel;
use App\Model\Locale as Locale;
use App\Utils;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;

/**
 * Controller zur Cookie-Verwaltung
 *
 * @Route("/domains/{_domainId}/cookies", name="app_cookies_")
 */
class Cookie extends DomainDependantController
{
	/**
	 * @Route("", name="list")
	 *
	 * @throws \Exception Wenn kein Zugriff auf das Cookie-File erfolgen kann
	 *
	 * @return Response
	 */
	public function listCookies(): Response
	{
		Utils::getSession()->save();

		$cookies = CookieModel::all();
		$purposes = Purpose::all();

		return $this->render('cookie/list.html.twig', [
			'cookies' => $cookies,
			'purposes' => $purposes,
		]);

	}

	/**
	 * Daten aus dem Array $cookieData in $cookie übertragen
	 */
	private function applyChanges(CookieModel $cookie, array $cookieData, string $defaultLocaleId): CookieModel
	{
		// Script-Blocking
		$codeBlock = explode("\n", trim((string)($cookieData['code_block'] ?? '')));
		$codeBlock = array_filter($codeBlock, function ($line) {
			return trim($line) !== '';
		});
		$codeBlock = array_values(array_map(function ($line) {
			return trim($line);
		}, $codeBlock));
		// Zweck
		$purpose = Purpose::find($cookieData['purpose']);

		// Allgemeines speichern
		$cookie
			->setName($cookieData['name'] ?? '')
			->setDescription($cookieData['description'][$defaultLocaleId] ?? '')
			->setCodeSnippet($cookieData['code_snippet'] ?? '')
			->setCodeBlock($codeBlock)
			->setCookieVendor($cookieData['cookie_vendor'] ?? '')
			->setPrivacyPolicyUrl($cookieData['privacy_policy_url'][$defaultLocaleId] ?? '')
			->setHttpCookieName($cookieData['http_cookie_name'] ?? '')
			->setLifetime($cookieData['lifetime'][$defaultLocaleId] ?? '')
			->setCollectedDataInfo($cookieData['collected_data_info'][$defaultLocaleId] ?? '')
			->setPurposeOfDataCollection($cookieData['purpose_of_data_collection'][$defaultLocaleId] ?? '')
			->setLegalBasis($cookieData['legal_basis'][$defaultLocaleId] ?? '')
			->setPlaceOfProcessing($cookieData['place_of_processing'][$defaultLocaleId] ?? '')
			->setActive($cookieData['active'] ?? false)
			->setPurpose($purpose)
		;

		// Übersetzungen speichern
		foreach (Locale::enabledLocales() as $locale) {
			$localeId = $locale->getId();
			if (!isset($cookieData['description'][$localeId])) {
				continue; // Wenn description in der Sprache komplett fehlt, ist die Sprache wohl nicht dabei
			}
			$cookie
				->setTranslatedDescription($locale, $cookieData['description'][$localeId] ?? '')
				->setTranslatedPrivacyPolicyUrl($locale, $cookieData['privacy_policy_url'][$localeId] ?? '')
				->setTranslatedLifetime($locale, $cookieData['lifetime'][$localeId] ?? '')
				->setTranslatedCollectedDataInfo($locale, $cookieData['collected_data_info'][$localeId] ?? '')
				->setTranslatedPurposeOfDataCollection($locale, $cookieData['purpose_of_data_collection'][$localeId] ?? '')
				->setTranslatedLegalBasis($locale, $cookieData['legal_basis'][$localeId] ?? '')
				->setTranslatedPlaceOfProcessing($locale, $cookieData['place_of_processing'][$localeId] ?? '')
			;
		}

		return $cookie;
	}

	/**
	 * @Route("/new", name="new")
	 *
	 * @param Request $request
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function createCookie(Request $request, TranslatorInterface $translator): Response
	{
		$csrfToken = CsrfToken::get();
		$cookieData = [];
		$purposes = Purpose::all();
		$defaultLocale = Locale::getDefault();
		$defaultLocaleId = $defaultLocale->getId();

		if ($request->getRealMethod() === 'GET') {

			//sanitized Name holen
			$cookieData['name']=CookieModel::getNameFromGet($_GET['cookiename'] ?? '');

			//check ob es Daten dazu gibt...
			$remoteDataMIX = CookieModel::getCookeDBInformation($cookieData['name']);

			if (!empty($remoteDataMIX['cookie_daten']['de']))
			{
				$cookieData['hinweis']="hinweis_remote";
			}

			//Deutsch
			if (!empty($remoteDataMIX['cookie_daten']['de']))
			{
				$remoteData = $remoteDataMIX['cookie_daten']['de'][0];
			} else {
				$remoteData = [];
			}

			//die versch. Purposes
			$remotePurposes = [
				1 => Purpose::findByName('Technisch notwendig'),
				2 => Purpose::findByName('Anzeigen / Ads'),
				3 => Purpose::findByName('Analyse'),
				4 => Purpose::findByName('Personalisierung'),
				5 => Purpose::findByName('Statistik'),
				6 => Purpose::findByName('Sonstiges')
			];

			if (empty($remoteData['Zweck_2']))
			{
				$remoteData['Zweck_2'] = 0;
			}

			//wenn remote Daten vorhanden - diese einbauen...
			if (!empty($remoteData['NamedesCookiesimBrowser_7']))
			{
				$cookieData['purpose'] = $remotePurposes[$remoteData['Zweck_2']] ?? null;
				$cookieData['http_cookie_name'] = $remoteData['NamedesCookiesimBrowser_7'] ?? '';
				$cookieData['cookie_vendor'] = $remoteData['AnbieterdesCookies_4'] ?? '';
			}
			else {
				$cookieData['purpose'] = $remotePurposes[$remoteData['Zweck_2']] ?? null;
			}

			//Sprachdaten DE
			if (!empty($remoteData['NamedesCookiesimBrowser_7'])) {
				$cookieData['description'][$defaultLocaleId] = $remoteData['BeschreibungdesCookies_5'] . "  " . $remoteData['Hinweis_15'];
				$cookieData['privacy_policy_url'][$defaultLocaleId] = $remoteData['DatenschutzLinkfrdasCookie_6'] ?? '';
				$cookieData['lifetime'][$defaultLocaleId] = $remoteData['LebensdauerdesCookies_8'] ?? '';
				$cookieData['collected_data_info'][$defaultLocaleId] = $remoteData['WelcheDatenwerdengesammelt_9'] ?? '';
				$cookieData['purpose_of_data_collection'][$defaultLocaleId] = $remoteData['ZuwelchemZweckwerdendieDatengesammelt_10'] ?? '';
				$cookieData['legal_basis'][$defaultLocaleId] = $remoteData['RechtlicheGrundlage_11'] ?? '';
				$cookieData['place_of_processing'][$defaultLocaleId] = $remoteData['OrtderVerarbeitung_12'] ?? '';
			}

			//Sprachdaten EN
			if (!empty($remoteDataMIX['cookie_daten']['en'])) {
				$remoteData = $remoteDataMIX['cookie_daten']['en'][0];
			}
			foreach (Locale::all() as $locale) {
				$localeId = $locale->getId();
			}

			if (!empty($remoteData['NamedesCookiesimBrowser_23'])) {
				$cookieData['description'][$localeId] = $remoteData['BeschreibungdesCookies_21'] . "  " . $remoteData['Hinweis_29'];
				$cookieData['privacy_policy_url'][$localeId] = $remoteData['DatenschutzLinkfrdasCookie_22'] ?? '';
				$cookieData['lifetime'][$localeId] = $remoteData['LebensdauerdesCookies_24'] ?? '';
				$cookieData['collected_data_info'][$localeId] = $remoteData['WelcheDatenwerdengesammelt_25'] ?? '';
				$cookieData['purpose_of_data_collection'][$localeId] = $remoteData['ZuwelchemZweckwerdendieDatengesammelt_26'] ?? '';
				$cookieData['legal_basis'][$localeId] = $remoteData['RechtlicheGrundlage_27'] ?? '';
				$cookieData['place_of_processing'][$localeId] = $remoteData['OrtderVerarbeitung_28'] ?? '';
			}
		}

		if ($request->getRealMethod() === 'POST') {
			try {
				$csrfToken->checkRequest($request);
				// Cookie-Daten holen und aufbereiten
				$cookieData = $request->request->all();
				unset($cookieData['action']);

				$formData = $request->request->all();

				// ohne Namen nicht speichern
				if (trim($cookieData['name']) === '') {
					$this->addFlash('warning', 'Ein Cookie kann nicht ohne Namen gespeichert werden');
					return $this->render('cookie/new.html.twig', [
						'formData' => ['name' => '',] + $formData,
						'purposes' => $purposes,
						'locales' => Locale::enabledLocales(),
						'csrfToken' => $csrfToken,
					]);
				}

				// ohne Verwendungszweck nicht speichern
				if (Purpose::exists($cookieData['purpose']) == false) {
					$this->addFlash('warning', 'Ein Cookie kann nicht ohne Verwendungszweck gespeichert werden');
					return $this->render('cookie/new.html.twig', [
						'formData' => ['purpose' => '',] + $formData,
						'purposes' => $purposes,
						'locales' => Locale::enabledLocales(),
						'csrfToken' => $csrfToken,
					]);
				}

				// Speichern
				$cookie = $this->applyChanges(CookieModel::create(), $cookieData, $defaultLocaleId);
				$cookie->save();

				$this->addFlash('success', 'Das Cookie "' . $cookieData['name'] . '" wurde erfolgreich erstellt!');
				Utils::getSession()->save();

				return $this->redirectToRoute('app_cookies_list');
			}
			catch (CsrfTokenException $e) {
				$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			}
		}

		Utils::getSession()->save();

		return $this->render('cookie/new.html.twig', [
			'purposes' => $purposes,
			'locales' => Locale::enabledLocales(),
			'csrfToken' => $csrfToken,
			'formData' => $cookieData ?? [],
		]);
	}

	/**
	 * @Route("/{id}/edit", methods={"HEAD", "GET"}, name="edit")
	 *
	 * @param string $id
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function editCookie(string $id, Request $request): Response
	{
		if (CookieModel::exists($id) == false) {
			return $this->redirectToRoute('app_cookies_list');
		}

		$cookie = CookieModel::find($id);

		$purposes = Purpose::all();

		return $this->render('cookie/edit.html.twig', [
			'cookie' => $cookie,
			'purposes' => $purposes,
			'locales' => Locale::enabledLocales(),
			'csrfToken' => CsrfToken::get(),
		]);
	}

	/**
	 * @Route("/{id}/edit", methods={"POST"}, name="edit_post")
	 *
	 * @param string $id
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function editCookiePost(string $id, Request $request, TranslatorInterface $translator): Response
	{
		CookieModel::beginWrite();
		if (CookieModel::exists($id) == false) {
			return $this->redirectToRoute('app_cookies_list');
		}

		$defaultLocale = Locale::getDefault();
		$defaultLocaleId = $defaultLocale->getId();
		$cookie = CookieModel::find($id);

		try {
			CsrfToken::get()->checkRequest($request);

			// Cookie-Daten holen und aufbereiten
			$cookieData = $request->request->all();

			// ohne Verwendungszweck nicht speichern
			if (Purpose::exists($cookieData['purpose']) == false) {
				$this->addFlash('warning', 'Ein Cookie kann nicht ohne Verwendungszweck gespeichert werden');
				return $this->redirectToRoute('app_cookies_edit', ['id' => $cookie->getId()]);
			}

			$purpose = Purpose::find($cookieData['purpose']);

			// Script-Blocking
			$codeBlock = explode("\n", trim((string)($cookieData['code_block'] ?? '')));
			$codeBlock = array_filter($codeBlock, function ($line) {
				return trim($line) !== '';
			});
			$codeBlock = array_values(array_map(function ($line) {
				return trim($line);
			}, $codeBlock));

			// ohne Namen nicht speichern
			if (trim($cookieData['name']) === '') {
				$this->addFlash('warning', 'Ein Cookie kann nicht ohne Namen gespeichert werden');
				return $this->redirectToRoute('app_cookies_edit', ['id' => $cookie->getId()]);
			}

			// Speichern
			$cookie = $this->applyChanges($cookie, $cookieData, $defaultLocaleId);
			$cookie->save();

			$this->addFlash('success', 'Das Cookie "' . $cookieData['name'] . '" wurde erfolgreich bearbeitet!');
		}
		catch (CsrfTokenException $e) {
			$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
		}

		return $this->redirectToRoute('app_cookies_list');
	}

	/**
	 * @Route("/{id}/delete", name="delete")
	 * @return Response
	 * @throws ConfigNotWritableException
	 */
	public function deleteCookie(string $id, Request $request, TranslatorInterface $translator): Response
	{
		CookieModel::beginWrite();
		if (CookieModel::exists($id) == false) {
			return $this->redirectToRoute('app_cookies_list');
		}

		$cookie = CookieModel::find($id);
		$cookieName = $cookie->getName();

		if ($request->getRealMethod() === 'POST') {
			try {
				CsrfToken::get()->checkRequest($request);
				CookieModel::delete($id);
				$this->addFlash('success', 'Das Cookie "' . $cookieName . '" wurde erfolgreich gelöscht!');
				return $this->redirectToRoute('app_cookies_list');
			}
			catch (CsrfTokenException $e) {
				$this->addFlash('danger', $translator->trans('CSRF token is missing or invalid. Please try again.'));
			}
		}

		return $this->render('cookie/delete.html.twig', [
			'user' => User::loggedInUser(),
			'cookie' => $cookie,
			'csrfToken' => CsrfToken::get(),
		]);
	}
}
