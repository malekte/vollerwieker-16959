<?php

namespace App\Controller;

use App\Component\Ccm19LicensingApiClient;
use App\Component\LoggerInterface;
use App\Config;
use App\Exception\UserIsBlockedException;
use App\Exception\UserIsDeactivatedException;
use App\Exception\CsrfTokenException;
use App\MailMessage;
use App\Model\CsrfToken;
use App\Model\User;
use App\Utils;
use DateTime;
use Exception;
use RuntimeException;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use Swift_Mailer;

class Login extends AbstractController
{
	/**
	 * Diese Methode bildet den Einstiegspunkt der Loginroutine.
	 *
	 * @Route("/login", methods={"HEAD","GET"}, name="app_login")
	 */
	public function loginPage(Request $request): Response
	{
		if (User::count() == 0) {
			return $this->redirectToRoute('app_setup', [], 303);
		}
		else if (User::loggedInUser()) {
			return $this->redirectAfterLogin($request);
		}

		list($route, $parameters) = $this->parseReturnTo($request->query->get('backTo', ''));

		$response = $this->render('login/index.html.twig', [
			'error' => null,
			'username' => $request->query->get('username', null),
			'backToRoute' => $route,
			'backToArgs' => json_encode($parameters),
		]);

		return $response;
	}

	/**
	 * Parsen eines eventuellen 'returnTo'-Parameters
	 *
	 * @param string|null $string
	 * @return array [$route, $parameters]
	 */
	private function parseReturnTo($string): array
	{
		$route = 'app_root';
		$parameters = null;

		// Sicherheitscheck
		if (!$string or !is_string($string)) {
			return [$route, $parameters];
		}

		// String dekodieren und bei falschem Format abbrechen
		$routeinfo = @json_decode(base64_decode(strtr($string, ['-'=>'+', '_'=>'/'])), true, 5);
		if (!is_array($routeinfo) or count($routeinfo) !== 2) {
			return [$route, $parameters];
		}

		// Route und Parameter bestimmen
		list($route, $parameters) = $routeinfo;

		// Weiterer Sicherheitscheck
		if (!$route or !is_string($route) or !is_array($parameters)) {
			return ['app_root', []];
		}

		return [$route, $parameters];
	}

	/**
	 * Weiterleiten zur in GET/POST gespeicherten Route, ansonsten zum Dashboard
	 *
	 * @param Request $request
	 * @return RedirectResponse
	 */
	private function redirectAfterLogin(Request $request): RedirectResponse
	{
		//self::$IS_LOGIN = true;

		// Routen-Parameter bestimmen
		if ($request->request->has('backToRoute')) {
			$route = $request->request->get('backToRoute', 'app_root');
			$parameters = json_decode($request->request->get('backToArgs', '[]'), true, 5);
		} else {
			list($route, $parameters) = $this->parseReturnTo($request->query->get('backTo', ''));
		}
		if (!$route) {
			$route = 'app_root';
			$parameters = [];
		}
		if (!is_array($parameters)) {
			$route = 'app_root';
			$parameters = [];
		}

		// Redirect zurück
		try {
			return $this->redirectToRoute(
				$route,
				$parameters,
				303
			);
		} catch (\Throwable $e) {
			return $this->redirectToRoute('app_root', [], 303);
		}
	}

	/**
	 * Aktualisiert den Lizenzstatus.
	 *
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return void
	 */
	private function licenseCheck(Request $request, LoggerInterface $logger, TranslatorInterface $translator): void
	{
		$api = new Ccm19LicensingApiClient();
		$api->registerLicense(Utils::getLicenseKey(), $request->getHttpHost());
		$config = Config::getInstance();

		if ($api->isSuccess()) {
			$mayWhitelabel = $api->hasWhitelabel();
			$currentWhitelabel = $config->get('whitelabel');
			if ($currentWhitelabel != $mayWhitelabel) {
				Config::getInstance()->set('whitelabel', $mayWhitelabel);
				$logger->logInfo('LicenseCheck', ($mayWhitelabel) ? 'Whitelabel license unlocked' : 'Whitelabel license revoked');
			}
		}
		else {
			$logger->logWarning('LicenseCheck', 'Error while checking license: '.$api->getErrorMessage());
			$this->addFlash('warning', $translator->trans($api->getErrorMessage()));
		}
	}

	/**
	 * Diese Methode bildet den Einstiegspunkt der Loginroutine.
	 *
	 * @Route("/login", methods={"POST"}, name="app_login_post")
	 * @param Request $request
	 * @param TranslatorInterface $translator
	 * @return Response
	 */
	public function loginAction(Request $request, LoggerInterface $logger, TranslatorInterface $translator): Response
	{
		$response = new Response();
		$error = null;

		// Wenn das Formular abgeschickt wurde, Daten prüfen und ggf. Benutzer einloggen
		$username = trim($request->request->get('username'));
		$password = trim($request->request->get('password'));

		try {
			$user = User::login($username, $password);
			if ($user) {
				if ($user->getRole() == User::ROLE_ADMIN) {
					$this->licenseCheck($request, $logger, $translator);
				}
				$logger->logInfo("Login","Successful login by user: ".$username);
				return $this->redirectAfterLogin($request);
			}
			else {
				$response->setStatusCode(401);
				$error = $translator->trans('Please check your credentials.');
				$logger->logError("Login", 'Failed login due to wrong credentials for user '.$username);
			}
		}

		catch (UserIsDeactivatedException $exception) {
			$error = $translator->trans('User is deactivated from logging into the system.');
			$logger->logError("Login", 'Failed login due to deactivation for user '.$username);
			$response->setStatusCode(401);
		}

		catch (UserIsBlockedException $exception) {
			$response->setStatusCode(401);
			$error = $translator->trans('Your account is blocked for the next %n% minutes.', [
				'%n%' => (int)ceil(User::LOGIN_BLOCKED_DURATION / 60),
			]);
			$logger->logError("Login", 'Failed login due to too many tries for user '.$username);
		}


		return $this->render('login/index.html.twig', [
			'error' => $error,
			'username' => $username,
			'backToRoute' => $request->request->get('backToRoute', 'app_root'),
			'backToArgs' => $request->request->get('backToArgs', ''),
		], $response);
	}

	/**
	 * Über diesen Endpunkt kann nach einem Benutzerwechsel zum ursprünglichen Benutzer
	 * zurückgesprungen werden.
	 *
	 * @Route("/login/switchBack", methods={"POST"}, name="app_login_switch_back")
	 * @param Request $request
	 * @return Response
	 */
	public function switchBackAction(Request $request): Response
	{
		$user = User::originalLoggedInUser();
		if ($user) {
			$user->switchTo();
			$response = $this->redirectToRoute('app_hosting_client_index', [], 303);
		}
		else {
			$response = $this->redirectToRoute('app_login', [], 303);
		}
		$response->headers->set('Clear-Site-Data', '"cache"');
		return $response;
	}

	/**
	 * Diese Methode loggt den Benutzer aus und leitet zur Loginmaske weiter.
	 *
	 * @Route("/logout", methods={"HEAD","GET"}, name="app_logout")
	 */
	public function logoutPage(): Response
	{
		return $this->render('login/logout.html.twig', []);
	}
	
	/**
	 * Diese Methode loggt den Benutzer aus und leitet zur Loginmaske weiter.
	 *
	 * @Route("/logout", methods={"POST"}, name="app_logout_post")
	 */
	public function logoutAction(): RedirectResponse
	{
		User::logout();
		return $this->redirectToRoute('app_login', [], 303);
	}

	/**
	 * Diese Methode gibt zurück, ob und als wer der User eingeloggt ist
	 *
	 * @Route("/login/check", methods={"HEAD","GET"}, name="app_login_check")
	 */
	public function loginCheckAction(): JsonResponse
	{
		$user = User::loggedInUser();
		$origUser = User::originalLoggedInUser();

		$session = Utils::getSession();
		$session->save();

		$data = [
			'auth' => ($user !== null),
		];

		if ($user) {
			$data['user'] = $user->getUsername();
		}
		if ($origUser) {
			$data['origUser'] = $origUser->getUsername();
		}

		return $this->json($data, 200);
	}

	/**
	 * Passwort-Recovery: 1. Schritt - Formular
	 *
	 * @Route("/login/forgot_password",  methods={"HEAD","GET"}, name="app_login_forgot_password")
	 */
	public function forgotPasswordPage(Request $request, ?TranslatorInterface $translator=null): Response
	{
		return $this->render('login/forgot_password.html.twig', [
			'csrfToken' => CsrfToken::get(),
			'username' => $request->query->get('username', null)
		]);
	}

	/**
	 * Passwort-Recovery: 1. Schritt - Formular absenden, E-Mail verschicken
	 *
	 * @Route("/login/forgot_password",  methods={"POST"}, name="app_login_forgot_password_post")
	 */
	public function forgotPasswordAction(Request $request, Swift_Mailer $mailer, ?TranslatorInterface $translator=null): Response
	{
		usleep(500000);
		$response = new Response();
		$username = trim($request->request->get('username', ''));
		$email = trim(strtolower($request->request->get('email', '')));
		$error = null;
		try {
			CsrfToken::get()->checkRequest($request);
		}
		catch (CsrfTokenException $e) {
			$error = $translator->trans('CSRF token is missing or invalid. Please try again.');
			return $this->render('login/forgot_password.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'error' => $error,
				'username' => $username,
			], $response);
		}

		$user = User::find($username);

		if (!$user or strtolower($user->getEmailAddress()) != $email)
		{
			$error = $translator->trans('Wrong user name or wrong email address entered.');
			return $this->render('login/forgot_password.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'error' => $error,
				'username' => $username,
			], $response);
		}

		if ($user->isBlocked()) {
			$error = $translator->trans('Your account is blocked for the next %n% minutes.', [
				'%n%' => (int)ceil(User::LOGIN_BLOCKED_DURATION / 60),
			]);
			return $this->render('login/forgot_password.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'error' => $error,
				'username' => $username,
			], $response);
		}

		$timediff = (new Datetime('now'))->getTimestamp() - $user->getPasswordRecoveryTime()->getTimestamp();
		if ($timediff < 300) {
			$error = $translator->trans('You already requested a password recovery in the last five minutes.');
			return $this->render('login/forgot_password.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'error' => $error,
				'username' => $username,
			], $response);
		}

		$token = bin2hex(random_bytes(20));
		$user->setPasswordRecoveryKey($token);

		$message = (new MailMessage($translator->trans('CCM19 Account recovery')))
		->setTo($user->getEmailAddress())
		->setBody($this->renderView(
				'emails/password_recovery.txt.twig',
				['user' => $user, 'token' => $token]
			), 'text/plain');

		try {
			$mailer->send($message);
		} catch (Exception $e) {
			return $this->render('login/forgot_password.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'error' => $translator->trans('Email delivery failed. Please contact an administrator.'),
				'username' => $username,
				'email' => $email,
			], $response);
		}

		$user->save();

		return $this->render('login/forgot_password.html.twig', [
			'csrfToken' => CsrfToken::get(),
			'success' => $translator->trans('In a few minutes you should receive an email with further instructions to reset your account.'),
			'username' => $username,
		], $response);
	}

	/**
	 * Passwort-Recovery: 2. Schritt - Passwort ändern
	 *
	 * @Route("/login/recover",  methods={"HEAD","GET", "POST"}, name="app_login_recover")
	 */
	public function recoverPasswordAction(Request $request, LoggerInterface $logger, TranslatorInterface $translator): Response
	{
		$response = new Response();
		$now = new DateTime('now');
		usleep(500000);
		User::beginWrite();
		$user = User::find($request->query->get('u', ''));
		if ($user) {
			$token = $user->getPasswordRecoveryKey();
			$time = $user->getPasswordRecoveryTime();
		}
		else {
			$token = null;
			$time = null;
		}

		// Token und Zeitraum prüfen
		if ($token === '' or $token === null or $now->getTimestamp() - $time->getTimestamp() > 86400 or !hash_equals($token, $request->query->get('t'))) {
			return $this->redirectToRoute('app_login', [], 303);
		}

		if ($request->getRealMethod() !== 'POST') {
			// Bei GET: Formular anzeigen
			return $this->render('login/recover.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'username' => $user->getUsername(),
				'token' => $request->query->get('t'),
			]);
		}

		$password = $request->request->get('password');
		$password2 = $request->request->get('password2');

		if (!hash_equals($password, $password2)) {
			return $this->render('login/recover.html.twig', [
				'csrfToken' => CsrfToken::get(),
				'error' => $translator->trans('The passwords did not match!'),
				'username' => $user->getUsername(),
				'token' => $request->query->get('t'),
			]);
		}

		$user->setPassword($password);
		$user->setPasswordRecoveryKey(null);
		$user->save();

		try {
			$user = User::login($user->getUsername(), $password);
			if ($user) {
				if ($user->getRole() == User::ROLE_ADMIN) {
					$this->licenseCheck($request, $logger, $translator);
				}
				return $this->redirectToRoute('app_root', [], 303);
			}
			else {
				$error = $translator->trans('Please check your credentials.');
				$response->setStatusCode(401);
			}
		}
		catch (UserIsBlockedException $exception) {
			$error = $translator->trans('Your account is blocked for the next %n% minutes.', [
				'%n%' => (int)ceil(User::LOGIN_BLOCKED_DURATION / 60),
			]);
			$response->setStatusCode(401);
		}

		catch (UserIsDeactivatedException $exception) {
			$error = $translator->trans('User is deactivated from logging into the system.');
			$response->setStatusCode(401);
		}

		return $this->render('login/index.html.twig', [
			'csrfToken' => CsrfToken::get(),
			'error' => $error,
			'username' => ($user ? $user->getUsername() : null)
		], $response);
	}

}
