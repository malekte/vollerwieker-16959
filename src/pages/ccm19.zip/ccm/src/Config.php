<?php

namespace App;

use App\Exception\ConfigNotWritableException;

class Config
{
	const CONFIG_FILENAME = 'cm-config.json';

	/** @var self|null $instance */
	private static $instance = null;

	/** @var JsonConfig $config */
	private $config;

	private function __construct()
	{
		$this->config = new JsonConfig(self::CONFIG_FILENAME);
	}

	/**
	 * Diese Methode gibt die Instanz der Klasse Config zurück, die nach dem Singleton-Pattern erzeugt wird.
	 * @return self
	 */
	public static function getInstance(): self
	{
		if (self::$instance === null) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	/**
	 * Diese Methode liest Daten aus der Konfiguration. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $fallback
	 * @return mixed
	 */
	public function get(string $identifier, $fallback = null)
	{
		return $this->config->get($identifier, $fallback);
	}

	/**
	 * Diese Methode schreibt Daten in die Konfiguration. Schlüssel werden im $identifier durch einen Punkt separiert.
	 * @param string $identifier
	 * @param mixed $data
	 * @return $this
	 */
	public function set(string $identifier, $data): self
	{
		$this->config->set($identifier, $data);
		return $this;
	}

	/**
	 * @param string $identifier
	 */
	public function unset(string $identifier): void
	{
		$this->config->unset($identifier);
	}

	/**
	 * Diese Methode schreibt alle an der Konfiguration vorgenommenen Änderungen auf die Platte.
	 * @throws ConfigNotWritableException
	 */
	public function flush(): void
	{
		$this->config->flush();
	}

	/**
	 * Diese Methode liest die Konfiguration erneut von der Festplatte ein. Sämtliche Änderungen gehen verloren.
	 */
	public function reload(): void
	{
		$this->config->reload();
	}

	/**
	 * Sperrt die Konfiguration zum Schreiben.
	 *
	 * Danach kann bis zu flush() oder reload() kein parallel laufender
	 * Prozess auf die Datei zugreifen.
	 */
	public function beginWrite(): void
	{
		$this->config->beginWrite();
	}

	/**
	 * @return bool
	 */
	public function isForceHttpsConnection(): bool
	{
		return (bool)$this->get('forceHttpsConnection', false);
	}

	/**
	 * @param bool $state
	 * @return $this
	 */
	public function setForceHttpsConnection(bool $state): self
	{
		$this->set('forceHttpsConnection', $state);
		return $this;
	}


	/**
	 * Maximale Generation, auf die bei Updates derzeit gesprungen werden kann.
	 */
	public function getMaximumGeneration(): int
	{
		return (int)$this->get('maxGeneration', 1);
	}

	/**
	 * @param int $generationNumber
	 * @return $this
	 */
	public function setMaximumGeneration(int $generationNumber): self
	{
		$this->set('maxGeneration', $generationNumber);
		return $this;
	}

	/**
	 * @param int $generationNumber
	 * @return $this
	 */
	public function raiseMaximumGeneration(int $generationNumber): self
	{
		$this->beginWrite();
		$generationNumber = max($this->getMaximumGeneration(), Utils::getVersionGeneration(), $generationNumber);
		$this->set('maxGeneration', $generationNumber);
		return $this;
	}
}
