<?php

function http_redirect($url = "", $code = 307)
{
	$https = !empty($_SERVER['HTTPS']);

	$i = strpos($url, '://');
	if ($i !== false and $i < 8) {
		$fullurl = $url;
	}
	else if ($url[0] == '/') {
		$fullurl = ($https ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $url;
	}
	else {
		$fullurl =
			($https ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/')
			. '/' . $url;
	}

	http_response_code($code);
	header("Location: " . $fullurl);
	echo '<html><body><a href="' . htmlspecialchars($fullurl) . '">Continue&hellip;</a></body></html>';
	exit();
}

http_redirect('./public/');
